# AI-Powered Bulk Menu Import

## Overview

Restaurant admins can upload multiple menu images, PDFs, CSV/Excel, or JSON files. The system extracts items via a pluggable extraction provider, runs category/food-type/variant/add-on detection, flags duplicates and low-confidence rows, and **never** writes to the live menu until the admin reviews and commits.

## Workflow

1. **Upload** — `POST /api/menu-import/upload` (multipart)
2. **Process** — `POST /api/menu-import/:id/process` (OCR/AI + normalization)
3. **Preview** — `GET /api/menu-import/:id/preview?filter=`
4. **Edit item** — `PATCH /api/menu-import/:id/items/:itemId`
5. **Bulk edit** — `POST /api/menu-import/:id/bulk`
6. **Commit** — `POST /api/menu-import/:id/commit`
7. **History** — `GET /api/menu-import/history`

## Security & multi-tenancy

- All routes require `owner` or `manager` via `requireTenant`
- Session restaurant ID is the only scope; client-supplied restaurant IDs are ignored
- File type + size validated on the server (images ≤15MB, PDF ≤50MB, tabular ≤20MB)
- MIME + extension checks; path-safe storage keys under `menu-import/{restaurantId}/…`
- CSRF exempt only for the multipart upload path (same pattern as logo upload)

## Extraction providers

See `src/lib/server/menu-import/extraction-provider.ts`.

- **HeuristicExtractionProvider** (default): JSON, CSV, plain-text heuristics; images/PDFs produce low-confidence filename-based placeholders unless a vision provider is registered.
- Register real providers with `registerExtractionProvider()` (OpenAI Vision, Google Document AI, Tesseract, etc.).

Production recommendation: implement an `OpenAIVisionProvider` that:

1. Sends images/PDF pages to a vision model with a structured JSON schema prompt
2. Parses name, description, price, category, food type, Jain options, variants, add-ons
3. Returns confidence scores per field

## Database

New table `menu_import_sessions` (see `drizzle/0001_menu_import_sessions.sql`). Apply with:

```bash
npm run db:migrate
# or
psql $DATABASE_URL -f drizzle/0001_menu_import_sessions.sql
```

## Frontend

`/menu/bulk-import` — multi-step wizard (upload → processing → editable preview table → result).

Linked from the main Menu page via **Bulk Import**.

## Design principles enforced

- Accuracy → Human Review → Validation → Security → Tenant Isolation → DB Integrity
- No blind insert of AI/OCR data into production menu tables
- Duplicate detection with skip/create choices at commit time
- Categories reused by normalized name match

## Groq vision (images)

### Configuration (secure)

1. **Environment (ops override, highest priority)**  
   ```bash
   GROQ_API_KEY=gsk_...
   GROQ_VISION_MODEL=qwen/qwen3.6-27b   # optional
   SECRETS_ENCRYPTION_KEY=long-random-string  # optional; falls back to AUTH_SECRET
   ```

2. **Database (encrypted at rest)**  
   Super-admin APIs:
   - `GET  /api/platform/ai-config` — status + masked hint (never full key)
   - `PUT  /api/platform/ai-config` — body: `{ "groqApiKey": "gsk_...", "groqVisionModel": "...", "groqEnabled": true }`
   - `DELETE /api/platform/ai-config` — clear stored key

   Keys are stored in the `singletons` table under `platform:ai_config` as AES-256-GCM ciphertext. The API never returns the plaintext token.

3. **Restaurant visibility**  
   - `GET /api/settings/ai-status` — owners/managers see whether extraction is available (boolean + model name only).

### Behaviour

- Image uploads (JPG/PNG/WebP) use **Groq vision** when a key is configured and `groqEnabled` is true.
- If Groq fails or is not configured, the pipeline falls back to the heuristic provider.
- PDFs are not accepted by Groq vision models as binary PDFs — convert pages to images first (or use CSV/JSON).
- Extracted rows still go through **review → commit**; nothing is written to the live menu without admin approval.

### Example: save key as super_admin

```bash
curl -X PUT "$API/api/platform/ai-config" \
  -H "Authorization: Bearer $SUPER_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"groqApiKey":"gsk_your_token","groqVisionModel":"qwen/qwen3.6-27b","groqEnabled":true}'
```
