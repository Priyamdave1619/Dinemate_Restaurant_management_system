-- Neon PostgreSQL schema for Sevusal multi-tenant SaaS
-- Apply: psql "$DATABASE_URL" -f drizzle/0000_init.sql
-- Or: npm run db:push

CREATE TABLE IF NOT EXISTS restaurants (
  id TEXT PRIMARY KEY, data JSONB NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
  plan_id TEXT, subscription_expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS restaurants_status_idx ON restaurants (status);
CREATE INDEX IF NOT EXISTS restaurants_plan_idx ON restaurants (plan_id);

CREATE TABLE IF NOT EXISTS subscription_plans (
  id TEXT PRIMARY KEY, data JSONB NOT NULL, active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, restaurant_id TEXT, username TEXT NOT NULL, data JSONB NOT NULL,
  role TEXT NOT NULL, active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS users_username_uidx ON users (username);
CREATE INDEX IF NOT EXISTS users_restaurant_idx ON users (restaurant_id);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY, restaurant_id TEXT, data JSONB NOT NULL, action TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS audit_logs_restaurant_idx ON audit_logs (restaurant_id);

CREATE TABLE IF NOT EXISTS login_history (
  id TEXT PRIMARY KEY, restaurant_id TEXT, user_id TEXT, data JSONB NOT NULL,
  success BOOLEAN NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS login_history_restaurant_idx ON login_history (restaurant_id);

CREATE TABLE IF NOT EXISTS refresh_tokens (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL, token_hash TEXT NOT NULL, data JSONB NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL, revoked_at TIMESTAMPTZ, replaced_by_token_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS refresh_tokens_hash_uidx ON refresh_tokens (token_hash);
CREATE INDEX IF NOT EXISTS refresh_tokens_user_idx ON refresh_tokens (user_id);

CREATE TABLE IF NOT EXISTS counters (key TEXT PRIMARY KEY, value INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS singletons (key TEXT PRIMARY KEY, data JSONB NOT NULL);

CREATE TABLE IF NOT EXISTS categories (
  id TEXT NOT NULL, restaurant_id TEXT NOT NULL, data JSONB NOT NULL, PRIMARY KEY (restaurant_id, id)
);
CREATE TABLE IF NOT EXISTS menu_items (
  id TEXT NOT NULL, restaurant_id TEXT NOT NULL, category_id TEXT, data JSONB NOT NULL, PRIMARY KEY (restaurant_id, id)
);
CREATE TABLE IF NOT EXISTS tables (
  id TEXT NOT NULL, restaurant_id TEXT NOT NULL, number INTEGER NOT NULL, data JSONB NOT NULL, PRIMARY KEY (restaurant_id, id)
);
CREATE UNIQUE INDEX IF NOT EXISTS tables_restaurant_number_uidx ON tables (restaurant_id, number);
CREATE TABLE IF NOT EXISTS offers (
  id TEXT NOT NULL, restaurant_id TEXT NOT NULL, data JSONB NOT NULL, PRIMARY KEY (restaurant_id, id)
);
CREATE TABLE IF NOT EXISTS orders (
  id TEXT NOT NULL, restaurant_id TEXT NOT NULL, status TEXT NOT NULL, table_number INTEGER,
  bill_generated BOOLEAN NOT NULL DEFAULT FALSE, placed_at TIMESTAMPTZ, data JSONB NOT NULL,
  PRIMARY KEY (restaurant_id, id)
);
CREATE TABLE IF NOT EXISTS billed_orders (
  id TEXT NOT NULL, restaurant_id TEXT NOT NULL, placed_at TIMESTAMPTZ, data JSONB NOT NULL,
  PRIMARY KEY (restaurant_id, id)
);
CREATE TABLE IF NOT EXISTS sold_items (
  id TEXT NOT NULL, restaurant_id TEXT NOT NULL, order_id TEXT, item_id TEXT,
  date_key TEXT, month_key TEXT, data JSONB NOT NULL, PRIMARY KEY (restaurant_id, id)
);
CREATE TABLE IF NOT EXISTS expenses (
  id TEXT NOT NULL, restaurant_id TEXT NOT NULL, month_key TEXT, year_key TEXT,
  date TIMESTAMPTZ, data JSONB NOT NULL, PRIMARY KEY (restaurant_id, id)
);
CREATE TABLE IF NOT EXISTS notifications (
  id TEXT NOT NULL, restaurant_id TEXT NOT NULL, data JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), PRIMARY KEY (restaurant_id, id)
);
CREATE TABLE IF NOT EXISTS daily_stats (
  restaurant_id TEXT NOT NULL, date_key TEXT NOT NULL, data JSONB NOT NULL, PRIMARY KEY (restaurant_id, date_key)
);
CREATE TABLE IF NOT EXISTS monthly_stats (
  restaurant_id TEXT NOT NULL, month_key TEXT NOT NULL, data JSONB NOT NULL, PRIMARY KEY (restaurant_id, month_key)
);
