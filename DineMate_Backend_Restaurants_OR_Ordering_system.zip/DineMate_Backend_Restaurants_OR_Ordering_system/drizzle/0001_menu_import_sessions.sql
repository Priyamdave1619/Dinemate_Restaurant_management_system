-- Bulk Menu Import sessions (tenant-scoped)
CREATE TABLE IF NOT EXISTS "menu_import_sessions" (
  "id" text NOT NULL,
  "restaurant_id" text NOT NULL,
  "status" text NOT NULL DEFAULT 'uploaded',
  "data" jsonb NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "menu_import_sessions_restaurant_id_id_pk" PRIMARY KEY("restaurant_id","id")
);

CREATE INDEX IF NOT EXISTS "menu_import_sessions_status_idx" ON "menu_import_sessions" ("restaurant_id","status");
CREATE INDEX IF NOT EXISTS "menu_import_sessions_created_idx" ON "menu_import_sessions" ("restaurant_id","created_at");
