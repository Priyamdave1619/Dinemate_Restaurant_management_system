-- Menu file uploads (tenant-scoped)
CREATE TABLE IF NOT EXISTS "menu_files" (
  "id" text NOT NULL,
  "restaurant_id" text NOT NULL,
  "file_name" text NOT NULL,
  "file_type" text NOT NULL,
  "file_size" integer NOT NULL,
  "sha256" text,
  "storage_key" text,
  "file_url" text,
  "content_base64" text,
  "uploaded_by" text,
  "status" text NOT NULL DEFAULT 'uploaded',
  "data" jsonb NOT NULL DEFAULT '{}'::jsonb,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "menu_files_restaurant_id_id_pk" PRIMARY KEY("restaurant_id","id")
);

CREATE INDEX IF NOT EXISTS "menu_files_restaurant_idx" ON "menu_files" ("restaurant_id");
CREATE INDEX IF NOT EXISTS "menu_files_created_idx" ON "menu_files" ("restaurant_id","created_at");
CREATE INDEX IF NOT EXISTS "menu_files_sha256_idx" ON "menu_files" ("restaurant_id","sha256");
