# Backend updates (Super Admin)

## New endpoints
- `GET /api/admin/users` — platform-wide user directory (search, role, pagination)
- `GET /api/admin/system` — system health, memory, uptime, integration flags

## Updated
- `GET /api/admin/restaurants` — added `?planId=` filter

## Existing (unchanged, used by admin UI)
- Plans CRUD, restaurant detail PATCH (planId, renew, status), dashboard, audit logs
