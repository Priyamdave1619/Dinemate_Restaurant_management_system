/**
 * Apply drizzle/0000_init.sql to Neon (creates all tables if missing).
 *
 * Usage:
 *   npm run db:setup
 *
 * Requires DATABASE_URL in .env (with sslmode=require).
 * Uses the Neon HTTP API (no extra packages).
 */
import { readFileSync, existsSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";
import { neon } from "@neondatabase/serverless";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");

function loadEnv() {
  for (const name of [".env.local", ".env"]) {
    const p = resolve(root, name);
    if (!existsSync(p)) continue;
    for (const line of readFileSync(p, "utf8").split("\n")) {
      const t = line.trim();
      if (!t || t.startsWith("#") || !t.includes("=")) continue;
      const i = t.indexOf("=");
      const k = t.slice(0, i).trim();
      let v = t.slice(i + 1).trim();
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
        v = v.slice(1, -1);
      }
      if (!(k in process.env)) process.env[k] = v;
    }
  }
}

/** Run a raw SQL string via the neon tagged-template function (no parameters). */
async function exec(sqlFn, statement) {
  // neon's function only accepts TemplateStringsArray — build a fake one
  const strings = [statement];
  strings.raw = [statement];
  return sqlFn(strings);
}

loadEnv();

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("ERROR: DATABASE_URL is not set in .env");
  process.exit(1);
}

const sqlPath = resolve(root, "drizzle/0000_init.sql");
if (!existsSync(sqlPath)) {
  console.error("ERROR: missing", sqlPath);
  process.exit(1);
}

const raw = readFileSync(sqlPath, "utf8");
const statements = raw
  .split("\n")
  .map((l) => (l.trimStart().startsWith("--") ? "" : l))
  .join("\n")
  .split(";")
  .map((s) => s.trim())
  .filter((s) => s.length > 0);

const sql = neon(DATABASE_URL);

console.log(`Applying ${statements.length} SQL statements to Neon...`);

let ok = 0;
for (const stmt of statements) {
  try {
    await exec(sql, stmt);
    ok += 1;
    const preview = stmt.replace(/\s+/g, " ").slice(0, 72);
    console.log(`  ✓ ${preview}${stmt.length > 72 ? "…" : ""}`);
  } catch (err) {
    console.error(`  ✗ failed: ${stmt.replace(/\s+/g, " ").slice(0, 80)}`);
    console.error("   ", err?.message || err);
    process.exit(1);
  }
}

const rows = await sql`SELECT to_regclass('public.users') AS users_table`;
if (!rows[0]?.users_table) {
  console.error('ERROR: users table still missing after setup');
  process.exit(1);
}

console.log(`\nDone. ${ok} statements applied. Table "users" exists.`);
console.log("Next: npm run create-superadmin");
console.log("  or set SUPER_ADMIN_USERNAME / SUPER_ADMIN_PASSWORD and POST /api/auth/login");
