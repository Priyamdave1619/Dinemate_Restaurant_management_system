/**
 * Create or reset the platform super_admin account.
 *
 * Usage:
 *   npm run create-superadmin
 *   npm run create-superadmin -- --username Superadmin --password 'StrongPass123!'
 *
 * Falls back to SUPER_ADMIN_USERNAME / SUPER_ADMIN_PASSWORD from .env.
 * Requires tables to exist first: npm run db:setup
 */
import { readFileSync, existsSync } from "fs";
import { resolve, dirname } from "path";
import { fileURLToPath } from "url";
import { randomUUID, scryptSync, randomBytes, timingSafeEqual } from "crypto";
import { neon } from "@neondatabase/serverless";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");

function loadEnv() {
  for (const name of [".env.local", ".env"]) {
    const p = resolve(root, name);
    if (!existsSync(p)) continue;
    for (const line of readFileSync(p, "utf8").split("\n")) {
      const t = line.trim();
      if (!t || t.startsWith("#") || !t.includes("=")) continue;
      const i = t.indexOf("=");
      const k = t.slice(0, i).trim();
      let v = t.slice(i + 1).trim();
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
        v = v.slice(1, -1);
      }
      if (!(k in process.env)) process.env[k] = v;
    }
  }
}

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === "--username" && argv[i + 1]) out.username = argv[++i];
    else if (argv[i] === "--password" && argv[i + 1]) out.password = argv[++i];
    else if (argv[i] === "--name" && argv[i + 1]) out.name = argv[++i];
  }
  return out;
}

/** Must match src/lib/server/auth.ts hashPassword format */
function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return { hash, salt };
}

loadEnv();

const args = parseArgs(process.argv.slice(2));
const username = (args.username || process.env.SUPER_ADMIN_USERNAME || "").trim();
const password = args.password || process.env.SUPER_ADMIN_PASSWORD || "";
const name = (args.name || "Platform Super Admin").trim();

if (!username || !password) {
  console.error("Usage: npm run create-superadmin -- --username Superadmin --password 'StrongPass123!'");
  console.error("   or set SUPER_ADMIN_USERNAME and SUPER_ADMIN_PASSWORD in .env");
  process.exit(1);
}
if (password.length < 8) {
  console.error("ERROR: password must be at least 8 characters");
  process.exit(1);
}

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("ERROR: DATABASE_URL is not set in .env");
  process.exit(1);
}

const sql = neon(DATABASE_URL);
const uname = username.toLowerCase();

// Ensure schema exists
try {
  const check = await sql`SELECT to_regclass('public.users') AS t`;
  if (!check[0]?.t) {
    console.error('ERROR: relation "users" does not exist.');
    console.error("Run first:  npm run db:setup");
    process.exit(1);
  }
} catch (err) {
  console.error("ERROR: cannot reach database:", err?.message || err);
  process.exit(1);
}

const { hash, salt } = hashPassword(password);
const existing = await sql`SELECT id, data FROM users WHERE username = ${uname} LIMIT 1`;

if (existing[0]) {
  const prev = existing[0].data || {};
  const data = {
    ...prev,
    id: existing[0].id,
    restaurantId: null,
    username: uname,
    name,
    role: "super_admin",
    passwordHash: hash,
    passwordSalt: salt,
    active: true,
  };
  await sql`
    UPDATE users
    SET data = ${JSON.stringify(data)},
        role = 'super_admin',
        restaurant_id = NULL,
        active = TRUE
    WHERE id = ${existing[0].id}
  `;
  console.log(`Updated existing super_admin: ${uname} (id=${existing[0].id})`);
} else {
  const id = randomUUID();
  const data = {
    id,
    restaurantId: null,
    username: uname,
    name,
    role: "super_admin",
    passwordHash: hash,
    passwordSalt: salt,
    createdAt: new Date().toISOString(),
    active: true,
  };
  await sql`
    INSERT INTO users (id, restaurant_id, username, data, role, active, created_at)
    VALUES (${id}, NULL, ${uname}, ${JSON.stringify(data)}, 'super_admin', TRUE, NOW())
  `;
  console.log(`Created super_admin: ${uname} (id=${id})`);
}

console.log("Login with:");
console.log(`  username: ${uname}`);
console.log(`  password: (the one you just set)`);
console.log("POST /api/auth/login  or use Swagger UI");
