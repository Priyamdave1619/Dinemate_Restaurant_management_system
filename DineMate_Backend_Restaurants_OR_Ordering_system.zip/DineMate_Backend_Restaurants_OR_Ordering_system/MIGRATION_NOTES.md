# Multi-Tenant SaaS Migration — Phase 1 Notes

## What changed

This backend went from a single-restaurant POS to a multi-tenant SaaS
platform. Every business collection is now scoped by `restaurantId`, and
there's a new platform layer above it for the Super Admin.

**Storage bug fixed along the way:** the app runs entirely on MongoDB
(`mongo-store.ts` / `mongodb.ts`), but `mongodb` wasn't even listed in
`package.json`, and there was a dead, half-finished Postgres/Drizzle setup
(`schema.ts`, `drizzle.config.ts`, `@neondatabase/serverless`) that nothing
actually used. Removed the dead code, added the real dependency.

## Roles

`super_admin` (Product Owner, no restaurant) → `owner` (Restaurant Admin,
one per restaurant, username = their Restaurant ID) → `manager` → `waiter`.
All four log in through the same `POST /api/auth/login {username, password}`
— see that route's comments for why one endpoint covers every role.

**Usernames are globally unique across the whole platform**, not just
per-restaurant — waiter/manager login has no restaurant-selector field (per
the spec), so this was the only way to make a bare username+password lookup
unambiguous. Enforced in `restaurants.ts` / the users routes.

## New public endpoint

`POST /api/restaurants/register` — self-service sign-up. Creates the
restaurant (14-day free trial) + the owner's login in one call.

## Super Admin (`/api/admin/**`)

`restaurants` (list/provision/activate/suspend/renew/delete),
`plans` (CRUD), `dashboard` (platform totals), `audit-logs` (+ login
history). All require role `super_admin`.

## How customer (unauthenticated) requests find their tenant

There's no login for someone scanning a table QR code, so:
- Menu/table/offer/settings browsing needs `?restaurantId=REST000021` on
  the request (this is what the table QR code now encodes — see
  `tenant-context.ts` and the QR route).
- Order IDs are minted as `ord-{restaurantId}-{n}`, so once a customer has
  an order id, every order-scoped route (view order, add items, KOT, bill)
  resolves its tenant straight from the id — no query param needed there.

**Frontend follow-up required:** the customer-facing site needs to read
`restaurantId` out of the scanned QR URL and pass it on every relevant
call. This backend change alone doesn't do anything until that's wired up
on that site.

## What's enforced now vs. what's still a stub

Enforced: tenant data isolation (every collection + index), subscription
expiry/suspension blocking login AND every tenant API call (re-checked on
every request, not just at login), owner→manager→waiter permission
hierarchy on the Staff module, per-plan product/order/staff limits.

Not yet built (flagged in the previous chat message, still true): the
Notifications module (email/SMS/push), a real Billing/Invoices UI (the
subscription fields exist on `Restaurant`, but there's no payment gateway
integration), rate limiting, and audit-log entries on every single mutation
(currently logged for the highest-value actions — login, restaurant
lifecycle, staff changes — not yet every menu/order edit).

## Verified

`npx tsc --noEmit` — 0 errors, strict mode.
`npx next build` — succeeds, all 27 API routes register correctly.
Not run against a live MongoDB (no network path to Atlas/local Mongo from
this environment) — set `MONGODB_URI` and smoke-test against a real
database before deploying.

## Phase 2 — security hardening (this pass)

- **Rate limiting** (`src/proxy.ts`): in-memory sliding window, strict on
  `/api/auth/login` (10/min/IP) and `/api/restaurants/register` (5/min/IP),
  looser on everything else (240/min/IP). This is **single-instance only**
  — it does not share state across multiple serverless/edge instances. For
  real multi-instance production, swap the `Map` for a shared store (e.g.
  `@upstash/ratelimit` + Upstash Redis) using the same bucket keys; nothing
  else in the file needs to change.
- **Security headers** (helmet-equivalent for a JSON API): X-Content-Type-
  Options, X-Frame-Options, Referrer-Policy, Permissions-Policy, HSTS — all
  set in `proxy.ts` on every `/api/*` response.
- **CORS** made explicit and origin-allowlisted via `ALLOWED_ORIGINS` (see
  `.env.example`) instead of wide-open — required now that the admin/
  waiter/kitchen/customer sites are separate origins from this API.
- **AUTH_SECRET** now fails closed: if unset in `NODE_ENV=production`, the
  app throws instead of silently signing sessions with the dev default.
- **Audit logging expanded** to cover create/update/delete on menu items,
  categories, offers, tables (delete only — see comment in that route for
  why waiter status-flips aren't logged), and expenses, on top of the
  restaurant lifecycle / staff / login events Phase 1 already logged.
- **New**: `GET /api/activity-logs` — lets a restaurant Owner/Manager view
  their own tenant's audit trail + login history directly (previously only
  the Super Admin could see this, via `/api/admin/audit-logs`).

## Phase 3 — notifications, validation, logo upload (this pass)

- **Notifications module**: `AppNotification` type, tenant-scoped storage,
  `GET/PATCH /api/notifications` (+ `/[id]`). Wired into 3 real triggers:
  new order placed by a customer, a staff account created, subscription
  expiring within 5 days (checked at login, deduped so it fires once/day).
  Email/SMS/push are **not** connected to a real provider — `deliverExternal`
  in `notifications.ts` is the one seam to implement that once you pick a
  provider (SendGrid/Postmark, Twilio/MSG91, FCM/OneSignal, etc.); every
  notification already flows through it regardless of trigger site, so
  wiring a provider in later means touching one function, not every call
  site again.
- **Structured validation**: `src/lib/server/validation.ts` — real zod
  schemas now used by login, registration, orders (create + add-items),
  menu items, categories, tables, offers, users, and expenses, replacing
  the earlier ad-hoc `if (!body?.field)` checks.
- **Logo upload**: `POST /api/restaurants/upload-logo` — multipart, enforces
  the spec's 300KB limit + image-type allowlist, returns a `logoUrl` to
  pass into registration or `PATCH /api/restaurants/me`.
- **New `GET/PATCH /api/restaurants/me`**: owner-only restaurant PROFILE
  (name, logo, GST, contact, address) — separate from `/api/settings`
  (operational: tax rate, currency, opening hours). Owners could not
  previously edit their own restaurant's profile at all; only Super Admin
  could touch the `Restaurant` record.
- Extracted the QR route's storage logic into `src/lib/server/storage.ts`
  (Vercel Blob / local `/public` dual-mode) so the new logo upload route
  reuses it instead of duplicating it.

## Phase 4 — real email + payments integration (this pass)

- **Email is now real**, not a stub: `src/lib/server/email.ts` uses
  `nodemailer` over plain SMTP — works with Gmail, SendGrid/Postmark's SMTP
  relay, AWS SES SMTP, or any mail server, configured entirely through env
  vars (`SMTP_HOST/PORT/USER/PASS`, `EMAIL_FROM` — see `.env.example`). If
  unset, sends silently no-op with a console warning rather than breaking
  requests. Wired into: welcome email at registration, subscription-
  expiring/renewed/suspended emails, and a generic fallback for any other
  email-worthy in-app notification.
- **Payments are now real integration code** (Razorpay — chosen as the
  natural fit for an India-priced/INR platform; swap it out in
  `payments.ts` if that's not the right call for your deployment):
  `POST /api/billing/checkout` (owner starts a paid plan), 
  `POST /api/billing/verify` (client-side fast-path after Razorpay Checkout
  succeeds), `POST /api/billing/webhook` (server-to-server source of truth,
  HMAC-signature-verified, idempotent). Both verify and webhook funnel
  through the same `applySuccessfulPayment()` so a subscription is only
  ever extended once a real payment is confirmed. Fully env-gated
  (`RAZORPAY_KEY_ID/KEY_SECRET/WEBHOOK_SECRET`) — `createCheckoutOrder`
  returns a clear 501 "not configured" instead of failing unpredictably if
  unset.

### What "real" means here, honestly

This is genuine, working integration code — HMAC signature verification,
idempotent payment application, real SMTP delivery — not a mock. But it is
**unexercised**: I have no Razorpay test-mode credentials or an SMTP inbox
to actually send to from this sandbox, so none of it has been run
end-to-end. Test both with real (or Razorpay test-mode) credentials before
relying on them — particularly the webhook, since a payment-verification
bug is the kind of thing you want caught in staging, not production.

## Phase 5 — SMS, proactive expiry checks, and a real CSRF fix (this pass)

- **SMS via Twilio** (`sms.ts`), same env-gated pattern as email/payments.
  Deliberately reserved for only the single most time-critical case
  (subscription expiring/expired) — SMS costs money per message and
  shouldn't fire on routine events like new orders.
- **Proactive subscription-expiry checks**: `GET /api/cron/check-subscriptions`
  (protected by `CRON_SECRET`, wired to run daily via `vercel.json`).
  This matters because the previous expiry check only fired reactively at
  login — which is exactly the thing an already-expired restaurant can no
  longer do. Now owners get warned (and get an actual expired notice) even
  if they never log back in to see it.
- **A real CSRF fix, not just a documented assumption**: I'd previously
  reasoned that strict CORS + JSON content-type made a separate CSRF
  mechanism unnecessary. On closer inspection **that reasoning was wrong**
  — `req.json()` doesn't check the `Content-Type` header, and a plain HTML
  `<form>` (no JS, no CORS preflight at all) can submit
  `Content-Type: text/plain` with a crafted body that still parses as JSON,
  while the session cookie (`SameSite=None`, required for the separate
  admin/waiter/kitchen/customer origins) gets attached automatically. That
  was a real, exploitable JSON-CSRF vector against every mutating route.
  Fixed in `proxy.ts`: any request whose Content-Type is one of the three
  types an HTML form can actually produce
  (`application/x-www-form-urlencoded`, `multipart/form-data`,
  `text/plain`) is now rejected with 415, since legitimate `fetch()` calls
  from the real frontends always send `application/json` explicitly and a
  browser `<form>` element cannot. One deliberate, documented exception:
  `/api/restaurants/upload-logo` needs real `multipart/form-data`, so it's
  exempted — worst case there is an unwanted file landing under a random
  UUID key, not a security issue.

## Phase 6 — closing two gaps I'd actually missed (this pass)

Every previous phase's "still not done" list was honest about what I knew
was missing. This pass exists because, when asked again whether the
backend was complete, I went back and actually checked against the
original spec line-by-line instead of re-asserting the same list — and
found two concrete requirements I'd overlooked entirely:

- **"Refresh Token" was in the spec's Technology Requirements and was
  never built.** The backend only ever issued a single long-lived (12h)
  access token. Fixed properly, not just bolted on:
  - Access tokens are now short-lived (15 min); a new, separate,
    long-lived (30 day) refresh token is issued alongside it at login.
  - Refresh tokens are opaque random values — only their SHA-256 hash is
    ever stored (`refresh-tokens.ts`), same principle as password hashing.
  - **Rotation on every use**: each `POST /api/auth/refresh` call
    invalidates the presented token and issues a new one. If an
    already-rotated (i.e. stolen-and-reused) token is ever presented
    again, that's detected and treated as a compromise signal — every
    refresh token for that user is immediately revoked, forcing a real
    password login.
  - Refresh also re-checks the restaurant's live status/subscription
    (same as `requireTenant` does for regular requests), and MongoDB TTL-
    indexes expired tokens for automatic cleanup.
  - Sessions are now also explicitly revoked (not just left to expire) on
    logout, password reset, and staff deactivation/deletion — a
    meaningfully different (and stronger) security posture than before,
    not just a checkbox for the spec.
  - **One real bug caught and fixed during this**: I initially stored the
    refresh token's expiry as an ISO string, matching this codebase's
    convention everywhere else — but MongoDB's TTL auto-delete index only
    works on native BSON `Date` fields, so that would have silently never
    expired anything. Worth flagging because it's exactly the kind of
    thing that looks correct, type-checks fine, and would only surface as
    a slow, silent problem in production (a `refreshTokens` collection
    that never gets cleaned up) — not something `tsc`/`next build` could
    ever catch.
  - Client integration note: your frontend needs to catch a `401` from any
    API call, call `POST /api/auth/refresh` (no body), and retry the
    original request once. This wasn't needed before (12h sessions rarely
    expired mid-use); it is now.

- **"API Documentation" was its own line item in the spec and didn't
  exist.** Added `API_REFERENCE.md` — every route, method, required role,
  and a short note on request shape/query params. Not a formal OpenAPI/
  Swagger spec (nothing in this codebase generates one automatically, and
  hand-writing a full OpenAPI 3.0 document for 36 routes was judged lower
  value than a fast, accurate reference table) — if you specifically need
  machine-readable OpenAPI (e.g. for client SDK generation), that's a
  reasonable follow-up but is a different, larger task than what's here.

- **"Pagination, Search, Filtering, Sorting" was its own line item and was
  only implemented on one endpoint** (`/api/admin/restaurants`). Added a
  shared `pagination.ts` helper and wired it into the highest-volume list
  endpoints: `GET /api/orders` (page/pageSize/search), `GET /api/menu`
  (search/sort/opt-in pagination — kept opt-in since the primary caller is
  the public full-menu customer page, which wants everything on one
  screen, not page 1 of N), and `GET /api/finance/expenses`. Smaller,
  inherently-bounded lists (categories, tables, offers — a restaurant
  realistically has single or low-double digits of these) were
  deliberately left unpaginated.

- **Also found while touching that code: a real, more serious bug.**
  `GET /api/orders` (list every order for a restaurant) was using the same
  "public" tenant-resolution helper as the menu-browsing routes — meaning
  anyone who knew a restaurant's ID could list every order (customer
  names, table numbers, totals) with **no login at all**. This is
  different from the routes that are *supposed* to be public
  (`GET /api/orders/[id]` — a customer viewing their own order, gated by
  knowing that specific id) — listing *every* order is a staff operation
  and was never meant to be reachable this way. Fixed: it now requires an
  authenticated owner/manager/waiter session. Calling this out explicitly
  rather than folding it quietly into the pagination entry, because it's
  the kind of bug that's easy to gloss over and shouldn't be.

## Phase 7 — Bearer token auth (this pass)

Asked the same question again, checked the spec again, found another real
gap: **"Every API must be protected using `Authorization: Bearer
<JWT_TOKEN>`" is stated explicitly in the spec's Authentication section,
and this backend never implemented it** — every previous phase built and
verified cookie-only auth instead. That's a genuine architectural mismatch
against a requirement stated in the very first paragraph of the spec's
Authentication section, not a subtle omission, and I'd missed it through
six previous "is it complete" passes.

Fixed by making Bearer the primary mechanism, not a bolt-on:
- `getSession()` (used by every `requireRole`/`requireTenant` check on
  every route) now checks `Authorization: Bearer <token>` first, falling
  back to the httpOnly cookie only if no Bearer header is present.
- `POST /api/auth/login` and `POST /api/auth/refresh` now return
  `accessToken`/`refreshToken` directly in the JSON response body (not
  just as cookies) — a Bearer client can't read an httpOnly cookie, so it
  needs the raw values to store and attach itself.
- `POST /api/auth/refresh` and `POST /api/auth/logout` now accept the
  refresh token via `Authorization: Bearer`, JSON body, or cookie — in
  that priority order — so a pure Bearer-token client (mobile app,
  server-to-server integration) never has to touch a cookie at all.
- The httpOnly cookies remain fully functional as a same-origin browser
  convenience (so a web frontend doesn't have to manually manage token
  storage) — this is additive, not a replacement; nothing that worked via
  cookies in Phase 6 stopped working.

I want to be direct about the pattern here: this is the second time
re-reading the spec line-by-line (rather than re-asserting my own previous
"complete" list) turned up something real — first the missing refresh
token and an unauthenticated data leak, now a whole auth-transport
mismatch against an explicit requirement. That's worth taking seriously as
a signal: I don't have strong confidence there are zero remaining gaps of
this kind, only that I haven't found more on this pass.

## Phase 8 — Swagger/OpenAPI, and the first genuinely *running* test this project has had

- **`GET /api/openapi.json`** serves a hand-written OpenAPI 3.0 document
  (`openapi-spec.ts`) covering all 47 routes.
- **`/swagger-ui/index.html`** — self-hosted Swagger UI (not a CDN
  dependency — the JS/CSS bundle is vendored into `public/swagger-ui/`
  from the `swagger-ui-dist` package), pointed at that spec. Click
  "Authorize" and paste an access token to interactively call any endpoint
  against a real running instance.
- **This was actually validated, not just asserted**: I ran the spec
  through `@apidevtools/swagger-parser`'s full validator (resolves every
  `$ref`, checks schema correctness) — it passed. I then diffed the
  spec's path list against every real `route.ts` file on disk
  programmatically: **zero drift, exact 1:1 match, all 47 routes**,
  nothing documented that doesn't exist and nothing real left undocumented.
- **This also produced the first genuinely *running* test in this entire
  project.** I started the actual built server (`next start`) and sent
  real HTTP requests to it — `/api/openapi.json` and both Swagger UI
  assets came back `200`, and the served JSON was byte-for-byte identical
  to the source. This doesn't touch MongoDB (these three routes don't need
  a database), so it's not the full end-to-end proof this backend still
  needs — but it is the first time anything in this codebase has been
  exercised by an actual running process instead of only `tsc`/`next
  build`, and it worked.

### Still not done

Push notifications (no client exists yet to register device tokens
against). And the one gap every phase keeps landing on: **the actual
business logic — orders, billing, tenant isolation, all of it — has still
never been exercised against a real MongoDB.** What changed this phase is
proof that this codebase *can* run and serve real HTTP responses
correctly when given a chance to; what hasn't changed is that the parts
requiring a database remain unverified beyond static analysis.

## Phase 9 — the exact API response envelope, and two more live-caught bugs

You asked for the full refactor to the spec's exact response shape:
```json
{ "success": true, "message": "...", "data": {}, "pagination": {} }
{ "success": false, "message": "...", "errors": [] }
```
This is now applied everywhere — all 46 routes (`openapi.json` deliberately
excluded, since it must serve a standards-compliant OpenAPI document, not
our envelope) plus the middleware. `src/lib/server/api-response.ts` holds
the two helpers (`apiSuccess`/`apiError`) every route now uses.

This was done with codemods, not by hand, given the scale (46 files):
regex-based for the very regular `{error: X}, {status: Y}` patterns
(including the `{error: auth.message}, {status: auth.status}` variant,
which needed a second pass — my first regex only matched literal numeric
status codes), and a TypeScript-compiler-AST-based transform (not regex)
for the riskier structural change of wrapping every handler for the error
handler below, specifically to avoid corrupting 46 files with nested
braces. Every automated pass was followed by `tsc --noEmit` to catch
mistakes immediately.

**Two more real bugs, caught by actually running the server, not by
reading code:**

1. **The CSRF/rate-limit middleware (`proxy.ts`) was still returning the
   old `{error}` shape.** It isn't a `route.ts` file, so the route-level
   codemods never touched it. Live-tested before and after: before, a
   CSRF-blocked request returned `{"error": "..."}`; after, it returns the
   correct `{"success": false, "message": "...", "errors": []}`.

2. **There was no global error handler at all — confirmed live, not
   suspected.** I tested an unhandled exception (a real MongoDB connection
   failure, but this applies to *any* uncaught exception in *any* route)
   and the response was **`HTTP 500` with a completely empty body** — not
   JSON, not our envelope, nothing. The real error was only visible in
   server logs. This is the spec's "Global Error Handler" requirement,
   and it plainly didn't exist. Fixed with `withErrorHandling()` in
   `api-response.ts`, applied to every exported route handler via the
   AST-based codemod mentioned above (each `export async function GET(...)`
   became `async function getImpl(...)` + `export const GET =
   withErrorHandling(getImpl);`). Re-tested the *exact same* failing
   request afterward: now returns
   `{"success":false,"message":"An unexpected error occurred. Please try
   again.","errors":[]}` with the real error still logged server-side for
   debugging, never leaked to the client.

**A third issue, caught while fixing the above rather than through live
testing**: the 4 endpoints with real pagination (`/api/orders`,
`/api/menu`, `/api/finance/expenses`, `/api/admin/restaurants`) had their
codemod-converted responses stuff `page`/`pageSize`/`total`/`totalPages`
*inside* `data` alongside the list, rather than as the sibling
`pagination` field the spec's own example shows. Fixed all four to use
`apiSuccess(data, message, { pagination })` properly.

**The OpenAPI spec was updated to match** (it had been validated against
the *old* response shape, which would have made it actively wrong the
moment this refactor shipped) — re-validated with `@apidevtools/
swagger-parser` (passed) and re-diffed against the filesystem (still exact
1:1 match, 47 routes, zero drift).

**Verified, live, after all of the above** (not just `tsc`/`next build`,
though both are also clean): started the real server and hit it with curl
for all four cases — a zod validation error, a CSRF-blocked request, an
unhandled exception, and confirmed `openapi.json` itself correctly stays
unwrapped. All four returned exactly the expected shape.

### Still not done

Push notifications (no client exists yet to register device tokens
against). And, once again, the gap that doesn't change no matter how many
more bugs get caught by careful reading and light live-testing of routes
that don't need a database: **the actual business logic — orders,
billing, tenant isolation — has never been exercised against a real
MongoDB.** The pattern across Phases 6 through 9 (refresh tokens, a real
data-exposure bug, Bearer auth, a missing global error handler) is a
concrete argument for why that testing matters more than it might seem:
every one of those was invisible to `tsc`/`next build`, and surfaced only
by either reading very carefully or actually running the code. The parts
of this backend that touch a database have had neither the reading nor
the running applied to them nearly as much.

## Phase 10 — one more validation gap, found by re-checking my own earlier work

While reviewing whether the Phase 9 envelope refactor was actually
complete, checked something adjacent: 4 PATCH routes (categories, offers,
menu items, expenses) had never had a create-time zod schema written for
their *update* path — only their create (POST) path was validated. Each
one spread the raw, unvalidated request body directly onto the stored
document (`{ ...existing, ...patch, id: existing.id, restaurantId:
existing.restaurantId }`). The `id`/`restaurantId` pinning meant
tenant-hopping was never possible, but nothing stopped a malformed
`price: "not a number"` or an arbitrary extra field from landing in a
stored document — a real, if lower-severity, gap in "API Validation"
coverage, and a mass-assignment-shaped inconsistency between the create
and update paths for the same 4 resources.

Fixed with `.partial()` variants of the existing create schemas
(`updateCategorySchema`, `updateOfferSchema`, `updateMenuItemSchema`,
`updateExpenseSchema` in `validation.ts`) — every field optional (it's a
PATCH), but any field that IS present must still be the correct type.

Couldn't live-test this one through the API the way previous fixes were
tested — `requireTenant` correctly checks auth before validation runs, and
auth needs a real database, so hitting these routes without one just
proves the auth gate works (which it does — verified: an unauthenticated
PATCH returns 401 before ever reaching the new validation). Instead,
**unit-tested the zod schemas directly**, in isolation from the rest of
the app: compiled `validation.ts` standalone and asserted against it —
confirmed a wrong-typed `name`, `price`, `type`, and `amount` are each
correctly rejected, and confirmed legitimate partial updates (e.g. just
toggling `available: false`) still pass. All 6 assertions passed.

### Still not done

Same as Phase 9's ending, unchanged: push notifications, and the database
gap. Worth naming directly at this point — five consecutive rounds
(Phases 6–10) have each surfaced at least one genuine, previously-unknown
issue through either careful re-reading or actual (if partial) testing.
That is not evidence the codebase is converging toward "no more bugs" —
if anything it's evidence the opposite risk is real: that the parts of
this system requiring a live database, which have had no equivalent
scrutiny, likely have issues of their own that neither of us can see from
here. The Swagger UI built in Phase 8 remains the most direct path to
finding them.

## Phase 11 — a real automated test suite, and it immediately found two genuine production bugs

Every previous phase's testing was either static (`tsc`/`next build`) or
one-off manual `curl`/isolated-script checks that left nothing behind.
This phase adds something durable: `npm test` runs 89 real, repeatable
tests (Vitest) that actually execute this codebase's logic and assert on
real outcomes.

**The database problem, solved honestly, not talked around.** There is
still no `mongod` binary and no network path to get one in this sandbox
— that hasn't changed. But the single most important correctness property
of a multi-tenant platform (tenant A can never read/write/delete tenant
B's data) is a property of *logic*, and logic can be exercised without a
real database. `src/lib/server/__tests__/fake-mongo.ts` is a small,
narrowly-scoped, in-memory implementation of exactly the MongoDB driver
surface this codebase actually calls (audited via `grep` first, not
guessed at) — `find`/`findOne` with the handful of filter operators
actually used (`$nin`/`$gte`/`$lte`/`$ne`/`$in`), `insertOne`/`insertMany`,
`updateOne`/`updateMany` (`$set`/`$inc`/`$setOnInsert`, upsert),
`deleteOne`/`deleteMany`, `countDocuments`, `findOneAndUpdate`,
`distinct`, `bulkWrite`/`replaceOne`, and a minimal aggregation engine
covering only the `$match`/`$group`/`$project`/`$sort`/`$limit`
stages and `$sum`/`$addToSet`/`$first`/`$size` operators `analytics.ts`
actually uses. It's wired in via Vitest's module mocking
(`__tests__/setup.ts`), so every test runs the REAL `mongo-store.ts`,
`db.ts`, `sales.ts`, `refresh-tokens.ts`, etc. — completely unmodified —
against it.

**This is explicitly not a substitute for testing against real MongoDB.**
It's a hand-built fake; it can have (and, per the log below, did have)
its own bugs, and it can't validate things like real index behavior,
BSON edge cases beyond what's covered, or connection-level failure modes.
What it *can* do, and does: catch real logic bugs in the application code
that static analysis cannot, which turned out to matter immediately.

**What's actually tested (89 tests, 7 files):**
- `mongo-store.test.ts` (9) — tenant isolation at the storage layer:
  same-id documents in two different tenants never collide on read,
  write, update, or delete; a `restaurantId: null` scope (super_admin) is
  correctly isolated from every real tenant; a direct regression test for
  the bug below.
- `db.test.ts` (10) — the actual `tenantDb()`/`platformDb` interface every
  route uses, not just the lower-level storage functions.
- `auth.test.ts` (10) — password hashing (correct/incorrect verification,
  random salting, no-plaintext-storage) and JWT session tokens (round-trip,
  tamper detection, garbage-input handling, `restaurantId: null` for
  super_admin preserved correctly).
- `refresh-tokens.test.ts` (7) — issuance, rotation, and specifically the
  security-critical reuse-detection path (a stolen-and-reused token is
  caught and triggers full revocation, verified to actually lock out even
  the legitimately-rotated new token afterward).
- `pricing.test.ts` (19) — the order pricing engine: percent/flat/BOGO
  offers (including category-wide BOGO and quantity-boundary cases),
  `minOrderAmount` gating, manual discount stacking with offers, and tax
  calculated on the correct post-discount base.
- `validation.test.ts` (29) — every zod schema, both accept and reject
  cases.
- `sales.test.ts` (6) — the full order-to-bill archival integration flow:
  correct revenue/cost/profit on sold-item lines, the order actually
  moving from the active queue into permanent archive, daily/monthly
  stats incrementing (and accumulating correctly across multiple orders
  same-day) — and a `CRITICAL`-labeled test verifying this entire
  financial pipeline respects tenant isolation exactly like the storage
  layer does.

**Two genuine, previously-unknown bugs found by actually running this
code, neither of which `tsc`/`next build` could ever have caught:**

1. **A real, exploitable-by-accident production bug**: `readCollection`/
   `mutateCollection` auto-inserted their starter/demo seed content
   whenever a tenant's scope was empty — with no way to distinguish
   "this tenant was never initialized" from "this tenant legitimately
   deleted everything." A restaurant owner who cleared out the demo menu
   to build their own from scratch, or a super_admin who deleted every
   subscription plan, would have seen that content silently reappear on
   the very next page load. Caught because a test that deliberately
   emptied a tenant's category list, then re-read it, got back 5 items
   instead of 0 — and the *real* `mongo-store.ts` produced that result,
   not a mock of it. Fixed at the architectural level, not patched at the
   symptom: `readCollection`/`mutateCollection` no longer auto-seed under
   any circumstance; a new `seedCollectionOnce()` is the only thing that
   ever inserts starter content, called exactly once — from
   `registerRestaurant()` for tenant content, and lazily-but-idempotently
   for the platform's 4 default subscription plans (a deliberately
   different tradeoff for that one case — see the comment on
   `platformDb.plans.all()` for why).

2. **`ensureSuperAdminBootstrap()` was fully implemented, and never called
   from anywhere in the entire codebase.** `grep` confirmed zero call
   sites. This means `.env.example`'s documented
   `SUPER_ADMIN_USERNAME`/`SUPER_ADMIN_PASSWORD` variables would have done
   nothing at all on a real deployment — no super_admin account would ever
   have been created, making the entire Super Admin module permanently
   unreachable. Not found by any test (there's no way to test "a function
   is never called" via a unit test of that function) — found by grepping
   for call sites while investigating the seeding bug above, on the
   theory that if one lazy-initialization pattern had a real bug, it was
   worth checking whether the *other* one was even wired up at all. It
   wasn't. Fixed: called once, cheaply and idempotently, at the top of
   `POST /api/auth/login`.

Both fixes were re-verified: full test suite passes (89/89), `tsc
--noEmit` clean, `next build` clean (47 routes).

### Still not done

Push notifications, and — genuinely narrower now than at any previous
phase, but not gone — **live MongoDB verification**. What Phase 11 changes
the honest answer to is no longer "nothing has been tested," it's "the
logic has been tested thoroughly against a faithful fake; the real
database driver, real network behavior, real index enforcement, and
anything outside what `fake-mongo.ts` was scoped to cover have not." That
remaining gap is real, but it is a categorically smaller one than it was
at the start of this conversation.

## Phase 12 — payment-signature tests, and a systematic dead-code sweep

- **`payments.test.ts` (11 tests)**: the Razorpay HMAC signature
  verification (`verifyCheckoutSignature`/`verifyWebhookSignature`) was
  pure, security-critical crypto with zero test coverage. Now verified: a
  correctly signed payload is accepted; a forged signature (wrong secret),
  a tampered body, a signature applied to a different order/payment id, and
  malformed/garbage input are all rejected; both functions fail closed
  (reject, don't throw) if their secret env var isn't configured. One
  specifically important case: a webhook body that's semantically
  identical but re-serialized with different whitespace/formatting is
  correctly REJECTED — this is exactly why `/api/billing/webhook` signs
  the raw request text rather than `JSON.parse`-then-`stringify`, and now
  there's a test asserting that distinction actually matters.
- **A systematic dead-code sweep** across all of `src/lib` (every exported
  function/const, checked for zero usages anywhere else in the codebase —
  this is the same technique that found the uncalled
  `ensureSuperAdminBootstrap` in Phase 11, run more broadly this time).
  Found 8 candidates; 6 were false positives from the sweep's own
  same-file-usage blind spot (harmless), and 2 were genuine:
  - `getMongoClient` and `archiveOrderById` are legitimately unused —
    both are intentional, already-documented forward-looking utilities
    (a raw client accessor for future transaction support; a batch-job
    helper for closing bills outside the normal bill-route flow), not
    broken promised functionality like the two Phase 11 bugs. Left as-is.
  - `RESTAURANT_STAFF_ROLES` — a shared constant that existed specifically
    to avoid repeating the `["owner", "manager", "waiter"]` role list, but
    nothing actually used it; that exact array was hand-typed independently
    in 8 places across 7 route files instead. Not a functional bug (all 8
    were consistent with each other), but a real maintainability gap —
    fixed by wiring the constant in everywhere it belongs, so the role list
    now has one source of truth instead of 8 copies that could silently
    drift apart from each other over time.

Full suite re-verified after both changes: 100/100 tests passing, `tsc
--noEmit` clean, `next build` clean (47 routes).

### Still not done

Unchanged: push notifications, and live MongoDB verification. No new
categories of gap found this round — Phase 12 was confirmation and
cleanup work on top of Phase 11's foundation, not the discovery of
another architectural bug.

## Phase 13 — closing the last known test-coverage gap (reports.ts/finance.ts)

Earlier phases deliberately skipped testing `analytics.ts`/`reports.ts`/
`finance.ts` on the reasoning that `analytics.ts`'s aggregation pipelines
would be tested against `fake-mongo.ts`'s own hand-built aggregation
engine, making the math checks partly circular. That reasoning was
correct as far as it went, but incomplete — it doesn't apply to
`reports.ts`/`finance.ts`, which don't use `.aggregate()` at all, just
plain `find`/`findOne`/`distinct` queries and JS-side summation. There was
no real reason to leave those untested, so this phase adds
`reports-finance.test.ts` (12 tests): daily/weekly/monthly/yearly stats
retrieval and aggregation, all with explicit same-scope-different-tenant
assertions (the weekly/yearly rollups are computed by summing raw
per-day/per-month records in JS, so getting the tenant filter wrong here
would silently blend two restaurants' revenue together), and the P&L
calculation (gross profit, expense deduction by category, net profit —
including the edge case of a period with real expenses but zero sales,
correctly producing a negative net profit rather than crashing or
returning zero).

One real catch during this pass, worth noting for what it says about the
limits of running tests without a full type-check: the new test file ran
and passed under `vitest run` on the first try, using object literals
that were missing a required field (`description` on `addExpense`).
Vitest's default transform is transpile-only and doesn't enforce
TypeScript's type system, so the JS still ran fine with `description`
simply `undefined` at runtime. `tsc --noEmit` — run as a completely
separate step, as it always has been in this project — caught it
immediately. This is exactly why this project's verification has never
relied on `vitest run` passing as sufficient on its own: a green test run
and a clean type-check catch different classes of mistakes, and both are
checked, every phase, specifically because relying on only one would have
let this through.

**112/112 tests passing, `tsc --noEmit` clean, `next build` clean (47
routes).** Every server module with meaningful logic — auth, sessions,
refresh tokens, pricing, validation, sales archival, tenant isolation at
every layer, reports, finance, and payment signature verification — now
has real automated test coverage.

### Still not done

Unchanged: push notifications (a scope decision, not a bug), and live
MongoDB verification (an environment limitation, not something more test
files can resolve). Both have been true, in the same form, since Phase 8
or earlier — everything found and fixed since then has been through
scrutiny of what already existed, not new scope.

## Phase 14 — testing the actual authorization gate (session.ts)

A genuine, identifiable gap, not a manufactured one: every server module
with meaningful logic had test coverage except `session.ts` — the module
that makes the actual allow/deny decision on every single protected
request (`requireRole`/`requireTenant`, both built on `getSession()`).
Everything downstream of it (routes, `db.ts`, `mongo-store.ts`) had been
tested; the gate itself hadn't.

This required extending the test infrastructure again: `getSession()`
calls Next.js's `cookies()`/`headers()`, which only work inside an active
Next.js request and throw outside one — so `next/headers` now has a
controllable mock alongside the MongoDB one, wired into the same global
setup file (`setMockAuthHeader`/`setMockSessionCookie`, reset before every
test the same way the fake database is).

**17 tests, all passing**, including two specifically labeled `SECURITY`
that verify the property this entire architecture depends on: a
still-valid, unexpired JWT is immediately rejected the moment the
restaurant it belongs to is suspended, or its subscription expires — not
eventually, not after the token would naturally expire, but on the very
next request after the state change. This was always the documented
intent (see `requireTenant`'s own comments, written back in Phase 1), but
until this phase it had never actually been verified to work, only
asserted in a code comment. It does work. Also covered: Bearer-header vs.
cookie precedence (Bearer wins when both are present), a present-but-
invalid Bearer header failing closed rather than silently falling back to
a valid cookie, super_admin correctly being rejected by the tenant gate,
and restaurant-to-restaurant isolation at the authorization layer itself
(a suspended restaurant B never affects a healthy restaurant A's access).

**129/129 tests passing, `tsc --noEmit` clean, `next build` clean (47
routes).**

### Still not done

Unchanged: push notifications and live MongoDB verification. Remaining
known test-coverage gaps, in descending priority, if this continues:
`notifications.ts` (in-app targeting/read-state logic), `restaurants.ts`
(registration flow, id generation), `tenant-context.ts`
(`restaurantIdFromOrderId` parsing — security-relevant since it's how
unauthenticated order routes resolve their tenant), `time-keys.ts` and
`pagination.ts` (small, pure, lower risk). None of these are the
authorization-critical class of gap `session.ts` was.












