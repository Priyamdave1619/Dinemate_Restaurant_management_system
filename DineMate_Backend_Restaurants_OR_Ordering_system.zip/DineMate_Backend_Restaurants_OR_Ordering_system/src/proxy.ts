import { NextRequest, NextResponse } from "next/server";

// This backend is now called from separate origins (admin site, waiter
// site, kitchen site, customer site — each its own deployment/domain), so
// every /api/* response needs CORS headers, and preflight OPTIONS requests
// need a direct answer instead of falling through to a route handler that
// doesn't implement OPTIONS.
//
// ALLOWED_ORIGINS is a comma-separated list of the exact origins permitted
// to call this API with credentials, e.g.:
//   ALLOWED_ORIGINS=https://admin.dinemate.app,https://waiter.dinemate.app,https://kitchen.dinemate.app,https://order.dinemate.app,http://localhost:3001,http://localhost:3002,http://localhost:3003,http://localhost:3000
const allowedOrigins = (process.env.ALLOWED_ORIGINS || "")
  .split(",")
  .map((o) => o.trim())
  .filter(Boolean);

function corsHeaders(origin: string | null): Headers {
  const headers = new Headers();
  if (origin && allowedOrigins.includes(origin)) {
    headers.set("Access-Control-Allow-Origin", origin);
    headers.set("Access-Control-Allow-Credentials", "true");
    headers.set("Vary", "Origin");
  }
  headers.set("Access-Control-Allow-Methods", "GET,POST,PATCH,PUT,DELETE,OPTIONS");
  headers.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
  return headers;
}

// A minimal "helmet"-equivalent for a JSON API — no HTML is ever served
// here, so most of the classic helmet directives (CSP script-src, etc.)
// don't apply; these are the ones that do.
function securityHeaders(res: NextResponse): void {
  res.headers.set("X-Content-Type-Options", "nosniff");
  res.headers.set("X-Frame-Options", "DENY");
  res.headers.set("Referrer-Policy", "no-referrer");
  res.headers.set("Permissions-Policy", "geolocation=(), camera=(), microphone=()");
  // Only meaningful over HTTPS (browsers ignore it over plain http) — safe
  // to always send.
  res.headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
}

// ---------------------------------------------------------------------------
// Rate limiting — simple in-memory sliding window, keyed by IP + route
// bucket. This protects a single running instance (fine for one Node/Vercel
// function instance, and for local dev) but does NOT share state across
// multiple serverless instances. For a real multi-instance production
// deployment, swap this Map for a shared store (e.g. Upstash Redis /
// @upstash/ratelimit) using the same bucket keys defined below — everything
// else in this file stays the same.
// ---------------------------------------------------------------------------

interface Bucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();

// Auth endpoints get a much tighter limit (brute-force protection) than
// the general API.
const LOGIN_LIMIT = { max: 10, windowMs: 60_000 };
const REGISTER_LIMIT = { max: 5, windowMs: 60_000 };
const GENERAL_LIMIT = { max: 240, windowMs: 60_000 };

function rateLimitBucketFor(pathname: string): { key: string; max: number; windowMs: number } | null {
  // Health probes are polled by load balancers — don't burn the general budget.
  if (pathname === "/api/health" || pathname === "/api/health/db") return null;
  if (pathname === "/api/auth/login") return { key: "login", ...LOGIN_LIMIT };
  if (pathname === "/api/restaurants/register") return { key: "register", ...REGISTER_LIMIT };
  return { key: "general", ...GENERAL_LIMIT };
}

function clientIp(req: NextRequest): string {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "unknown";
}

function checkRateLimit(req: NextRequest): { ok: true } | { ok: false; retryAfterSeconds: number } {
  const rule = rateLimitBucketFor(req.nextUrl.pathname);
  if (!rule) return { ok: true };

  const key = `${rule.key}:${clientIp(req)}`;
  const now = Date.now();
  const existing = buckets.get(key);

  if (!existing || existing.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + rule.windowMs });
    return { ok: true };
  }

  if (existing.count >= rule.max) {
    return { ok: false, retryAfterSeconds: Math.ceil((existing.resetAt - now) / 1000) };
  }

  existing.count += 1;
  return { ok: true };
}

// Periodically forget stale buckets so this Map doesn't grow forever on a
// long-lived instance. Cheap and approximate is fine here.
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt <= now) buckets.delete(key);
  }
}, 5 * 60_000).unref?.();

// ---------------------------------------------------------------------------
// CSRF: a plain HTML <form> (no JS, no CORS preflight involved at all) can
// still submit to any origin with Content-Type restricted to one of
// application/x-www-form-urlencoded, multipart/form-data, or text/plain —
// and our session cookie is SameSite=None (required so the separate admin/
// waiter/kitchen/customer origins can use it), so the browser WILL attach
// it to that cross-site form submission. Next's `req.json()` also doesn't
// check the Content-Type header — it happily parses whatever body text
// looks like JSON — so without this check, a crafted text/plain form body
// is a real JSON-CSRF vector against every mutating route, despite CORS
// being correctly configured (CORS governs *reading the response* via
// fetch, not *whether a simple form submission is sent* — those are
// different mechanisms and it's a common mistake to assume the former
// covers the latter).
//
// Requiring an exact `application/json` Content-Type on every mutating
// request closes this: a browser <form> element cannot set that
// Content-Type (its `enctype` attribute only permits the three types
// above), so only same-origin/CORS-approved JS `fetch()` calls — which is
// exactly what every legitimate client here already does — can ever send
// a request this middleware accepts. In practice we reject the three
// form-producible types rather than require exactly application/json, so
// legitimate bodyless requests (no Content-Type header at all — e.g.
// POST /kot, POST /logout) aren't broken by this check.
const CSRF_CHECK_EXEMPT_PATHS = new Set([
  // Needs multipart/form-data for the actual file upload, so it can't be
  // covered by the same check — a real HTML <form> could still submit a
  // multipart request here with an authenticated owner's cookie attached.
  // Deliberately accepted: the worst case is an unwanted file landing under
  // a random-UUID key in that tenant's `logos/` prefix (no read access, no
  // ability to overwrite anything else, no data exposure) — a nuisance, not
  // a security issue, and not worth blocking legitimate multipart uploads
  // over. Revisit if this route ever does anything higher-stakes than
  // storing a logo image.
  "/api/restaurants/upload-logo",
  // Bulk menu import — tenant-scoped files under menu-import/{restaurantId}/
  "/api/menu-import/upload",
  "/api/menu-files",
]);

// A plain HTML <form> can only ever produce one of these three
// Content-Types (its `enctype` attribute permits nothing else) — so
// rejecting exactly these three, rather than requiring every mutating
// request be exactly `application/json`, closes the form-CSRF vector
// without breaking legitimate bodyless requests (e.g. POST /kot,
// POST /logout) that never set a Content-Type at all.
const FORM_CONTENT_TYPES = ["application/x-www-form-urlencoded", "multipart/form-data", "text/plain"];

function csrfCheck(req: NextRequest): { ok: true } | { ok: false } {
  if (req.method === "GET" || req.method === "HEAD" || req.method === "OPTIONS") return { ok: true };
  if (CSRF_CHECK_EXEMPT_PATHS.has(req.nextUrl.pathname)) return { ok: true };

  const contentType = (req.headers.get("content-type") || "").toLowerCase();
  if (FORM_CONTENT_TYPES.some((t) => contentType.startsWith(t))) return { ok: false };
  return { ok: true };
}

export async function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (!pathname.startsWith("/api")) return NextResponse.next();

  const origin = req.headers.get("origin");
  const headers = corsHeaders(origin);

  // Preflight — answer directly, never reaches a route handler or the rate
  // limiter (OPTIONS requests are free).
  if (req.method === "OPTIONS") {
    return new NextResponse(null, { status: 204, headers });
  }

  const limit = checkRateLimit(req);
  if (!limit.ok) {
    const res = NextResponse.json(
      { success: false, message: "Too many requests — please slow down and try again shortly", errors: [] },
      { status: 429 }
    );
    headers.forEach((value, key) => res.headers.set(key, value));
    res.headers.set("Retry-After", String(limit.retryAfterSeconds));
    securityHeaders(res);
    return res;
  }

  if (!csrfCheck(req).ok) {
    const res = NextResponse.json(
      { success: false, message: "Requests must be sent as application/json", errors: [] },
      { status: 415 }
    );
    headers.forEach((value, key) => res.headers.set(key, value));
    securityHeaders(res);
    return res;
  }

  const res = NextResponse.next();
  headers.forEach((value, key) => res.headers.set(key, value));
  securityHeaders(res);
  return res;
}

export const config = {
  matcher: ["/api/:path*"],
};
