import {
  pgTable,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  uniqueIndex,
  index,
  primaryKey,
} from "drizzle-orm/pg-core";

/**
 * Relational schema for the multi-tenant SaaS platform (Neon PostgreSQL).
 *
 * Design:
 * - Full document shape lives in `data` JSONB (minimal route changes).
 * - Key lookup columns (id, restaurant_id, username, status, …) are real
 *   columns with indexes for efficient tenant-scoped queries.
 */

// ---------------------------------------------------------------------------
// Platform
// ---------------------------------------------------------------------------

export const restaurants = pgTable(
  "restaurants",
  {
    id: text("id").primaryKey(),
    data: jsonb("data").notNull(),
    status: text("status").notNull().default("pending"),
    planId: text("plan_id"),
    subscriptionExpiresAt: timestamp("subscription_expires_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("restaurants_status_idx").on(t.status),
    index("restaurants_plan_idx").on(t.planId),
  ]
);

export const subscriptionPlans = pgTable("subscription_plans", {
  id: text("id").primaryKey(),
  data: jsonb("data").notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const users = pgTable(
  "users",
  {
    id: text("id").primaryKey(),
    restaurantId: text("restaurant_id"), // null = super_admin
    username: text("username").notNull(),
    data: jsonb("data").notNull(),
    role: text("role").notNull(),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    uniqueIndex("users_username_uidx").on(t.username),
    index("users_restaurant_idx").on(t.restaurantId),
    index("users_role_idx").on(t.role),
  ]
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: text("id").primaryKey(),
    restaurantId: text("restaurant_id"),
    data: jsonb("data").notNull(),
    action: text("action").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("audit_logs_restaurant_idx").on(t.restaurantId),
    index("audit_logs_created_idx").on(t.createdAt),
  ]
);

export const loginHistory = pgTable(
  "login_history",
  {
    id: text("id").primaryKey(),
    restaurantId: text("restaurant_id"),
    userId: text("user_id"),
    data: jsonb("data").notNull(),
    success: boolean("success").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    index("login_history_restaurant_idx").on(t.restaurantId),
    index("login_history_user_idx").on(t.userId),
    index("login_history_created_idx").on(t.createdAt),
  ]
);

export const refreshTokens = pgTable(
  "refresh_tokens",
  {
    id: text("id").primaryKey(),
    userId: text("user_id").notNull(),
    tokenHash: text("token_hash").notNull(),
    data: jsonb("data").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
    replacedByTokenId: text("replaced_by_token_id"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    uniqueIndex("refresh_tokens_hash_uidx").on(t.tokenHash),
    index("refresh_tokens_user_idx").on(t.userId),
    index("refresh_tokens_expires_idx").on(t.expiresAt),
  ]
);

export const counters = pgTable("counters", {
  key: text("key").primaryKey(),
  value: integer("value").notNull().default(0),
});

export const singletons = pgTable("singletons", {
  key: text("key").primaryKey(),
  data: jsonb("data").notNull(),
});

// ---------------------------------------------------------------------------
// Tenant-scoped business data
// ---------------------------------------------------------------------------

export const categories = pgTable(
  "categories",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    data: jsonb("data").notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.id] }),
    index("categories_restaurant_idx").on(t.restaurantId),
  ]
);

export const menuItems = pgTable(
  "menu_items",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    categoryId: text("category_id"),
    data: jsonb("data").notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.id] }),
    index("menu_items_restaurant_idx").on(t.restaurantId),
    index("menu_items_category_idx").on(t.restaurantId, t.categoryId),
  ]
);

export const tables = pgTable(
  "tables",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    number: integer("number").notNull(),
    data: jsonb("data").notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.id] }),
    uniqueIndex("tables_restaurant_number_uidx").on(t.restaurantId, t.number),
  ]
);

export const offers = pgTable(
  "offers",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    data: jsonb("data").notNull(),
  },
  (t) => [primaryKey({ columns: [t.restaurantId, t.id] })]
);

export const orders = pgTable(
  "orders",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    status: text("status").notNull(),
    tableNumber: integer("table_number"),
    billGenerated: boolean("bill_generated").notNull().default(false),
    placedAt: timestamp("placed_at", { withTimezone: true }),
    data: jsonb("data").notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.id] }),
    index("orders_status_idx").on(t.restaurantId, t.status),
    index("orders_table_idx").on(t.restaurantId, t.tableNumber),
    index("orders_placed_idx").on(t.restaurantId, t.placedAt),
  ]
);

export const billedOrders = pgTable(
  "billed_orders",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    placedAt: timestamp("placed_at", { withTimezone: true }),
    data: jsonb("data").notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.id] }),
    index("billed_orders_placed_idx").on(t.restaurantId, t.placedAt),
  ]
);

export const soldItems = pgTable(
  "sold_items",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    orderId: text("order_id"),
    itemId: text("item_id"),
    dateKey: text("date_key"),
    monthKey: text("month_key"),
    data: jsonb("data").notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.id] }),
    index("sold_items_order_idx").on(t.restaurantId, t.orderId),
    index("sold_items_item_idx").on(t.restaurantId, t.itemId),
    index("sold_items_date_idx").on(t.restaurantId, t.dateKey),
    index("sold_items_month_idx").on(t.restaurantId, t.monthKey),
  ]
);

export const expenses = pgTable(
  "expenses",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    monthKey: text("month_key"),
    yearKey: text("year_key"),
    date: timestamp("date", { withTimezone: true }),
    data: jsonb("data").notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.id] }),
    index("expenses_month_idx").on(t.restaurantId, t.monthKey),
    index("expenses_year_idx").on(t.restaurantId, t.yearKey),
  ]
);

export const notifications = pgTable(
  "notifications",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    data: jsonb("data").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.id] }),
    index("notifications_created_idx").on(t.restaurantId, t.createdAt),
  ]
);

export const dailyStats = pgTable(
  "daily_stats",
  {
    restaurantId: text("restaurant_id").notNull(),
    dateKey: text("date_key").notNull(),
    data: jsonb("data").notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.dateKey] }),
    index("daily_stats_date_idx").on(t.dateKey),
  ]
);

export const monthlyStats = pgTable(
  "monthly_stats",
  {
    restaurantId: text("restaurant_id").notNull(),
    monthKey: text("month_key").notNull(),
    data: jsonb("data").notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.monthKey] }),
    index("monthly_stats_month_idx").on(t.monthKey),
  ]
);

// ---------------------------------------------------------------------------
// Bulk Menu Import sessions (tenant-scoped)
// ---------------------------------------------------------------------------

export const menuImportSessions = pgTable(
  "menu_import_sessions",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    status: text("status").notNull().default("uploaded"),
    data: jsonb("data").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.id] }),
    index("menu_import_sessions_status_idx").on(t.restaurantId, t.status),
    index("menu_import_sessions_created_idx").on(t.restaurantId, t.createdAt),
  ]
);

// ---------------------------------------------------------------------------
// Menu file uploads (tenant-scoped) — metadata + content reference
// ---------------------------------------------------------------------------

export const menuFiles = pgTable(
  "menu_files",
  {
    id: text("id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    /** Original client filename (sanitized for display). */
    fileName: text("file_name").notNull(),
    /** MIME type, e.g. image/jpeg, application/pdf */
    fileType: text("file_type").notNull(),
    /** Size in bytes */
    fileSize: integer("file_size").notNull(),
    /** SHA-256 hex of file bytes (dedup / integrity) */
    sha256: text("sha256"),
    /** Object-storage key when R2 is configured */
    storageKey: text("storage_key"),
    /** Public or relative URL when available */
    fileUrl: text("file_url"),
    /**
     * Optional inline content (base64) for small files when object storage
     * is unavailable (e.g. Vercel without R2). Prefer storage_key in production.
     */
    contentBase64: text("content_base64"),
    uploadedBy: text("uploaded_by"),
    /** uploaded | processing | ready | failed | deleted */
    status: text("status").notNull().default("uploaded"),
    data: jsonb("data").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.restaurantId, t.id] }),
    index("menu_files_restaurant_idx").on(t.restaurantId),
    index("menu_files_created_idx").on(t.restaurantId, t.createdAt),
    index("menu_files_sha256_idx").on(t.restaurantId, t.sha256),
  ]
);
