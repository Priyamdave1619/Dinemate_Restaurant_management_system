/**
 * Time-window availability for menu items and categories
 * (e.g. Thali / Lunch category 11:00–15:00).
 */

export type TimedEntity = {
  available?: boolean;
  scheduleEnabled?: boolean;
  availableFrom?: string | null;
  availableTo?: string | null;
  name?: string;
};

const HHMM = /^([01]\d|2[0-3]):([0-5]\d)$/;

export function isValidHhMm(value: string | null | undefined): boolean {
  if (!value) return false;
  return HHMM.test(value.trim());
}

export function toMinutes(hhmm: string): number {
  const [h, m] = hhmm.trim().split(":").map(Number);
  return h * 60 + m;
}

/** Inclusive window; supports overnight (22:00 → 02:00). */
export function isWithinWindow(from: string, to: string, now: Date = new Date()): boolean {
  if (!isValidHhMm(from) || !isValidHhMm(to)) return true;
  const current = now.getHours() * 60 + now.getMinutes();
  const start = toMinutes(from);
  const end = toMinutes(to);
  if (start === end) return true;
  if (start < end) return current >= start && current <= end;
  return current >= start || current <= end;
}

/** Entity-level schedule (item or category). Does not check `available` flag for categories. */
export function isScheduleOpenNow(entity: TimedEntity | undefined | null, now: Date = new Date()): boolean {
  if (!entity) return true;
  if (entity.scheduleEnabled && entity.availableFrom && entity.availableTo) {
    return isWithinWindow(entity.availableFrom, entity.availableTo, now);
  }
  return true;
}

/**
 * Is this menu item orderable right now?
 * - item.available === false → no
 * - item schedule closed → no
 * - category schedule closed → no
 */
export function isMenuItemOrderableNow(
  item: TimedEntity | undefined | null,
  now: Date = new Date(),
  category?: TimedEntity | null
): boolean {
  if (!item) return false;
  if (item.available === false) return false;
  if (!isScheduleOpenNow(item, now)) return false;
  if (category && !isScheduleOpenNow(category, now)) return false;
  return true;
}

export function availabilityMessage(
  item: TimedEntity,
  category?: TimedEntity | null
): string {
  const name = item.name || "This item";
  if (item.available === false) return `${name} is currently unavailable`;
  if (item.scheduleEnabled && item.availableFrom && item.availableTo) {
    if (!isWithinWindow(item.availableFrom, item.availableTo)) {
      return `${name} is only available from ${item.availableFrom} to ${item.availableTo}`;
    }
  }
  if (category?.scheduleEnabled && category.availableFrom && category.availableTo) {
    if (!isWithinWindow(category.availableFrom, category.availableTo)) {
      const catName = category.name || "This category";
      return `${name} (${catName}) is only available from ${category.availableFrom} to ${category.availableTo}`;
    }
  }
  return `${name} is not available right now`;
}

export function withAvailabilityFlags<T extends TimedEntity>(
  items: T[],
  now: Date = new Date(),
  categoryById?: Map<string, TimedEntity>
): (T & { availableNow: boolean; outsideSchedule: boolean })[] {
  return items.map((item) => {
    const cat =
      categoryById && "categoryId" in item
        ? categoryById.get((item as { categoryId?: string }).categoryId || "")
        : undefined;
    const availableNow = isMenuItemOrderableNow(item, now, cat);
    const outsideSchedule =
      availableNow === false &&
      item.available !== false &&
      (!isScheduleOpenNow(item, now) || (cat ? !isScheduleOpenNow(cat, now) : false));
    return { ...item, availableNow, outsideSchedule };
  });
}

export function withCategoryAvailabilityFlags<T extends TimedEntity>(
  categories: T[],
  now: Date = new Date()
): (T & { availableNow: boolean; outsideSchedule: boolean })[] {
  return categories.map((c) => {
    const open = isScheduleOpenNow(c, now);
    return {
      ...c,
      availableNow: open,
      outsideSchedule: !open && !!c.scheduleEnabled,
    };
  });
}
