import { tenantDb } from "./db";
import { FoodType, MenuItem, Order, SoldItemRecord } from "@/lib/types";

export interface DateRange { from?: string; to?: string; }

async function loadSoldItems(restaurantId: string, range?: DateRange): Promise<SoldItemRecord[]> {
  const all = await tenantDb(restaurantId).soldItems.all();
  return all.filter((s) => {
    if (range?.from && s.dateKey < range.from) return false;
    if (range?.to && s.dateKey > range.to) return false;
    return true;
  });
}

async function loadBilledOrders(restaurantId: string, range?: DateRange): Promise<Order[]> {
  const all = await tenantDb(restaurantId).billedOrders.all();
  return all.filter((o) => {
    const billed = o.billedAt ?? o.placedAt;
    if (!billed) return true;
    const day = billed.slice(0, 10);
    if (range?.from && day < range.from) return false;
    if (range?.to && day > range.to) return false;
    return true;
  });
}

export interface ItemPerformance {
  itemId: string; itemName: string; categoryId: string; foodType: FoodType;
  quantitySold: number; revenue: number; cost: number; profit: number; orderCount: number;
}

export async function getItemWisePerformance(restaurantId: string, range?: DateRange): Promise<ItemPerformance[]> {
  const items = await loadSoldItems(restaurantId, range);
  const map = new Map<string, ItemPerformance & { orders: Set<string> }>();
  for (const s of items) {
    let row = map.get(s.itemId);
    if (!row) {
      row = { itemId: s.itemId, itemName: s.itemName, categoryId: s.categoryId, foodType: s.foodType as FoodType, quantitySold: 0, revenue: 0, cost: 0, profit: 0, orderCount: 0, orders: new Set() };
      map.set(s.itemId, row);
    }
    row.quantitySold += s.quantity; row.revenue += s.lineRevenue; row.cost += s.lineCost; row.profit += s.lineProfit; row.orders.add(s.orderId);
  }
  return [...map.values()].map(({ orders, ...rest }) => ({ ...rest, orderCount: orders.size })).sort((a, b) => b.quantitySold - a.quantitySold);
}

export async function getBestAndLeastSellers(restaurantId: string, menu: MenuItem[], range?: DateRange, limit = 10) {
  const performance = await getItemWisePerformance(restaurantId, range);
  const sold = new Map(performance.map((p) => [p.itemId, p]));
  const bestSelling = [...performance].sort((a, b) => b.quantitySold - a.quantitySold).slice(0, limit);
  const neverSold: ItemPerformance[] = menu.filter((m) => !sold.has(m.id)).map((m) => ({
    itemId: m.id, itemName: m.name, categoryId: m.categoryId, foodType: m.foodType, quantitySold: 0, revenue: 0, cost: 0, profit: 0, orderCount: 0,
  }));
  const worstOfSold = [...performance].sort((a, b) => a.quantitySold - b.quantitySold);
  return { bestSelling, leastSelling: [...neverSold, ...worstOfSold].slice(0, limit) };
}

export interface CategorySales { categoryId: string; revenue: number; quantitySold: number; profit: number; orderCount: number; }

export async function getCategoryWiseSales(restaurantId: string, range?: DateRange): Promise<CategorySales[]> {
  const items = await loadSoldItems(restaurantId, range);
  const map = new Map<string, CategorySales & { orders: Set<string> }>();
  for (const s of items) {
    let row = map.get(s.categoryId);
    if (!row) { row = { categoryId: s.categoryId, revenue: 0, quantitySold: 0, profit: 0, orderCount: 0, orders: new Set() }; map.set(s.categoryId, row); }
    row.revenue += s.lineRevenue; row.quantitySold += s.quantity; row.profit += s.lineProfit; row.orders.add(s.orderId);
  }
  return [...map.values()].map(({ orders, ...rest }) => ({ ...rest, orderCount: orders.size })).sort((a, b) => b.revenue - a.revenue);
}

export interface FoodTypeSales { foodType: FoodType; revenue: number; quantitySold: number; profit: number; }

export async function getFoodTypeWiseSales(restaurantId: string, range?: DateRange): Promise<FoodTypeSales[]> {
  const items = await loadSoldItems(restaurantId, range);
  const map = new Map<string, FoodTypeSales>();
  for (const s of items) {
    const ft = (s.foodType || "other") as FoodType;
    let row = map.get(ft);
    if (!row) { row = { foodType: ft, revenue: 0, quantitySold: 0, profit: 0 }; map.set(ft, row); }
    row.revenue += s.lineRevenue; row.quantitySold += s.quantity; row.profit += s.lineProfit;
  }
  return [...map.values()].sort((a, b) => b.revenue - a.revenue);
}

export interface HourlySales { hour: number; revenue: number; orderCount: number; }

export async function getPeakHours(restaurantId: string, range?: DateRange): Promise<HourlySales[]> {
  const items = await loadSoldItems(restaurantId, range);
  const map = new Map<number, { revenue: number; orders: Set<string> }>();
  for (const s of items) {
    const hour = s.hour ?? 0;
    let row = map.get(hour);
    if (!row) { row = { revenue: 0, orders: new Set() }; map.set(hour, row); }
    row.revenue += s.lineRevenue; row.orders.add(s.orderId);
  }
  return Array.from({ length: 24 }, (_, hour) => {
    const found = map.get(hour);
    return { hour, revenue: found?.revenue ?? 0, orderCount: found?.orders.size ?? 0 };
  });
}

export interface WeekdaySales { weekday: number; label: string; revenue: number; orderCount: number; }
const WEEKDAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export async function getBusiestWeekdays(restaurantId: string, range?: DateRange): Promise<WeekdaySales[]> {
  const items = await loadSoldItems(restaurantId, range);
  const map = new Map<number, { revenue: number; orders: Set<string> }>();
  for (const s of items) {
    const weekday = s.weekday ?? 0;
    let row = map.get(weekday);
    if (!row) { row = { revenue: 0, orders: new Set() }; map.set(weekday, row); }
    row.revenue += s.lineRevenue; row.orders.add(s.orderId);
  }
  return Array.from({ length: 7 }, (_, weekday) => {
    const found = map.get(weekday);
    return { weekday, label: WEEKDAY_LABELS[weekday], revenue: found?.revenue ?? 0, orderCount: found?.orders.size ?? 0 };
  });
}

export interface CustomerTrends {
  totalUniqueTables: number; repeatCustomerOrders: number; averageItemsPerOrder: number;
  averageOrderValue: number; topTablesByRevenue: { tableNumber: number; revenue: number; orderCount: number }[];
}

export async function getCustomerTrends(restaurantId: string, range?: DateRange): Promise<CustomerTrends> {
  const orders = await loadBilledOrders(restaurantId, range);
  const tables = new Set<number>();
  let totalItems = 0, totalRevenue = 0;
  const byTable = new Map<number, { revenue: number; orderCount: number }>();
  for (const o of orders) {
    tables.add(o.tableNumber);
    totalItems += o.items?.length ?? 0;
    totalRevenue += o.total ?? 0;
    const t = byTable.get(o.tableNumber) ?? { revenue: 0, orderCount: 0 };
    t.revenue += o.total ?? 0; t.orderCount += 1; byTable.set(o.tableNumber, t);
  }
  const topTables = [...byTable.entries()].map(([tableNumber, v]) => ({ tableNumber, ...v })).sort((a, b) => b.revenue - a.revenue).slice(0, 5);
  const repeat = topTables.filter((t) => t.orderCount > 1).reduce((s, t) => s + t.orderCount, 0);
  return {
    totalUniqueTables: tables.size, repeatCustomerOrders: repeat,
    averageItemsPerOrder: orders.length > 0 ? totalItems / orders.length : 0,
    averageOrderValue: orders.length > 0 ? totalRevenue / orders.length : 0,
    topTablesByRevenue: topTables,
  };
}
