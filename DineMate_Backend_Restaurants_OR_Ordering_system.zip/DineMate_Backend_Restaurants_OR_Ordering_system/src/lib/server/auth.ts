import { randomBytes, scryptSync, timingSafeEqual, createHash } from "crypto";
import { SignJWT, jwtVerify } from "jose";
import { UserRole } from "@/lib/types";

function getJwtSecret(): Uint8Array {
  const secret = process.env.AUTH_SECRET;
  if (!secret) {
    if (process.env.NODE_ENV === "production") {
      throw new Error(
        "AUTH_SECRET is not set. Refusing to sign/verify sessions with the insecure dev default in production."
      );
    }
    return new TextEncoder().encode("dinemate-dev-secret-change-me");
  }
  return new TextEncoder().encode(secret);
}

export const SESSION_COOKIE = "dinemate_session";
export const REFRESH_COOKIE = "dinemate_refresh";

// Access tokens are short-lived by design — the whole point of the
// refresh-token pattern is that a stolen/leaked access token is only
// useful for a short window, while the long-lived refresh token stays
// server-side-revocable (see refresh-tokens.ts) rather than living as a
// bearer credential in the browser for hours at a time.
export const ACCESS_TOKEN_TTL = "15m";
export const REFRESH_TOKEN_TTL_DAYS = 30;

export function hashPassword(password: string): { hash: string; salt: string } {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return { hash, salt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const candidate = scryptSync(password, salt, 64);
  const stored = Buffer.from(hash, "hex");
  if (candidate.length !== stored.length) return false;
  return timingSafeEqual(candidate, stored);
}

export interface SessionPayload {
  sub: string; // user id
  username: string;
  name: string;
  role: UserRole;
  /** null for super_admin — every restaurant-scoped role always has one. */
  restaurantId: string | null;
}

export async function createSessionToken(payload: SessionPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(ACCESS_TOKEN_TTL)
    .sign(getJwtSecret());
}

export async function verifySessionToken(token: string): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, getJwtSecret());
    return payload as unknown as SessionPayload;
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Refresh tokens — opaque random values, never stored in plaintext. Only
// their SHA-256 hash lives in MongoDB (see refresh-tokens.ts), the same
// principle as password hashing: a database leak alone should never be
// enough to impersonate a session.
// ---------------------------------------------------------------------------

export function generateRefreshTokenValue(): string {
  return randomBytes(48).toString("base64url");
}

export function hashRefreshToken(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

/** Shared cookie attributes for both the access-token and refresh-token
 * cookies — kept in one place so login/refresh/logout can't drift out of
 * sync with each other on SameSite/Secure/domain handling. */
export function authCookieOptions(maxAgeSeconds: number) {
  return {
    httpOnly: true,
    // The admin/waiter/kitchen/customer sites live on different origins
    // than this API, so the cookie must be sent cross-site — that requires
    // SameSite=None, which browsers only honor when Secure is also set.
    // For local dev over plain http, set AUTH_COOKIE_INSECURE=1 to fall
    // back to sameSite:"lax" so login still works without HTTPS.
    sameSite: (process.env.AUTH_COOKIE_INSECURE ? "lax" : "none") as "lax" | "none",
    secure: !process.env.AUTH_COOKIE_INSECURE,
    // If every frontend + this API share a parent domain (e.g.
    // admin.example.com / api.example.com both under example.com), set
    // COOKIE_DOMAIN=.example.com so the one cookie is valid on all of them
    // without relying on cross-site SameSite=None at all.
    domain: process.env.COOKIE_DOMAIN || undefined,
    path: "/",
    maxAge: maxAgeSeconds,
  };
}
