import { eq, and, gte, lte } from "drizzle-orm";
import { drizzleDb } from "./pg-store";
import * as schema from "./schema";
import { DailyStats, MonthlyStats, PeriodTotals, WeeklyStats, YearlyStats } from "@/lib/types";

const ZERO_TOTALS: PeriodTotals = {
  grossSales: 0, discountTotal: 0, netSales: 0, taxTotal: 0, totalCollected: 0,
  cogsTotal: 0, grossProfit: 0, orderCount: 0, itemsSold: 0,
};

function sumTotals(rows: PeriodTotals[]): PeriodTotals {
  return rows.reduce<PeriodTotals>(
    (acc, r) => ({
      grossSales: acc.grossSales + r.grossSales,
      discountTotal: acc.discountTotal + r.discountTotal,
      netSales: acc.netSales + r.netSales,
      taxTotal: acc.taxTotal + r.taxTotal,
      totalCollected: acc.totalCollected + r.totalCollected,
      cogsTotal: acc.cogsTotal + r.cogsTotal,
      grossProfit: acc.grossProfit + r.grossProfit,
      orderCount: acc.orderCount + r.orderCount,
      itemsSold: acc.itemsSold + r.itemsSold,
    }),
    { ...ZERO_TOTALS }
  );
}

function rowToDaily(row: { data: unknown; restaurantId: string; dateKey: string }): DailyStats {
  return { ...(row.data as DailyStats), restaurantId: row.restaurantId, dateKey: row.dateKey };
}
function rowToMonthly(row: { data: unknown; restaurantId: string; monthKey: string }): MonthlyStats {
  return { ...(row.data as MonthlyStats), restaurantId: row.restaurantId, monthKey: row.monthKey };
}

export async function getDailyStats(restaurantId: string, dateKey: string): Promise<DailyStats | null> {
  const rows = await drizzleDb.select().from(schema.dailyStats)
    .where(and(eq(schema.dailyStats.restaurantId, restaurantId), eq(schema.dailyStats.dateKey, dateKey))).limit(1);
  return rows[0] ? rowToDaily(rows[0]) : null;
}

export async function listDailyStats(restaurantId: string, from?: string, to?: string): Promise<DailyStats[]> {
  const conditions = [eq(schema.dailyStats.restaurantId, restaurantId)];
  if (from) conditions.push(gte(schema.dailyStats.dateKey, from));
  if (to) conditions.push(lte(schema.dailyStats.dateKey, to));
  const rows = await drizzleDb.select().from(schema.dailyStats).where(and(...conditions)).orderBy(schema.dailyStats.dateKey);
  return rows.map(rowToDaily);
}

export async function getWeeklyStats(restaurantId: string, weekKey: string): Promise<WeeklyStats> {
  const rows = await drizzleDb.select().from(schema.dailyStats).where(eq(schema.dailyStats.restaurantId, restaurantId));
  const days = rows.map(rowToDaily).filter((d) => (d as DailyStats & { weekKey?: string }).weekKey === weekKey);
  return { weekKey, updatedAt: new Date().toISOString(), ...sumTotals(days) };
}

export async function getMonthlyStats(restaurantId: string, monthKey: string): Promise<MonthlyStats | null> {
  const rows = await drizzleDb.select().from(schema.monthlyStats)
    .where(and(eq(schema.monthlyStats.restaurantId, restaurantId), eq(schema.monthlyStats.monthKey, monthKey))).limit(1);
  return rows[0] ? rowToMonthly(rows[0]) : null;
}

export async function listMonthlyStats(restaurantId: string, yearKey?: string): Promise<MonthlyStats[]> {
  const rows = await drizzleDb.select().from(schema.monthlyStats)
    .where(eq(schema.monthlyStats.restaurantId, restaurantId)).orderBy(schema.monthlyStats.monthKey);
  const all = rows.map(rowToMonthly);
  if (!yearKey) return all;
  return all.filter((m) => (m as MonthlyStats & { yearKey?: string }).yearKey === yearKey);
}

export async function getYearlyStats(restaurantId: string, yearKey: string): Promise<YearlyStats> {
  const months = await listMonthlyStats(restaurantId, yearKey);
  return { yearKey, updatedAt: new Date().toISOString(), ...sumTotals(months) };
}

export async function listYears(restaurantId: string): Promise<string[]> {
  const months = await listMonthlyStats(restaurantId);
  const years = new Set<string>();
  for (const m of months) {
    const y = (m as { yearKey?: string }).yearKey || m.monthKey?.slice(0, 4);
    if (y) years.add(y);
  }
  return Array.from(years).sort();
}
