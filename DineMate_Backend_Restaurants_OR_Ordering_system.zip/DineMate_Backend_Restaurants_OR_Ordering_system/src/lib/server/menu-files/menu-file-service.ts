/**
 * Menu file upload service — validate, store metadata (+ content ref) in Postgres.
 * No OCR / extraction — upload and persistence only.
 */

import { createHash, randomUUID } from "crypto";
import { eq, and, desc } from "drizzle-orm";
import { MenuFileRecord, MenuFileStatus } from "@/lib/types";
import { writeStoredFile, isR2Configured } from "@/lib/server/storage";
import { drizzleDb } from "@/lib/server/pg-store";
import * as schema from "@/lib/server/schema";

const MAX_IMAGE_BYTES = 15 * 1024 * 1024;
const MAX_PDF_BYTES = 50 * 1024 * 1024;
const MAX_INLINE_BASE64_BYTES = 4 * 1024 * 1024;

const ALLOWED_EXT = new Set([
  ".jpg",
  ".jpeg",
  ".png",
  ".webp",
  ".gif",
  ".bmp",
  ".pdf",
]);

const ALLOWED_MIME = new Set([
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
  "image/gif",
  "image/bmp",
  "application/pdf",
]);

function extOf(name: string): string {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i).toLowerCase() : "";
}

function sanitizeFileName(name: string): string {
  return name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 180) || "menu-file";
}

export function validateMenuUploadFile(
  fileName: string,
  mimeType: string,
  size: number
): { ok: true } | { ok: false; error: string } {
  const ext = extOf(fileName);
  if (!ALLOWED_EXT.has(ext) && !ALLOWED_MIME.has(mimeType)) {
    return {
      ok: false,
      error: `Unsupported file type. Allowed: JPG, PNG, WebP, GIF, BMP, PDF (got ${mimeType || ext || "unknown"})`,
    };
  }
  const isPdf = mimeType === "application/pdf" || ext === ".pdf";
  const max = isPdf ? MAX_PDF_BYTES : MAX_IMAGE_BYTES;
  if (size <= 0) return { ok: false, error: "Empty file" };
  if (size > max) {
    return {
      ok: false,
      error: `File exceeds maximum size of ${Math.round(max / 1024 / 1024)} MB`,
    };
  }
  return { ok: true };
}

function rowToRecord(row: typeof schema.menuFiles.$inferSelect): MenuFileRecord {
  const data = (row.data || {}) as Record<string, unknown>;
  return {
    id: row.id,
    restaurantId: row.restaurantId,
    fileName: row.fileName || String(data.fileName || ""),
    fileType: row.fileType || String(data.fileType || ""),
    fileSize: row.fileSize ?? Number(data.fileSize || 0),
    sha256: row.sha256 || (data.sha256 as string) || undefined,
    storageKey: row.storageKey || (data.storageKey as string) || undefined,
    fileUrl: row.fileUrl || (data.fileUrl as string) || undefined,
    contentBase64: row.contentBase64 || (data.contentBase64 as string) || undefined,
    uploadedBy: row.uploadedBy || (data.uploadedBy as string) || undefined,
    status: (row.status as MenuFileStatus) || "uploaded",
    createdAt: row.createdAt?.toISOString?.() || String(data.createdAt || new Date().toISOString()),
    updatedAt: row.updatedAt?.toISOString?.() || String(data.updatedAt || new Date().toISOString()),
  };
}

/** Public API shape — never includes contentBase64 */
export function toPublicMenuFile(rec: MenuFileRecord) {
  return {
    id: rec.id,
    restaurantId: rec.restaurantId,
    fileName: rec.fileName,
    fileType: rec.fileType,
    fileSize: rec.fileSize,
    sha256: rec.sha256,
    storageKey: rec.storageKey,
    fileUrl: rec.fileUrl,
    hasContent: !!(rec.contentBase64 || rec.storageKey),
    uploadedBy: rec.uploadedBy,
    status: rec.status,
    createdAt: rec.createdAt,
    updatedAt: rec.updatedAt,
  };
}

export async function saveMenuFile(input: {
  restaurantId: string;
  uploadedBy: string;
  fileName: string;
  mimeType: string;
  buffer: Buffer;
}): Promise<MenuFileRecord> {
  const check = validateMenuUploadFile(input.fileName, input.mimeType, input.buffer.length);
  if (!check.ok) throw new Error(check.error);

  const id = `mf-${randomUUID()}`;
  const now = new Date();
  const sha256 = createHash("sha256").update(input.buffer).digest("hex");
  const safeName = sanitizeFileName(input.fileName);
  const storageKey = `menu-files/${input.restaurantId}/${id}/${sha256.slice(0, 16)}-${safeName}`;

  let fileUrl: string | undefined;
  let contentBase64: string | undefined;

  try {
    fileUrl = await writeStoredFile(storageKey, input.buffer, input.mimeType);
  } catch {
    // Serverless without R2: keep inline bytes for retrieval
    if (input.buffer.length <= MAX_INLINE_BASE64_BYTES) {
      contentBase64 = input.buffer.toString("base64");
    } else {
      throw new Error(
        "Could not store file. Configure R2 object storage, or upload a file smaller than 4 MB."
      );
    }
  }

  // Always inline small files when R2 is not configured so process survives cold starts
  if (!isR2Configured() && !contentBase64 && input.buffer.length <= MAX_INLINE_BASE64_BYTES) {
    contentBase64 = input.buffer.toString("base64");
  }

  const record: MenuFileRecord = {
    id,
    restaurantId: input.restaurantId,
    fileName: input.fileName.slice(0, 255),
    fileType: input.mimeType || "application/octet-stream",
    fileSize: input.buffer.length,
    sha256,
    storageKey,
    fileUrl,
    contentBase64,
    uploadedBy: input.uploadedBy,
    status: "uploaded",
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
  };

  await drizzleDb.insert(schema.menuFiles).values({
    id: record.id,
    restaurantId: record.restaurantId,
    fileName: record.fileName,
    fileType: record.fileType,
    fileSize: record.fileSize,
    sha256: record.sha256 ?? null,
    storageKey: record.storageKey ?? null,
    fileUrl: record.fileUrl ?? null,
    contentBase64: record.contentBase64 ?? null,
    uploadedBy: record.uploadedBy ?? null,
    status: record.status,
    data: record as unknown as Record<string, unknown>,
    createdAt: now,
    updatedAt: now,
  });

  return record;
}

export async function listMenuFiles(
  restaurantId: string,
  opts?: { limit?: number; offset?: number }
): Promise<{ files: ReturnType<typeof toPublicMenuFile>[]; total: number }> {
  const limit = Math.min(Math.max(opts?.limit ?? 50, 1), 200);
  const offset = Math.max(opts?.offset ?? 0, 0);

  const rows = await drizzleDb
    .select()
    .from(schema.menuFiles)
    .where(and(eq(schema.menuFiles.restaurantId, restaurantId), eq(schema.menuFiles.status, "uploaded")))
    .orderBy(desc(schema.menuFiles.createdAt))
    .limit(limit)
    .offset(offset);

  // Approximate total for this page query scope
  const all = await drizzleDb
    .select({ id: schema.menuFiles.id })
    .from(schema.menuFiles)
    .where(and(eq(schema.menuFiles.restaurantId, restaurantId), eq(schema.menuFiles.status, "uploaded")));

  return {
    files: rows.map((r) => toPublicMenuFile(rowToRecord(r))),
    total: all.length,
  };
}

export async function getMenuFile(
  restaurantId: string,
  fileId: string,
  opts?: { includeContent?: boolean }
): Promise<MenuFileRecord | null> {
  const rows = await drizzleDb
    .select()
    .from(schema.menuFiles)
    .where(and(eq(schema.menuFiles.restaurantId, restaurantId), eq(schema.menuFiles.id, fileId)))
    .limit(1);
  if (!rows[0]) return null;
  const rec = rowToRecord(rows[0]);
  if (!opts?.includeContent) {
    delete rec.contentBase64;
  }
  return rec;
}

export async function deleteMenuFile(restaurantId: string, fileId: string): Promise<boolean> {
  const existing = await getMenuFile(restaurantId, fileId);
  if (!existing) return false;
  // Soft-delete
  await drizzleDb
    .update(schema.menuFiles)
    .set({
      status: "deleted",
      contentBase64: null,
      updatedAt: new Date(),
      data: { ...existing, status: "deleted", contentBase64: undefined, updatedAt: new Date().toISOString() },
    })
    .where(and(eq(schema.menuFiles.restaurantId, restaurantId), eq(schema.menuFiles.id, fileId)));
  return true;
}
