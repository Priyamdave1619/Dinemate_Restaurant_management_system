/**
 * Secure storage helpers for platform secrets (e.g. Groq API token).
 * Values are encrypted at rest with AES-256-GCM using a key derived from
 * AUTH_SECRET (or SECRETS_ENCRYPTION_KEY when set).
 *
 * Never log decrypted values. API responses only expose masked hints.
 */

import { createCipheriv, createDecipheriv, createHash, randomBytes } from "crypto";
import { readSingleton, writeSingleton } from "./pg-store";

const ALGO = "aes-256-gcm";
const IV_LEN = 12;
const TAG_LEN = 16;

export interface PlatformAiConfig {
  /** Encrypted Groq API key (base64: iv + tag + ciphertext). Empty = not set in DB. */
  groqApiKeyEnc?: string;
  /** Last 4 chars of the key for UI display (never the full key). */
  groqApiKeyHint?: string;
  /** Vision model id, e.g. qwen/qwen3.6-27b */
  groqVisionModel?: string;
  /** When true, menu-import uses Groq for images when a key is available. */
  groqEnabled?: boolean;
  updatedAt?: string;
  updatedBy?: string;
}

function encryptionKey(): Buffer {
  const raw =
    process.env.SECRETS_ENCRYPTION_KEY ||
    process.env.AUTH_SECRET ||
    "dinemate-dev-secret-change-me";
  return createHash("sha256").update(raw).digest();
}

export function encryptSecret(plain: string): string {
  const iv = randomBytes(IV_LEN);
  const cipher = createCipheriv(ALGO, encryptionKey(), iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, enc]).toString("base64");
}

export function decryptSecret(payload: string): string {
  const buf = Buffer.from(payload, "base64");
  if (buf.length < IV_LEN + TAG_LEN + 1) throw new Error("Invalid encrypted payload");
  const iv = buf.subarray(0, IV_LEN);
  const tag = buf.subarray(IV_LEN, IV_LEN + TAG_LEN);
  const data = buf.subarray(IV_LEN + TAG_LEN);
  const decipher = createDecipheriv(ALGO, encryptionKey(), iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8");
}

function hintFromKey(key: string): string {
  const trimmed = key.trim();
  if (trimmed.length < 8) return "****";
  return `…${trimmed.slice(-4)}`;
}

const SINGLETON_KEY = "platform:ai_config";

const DEFAULT_CONFIG: PlatformAiConfig = {
  groqEnabled: true,
  groqVisionModel: "qwen/qwen3.6-27b",
};

export async function getPlatformAiConfig(): Promise<PlatformAiConfig> {
  const stored = await readSingleton<PlatformAiConfig>(SINGLETON_KEY, DEFAULT_CONFIG);
  return { ...DEFAULT_CONFIG, ...stored };
}

/**
 * Resolve the usable Groq API key: env wins (ops override), else decrypted DB value.
 */
export async function resolveGroqApiKey(): Promise<string | null> {
  const fromEnv = (process.env.GROQ_API_KEY || "").trim();
  if (fromEnv) return fromEnv;

  const cfg = await getPlatformAiConfig();
  if (!cfg.groqApiKeyEnc) return null;
  try {
    const plain = decryptSecret(cfg.groqApiKeyEnc).trim();
    return plain || null;
  } catch {
    return null;
  }
}

export async function resolveGroqVisionModel(): Promise<string> {
  const fromEnv = (process.env.GROQ_VISION_MODEL || "").trim();
  if (fromEnv) return fromEnv;
  const cfg = await getPlatformAiConfig();
  return cfg.groqVisionModel || DEFAULT_CONFIG.groqVisionModel!;
}

export async function isGroqExtractionEnabled(): Promise<boolean> {
  const cfg = await getPlatformAiConfig();
  if (cfg.groqEnabled === false) return false;
  const key = await resolveGroqApiKey();
  return !!key;
}

export type SafeAiConfigPublic = {
  groqConfigured: boolean;
  groqSource: "env" | "database" | "none";
  groqApiKeyHint: string | null;
  groqVisionModel: string;
  groqEnabled: boolean;
};

export async function getSafeAiConfigPublic(): Promise<SafeAiConfigPublic> {
  const cfg = await getPlatformAiConfig();
  const fromEnv = !!(process.env.GROQ_API_KEY || "").trim();
  let fromDb = false;
  if (cfg.groqApiKeyEnc) {
    try {
      fromDb = !!decryptSecret(cfg.groqApiKeyEnc).trim();
    } catch {
      fromDb = false;
    }
  }
  return {
    groqConfigured: fromEnv || fromDb,
    groqSource: fromEnv ? "env" : fromDb ? "database" : "none",
    groqApiKeyHint: fromEnv ? "env:****" : cfg.groqApiKeyHint || null,
    groqVisionModel: cfg.groqVisionModel || DEFAULT_CONFIG.groqVisionModel!,
    groqEnabled: cfg.groqEnabled !== false,
  };
}

export async function updatePlatformAiConfig(input: {
  groqApiKey?: string | null;
  groqVisionModel?: string;
  groqEnabled?: boolean;
  updatedBy?: string;
}): Promise<SafeAiConfigPublic> {
  const current = await getPlatformAiConfig();
  const next: PlatformAiConfig = { ...current };

  if (input.groqApiKey !== undefined) {
    if (input.groqApiKey === null || input.groqApiKey === "") {
      next.groqApiKeyEnc = undefined;
      next.groqApiKeyHint = undefined;
    } else {
      const key = input.groqApiKey.trim();
      if (key.length < 20) throw new Error("Groq API key looks invalid (too short)");
      next.groqApiKeyEnc = encryptSecret(key);
      next.groqApiKeyHint = hintFromKey(key);
    }
  }

  if (typeof input.groqVisionModel === "string" && input.groqVisionModel.trim()) {
    next.groqVisionModel = input.groqVisionModel.trim();
  }
  if (typeof input.groqEnabled === "boolean") {
    next.groqEnabled = input.groqEnabled;
  }
  next.updatedAt = new Date().toISOString();
  if (input.updatedBy) next.updatedBy = input.updatedBy;

  await writeSingleton(SINGLETON_KEY, next);
  return getSafeAiConfigPublic();
}

/**
 * Live connectivity check against Groq (models list).
 * Does not send the API key in the response.
 */
export async function testGroqConnection(): Promise<{
  ok: boolean;
  model: string;
  source: "env" | "database" | "none";
  message: string;
  latencyMs?: number;
}> {
  const publicCfg = await getSafeAiConfigPublic();
  const key = await resolveGroqApiKey();
  const model = await resolveGroqVisionModel();

  if (!key) {
    return {
      ok: false,
      model,
      source: publicCfg.groqSource,
      message: "No Groq API key configured (set GROQ_API_KEY env or store via /api/platform/ai-config).",
    };
  }
  if (publicCfg.groqEnabled === false) {
    return {
      ok: false,
      model,
      source: publicCfg.groqSource,
      message: "Groq is disabled in platform AI config (groqEnabled=false).",
    };
  }

  const started = Date.now();
  try {
    const res = await fetch("https://api.groq.com/openai/v1/models", {
      method: "GET",
      headers: { Authorization: `Bearer ${key}`, Accept: "application/json" },
    });
    const latencyMs = Date.now() - started;
    if (res.status === 401 || res.status === 403) {
      return {
        ok: false,
        model,
        source: publicCfg.groqSource,
        message: "Groq rejected the API key (invalid or revoked).",
        latencyMs,
      };
    }
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      return {
        ok: false,
        model,
        source: publicCfg.groqSource,
        message: `Groq API error HTTP ${res.status}${body ? `: ${body.slice(0, 120)}` : ""}`,
        latencyMs,
      };
    }
    return {
      ok: true,
      model,
      source: publicCfg.groqSource,
      message: `Connected to Groq successfully. Vision model: ${model}`,
      latencyMs,
    };
  } catch (e) {
    return {
      ok: false,
      model,
      source: publicCfg.groqSource,
      message: e instanceof Error ? e.message : "Network error reaching Groq",
      latencyMs: Date.now() - started,
    };
  }
}
