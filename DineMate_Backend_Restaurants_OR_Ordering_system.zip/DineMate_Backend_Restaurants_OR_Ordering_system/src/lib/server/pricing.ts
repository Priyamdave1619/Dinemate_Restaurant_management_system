import { AppliedOffer, MenuItem, Offer, OrderItem } from "@/lib/types";
import { isOfferLive } from "@/lib/server/offer-live";

export interface PricingResult {
  subtotal: number;
  appliedOffers: AppliedOffer[];
  offerDiscount: number;
  manualDiscountAmount: number;
  discountTotal: number;
  taxableAmount: number;
  taxAmount: number;
  total: number;
}

function itemInScope(item: OrderItem, offer: Offer, menuById: Map<string, MenuItem>): boolean {
  if (offer.excludeItemIds?.includes(item.itemId)) return false;

  const itemIds = [
    ...(offer.itemIds || []),
    ...(offer.itemId ? [offer.itemId] : []),
  ];
  const categoryIds = [
    ...(offer.categoryIds || []),
    ...(offer.categoryId ? [offer.categoryId] : []),
  ];

  if (itemIds.length === 0 && categoryIds.length === 0) {
    // Whole-cart offer
    return true;
  }
  if (itemIds.includes(item.itemId)) return true;
  if (categoryIds.length > 0) {
    const menuItem = menuById.get(item.itemId);
    if (menuItem && categoryIds.includes(menuItem.categoryId)) return true;
  }
  return false;
}

function scopedSubtotal(items: OrderItem[], offer: Offer, menuById: Map<string, MenuItem>): number {
  return items
    .filter((i) => itemInScope(i, offer, menuById))
    .reduce((s, i) => s + i.price * i.quantity, 0);
}

function capDiscount(amount: number, offer: Offer, base: number): number {
  let a = Math.max(0, Math.min(amount, base));
  if (offer.maxDiscountAmount != null) a = Math.min(a, offer.maxDiscountAmount);
  return Math.round(a);
}

function computeOfferAmount(
  offer: Offer,
  items: OrderItem[],
  subtotal: number,
  menuById: Map<string, MenuItem>
): number {
  const scoped = scopedSubtotal(items, offer, menuById);

  if (offer.type === "bogo" && offer.buyQty && offer.getQty) {
    const matching = items.filter((i) => itemInScope(i, offer, menuById));
    const totalQty = matching.reduce((s, i) => s + i.quantity, 0);
    if (totalQty <= 0) return 0;
    const groupSize = offer.buyQty + offer.getQty;
    const groups = Math.floor(totalQty / groupSize);
    const freeUnits = groups * offer.getQty;
    if (freeUnits <= 0) return 0;
    const cheapest = Math.min(...matching.map((i) => i.price));
    return capDiscount(freeUnits * cheapest, offer, scoped || subtotal);
  }

  if (offer.minOrderAmount && subtotal < offer.minOrderAmount) return 0;

  if (offer.type === "flat" && offer.discountAmount) {
    return capDiscount(offer.discountAmount, offer, scoped || subtotal);
  }

  // percent / happy_hour / category / item / combo / coupon
  if (offer.discountPercent != null && offer.discountPercent > 0) {
    const base = scoped > 0 ? scoped : subtotal;
    return capDiscount((base * offer.discountPercent) / 100, offer, base);
  }
  if (offer.discountAmount != null && offer.discountAmount > 0) {
    const base = scoped > 0 ? scoped : subtotal;
    return capDiscount(offer.discountAmount, offer, base);
  }

  return 0;
}

/**
 * Applies active, live offers to order items.
 * - Non-stackable offers: only the highest-value one among non-stackable set is kept
 * - Stackable offers: all eligible apply
 * - Coupon-only offers (autoApply === false with couponCode) are skipped unless couponCodes includes the code
 */
export function priceOrder(
  items: OrderItem[],
  offers: Offer[],
  menu: MenuItem[],
  manualDiscountPercent: number,
  taxRatePercent: number,
  opts?: { couponCodes?: string[]; now?: Date }
): PricingResult {
  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const menuById = new Map(menu.map((m) => [m.id, m]));
  const now = opts?.now ?? new Date();
  const coupons = new Set((opts?.couponCodes || []).map((c) => c.trim().toUpperCase()).filter(Boolean));

  const candidates = offers
    .filter((o) => isOfferLive(o, now))
    .filter((o) => {
      // Manual coupon required
      if (o.couponCode && o.autoApply === false) {
        return coupons.has(o.couponCode.toUpperCase());
      }
      // Coupon type with code — auto if autoApply true/undefined, else need code
      if (o.type === "coupon" && o.couponCode && o.autoApply === false) {
        return coupons.has(o.couponCode.toUpperCase());
      }
      return true;
    })
    .sort((a, b) => (b.priority ?? 0) - (a.priority ?? 0));

  const appliedOffers: AppliedOffer[] = [];
  let offerDiscount = 0;
  let usedNonStackable = false;

  for (const offer of candidates) {
    const stackable = offer.stackable !== false; // default stackable true for backward compat
    if (!stackable && usedNonStackable) continue;

    const amount = computeOfferAmount(offer, items, subtotal, menuById);
    if (amount <= 0) continue;

    // Don't exceed remaining subtotal
    const remaining = Math.max(0, subtotal - offerDiscount);
    const applied = Math.min(amount, remaining);
    if (applied <= 0) continue;

    offerDiscount += applied;
    appliedOffers.push({ offerId: offer.id, name: offer.name, amount: applied });

    if (!stackable) usedNonStackable = true;
  }

  const afterOffers = Math.max(0, subtotal - offerDiscount);
  const manualDiscountAmount = Math.round((afterOffers * Math.max(0, Math.min(100, manualDiscountPercent || 0))) / 100);
  const discountTotal = offerDiscount + manualDiscountAmount;
  const taxableAmount = Math.max(0, subtotal - discountTotal);
  const taxAmount = Math.round((taxableAmount * taxRatePercent) / 100);
  const total = taxableAmount + taxAmount;

  return {
    subtotal,
    appliedOffers,
    offerDiscount,
    manualDiscountAmount,
    discountTotal,
    taxableAmount,
    taxAmount,
    total,
  };
}
