import { describe, it, expect, beforeEach, afterEach } from "vitest";
import { createHmac } from "crypto";
import { verifyCheckoutSignature, verifyWebhookSignature } from "../payments";

const ORIGINAL_ENV = { ...process.env };

describe("verifyCheckoutSignature", () => {
  beforeEach(() => {
    process.env.RAZORPAY_KEY_SECRET = "test-key-secret";
  });
  afterEach(() => {
    process.env = { ...ORIGINAL_ENV };
  });

  function sign(orderId: string, paymentId: string, secret = "test-key-secret") {
    return createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex");
  }

  it("accepts a correctly signed order_id|payment_id pair", () => {
    const sig = sign("order_123", "pay_456");
    expect(verifyCheckoutSignature("order_123", "pay_456", sig)).toBe(true);
  });

  it("rejects a signature computed with the wrong secret (forged by an attacker who doesn't have the real key)", () => {
    const forged = sign("order_123", "pay_456", "attacker-guessed-secret");
    expect(verifyCheckoutSignature("order_123", "pay_456", forged)).toBe(false);
  });

  it("rejects a valid signature applied to a DIFFERENT order/payment id (replay-style tampering)", () => {
    const sig = sign("order_123", "pay_456");
    expect(verifyCheckoutSignature("order_999", "pay_456", sig)).toBe(false);
    expect(verifyCheckoutSignature("order_123", "pay_999", sig)).toBe(false);
  });

  it("rejects garbage/non-hex signatures without throwing", () => {
    expect(() => verifyCheckoutSignature("order_123", "pay_456", "not-a-valid-signature!!!")).not.toThrow();
    expect(verifyCheckoutSignature("order_123", "pay_456", "not-a-valid-signature!!!")).toBe(false);
  });

  it("rejects an empty signature", () => {
    expect(verifyCheckoutSignature("order_123", "pay_456", "")).toBe(false);
  });

  it("fails closed (returns false, never throws) if RAZORPAY_KEY_SECRET isn't configured", () => {
    delete process.env.RAZORPAY_KEY_SECRET;
    expect(verifyCheckoutSignature("order_123", "pay_456", sign("order_123", "pay_456"))).toBe(false);
  });
});

describe("verifyWebhookSignature", () => {
  beforeEach(() => {
    process.env.RAZORPAY_WEBHOOK_SECRET = "test-webhook-secret";
  });
  afterEach(() => {
    process.env = { ...ORIGINAL_ENV };
  });

  function sign(body: string, secret = "test-webhook-secret") {
    return createHmac("sha256", secret).update(body).digest("hex");
  }

  it("accepts a correctly signed raw body", () => {
    const body = JSON.stringify({ event: "payment.captured", payload: { payment: { entity: { notes: {} } } } });
    expect(verifyWebhookSignature(body, sign(body))).toBe(true);
  });

  it("REJECTS a body that was re-serialized/reformatted even though the content is semantically identical — this is exactly why the webhook route must sign the raw text, not JSON.parse then re-stringify", () => {
    const original = '{"event":"payment.captured","amount":100}';
    const reformatted = '{ "event": "payment.captured", "amount": 100 }'; // same data, different bytes
    const sig = sign(original);
    expect(verifyWebhookSignature(reformatted, sig)).toBe(false);
  });

  it("rejects a tampered body (e.g. an attacker changing the amount after the fact)", () => {
    const original = '{"event":"payment.captured","amount":100}';
    const tampered = '{"event":"payment.captured","amount":999999}';
    const sig = sign(original);
    expect(verifyWebhookSignature(tampered, sig)).toBe(false);
  });

  it("rejects a signature forged without the real webhook secret", () => {
    const body = '{"event":"payment.captured"}';
    const forged = sign(body, "wrong-secret");
    expect(verifyWebhookSignature(body, forged)).toBe(false);
  });

  it("fails closed if RAZORPAY_WEBHOOK_SECRET isn't configured", () => {
    delete process.env.RAZORPAY_WEBHOOK_SECRET;
    const body = '{"event":"payment.captured"}';
    expect(verifyWebhookSignature(body, sign(body))).toBe(false);
  });
});
