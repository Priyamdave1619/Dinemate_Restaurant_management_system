import { describe, it, expect } from "vitest";
import { priceOrder } from "../pricing";
import { MenuItem, Offer, OrderItem } from "@/lib/types";

function item(overrides: Partial<OrderItem> = {}): OrderItem {
  return { id: "oi-1", itemId: "item-1", name: "Test Item", quantity: 1, price: 100, ...overrides };
}

describe("priceOrder — basics", () => {
  it("computes a plain subtotal + tax with no offers or discounts", () => {
    const result = priceOrder([item({ quantity: 2, price: 100 })], [], [], 0, 5);
    expect(result.subtotal).toBe(200);
    expect(result.discountTotal).toBe(0);
    expect(result.taxableAmount).toBe(200);
    expect(result.taxAmount).toBe(10); // 5% of 200
    expect(result.total).toBe(210);
  });

  it("sums multiple line items correctly", () => {
    const result = priceOrder(
      [item({ id: "1", price: 90, quantity: 1 }), item({ id: "2", price: 60, quantity: 2 })],
      [],
      [],
      0,
      0
    );
    expect(result.subtotal).toBe(90 + 120);
  });

  it("zero tax rate produces zero tax", () => {
    const result = priceOrder([item({ price: 500, quantity: 1 })], [], [], 0, 0);
    expect(result.taxAmount).toBe(0);
    expect(result.total).toBe(500);
  });
});

describe("priceOrder — manual discount", () => {
  it("applies a manual discount percentage, and tax is charged on the post-discount amount", () => {
    const result = priceOrder([item({ price: 1000, quantity: 1 })], [], [], 10, 5);
    // 10% off 1000 = 100 discount -> taxable 900 -> 5% tax = 45
    expect(result.manualDiscountAmount).toBe(100);
    expect(result.taxableAmount).toBe(900);
    expect(result.taxAmount).toBe(45);
    expect(result.total).toBe(945);
  });

  it("100% manual discount results in zero tax and zero total", () => {
    const result = priceOrder([item({ price: 500, quantity: 1 })], [], [], 100, 18);
    expect(result.taxableAmount).toBe(0);
    expect(result.taxAmount).toBe(0);
    expect(result.total).toBe(0);
  });
});

describe("priceOrder — percent offer", () => {
  const percentOffer: Offer = {
    id: "offer-1",
    restaurantId: "REST_A",
    name: "10% off",
    type: "percent",
    active: true,
    discountPercent: 10,
    createdAt: new Date().toISOString(),
  };

  it("applies a percent discount off the subtotal", () => {
    const result = priceOrder([item({ price: 1000, quantity: 1 })], [percentOffer], [], 0, 0);
    expect(result.offerDiscount).toBe(100);
    expect(result.appliedOffers).toEqual([{ offerId: "offer-1", name: "10% off", amount: 100 }]);
    expect(result.total).toBe(900);
  });

  it("respects minOrderAmount — offer does not apply below the threshold", () => {
    const gatedOffer: Offer = { ...percentOffer, minOrderAmount: 500 };
    const result = priceOrder([item({ price: 300, quantity: 1 })], [gatedOffer], [], 0, 0);
    expect(result.offerDiscount).toBe(0);
    expect(result.appliedOffers).toEqual([]);
    expect(result.total).toBe(300);
  });

  it("applies the offer once the order meets minOrderAmount", () => {
    const gatedOffer: Offer = { ...percentOffer, minOrderAmount: 500 };
    const result = priceOrder([item({ price: 600, quantity: 1 })], [gatedOffer], [], 0, 0);
    expect(result.offerDiscount).toBe(60);
  });

  it("an inactive offer is never applied", () => {
    const inactive: Offer = { ...percentOffer, active: false };
    const result = priceOrder([item({ price: 1000, quantity: 1 })], [inactive], [], 0, 0);
    expect(result.offerDiscount).toBe(0);
    expect(result.total).toBe(1000);
  });
});

describe("priceOrder — flat offer", () => {
  it("applies a flat discount amount", () => {
    const flatOffer: Offer = {
      id: "offer-flat",
      restaurantId: "REST_A",
      name: "₹50 off",
      type: "flat",
      active: true,
      discountAmount: 50,
      createdAt: new Date().toISOString(),
    };
    const result = priceOrder([item({ price: 300, quantity: 1 })], [flatOffer], [], 0, 0);
    expect(result.offerDiscount).toBe(50);
    expect(result.total).toBe(250);
  });

  it("a flat discount never exceeds the subtotal (no negative totals)", () => {
    const flatOffer: Offer = {
      id: "offer-flat",
      restaurantId: "REST_A",
      name: "₹500 off",
      type: "flat",
      active: true,
      discountAmount: 500,
      createdAt: new Date().toISOString(),
    };
    const result = priceOrder([item({ price: 100, quantity: 1 })], [flatOffer], [], 0, 0);
    expect(result.offerDiscount).toBe(100); // capped at the subtotal
    expect(result.total).toBe(0);
  });
});

describe("priceOrder — BOGO offer", () => {
  const menu: MenuItem[] = [
    {
      id: "burger",
      restaurantId: "REST_A",
      name: "Burger",
      description: "",
      categoryId: "mains",
      price: 100,
      image: "",
      prepTimeMinutes: 5,
      available: true,
      spiceLevel: "mild",
      isVeg: true,
      foodType: "veg",
      costPrice: 40,
    },
  ];

  const bogoOffer: Offer = {
    id: "offer-bogo",
    restaurantId: "REST_A",
    name: "Buy 1 Get 1",
    type: "bogo",
    active: true,
    itemId: "burger",
    buyQty: 1,
    getQty: 1,
    createdAt: new Date().toISOString(),
  };

  it("buy-1-get-1: ordering 2 gives exactly 1 free unit", () => {
    const result = priceOrder([item({ itemId: "burger", price: 100, quantity: 2 })], [bogoOffer], menu, 0, 0);
    expect(result.offerDiscount).toBe(100); // one unit free, valued at 100
    expect(result.total).toBe(100);
  });

  it("buy-1-get-1: ordering 3 (not a full second group) still only gives 1 free unit", () => {
    const result = priceOrder([item({ itemId: "burger", price: 100, quantity: 3 })], [bogoOffer], menu, 0, 0);
    expect(result.offerDiscount).toBe(100);
  });

  it("buy-1-get-1: ordering 4 gives 2 free units (two complete groups)", () => {
    const result = priceOrder([item({ itemId: "burger", price: 100, quantity: 4 })], [bogoOffer], menu, 0, 0);
    expect(result.offerDiscount).toBe(200);
  });

  it("buy-1-get-1: ordering only 1 gives no free units (group not complete)", () => {
    const result = priceOrder([item({ itemId: "burger", price: 100, quantity: 1 })], [bogoOffer], menu, 0, 0);
    expect(result.offerDiscount).toBe(0);
  });

  it("a category-wide BOGO matches any item in that category, not just one specific item", () => {
    const categoryBogo: Offer = { ...bogoOffer, itemId: undefined, categoryId: "mains" };
    const otherMainsItem = { ...item({ itemId: "fries", price: 50, quantity: 1 }) };
    const menuWithFries: MenuItem[] = [...menu, { ...menu[0], id: "fries", name: "Fries", price: 50 }];
    const result = priceOrder(
      [item({ itemId: "burger", price: 100, quantity: 1 }), otherMainsItem],
      [categoryBogo],
      menuWithFries,
      0,
      0
    );
    // Total matching qty across both mains items = 2 -> 1 free group.
    // Free unit valued at the cheapest matching line's price (50, the fries).
    expect(result.offerDiscount).toBe(50);
  });

  it("a BOGO offer never applies to items outside its target item/category", () => {
    const result = priceOrder([item({ itemId: "unrelated-item", price: 100, quantity: 5 })], [bogoOffer], menu, 0, 0);
    expect(result.offerDiscount).toBe(0);
  });
});

describe("priceOrder — combined offers, manual discount, and tax", () => {
  it("stacks an offer discount with a manual discount, then taxes the remainder", () => {
    const offer: Offer = {
      id: "offer-1",
      restaurantId: "REST_A",
      name: "10% off",
      type: "percent",
      active: true,
      discountPercent: 10,
      createdAt: new Date().toISOString(),
    };
    // subtotal 1000 -> offer discount 100 -> afterOffers 900 -> manual 10% of 900 = 90
    const result = priceOrder([item({ price: 1000, quantity: 1 })], [offer], [], 10, 5);
    expect(result.offerDiscount).toBe(100);
    expect(result.manualDiscountAmount).toBe(90);
    expect(result.discountTotal).toBe(190);
    expect(result.taxableAmount).toBe(810);
    expect(result.total).toBe(810 + result.taxAmount);
  });

  it("multiple stacked percent+flat offers both apply and their amounts sum correctly", () => {
    const percentOffer: Offer = {
      id: "p1",
      restaurantId: "REST_A",
      name: "5% off",
      type: "percent",
      active: true,
      discountPercent: 5,
      createdAt: new Date().toISOString(),
    };
    const flatOffer: Offer = {
      id: "f1",
      restaurantId: "REST_A",
      name: "₹20 off",
      type: "flat",
      active: true,
      discountAmount: 20,
      createdAt: new Date().toISOString(),
    };
    const result = priceOrder([item({ price: 1000, quantity: 1 })], [percentOffer, flatOffer], [], 0, 0);
    expect(result.offerDiscount).toBe(50 + 20);
    expect(result.appliedOffers).toHaveLength(2);
  });
});
