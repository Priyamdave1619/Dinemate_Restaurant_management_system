import { describe, it, expect } from "vitest";
import {
  createOrderSchema,
  addOrderItemsSchema,
  createMenuItemSchema,
  updateMenuItemSchema,
  createCategorySchema,
  updateCategorySchema,
  createTableSchema,
  createOfferSchema,
  updateOfferSchema,
  createUserSchema,
  createExpenseSchema,
  updateExpenseSchema,
} from "../validation";

describe("createOrderSchema", () => {
  it("accepts a well-formed order", () => {
    const result = createOrderSchema.safeParse({
      tableNumber: 5,
      items: [{ itemId: "item-1", name: "Burger", quantity: 2, price: 100 }],
    });
    expect(result.success).toBe(true);
  });

  it("rejects a missing tableNumber", () => {
    expect(createOrderSchema.safeParse({ items: [{ itemId: "i", name: "n" }] }).success).toBe(false);
  });

  it("rejects an empty items array", () => {
    expect(createOrderSchema.safeParse({ tableNumber: 1, items: [] }).success).toBe(false);
  });

  it("rejects a negative table number", () => {
    expect(createOrderSchema.safeParse({ tableNumber: -1, items: [{ itemId: "i", name: "n" }] }).success).toBe(false);
  });

  it("rejects an item missing required fields", () => {
    expect(createOrderSchema.safeParse({ tableNumber: 1, items: [{ quantity: 2 }] }).success).toBe(false);
  });

  it("rejects a non-integer quantity", () => {
    expect(
      createOrderSchema.safeParse({ tableNumber: 1, items: [{ itemId: "i", name: "n", quantity: 1.5 }] }).success
    ).toBe(false);
  });
});

describe("addOrderItemsSchema", () => {
  it("requires at least one item", () => {
    expect(addOrderItemsSchema.safeParse({ items: [] }).success).toBe(false);
  });
  it("accepts valid items", () => {
    expect(addOrderItemsSchema.safeParse({ items: [{ itemId: "i", name: "n" }] }).success).toBe(true);
  });
});

describe("createMenuItemSchema", () => {
  it("accepts a minimal valid item", () => {
    expect(createMenuItemSchema.safeParse({ name: "Burger", categoryId: "mains", price: 100 }).success).toBe(true);
  });
  it("rejects a negative price", () => {
    expect(createMenuItemSchema.safeParse({ name: "Burger", categoryId: "mains", price: -5 }).success).toBe(false);
  });
  it("rejects an invalid foodType enum value", () => {
    expect(
      createMenuItemSchema.safeParse({ name: "Burger", categoryId: "mains", price: 100, foodType: "meat" }).success
    ).toBe(false);
  });
  it("rejects a missing name", () => {
    expect(createMenuItemSchema.safeParse({ categoryId: "mains", price: 100 }).success).toBe(false);
  });
});

describe("updateMenuItemSchema (partial)", () => {
  it("accepts an empty patch (no fields — a no-op PATCH is still valid shape-wise)", () => {
    expect(updateMenuItemSchema.safeParse({}).success).toBe(true);
  });
  it("accepts updating just one field", () => {
    expect(updateMenuItemSchema.safeParse({ available: false }).success).toBe(true);
  });
  it("still rejects a wrong-typed field even though all fields are optional", () => {
    expect(updateMenuItemSchema.safeParse({ price: "free" }).success).toBe(false);
  });
});

describe("createCategorySchema / updateCategorySchema", () => {
  it("requires a name on create", () => {
    expect(createCategorySchema.safeParse({}).success).toBe(false);
    expect(createCategorySchema.safeParse({ name: "Beverages" }).success).toBe(true);
  });
  it("update allows omitting name entirely, but rejects wrong type if present", () => {
    expect(updateCategorySchema.safeParse({}).success).toBe(true);
    expect(updateCategorySchema.safeParse({ name: 123 }).success).toBe(false);
  });
});

describe("createTableSchema", () => {
  it("requires a positive integer table number", () => {
    expect(createTableSchema.safeParse({ number: 5 }).success).toBe(true);
    expect(createTableSchema.safeParse({ number: 0 }).success).toBe(false);
    expect(createTableSchema.safeParse({ number: 1.5 }).success).toBe(false);
  });
});

describe("createOfferSchema / updateOfferSchema", () => {
  it("requires name and a valid type enum", () => {
    expect(createOfferSchema.safeParse({ name: "10% off", type: "percent" }).success).toBe(true);
    expect(createOfferSchema.safeParse({ name: "10% off", type: "invalid-type" }).success).toBe(false);
  });
  it("rejects discountPercent over 100", () => {
    expect(createOfferSchema.safeParse({ name: "x", type: "percent", discountPercent: 150 }).success).toBe(false);
  });
  it("update accepts partial fields", () => {
    expect(updateOfferSchema.safeParse({ active: false }).success).toBe(true);
  });
});

describe("createUserSchema — staff account creation", () => {
  it("accepts a valid manager/waiter account", () => {
    expect(
      createUserSchema.safeParse({ username: "waiter1", password: "password123", name: "A Waiter", role: "waiter" }).success
    ).toBe(true);
  });
  it("rejects a password under 8 characters", () => {
    expect(
      createUserSchema.safeParse({ username: "waiter1", password: "short", name: "A Waiter", role: "waiter" }).success
    ).toBe(false);
  });
  it("rejects role values outside manager/waiter (owner/super_admin can't be created via this schema)", () => {
    expect(
      createUserSchema.safeParse({ username: "x", password: "password123", name: "X", role: "owner" }).success
    ).toBe(false);
    expect(
      createUserSchema.safeParse({ username: "x", password: "password123", name: "X", role: "super_admin" }).success
    ).toBe(false);
  });
  it("rejects usernames with disallowed characters (spaces, symbols)", () => {
    expect(
      createUserSchema.safeParse({ username: "bad username!", password: "password123", name: "X", role: "waiter" })
        .success
    ).toBe(false);
  });
  it("lowercases the username automatically", () => {
    const result = createUserSchema.safeParse({ username: "MixedCase", password: "password123", name: "X", role: "waiter" });
    expect(result.success).toBe(true);
    if (result.success) expect(result.data.username).toBe("mixedcase");
  });
});

describe("createExpenseSchema / updateExpenseSchema", () => {
  it("requires a positive amount", () => {
    expect(createExpenseSchema.safeParse({ date: "2026-07-01", category: "rent", amount: 1000 }).success).toBe(true);
    expect(createExpenseSchema.safeParse({ date: "2026-07-01", category: "rent", amount: 0 }).success).toBe(false);
    expect(createExpenseSchema.safeParse({ date: "2026-07-01", category: "rent", amount: -100 }).success).toBe(false);
  });
  it("rejects an invalid category enum", () => {
    expect(createExpenseSchema.safeParse({ date: "2026-07-01", category: "not-a-category", amount: 100 }).success).toBe(
      false
    );
  });
  it("update rejects a negative amount even though the field is optional", () => {
    expect(updateExpenseSchema.safeParse({ amount: -50 }).success).toBe(false);
    expect(updateExpenseSchema.safeParse({}).success).toBe(true);
  });
});
