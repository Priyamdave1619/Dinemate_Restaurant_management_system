import { describe, it, expect } from "vitest";
import { getSession, requireRole, requireTenant } from "../session";
import { createSessionToken } from "../auth";
import { platformDb } from "../db";
import { setMockAuthHeader, setMockSessionCookie } from "./setup";
import { Restaurant } from "@/lib/types";

const ownerPayload = { sub: "user-1", username: "rest000021", name: "Test Owner", role: "owner" as const, restaurantId: "REST000021" };

async function seedRestaurant(overrides: Partial<Restaurant> = {}): Promise<void> {
  const restaurant: Restaurant = {
    id: "REST000021",
    name: "Test Restaurant",
    ownerName: "Test Owner",
    email: "owner@test.com",
    mobile: "9999999999",
    currency: "INR",
    status: "active",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    planId: "free",
    subscriptionStatus: "active",
    subscriptionStartedAt: new Date().toISOString(),
    subscriptionExpiresAt: new Date(Date.now() + 30 * 86400000).toISOString(), // 30 days out
    ...overrides,
  };
  await platformDb.restaurants.mutate((cur) => [...cur, restaurant]);
}

describe("getSession — Bearer header vs cookie precedence", () => {
  it("returns null when neither a Bearer header nor a session cookie is present", async () => {
    expect(await getSession()).toBeNull();
  });

  it("reads a valid session from the Authorization: Bearer header", async () => {
    const token = await createSessionToken(ownerPayload);
    setMockAuthHeader(`Bearer ${token}`);
    const session = await getSession();
    expect(session).toMatchObject(ownerPayload);
  });

  it("falls back to the session cookie when no Bearer header is present", async () => {
    const token = await createSessionToken(ownerPayload);
    setMockSessionCookie(token);
    const session = await getSession();
    expect(session).toMatchObject(ownerPayload);
  });

  it("Bearer header takes priority over the cookie when both are present (and disagree)", async () => {
    const bearerToken = await createSessionToken(ownerPayload);
    const cookieToken = await createSessionToken({ ...ownerPayload, sub: "different-user", name: "Cookie User" });
    setMockAuthHeader(`Bearer ${bearerToken}`);
    setMockSessionCookie(cookieToken);

    const session = await getSession();
    expect(session?.sub).toBe("user-1"); // the Bearer token's identity won, not the cookie's
  });

  it("an invalid/tampered Bearer token returns null rather than falling back to the cookie", async () => {
    const validCookieToken = await createSessionToken(ownerPayload);
    setMockAuthHeader("Bearer this-is-not-a-valid-jwt");
    setMockSessionCookie(validCookieToken);

    // Current behavior: a present-but-invalid Bearer header is NOT a
    // silent fallback to the cookie — it's authoritative and fails
    // closed. Documenting this explicitly since it's a real design choice
    // worth having a test pin down.
    expect(await getSession()).toBeNull();
  });
});

describe("requireRole — platform-level role gate (no restaurant/subscription checks)", () => {
  it("rejects when there is no session at all", async () => {
    const result = await requireRole(["super_admin"]);
    expect(result).toEqual({ ok: false, status: 401, message: "Not authenticated" });
  });

  it("rejects a valid session whose role isn't in the allowed list", async () => {
    const token = await createSessionToken(ownerPayload); // role: owner
    setMockAuthHeader(`Bearer ${token}`);
    const result = await requireRole(["super_admin"]);
    expect(result).toEqual({ ok: false, status: 403, message: "Not authorized" });
  });

  it("accepts a session whose role is in the allowed list", async () => {
    const token = await createSessionToken(ownerPayload);
    setMockAuthHeader(`Bearer ${token}`);
    const result = await requireRole(["owner", "manager"]);
    expect(result.ok).toBe(true);
  });

  it("does NOT check restaurant status — a suspended restaurant's owner still passes requireRole (by design; requireRole is for platform-level routes)", async () => {
    await seedRestaurant({ status: "suspended" });
    const token = await createSessionToken(ownerPayload);
    setMockAuthHeader(`Bearer ${token}`);
    const result = await requireRole(["owner"]);
    expect(result.ok).toBe(true);
  });
});

describe("requireTenant — the gate every restaurant-scoped route uses", () => {
  it("rejects super_admin — they have no restaurantId and must use admin routes instead", async () => {
    const token = await createSessionToken({ sub: "admin-1", username: "superadmin", name: "Admin", role: "super_admin", restaurantId: null });
    setMockAuthHeader(`Bearer ${token}`);
    const result = await requireTenant(["super_admin", "owner"]);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.message).toMatch(/no restaurant/i);
  });

  it("rejects when the restaurant no longer exists in the database", async () => {
    // Deliberately not seeding any restaurant — session references one
    // that isn't there (e.g. deleted after the token was issued).
    const token = await createSessionToken(ownerPayload);
    setMockAuthHeader(`Bearer ${token}`);
    const result = await requireTenant(["owner"]);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.status).toBe(401);
  });

  it("SECURITY: rejects immediately once a restaurant is suspended, even with a still-valid, unexpired access token", async () => {
    await seedRestaurant({ status: "active" });
    const token = await createSessionToken(ownerPayload);
    setMockAuthHeader(`Bearer ${token}`);

    // Works fine while active.
    expect((await requireTenant(["owner"])).ok).toBe(true);

    // Restaurant gets suspended by a super_admin mid-session — the SAME
    // access token, still cryptographically valid and unexpired, must now
    // be rejected on the very next request. This is the entire point of
    // requireTenant re-checking live status instead of trusting the JWT
    // alone.
    await platformDb.restaurants.mutate((cur) => cur.map((r) => (r.id === "REST000021" ? { ...r, status: "suspended" } : r)));
    const afterSuspension = await requireTenant(["owner"]);
    expect(afterSuspension.ok).toBe(false);
    if (!afterSuspension.ok) {
      expect(afterSuspension.status).toBe(403);
      expect(afterSuspension.message).toMatch(/suspended/i);
    }
  });

  it("rejects a restaurant with status 'pending'", async () => {
    await seedRestaurant({ status: "pending" });
    const token = await createSessionToken(ownerPayload);
    setMockAuthHeader(`Bearer ${token}`);
    const result = await requireTenant(["owner"]);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.message).toMatch(/pending/i);
  });

  it("SECURITY: rejects immediately once a subscription expires, even mid-session with a valid token", async () => {
    await seedRestaurant({ subscriptionExpiresAt: new Date(Date.now() + 30 * 86400000).toISOString() });
    const token = await createSessionToken(ownerPayload);
    setMockAuthHeader(`Bearer ${token}`);

    expect((await requireTenant(["owner"])).ok).toBe(true);

    // Subscription lapses (e.g. a renewal job runs, or time simply
    // passes) — same still-cryptographically-valid token must now fail.
    await platformDb.restaurants.mutate((cur) =>
      cur.map((r) => (r.id === "REST000021" ? { ...r, subscriptionExpiresAt: new Date(Date.now() - 1000).toISOString() } : r))
    );
    const afterExpiry = await requireTenant(["owner"]);
    expect(afterExpiry.ok).toBe(false);
    if (!afterExpiry.ok) expect(afterExpiry.status).toBe(402);
  });

  it("accepts a valid session for an active, non-expired restaurant, and the returned session carries restaurantId", async () => {
    await seedRestaurant();
    const token = await createSessionToken(ownerPayload);
    setMockAuthHeader(`Bearer ${token}`);
    const result = await requireTenant(["owner", "manager", "waiter"]);
    expect(result.ok).toBe(true);
    if (result.ok) expect(result.session.restaurantId).toBe("REST000021");
  });

  it("rejects a role not in the allowed list even for an otherwise-healthy restaurant", async () => {
    await seedRestaurant();
    const token = await createSessionToken(ownerPayload); // role: owner
    setMockAuthHeader(`Bearer ${token}`);
    const result = await requireTenant(["manager", "waiter"]); // owner not allowed here
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.status).toBe(403);
  });

  it("ISOLATION: a suspended restaurant B never blocks a healthy restaurant A's requests", async () => {
    await seedRestaurant({ id: "REST000021" });
    await seedRestaurant({ id: "REST000099", status: "suspended" });

    const tokenA = await createSessionToken(ownerPayload);
    setMockAuthHeader(`Bearer ${tokenA}`);
    const result = await requireTenant(["owner"]);
    expect(result.ok).toBe(true);
  });
});
