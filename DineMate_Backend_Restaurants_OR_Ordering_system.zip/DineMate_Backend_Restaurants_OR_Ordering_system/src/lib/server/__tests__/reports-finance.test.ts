import { describe, it, expect } from "vitest";
import { getDailyStats, listDailyStats, getWeeklyStats, getMonthlyStats, listMonthlyStats, getYearlyStats, listYears } from "../reports";
import { getMonthlyPnl, getYearlyPnl, addExpense } from "../finance";
import { getRawDb } from "../db";
import { DailyStats, MonthlyStats } from "@/lib/types";

async function seedDaily(restaurantId: string, dateKey: string, overrides: Partial<DailyStats> = {}) {
  const db = await getRawDb();
  const base: DailyStats = {
    restaurantId,
    dateKey,
    weekKey: "2026-W01",
    monthKey: dateKey.slice(0, 7),
    yearKey: dateKey.slice(0, 4),
    grossSales: 1000,
    discountTotal: 0,
    netSales: 1000,
    taxTotal: 50,
    totalCollected: 1050,
    cogsTotal: 400,
    grossProfit: 600,
    orderCount: 5,
    itemsSold: 10,
    ...overrides,
  } as DailyStats;
  await db.collection("dailyStats").insertOne({ ...base });
  return base;
}

async function seedMonthly(restaurantId: string, monthKey: string, overrides: Partial<MonthlyStats> = {}) {
  const db = await getRawDb();
  const base: MonthlyStats = {
    restaurantId,
    monthKey,
    yearKey: monthKey.slice(0, 4),
    grossSales: 10000,
    discountTotal: 500,
    netSales: 9500,
    taxTotal: 475,
    totalCollected: 9975,
    cogsTotal: 4000,
    grossProfit: 5500,
    orderCount: 50,
    itemsSold: 120,
    ...overrides,
  } as MonthlyStats;
  await db.collection("monthlyStats").insertOne({ ...base });
  return base;
}

describe("reports.ts — daily stats", () => {
  it("getDailyStats returns null for a day with no data (not an error)", async () => {
    expect(await getDailyStats("REST_A", "2026-07-15")).toBeNull();
  });

  it("getDailyStats retrieves exactly the requested tenant+date, scoped correctly", async () => {
    await seedDaily("REST_A", "2026-07-15", { grossSales: 5000 });
    await seedDaily("REST_B", "2026-07-15", { grossSales: 9999 }); // same date, different tenant

    const result = await getDailyStats("REST_A", "2026-07-15");
    expect(result?.grossSales).toBe(5000);
    expect(result?.restaurantId).toBe("REST_A");
  });

  it("listDailyStats respects a date range and tenant scope together", async () => {
    await seedDaily("REST_A", "2026-07-10");
    await seedDaily("REST_A", "2026-07-15");
    await seedDaily("REST_A", "2026-07-20");
    await seedDaily("REST_B", "2026-07-15"); // different tenant, must never appear

    const inRange = await listDailyStats("REST_A", "2026-07-12", "2026-07-18");
    expect(inRange).toHaveLength(1);
    expect(inRange[0].dateKey).toBe("2026-07-15");
    expect(inRange.every((d) => d.restaurantId === "REST_A")).toBe(true);
  });

  it("getWeeklyStats aggregates all days sharing a weekKey, scoped to one tenant", async () => {
    await seedDaily("REST_A", "2026-07-13", { weekKey: "2026-W29", grossSales: 100, orderCount: 1 });
    await seedDaily("REST_A", "2026-07-14", { weekKey: "2026-W29", grossSales: 200, orderCount: 2 });
    await seedDaily("REST_A", "2026-07-20", { weekKey: "2026-W30", grossSales: 9999, orderCount: 99 }); // different week
    await seedDaily("REST_B", "2026-07-13", { weekKey: "2026-W29", grossSales: 5000, orderCount: 50 }); // different tenant

    const week = await getWeeklyStats("REST_A", "2026-W29");
    expect(week.grossSales).toBe(300);
    expect(week.orderCount).toBe(3);
  });
});

describe("reports.ts — monthly/yearly stats", () => {
  it("getMonthlyStats returns null when nothing recorded for that month", async () => {
    expect(await getMonthlyStats("REST_A", "2026-07")).toBeNull();
  });

  it("listMonthlyStats filters by year and by tenant", async () => {
    await seedMonthly("REST_A", "2026-01");
    await seedMonthly("REST_A", "2026-06");
    await seedMonthly("REST_A", "2025-12"); // different year
    await seedMonthly("REST_B", "2026-01"); // different tenant

    const year2026 = await listMonthlyStats("REST_A", "2026");
    expect(year2026).toHaveLength(2);
    expect(year2026.every((m) => m.yearKey === "2026" && m.restaurantId === "REST_A")).toBe(true);
  });

  it("getYearlyStats aggregates every month of that year for one tenant", async () => {
    await seedMonthly("REST_A", "2026-01", { grossSales: 1000, orderCount: 10 });
    await seedMonthly("REST_A", "2026-02", { grossSales: 2000, orderCount: 20 });
    await seedMonthly("REST_B", "2026-01", { grossSales: 99999, orderCount: 999 }); // different tenant

    const year = await getYearlyStats("REST_A", "2026");
    expect(year.grossSales).toBe(3000);
    expect(year.orderCount).toBe(30);
  });

  it("listYears returns only years this tenant actually has data for", async () => {
    await seedMonthly("REST_A", "2025-06");
    await seedMonthly("REST_A", "2026-01");
    await seedMonthly("REST_B", "2024-01"); // different tenant, must not leak in

    const years = await listYears("REST_A");
    expect(years.sort()).toEqual(["2025", "2026"]);
  });
});

describe("finance.ts — P&L", () => {
  it("getMonthlyPnl computes gross profit and net profit correctly, subtracting logged expenses", async () => {
    await seedMonthly("REST_A", "2026-07", {
      grossSales: 10000,
      discountTotal: 500,
      netSales: 9500,
      taxTotal: 475,
      cogsTotal: 3000,
      grossProfit: 6500,
      orderCount: 40,
      totalCollected: 9975,
    });
    await addExpense("REST_A", { date: "2026-07-05", category: "rent", description: "", amount: 2000 });
    await addExpense("REST_A", { date: "2026-07-10", category: "utilities", description: "", amount: 500 });

    const pnl = await getMonthlyPnl("REST_A", "2026-07");
    expect(pnl.grossSales).toBe(10000);
    expect(pnl.cogs).toBe(3000);
    expect(pnl.grossProfit).toBe(6500);
    expect(pnl.totalExpenses).toBe(2500);
    expect(pnl.netProfit).toBe(6500 - 2500); // 4000
    expect(pnl.expensesByCategory.rent).toBe(2000);
    expect(pnl.expensesByCategory.utilities).toBe(500);
  });

  it("getMonthlyPnl for a tenant/month with zero sales but real expenses still computes a (negative) net profit", async () => {
    await addExpense("REST_A", { date: "2026-08-01", category: "rent", description: "", amount: 1500 });
    const pnl = await getMonthlyPnl("REST_A", "2026-08");
    expect(pnl.grossSales).toBe(0);
    expect(pnl.totalExpenses).toBe(1500);
    expect(pnl.netProfit).toBe(-1500);
  });

  it("expenses logged for one tenant never appear in another tenant's P&L", async () => {
    await seedMonthly("REST_A", "2026-07", { grossSales: 1000, cogsTotal: 0, grossProfit: 1000 });
    await addExpense("REST_A", { date: "2026-07-01", category: "rent", description: "", amount: 100 });
    await addExpense("REST_B", { date: "2026-07-01", category: "rent", description: "", amount: 99999 });

    const pnlA = await getMonthlyPnl("REST_A", "2026-07");
    expect(pnlA.totalExpenses).toBe(100);
  });

  it("getYearlyPnl aggregates the whole year's monthly stats plus that year's expenses", async () => {
    await seedMonthly("REST_A", "2026-01", { grossSales: 1000, cogsTotal: 200, grossProfit: 800 });
    await seedMonthly("REST_A", "2026-02", { grossSales: 2000, cogsTotal: 400, grossProfit: 1600 });
    await addExpense("REST_A", { date: "2026-01-15", category: "salaries", description: "", amount: 500 });

    const pnl = await getYearlyPnl("REST_A", "2026");
    expect(pnl.grossSales).toBe(3000);
    expect(pnl.grossProfit).toBe(2400);
    expect(pnl.totalExpenses).toBe(500);
    expect(pnl.netProfit).toBe(1900);
  });
});
