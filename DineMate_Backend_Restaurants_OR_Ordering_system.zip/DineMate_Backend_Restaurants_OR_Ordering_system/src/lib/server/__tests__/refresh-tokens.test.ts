import { describe, it, expect } from "vitest";
import { issueRefreshToken, rotateRefreshToken, revokeRefreshToken, revokeAllRefreshTokensForUser } from "../refresh-tokens";

const user = { id: "user-1", username: "rest000021", name: "Test Owner", role: "owner" as const, restaurantId: "REST000021" };

describe("refresh tokens", () => {
  it("a freshly issued token rotates successfully and returns the same user identity", async () => {
    const token = await issueRefreshToken(user);
    const result = await rotateRefreshToken(token);

    expect(result.ok).toBe(true);
    if (result.ok) {
      expect(result.record.userId).toBe(user.id);
      expect(result.record.username).toBe(user.username);
      expect(result.record.role).toBe(user.role);
      expect(result.record.restaurantId).toBe(user.restaurantId);
      expect(result.newValue).not.toBe(token); // rotation issues a genuinely new token
    }
  });

  it("an unknown token is rejected", async () => {
    const result = await rotateRefreshToken("this-token-was-never-issued");
    expect(result).toEqual({ ok: false, reason: "not_found" });
  });

  it("REUSE DETECTION: presenting an already-rotated token a second time is rejected and flagged", async () => {
    const token = await issueRefreshToken(user);
    const first = await rotateRefreshToken(token);
    expect(first.ok).toBe(true);

    // An attacker who stole the original token before the legitimate
    // client rotated it tries to use the now-stale token.
    const second = await rotateRefreshToken(token);
    expect(second.ok).toBe(false);
    if (!second.ok) {
      expect(second.reason).toBe("reused");
      if (second.reason === "reused") expect(second.userId).toBe(user.id);
    }
  });

  it("after reuse is detected and all tokens revoked, even the NEW (legitimately rotated) token stops working", async () => {
    const token = await issueRefreshToken(user);
    const first = await rotateRefreshToken(token);
    expect(first.ok).toBe(true);
    if (!first.ok) throw new Error("unreachable");
    const legitimateNewToken = first.newValue;

    // Reuse detected on the old token...
    const reuseAttempt = await rotateRefreshToken(token);
    expect(reuseAttempt.ok).toBe(false);

    // ...the caller (the real /api/auth/refresh route) is expected to
    // respond to that by revoking every token for the user. Simulate that:
    await revokeAllRefreshTokensForUser(user.id);

    // Now even the legitimately-rotated new token — which had done
    // nothing wrong — is correctly locked out too, because we can no
    // longer distinguish "this session is fine" from "this session was
    // stolen at the same time," and erring toward requiring a fresh login
    // is the safe choice.
    const afterRevocation = await rotateRefreshToken(legitimateNewToken);
    expect(afterRevocation.ok).toBe(false);
    if (!afterRevocation.ok) expect(afterRevocation.reason).toBe("revoked");
  });

  it("a manually revoked token (logout) cannot be rotated afterward", async () => {
    const token = await issueRefreshToken(user);
    await revokeRefreshToken(token);

    const result = await rotateRefreshToken(token);
    expect(result.ok).toBe(false);
    if (!result.ok) expect(result.reason).toBe("revoked");
  });

  it("revoking one user's tokens never affects a different user's tokens", async () => {
    const otherUser = { id: "user-2", username: "waiter1", name: "A Waiter", role: "waiter" as const, restaurantId: "REST000021" };
    const tokenA = await issueRefreshToken(user);
    const tokenB = await issueRefreshToken(otherUser);

    await revokeAllRefreshTokensForUser(user.id);

    const resultA = await rotateRefreshToken(tokenA);
    expect(resultA.ok).toBe(false);

    const resultB = await rotateRefreshToken(tokenB);
    expect(resultB.ok).toBe(true); // untouched — different user entirely
  });

  it("two tokens issued for the same user are independent — rotating one doesn't invalidate the other", async () => {
    // Simulates a user logged in on two devices simultaneously.
    const tokenDeviceA = await issueRefreshToken(user);
    const tokenDeviceB = await issueRefreshToken(user);

    const rotateA = await rotateRefreshToken(tokenDeviceA);
    expect(rotateA.ok).toBe(true);

    // Device B's token was never touched, so it's still valid.
    const rotateB = await rotateRefreshToken(tokenDeviceB);
    expect(rotateB.ok).toBe(true);
  });
});
