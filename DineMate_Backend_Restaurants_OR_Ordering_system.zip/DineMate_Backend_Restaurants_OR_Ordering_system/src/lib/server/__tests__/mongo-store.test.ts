import { describe, it, expect } from "vitest";
import { readCollection, writeCollection, mutateCollection, nextCounter, seedCollectionOnce } from "../mongo-store";

interface Item {
  id: string;
  name: string;
}

describe("mongo-store tenant isolation", () => {
  // This is the single most important property of this entire platform:
  // one restaurant must never be able to read, overwrite, or delete
  // another restaurant's data, no matter what collection or operation is
  // involved. Everything below tests that directly against the real
  // scoping logic in mongo-store.ts — not a mock of it.

  it("readCollection only ever returns documents scoped to the given restaurantId", async () => {
    await writeCollection<Item>("items", [{ id: "a", name: "Tenant A Item" }], { restaurantId: "REST_A" });
    await writeCollection<Item>("items", [{ id: "b", name: "Tenant B Item" }], { restaurantId: "REST_B" });

    const tenantA = await readCollection<Item>("items", { restaurantId: "REST_A" });
    const tenantB = await readCollection<Item>("items", { restaurantId: "REST_B" });

    expect(tenantA).toEqual([{ id: "a", name: "Tenant A Item", restaurantId: "REST_A" }]);
    expect(tenantB).toEqual([{ id: "b", name: "Tenant B Item", restaurantId: "REST_B" }]);
    // Neither list contains so much as a trace of the other tenant's data.
    expect(tenantA.some((i) => i.id === "b")).toBe(false);
    expect(tenantB.some((i) => i.id === "a")).toBe(false);
  });

  it("writeCollection replacing tenant A's data never touches tenant B's data in the same collection", async () => {
    await writeCollection<Item>("items", [{ id: "a1", name: "A1" }, { id: "a2", name: "A2" }], { restaurantId: "REST_A" });
    await writeCollection<Item>("items", [{ id: "b1", name: "B1" }], { restaurantId: "REST_B" });

    // Tenant A replaces their entire list with something totally different.
    await writeCollection<Item>("items", [{ id: "a3", name: "A3 — completely different" }], { restaurantId: "REST_A" });

    const tenantA = await readCollection<Item>("items", { restaurantId: "REST_A" });
    const tenantB = await readCollection<Item>("items", { restaurantId: "REST_B" });

    expect(tenantA).toEqual([{ id: "a3", name: "A3 — completely different", restaurantId: "REST_A" }]);
    // Tenant B's data survived Tenant A's full-collection rewrite untouched.
    expect(tenantB).toEqual([{ id: "b1", name: "B1", restaurantId: "REST_B" }]);
  });

  it("mutateCollection deletions for one tenant never delete another tenant's rows with the same id", async () => {
    // Deliberately using the SAME id in both tenants — a real scenario
    // (e.g. two different restaurants both naming a category "cat-1"
    // before ids were made tenant-scoped-only in practice) and the
    // sharpest possible test of whether scoping is actually enforced by
    // the query, not just by convention.
    await writeCollection<Item>("items", [{ id: "shared-id", name: "A's item" }], { restaurantId: "REST_A" });
    await writeCollection<Item>("items", [{ id: "shared-id", name: "B's item" }], { restaurantId: "REST_B" });

    await mutateCollection<Item>("items", (cur) => cur.filter((i) => i.id !== "shared-id"), { restaurantId: "REST_A" });

    const tenantA = await readCollection<Item>("items", { restaurantId: "REST_A" });
    const tenantB = await readCollection<Item>("items", { restaurantId: "REST_B" });

    expect(tenantA).toEqual([]);
    // Tenant B's row with the identical id must survive — it's a
    // completely different document, scoped separately.
    expect(tenantB).toEqual([{ id: "shared-id", name: "B's item", restaurantId: "REST_B" }]);
  });

  it("mutateCollection updates for one tenant never leak into another tenant's row with the same id", async () => {
    await writeCollection<Item>("items", [{ id: "x", name: "Original A" }], { restaurantId: "REST_A" });
    await writeCollection<Item>("items", [{ id: "x", name: "Original B" }], { restaurantId: "REST_B" });

    await mutateCollection<Item>(
      "items",
      (cur) => cur.map((i) => (i.id === "x" ? { ...i, name: "Updated A" } : i)),
      { restaurantId: "REST_A" }
    );

    const tenantA = await readCollection<Item>("items", { restaurantId: "REST_A" });
    const tenantB = await readCollection<Item>("items", { restaurantId: "REST_B" });

    expect(tenantA).toEqual([{ id: "x", name: "Updated A", restaurantId: "REST_A" }]);
    expect(tenantB).toEqual([{ id: "x", name: "Original B", restaurantId: "REST_B" }]);
  });

  it("REGRESSION: fully emptying a tenant's collection must NEVER cause it to silently re-populate on the next read", async () => {
    // This is a direct regression test for a real bug found while writing
    // this test suite: readCollection used to auto-insert seed content
    // whenever a scope was empty, with no way to distinguish "never
    // initialized" from "the user legitimately deleted everything." A
    // restaurant that cleared out their whole menu to build their own from
    // scratch would see the demo content mysteriously reappear.
    await writeCollection<Item>("items3", [{ id: "a", name: "A" }], { restaurantId: "REST_A" });

    // The tenant deletes everything.
    await mutateCollection<Item>("items3", () => [], { restaurantId: "REST_A" });

    // Reading again — possibly several times, the way a real dashboard
    // would poll — must keep returning empty, not resurrect anything.
    expect(await readCollection<Item>("items3", { restaurantId: "REST_A" })).toEqual([]);
    expect(await readCollection<Item>("items3", { restaurantId: "REST_A" })).toEqual([]);
    expect(await mutateCollection<Item>("items3", (cur) => cur, { restaurantId: "REST_A" })).toEqual([]);
  });

  it("seedCollectionOnce inserts content, and is the ONLY thing that ever does — readCollection alone never seeds", async () => {
    const seed: Item[] = [{ id: "seed-1", name: "Starter Item" }];

    // Before seeding, a fresh tenant's collection is genuinely empty — not
    // silently populated just by reading it.
    expect(await readCollection<Item>("items4", { restaurantId: "REST_A" })).toEqual([]);

    await seedCollectionOnce("items4", seed, { restaurantId: "REST_A" });
    const afterSeed = await readCollection<Item>("items4", { restaurantId: "REST_A" });
    expect(afterSeed).toEqual([{ id: "seed-1", name: "Starter Item", restaurantId: "REST_A" }]);

    // A completely separate tenant is unaffected by another tenant's seed call.
    expect(await readCollection<Item>("items4", { restaurantId: "REST_B" })).toEqual([]);
  });

  it("scope with a null-valued field (e.g. restaurantId: null for platform-level users) is isolated from real tenant scopes", async () => {
    // This is exactly how super_admin accounts are isolated from every
    // real restaurant's staff — restaurantId: null is its own scope, not
    // "unscoped" / "matches everything".
    await writeCollection<Item>("users", [{ id: "admin-1", name: "Super Admin" }], { restaurantId: null });
    await writeCollection<Item>("users", [{ id: "staff-1", name: "Waiter" }], { restaurantId: "REST_A" });

    const superAdmins = await readCollection<Item>("users", { restaurantId: null });
    const tenantAStaff = await readCollection<Item>("users", { restaurantId: "REST_A" });

    expect(superAdmins).toEqual([{ id: "admin-1", name: "Super Admin", restaurantId: null }]);
    expect(tenantAStaff).toEqual([{ id: "staff-1", name: "Waiter", restaurantId: "REST_A" }]);
  });
});

describe("mongo-store counters", () => {
  it("increments independently per key — used for per-tenant order/bill sequences and restaurant id generation", async () => {
    const a1 = await nextCounter("restaurant_id");
    const a2 = await nextCounter("restaurant_id");
    const b1 = await nextCounter("REST_A:order");

    expect(a2).toBe(a1 + 1);
    // A completely different counter key starts its own independent
    // sequence — this is what gives every tenant their own order/bill
    // numbering starting at 1, instead of sharing one global sequence.
    expect(b1).toBe(1);
  });
});
