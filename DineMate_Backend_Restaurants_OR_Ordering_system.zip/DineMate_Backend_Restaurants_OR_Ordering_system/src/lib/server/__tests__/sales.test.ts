import { describe, it, expect } from "vitest";
import { archiveBilledOrder } from "../sales";
import { getRawDb } from "../db";
import { deriveTimeKeys } from "../time-keys";
import { MenuItem, Order, OrderItem } from "@/lib/types";

function orderItem(overrides: Partial<OrderItem> = {}): OrderItem {
  return {
    id: "oi-1",
    itemId: "item-burger",
    name: "Burger",
    quantity: 2,
    price: 150,
    foodType: "non-veg",
    categoryId: "mains",
    costPrice: 60,
    ...overrides,
  };
}

function order(restaurantId: string, overrides: Partial<Order> = {}): Order {
  const items = overrides.items ?? [orderItem()];
  const subtotal = items.reduce((s, i) => s + i.price * i.quantity, 0);
  return {
    id: `ord-${restaurantId}-1001`,
    restaurantId,
    tableNumber: 5,
    items,
    status: "completed",
    placedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    estimatedMinutes: 10,
    subtotal,
    manualDiscountPercent: 0,
    appliedOffers: [],
    discountTotal: 0,
    taxRatePercent: 5,
    taxAmount: Math.round(subtotal * 0.05),
    total: subtotal + Math.round(subtotal * 0.05),
    kotBatches: 1,
    billGenerated: true,
    waiterName: "Test Waiter",
    ...overrides,
  };
}

const menu: MenuItem[] = [
  {
    id: "item-burger",
    restaurantId: "REST_A",
    name: "Burger",
    description: "",
    categoryId: "mains",
    price: 150,
    image: "",
    prepTimeMinutes: 5,
    available: true,
    spiceLevel: "mild",
    isVeg: false,
    foodType: "non-veg",
    costPrice: 60,
  },
];

describe("archiveBilledOrder", () => {
  it("writes one soldItem per unit-of-sale line, with correct revenue/cost/profit", async () => {
    const billedAt = new Date().toISOString();
    const { soldItems, cogsTotal } = await archiveBilledOrder("REST_A", order("REST_A"), menu, billedAt);

    expect(soldItems).toHaveLength(1);
    const line = soldItems[0];
    expect(line.restaurantId).toBe("REST_A");
    expect(line.quantity).toBe(2);
    expect(line.lineRevenue).toBe(300); // 150 * 2
    expect(line.lineCost).toBe(120); // 60 * 2
    expect(line.lineProfit).toBe(180); // 300 - 120
    expect(cogsTotal).toBe(120);
  });

  it("moves the order from the active queue into billedOrders permanently", async () => {
    const db = await getRawDb();
    // Simulate the order having been in the active queue first, the way
    // the real bill route's flow works.
    await db.collection("orders").insertOne({ ...order("REST_A") });

    await archiveBilledOrder("REST_A", order("REST_A"), menu, new Date().toISOString());

    const stillActive = await db.collection("orders").findOne({ id: "ord-REST_A-1001", restaurantId: "REST_A" });
    const archived = await db.collection("billedOrders").findOne({ id: "ord-REST_A-1001", restaurantId: "REST_A" });

    expect(stillActive).toBeNull();
    expect(archived).not.toBeNull();
    expect(archived?.billedAt).toBeDefined();
  });

  it("increments dailyStats and monthlyStats by the order's totals, scoped to the right restaurant", async () => {
    const billedAt = new Date().toISOString();
    const keys = deriveTimeKeys(billedAt);
    const testOrder = order("REST_A");

    await archiveBilledOrder("REST_A", testOrder, menu, billedAt);

    const db = await getRawDb();
    const daily = await db.collection("dailyStats").findOne({ restaurantId: "REST_A", dateKey: keys.dateKey });
    const monthly = await db.collection("monthlyStats").findOne({ restaurantId: "REST_A", monthKey: keys.monthKey });

    expect(daily).not.toBeNull();
    expect(daily?.grossSales).toBe(testOrder.subtotal);
    expect(daily?.orderCount).toBe(1);
    expect(daily?.itemsSold).toBe(2);

    expect(monthly).not.toBeNull();
    expect(monthly?.grossSales).toBe(testOrder.subtotal);
  });

  it("archiving a SECOND order the same day accumulates stats rather than overwriting them", async () => {
    const billedAt = new Date().toISOString();
    const keys = deriveTimeKeys(billedAt);

    await archiveBilledOrder("REST_A", order("REST_A", { id: "ord-REST_A-1001" }), menu, billedAt);
    await archiveBilledOrder(
      "REST_A",
      order("REST_A", { id: "ord-REST_A-1002", items: [orderItem({ quantity: 1 })] }),
      menu,
      billedAt
    );

    const db = await getRawDb();
    const daily = await db.collection("dailyStats").findOne({ restaurantId: "REST_A", dateKey: keys.dateKey });

    expect(daily?.orderCount).toBe(2);
    expect(daily?.itemsSold).toBe(3); // 2 + 1
  });

  it("CRITICAL: archiving an order for tenant A never affects tenant B's stats, soldItems, or billedOrders", async () => {
    const billedAt = new Date().toISOString();
    const keys = deriveTimeKeys(billedAt);

    // Tenant B already has their own data before tenant A does anything.
    await archiveBilledOrder("REST_B", order("REST_B", { id: "ord-REST_B-5001" }), menu, billedAt);

    // Now tenant A archives a completely different order.
    await archiveBilledOrder("REST_A", order("REST_A", { id: "ord-REST_A-1001" }), menu, billedAt);

    const db = await getRawDb();

    const dailyA = await db.collection("dailyStats").findOne({ restaurantId: "REST_A", dateKey: keys.dateKey });
    const dailyB = await db.collection("dailyStats").findOne({ restaurantId: "REST_B", dateKey: keys.dateKey });

    // Each tenant's daily stats reflect ONLY their own order, not a
    // combined total — if scoping were broken, both would show
    // orderCount 2 instead of 1 each.
    expect(dailyA?.orderCount).toBe(1);
    expect(dailyB?.orderCount).toBe(1);

    const soldItemsA = await db.collection("soldItems").find({ restaurantId: "REST_A" }).toArray();
    const soldItemsB = await db.collection("soldItems").find({ restaurantId: "REST_B" }).toArray();
    expect(soldItemsA.every((i) => i.restaurantId === "REST_A")).toBe(true);
    expect(soldItemsB.every((i) => i.restaurantId === "REST_B")).toBe(true);

    const billedA = await db.collection("billedOrders").find({ restaurantId: "REST_A" }).toArray();
    const billedB = await db.collection("billedOrders").find({ restaurantId: "REST_B" }).toArray();
    expect(billedA).toHaveLength(1);
    expect(billedB).toHaveLength(1);
    expect(billedA[0].id).toBe("ord-REST_A-1001");
    expect(billedB[0].id).toBe("ord-REST_B-5001");
  });

  it("falls back to the menu item's foodType/categoryId/costPrice when the order line doesn't have its own snapshot", async () => {
    const lineWithoutSnapshot: OrderItem = {
      id: "oi-2",
      itemId: "item-burger",
      name: "Burger",
      quantity: 1,
      price: 150,
      // foodType/categoryId/costPrice deliberately omitted — should fall
      // back to looking them up on the menu item passed in.
    };
    const { soldItems } = await archiveBilledOrder(
      "REST_A",
      order("REST_A", { items: [lineWithoutSnapshot] }),
      menu,
      new Date().toISOString()
    );
    expect(soldItems[0].foodType).toBe("non-veg");
    expect(soldItems[0].categoryId).toBe("mains");
    expect(soldItems[0].unitCost).toBe(60);
  });
});
