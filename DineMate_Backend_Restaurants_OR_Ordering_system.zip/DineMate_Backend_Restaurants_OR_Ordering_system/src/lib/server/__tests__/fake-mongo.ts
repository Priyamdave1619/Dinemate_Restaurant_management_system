/**
 * A faithful, narrowly-scoped in-memory implementation of the MongoDB
 * driver surface this codebase actually calls (see the `grep` audit in
 * MIGRATION_NOTES.md Phase 11 for exactly which methods/operators that
 * is). This exists because there is no `mongod` binary and no network
 * path to get one in the sandbox this backend was built in — but the
 * single most important correctness property of a multi-tenant SaaS
 * platform (tenant A can never read/write tenant B's data) is a property
 * of *logic*, not of MongoDB itself, and that logic can be genuinely
 * exercised without a real database.
 *
 * This is deliberately NOT a general-purpose MongoDB emulator. It
 * implements exactly: find/findOne (with $nin/$gte/$lte/$ne/$in filter
 * operators), insertOne/insertMany, updateOne/updateMany ($set/$inc/
 * $setOnInsert, upsert), deleteOne/deleteMany, countDocuments,
 * createIndex (no-op — index *behavior*, like uniqueness, isn't what
 * these tests are checking), findOneAndUpdate, distinct, bulkWrite
 * (replaceOne+upsert only, matching mongo-store.ts's actual usage), and
 * aggregate (only the pipeline stages/operators actually used:
 * $match/$group/$project/$sort/$limit with $sum/$addToSet/$first/$size).
 *
 * Every read returns a deep clone, matching real MongoDB's over-the-wire
 * semantics (mutating a returned document must never affect the stored
 * data) — this is a real, easy-to-get-wrong detail, and getting it wrong
 * would make these tests pass for the wrong reasons.
 */

type Doc = Record<string, unknown>;

function clone<T>(v: T): T {
  // structuredClone (not JSON.stringify/parse!) — the real MongoDB driver
  // deserializes BSON Date fields into genuine JS Date instances, and
  // refresh-tokens.ts specifically relies on that (its TTL index only
  // works on a real Date field — see the comment in mongodb.ts). A
  // JSON-based clone would silently turn every Date into a string instead,
  // which is exactly wrong and would make tests pass or fail for reasons
  // that have nothing to do with the actual code under test.
  return v === undefined ? v : structuredClone(v);
}

function getPath(doc: Doc, path: string): unknown {
  return path.split(".").reduce<unknown>((acc, key) => (acc && typeof acc === "object" ? (acc as Doc)[key] : undefined), doc);
}

function matchesCondition(value: unknown, cond: unknown): boolean {
  if (cond !== null && typeof cond === "object" && !Array.isArray(cond)) {
    for (const [op, opVal] of Object.entries(cond as Doc)) {
      switch (op) {
        case "$nin":
          if ((opVal as unknown[]).includes(value)) return false;
          break;
        case "$in":
          if (!(opVal as unknown[]).includes(value)) return false;
          break;
        case "$ne":
          if (value === opVal) return false;
          break;
        case "$gte":
          if (!(value !== undefined && value !== null && (value as never) >= (opVal as never))) return false;
          break;
        case "$lte":
          if (!(value !== undefined && value !== null && (value as never) <= (opVal as never))) return false;
          break;
        default:
          throw new Error(`fake-mongo: unsupported filter operator ${op} — extend fake-mongo.ts, don't skip the test`);
      }
    }
    return true;
  }
  return value === cond;
}

function matchesFilter(doc: Doc, filter: Doc): boolean {
  for (const [key, cond] of Object.entries(filter)) {
    if (!matchesCondition(getPath(doc, key), cond)) return false;
  }
  return true;
}

function applyUpdate(doc: Doc, update: Doc, isInsert: boolean): Doc {
  let next = { ...doc };
  if (update.$set) next = { ...next, ...(update.$set as Doc) };
  if (update.$setOnInsert && isInsert) next = { ...next, ...(update.$setOnInsert as Doc) };
  if (update.$inc) {
    for (const [k, v] of Object.entries(update.$inc as Doc)) {
      next[k] = (typeof next[k] === "number" ? (next[k] as number) : 0) + (v as number);
    }
  }
  return next;
}

class FakeCursor<T extends Doc> {
  private docs: T[];
  constructor(docs: T[]) {
    this.docs = docs;
  }
  sort(spec: Record<string, 1 | -1>): this {
    const [[field, dir]] = Object.entries(spec);
    this.docs = [...this.docs].sort((a, b) => {
      const av = getPath(a, field);
      const bv = getPath(b, field);
      if (av === bv) return 0;
      return ((av as never) > (bv as never) ? 1 : -1) * dir;
    });
    return this;
  }
  limit(n: number): this {
    this.docs = this.docs.slice(0, n);
    return this;
  }
  async toArray(): Promise<T[]> {
    return clone(this.docs);
  }
}

export class FakeCollection<T extends Doc = Doc> {
  private docs: T[] = [];

  find(filter: Doc = {}): FakeCursor<T> {
    return new FakeCursor(this.docs.filter((d) => matchesFilter(d, filter)));
  }

  async findOne(filter: Doc = {}): Promise<T | null> {
    const found = this.docs.find((d) => matchesFilter(d, filter));
    return found ? clone(found) : null;
  }

  async insertOne(doc: T): Promise<{ insertedId: unknown }> {
    this.docs.push(clone(doc));
    return { insertedId: (doc as Doc)._id ?? (doc as Doc).id };
  }

  async insertMany(docs: T[], _opts?: { ordered?: boolean }): Promise<{ insertedCount: number }> {
    for (const d of docs) this.docs.push(clone(d));
    return { insertedCount: docs.length };
  }

  async updateOne(
    filter: Doc,
    update: Doc,
    opts?: { upsert?: boolean }
  ): Promise<{ matchedCount: number; modifiedCount: number; upsertedCount: number }> {
    const idx = this.docs.findIndex((d) => matchesFilter(d, filter));
    if (idx >= 0) {
      this.docs[idx] = applyUpdate(this.docs[idx], update, false) as T;
      return { matchedCount: 1, modifiedCount: 1, upsertedCount: 0 };
    }
    if (opts?.upsert) {
      const base: Doc = {};
      for (const [k, v] of Object.entries(filter)) {
        if (v === null || typeof v !== "object") base[k] = v;
      }
      const inserted = applyUpdate(base, update, true) as T;
      this.docs.push(inserted);
      return { matchedCount: 0, modifiedCount: 0, upsertedCount: 1 };
    }
    return { matchedCount: 0, modifiedCount: 0, upsertedCount: 0 };
  }

  async updateMany(filter: Doc, update: Doc): Promise<{ matchedCount: number; modifiedCount: number }> {
    let count = 0;
    this.docs = this.docs.map((d) => {
      if (!matchesFilter(d, filter)) return d;
      count++;
      return applyUpdate(d, update, false) as T;
    });
    return { matchedCount: count, modifiedCount: count };
  }

  async findOneAndUpdate(filter: Doc, update: Doc, opts?: { upsert?: boolean; returnDocument?: "before" | "after" }): Promise<T | null> {
    const idx = this.docs.findIndex((d) => matchesFilter(d, filter));
    if (idx >= 0) {
      const before = this.docs[idx];
      const after = applyUpdate(before, update, false) as T;
      this.docs[idx] = after;
      return clone(opts?.returnDocument === "before" ? before : after);
    }
    if (opts?.upsert) {
      const base: Doc = {};
      for (const [k, v] of Object.entries(filter)) {
        if (v === null || typeof v !== "object") base[k] = v;
      }
      const inserted = applyUpdate(base, update, true) as T;
      this.docs.push(inserted);
      return clone(inserted);
    }
    return null;
  }

  async deleteOne(filter: Doc): Promise<{ deletedCount: number }> {
    const idx = this.docs.findIndex((d) => matchesFilter(d, filter));
    if (idx < 0) return { deletedCount: 0 };
    this.docs.splice(idx, 1);
    return { deletedCount: 1 };
  }

  async deleteMany(filter: Doc = {}): Promise<{ deletedCount: number }> {
    const before = this.docs.length;
    this.docs = this.docs.filter((d) => !matchesFilter(d, filter));
    return { deletedCount: before - this.docs.length };
  }

  async countDocuments(filter: Doc = {}, _opts?: { limit?: number }): Promise<number> {
    return this.docs.filter((d) => matchesFilter(d, filter)).length;
  }

  async createIndex(): Promise<string> {
    return "fake-index";
  }

  async distinct(field: string, filter: Doc = {}): Promise<unknown[]> {
    const values = this.docs.filter((d) => matchesFilter(d, filter)).map((d) => getPath(d, field));
    return [...new Set(values)];
  }

  async replaceOne(filter: Doc, replacement: T, opts?: { upsert?: boolean }): Promise<{ matchedCount: number; modifiedCount: number; upsertedCount: number }> {
    const idx = this.docs.findIndex((d) => matchesFilter(d, filter));
    if (idx >= 0) {
      this.docs[idx] = clone(replacement);
      return { matchedCount: 1, modifiedCount: 1, upsertedCount: 0 };
    }
    if (opts?.upsert) {
      this.docs.push(clone(replacement));
      return { matchedCount: 0, modifiedCount: 0, upsertedCount: 1 };
    }
    return { matchedCount: 0, modifiedCount: 0, upsertedCount: 0 };
  }

  async bulkWrite(ops: { replaceOne: { filter: Doc; replacement: T; upsert?: boolean } }[]): Promise<{ upsertedCount: number; modifiedCount: number }> {
    let upserted = 0;
    let modified = 0;
    for (const op of ops) {
      const { filter, replacement, upsert } = op.replaceOne;
      const idx = this.docs.findIndex((d) => matchesFilter(d, filter));
      if (idx >= 0) {
        this.docs[idx] = clone(replacement);
        modified++;
      } else if (upsert) {
        this.docs.push(clone(replacement));
        upserted++;
      }
    }
    return { upsertedCount: upserted, modifiedCount: modified };
  }

  // Minimal aggregation engine — only the stages/accumulators this
  // codebase's pipelines (analytics.ts) actually use.
  aggregate<R extends Doc = Doc>(pipeline: Doc[]): { toArray: () => Promise<R[]> } {
    let rows: Doc[] = clone(this.docs);

    for (const stage of pipeline) {
      if (stage.$match) {
        const filter = stage.$match as Doc;
        rows = rows.filter((d) => matchesFilter(d, filter));
      } else if (stage.$group) {
        rows = runGroup(rows, stage.$group as Doc);
      } else if (stage.$project) {
        rows = rows.map((d) => runProject(d, stage.$project as Doc));
      } else if (stage.$sort) {
        const [[field, dir]] = Object.entries(stage.$sort as Record<string, 1 | -1>);
        rows = [...rows].sort((a, b) => {
          const av = a[field],
            bv = b[field];
          if (av === bv) return 0;
          return ((av as never) > (bv as never) ? 1 : -1) * dir;
        });
      } else if (stage.$limit) {
        rows = rows.slice(0, stage.$limit as number);
      } else {
        throw new Error(`fake-mongo: unsupported aggregation stage ${Object.keys(stage)[0]}`);
      }
    }

    return { toArray: async () => clone(rows) as R[] };
  }
}

function resolveFieldExpr(doc: Doc, expr: unknown): unknown {
  if (typeof expr === "string" && expr.startsWith("$")) return getPath(doc, expr.slice(1));
  return expr;
}

function runGroup(rows: Doc[], spec: Doc): Doc[] {
  const groups = new Map<string, Doc[]>();
  const idExpr = spec._id;
  for (const row of rows) {
    const key = idExpr === null ? "null" : JSON.stringify(resolveFieldExpr(row, idExpr));
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(row);
  }

  const result: Doc[] = [];
  for (const [key, groupRows] of groups) {
    const out: Doc = { _id: key === "null" ? null : JSON.parse(key) };
    for (const [field, accExpr] of Object.entries(spec)) {
      if (field === "_id") continue;
      const acc = accExpr as Doc;
      if (acc.$sum !== undefined) {
        out[field] = groupRows.reduce((sum, r) => {
          const v = typeof acc.$sum === "number" ? acc.$sum : resolveFieldExpr(r, acc.$sum);
          return sum + (typeof v === "number" ? v : 0);
        }, 0);
      } else if (acc.$first !== undefined) {
        out[field] = resolveFieldExpr(groupRows[0], acc.$first);
      } else if (acc.$addToSet !== undefined) {
        const values = groupRows.map((r) => resolveFieldExpr(r, acc.$addToSet));
        out[field] = [...new Set(values.map((v) => JSON.stringify(v)))].map((v) => JSON.parse(v));
      } else {
        throw new Error(`fake-mongo: unsupported $group accumulator on field ${field}`);
      }
    }
    result.push(out);
  }
  return result;
}

function runProject(doc: Doc, spec: Doc): Doc {
  const out: Doc = {};
  for (const [field, expr] of Object.entries(spec)) {
    if (expr === 0) continue;
    if (expr === 1) {
      out[field] = doc[field];
    } else if (expr && typeof expr === "object" && "$size" in expr) {
      const arr = resolveFieldExpr(doc, (expr as Doc).$size);
      out[field] = Array.isArray(arr) ? arr.length : 0;
    } else {
      out[field] = resolveFieldExpr(doc, expr);
    }
  }
  return out;
}

/** A fake `Db` — just enough of the driver's Db interface (`.collection(name)`)
 * for this codebase's `getDb()`/`getRawDb()` call sites. Collections are
 * created lazily and persist for the lifetime of this FakeDb instance —
 * construct a fresh one per test (see test-db.ts) so tests never leak
 * state into each other. */
export class FakeDb {
  private collections = new Map<string, FakeCollection>();

  collection<T extends Doc = Doc>(name: string): FakeCollection<T> {
    if (!this.collections.has(name)) this.collections.set(name, new FakeCollection());
    return this.collections.get(name) as unknown as FakeCollection<T>;
  }
}
