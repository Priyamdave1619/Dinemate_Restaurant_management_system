import { describe, it, expect } from "vitest";
import { hashPassword, verifyPassword, createSessionToken, verifySessionToken } from "../auth";

describe("password hashing", () => {
  it("verifies a correct password against its own hash", () => {
    const { hash, salt } = hashPassword("correct-horse-battery-staple");
    expect(verifyPassword("correct-horse-battery-staple", hash, salt)).toBe(true);
  });

  it("rejects an incorrect password", () => {
    const { hash, salt } = hashPassword("correct-horse-battery-staple");
    expect(verifyPassword("wrong-password", hash, salt)).toBe(false);
  });

  it("never stores the password in plaintext — hash differs from the input", () => {
    const { hash } = hashPassword("my-password");
    expect(hash).not.toBe("my-password");
    expect(hash).not.toContain("my-password");
  });

  it("produces a different hash each time (random salt), even for the same password", () => {
    const a = hashPassword("same-password");
    const b = hashPassword("same-password");
    expect(a.hash).not.toBe(b.hash);
    expect(a.salt).not.toBe(b.salt);
    // But both still correctly verify against their own salt.
    expect(verifyPassword("same-password", a.hash, a.salt)).toBe(true);
    expect(verifyPassword("same-password", b.hash, b.salt)).toBe(true);
  });

  it("rejects a password checked against a mismatched hash/salt pair", () => {
    const a = hashPassword("password-a");
    const b = hashPassword("password-b");
    // a's plaintext against b's stored hash/salt must never verify.
    expect(verifyPassword("password-a", b.hash, b.salt)).toBe(false);
  });
});

describe("session JWTs", () => {
  const payload = {
    sub: "user-123",
    username: "rest000021",
    name: "Test Owner",
    role: "owner" as const,
    restaurantId: "REST000021",
  };

  it("round-trips a valid token: sign then verify returns the same payload", async () => {
    const token = await createSessionToken(payload);
    const verified = await verifySessionToken(token);
    expect(verified).toMatchObject(payload);
  });

  it("rejects a tampered token (payload modified after signing)", async () => {
    const token = await createSessionToken(payload);
    const parts = token.split(".");
    // Corrupt the payload segment (middle part of a JWT) — this is what an
    // attacker attempting to forge/escalate a role would have to do.
    const corruptedPayload = Buffer.from(parts[1], "base64url").toString("base64url") + "x";
    const tampered = `${parts[0]}.${corruptedPayload}.${parts[2]}`;
    expect(await verifySessionToken(tampered)).toBeNull();
  });

  it("rejects a token signed with a completely different structure (garbage input)", async () => {
    expect(await verifySessionToken("not.a.jwt")).toBeNull();
    expect(await verifySessionToken("")).toBeNull();
  });

  it("preserves restaurantId: null for super_admin payloads (not accidentally coerced to a string or dropped)", async () => {
    const superAdminPayload = { sub: "admin-1", username: "superadmin", name: "Platform Admin", role: "super_admin" as const, restaurantId: null };
    const token = await createSessionToken(superAdminPayload);
    const verified = await verifySessionToken(token);
    expect(verified?.restaurantId).toBeNull();
  });

  it("a token for one role cannot be silently read as a different role — the role claim round-trips exactly", async () => {
    for (const role of ["super_admin", "owner", "manager", "waiter"] as const) {
      const token = await createSessionToken({ ...payload, role, restaurantId: role === "super_admin" ? null : payload.restaurantId });
      const verified = await verifySessionToken(token);
      expect(verified?.role).toBe(role);
    }
  });
});
