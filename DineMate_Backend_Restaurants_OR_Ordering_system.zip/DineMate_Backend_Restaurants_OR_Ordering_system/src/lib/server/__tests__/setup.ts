import { vi, beforeEach } from "vitest";
import { FakeDb } from "./fake-mongo";

// A module-level `let` that the mock factory closes over — swapped out
// fresh before every single test (see beforeEach below) so no test can
// ever see another test's data. This is what makes tenant-isolation tests
// trustworthy: each one starts from a genuinely empty database.
let fakeDb = new FakeDb();

// Registered once, globally, via vitest.config.ts's `setupFiles` — every
// test file gets this mock automatically, with no per-file `vi.mock` call
// needed (and no risk of the hoisting pitfalls that come with trying to
// call `vi.mock` from inside a helper function instead of directly at a
// test file's top level).
vi.mock("@/lib/server/mongodb", () => ({
  getDb: async () => fakeDb,
  ensureIndexes: async () => undefined,
  getMongoClient: async () => {
    throw new Error("fake-mongo: getMongoClient() is not mocked — this codebase doesn't call it directly");
  },
}));

// next/headers (cookies()/headers()) only works inside an active Next.js
// request — outside of one (e.g. a plain Vitest run), calling it throws.
// session.ts's getSession() depends on both, so anything that tests
// session.ts, or anything that calls it transitively (requireRole,
// requireTenant, and by extension most route logic), needs this mocked
// too. Tests control the "incoming request" by importing
// setMockAuthHeader/setMockSessionCookie from this file.
let mockAuthHeader: string | null = null;
let mockSessionCookieValue: string | null = null;

export function setMockAuthHeader(value: string | null) {
  mockAuthHeader = value;
}
export function setMockSessionCookie(value: string | null) {
  mockSessionCookieValue = value;
}

vi.mock("next/headers", () => ({
  headers: async () => ({
    get: (name: string) => (name.toLowerCase() === "authorization" ? mockAuthHeader : null),
  }),
  cookies: async () => ({
    get: (name: string) => {
      if (name !== "dinemate_session" || mockSessionCookieValue === null) return undefined;
      return { value: mockSessionCookieValue };
    },
    set: () => undefined,
    delete: () => undefined,
  }),
}));

beforeEach(() => {
  fakeDb = new FakeDb();
  mockAuthHeader = null;
  mockSessionCookieValue = null;
});
