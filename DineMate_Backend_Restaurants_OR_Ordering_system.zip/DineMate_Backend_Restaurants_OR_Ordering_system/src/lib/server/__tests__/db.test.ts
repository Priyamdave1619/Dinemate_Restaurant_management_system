import { describe, it, expect } from "vitest";
import { tenantDb, platformDb, seedNewTenantContent } from "../db";
import { MenuCategory, Restaurant } from "@/lib/types";

describe("tenantDb() — the actual interface every route uses", () => {
  it("categories created for one restaurant are invisible to another restaurant's tenantDb instance", async () => {
    const dbA = tenantDb("REST_A");
    const dbB = tenantDb("REST_B");

    await dbA.categories.mutate((cur) => [...cur, { id: "cat-1", restaurantId: "REST_A", name: "Starters", icon: "🍟" }]);

    const categoriesA = await dbA.categories.all();
    const categoriesB = await dbB.categories.all();

    expect(categoriesA.some((c) => c.id === "cat-1")).toBe(true);
    expect(categoriesB.some((c) => c.id === "cat-1")).toBe(false);
  });

  it("two tenantDb(restaurantId) calls with the SAME id see the same data — scoping is by value, not by instance", async () => {
    const first = tenantDb("REST_A");
    await first.categories.mutate((cur) => [...cur, { id: "cat-x", restaurantId: "REST_A", name: "X", icon: "🍕" }]);

    // A brand-new tenantDb("REST_A") call — as every route handler makes
    // fresh, per-request — must see what the previous one wrote.
    const second = tenantDb("REST_A");
    const categories = await second.categories.all();
    expect(categories.some((c) => c.id === "cat-x")).toBe(true);
  });

  it("tenant settings are isolated per restaurant, with each restaurant getting its own default on first read", async () => {
    const dbA = tenantDb("REST_A");
    const dbB = tenantDb("REST_B");

    await dbA.settings.save({
      restaurantId: "REST_A",
      taxRatePercent: 18,
      restaurantName: "Tenant A Restaurant",
      currency: "INR",
      baseUrl: "http://localhost:3000",
    });

    const settingsA = await dbA.settings.get();
    const settingsB = await dbB.settings.get(); // never saved — should get its own default, not A's

    expect(settingsA.taxRatePercent).toBe(18);
    expect(settingsA.restaurantName).toBe("Tenant A Restaurant");
    expect(settingsB.taxRatePercent).not.toBe(18);
  });

  it("counters are namespaced per restaurant — each tenant's order sequence starts independently at 1", async () => {
    const dbA = tenantDb("REST_A");
    const dbB = tenantDb("REST_B");

    const a1 = await dbA.counters.next("order");
    const a2 = await dbA.counters.next("order");
    const b1 = await dbB.counters.next("order"); // a different tenant's FIRST order — must be 1, not 3

    expect(a1).toBe(1);
    expect(a2).toBe(2);
    expect(b1).toBe(1);
  });

  it("a brand-new tenant has NO menu content until seedNewTenantContent is explicitly called (no implicit auto-seeding)", async () => {
    const db = tenantDb("REST_NEW");
    // Deliberately NOT calling seedNewTenantContent — a tenant that exists
    // only via tenantDb() with no registration step must start genuinely
    // empty, not silently populated by the act of reading it.
    expect(await db.menu.all()).toEqual([]);
  });

  it("seedNewTenantContent (called once at registration) populates starter categories/menu/tables/offers, correctly scoped", async () => {
    await seedNewTenantContent("REST_NEW");
    const db = tenantDb("REST_NEW");

    const [menu, categories, tables, offers] = await Promise.all([
      db.menu.all(),
      db.categories.all(),
      db.tables.all(),
      db.offers.all(),
    ]);

    expect(menu.length).toBeGreaterThan(0);
    expect(menu.every((m) => m.restaurantId === "REST_NEW")).toBe(true);
    expect(categories.length).toBeGreaterThan(0);
    expect(tables.length).toBeGreaterThan(0);
    expect(offers.length).toBeGreaterThan(0);

    // A different, never-seeded tenant remains completely untouched.
    const otherTenantMenu = await tenantDb("REST_UNSEEDED").menu.all();
    expect(otherTenantMenu).toEqual([]);
  });

  it("deleting an item via mutate for one tenant never deletes a same-id item for another tenant", async () => {
    const dbA = tenantDb("REST_A");
    const dbB = tenantDb("REST_B");
    const item: MenuCategory = { id: "shared-cat-id", restaurantId: "REST_A", name: "A's", icon: "🍜" };
    const itemB: MenuCategory = { id: "shared-cat-id", restaurantId: "REST_B", name: "B's", icon: "🍜" };

    await dbA.categories.mutate(() => [item]);
    await dbB.categories.mutate(() => [itemB]);

    await dbA.categories.mutate((cur) => cur.filter((c) => c.id !== "shared-cat-id"));

    expect(await dbA.categories.all()).toEqual([]);
    expect(await dbB.categories.all()).toEqual([itemB]);
  });
});

describe("platformDb — cross-tenant, super-admin-only access", () => {
  it("restaurants created via platformDb are retrievable and listable", async () => {
    const restaurant: Restaurant = {
      id: "REST000099",
      name: "Test Diner",
      ownerName: "Test Owner",
      email: "owner@test.com",
      mobile: "9999999999",
      currency: "INR",
      status: "active",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      planId: "free",
      subscriptionStatus: "trialing",
      subscriptionStartedAt: new Date().toISOString(),
      subscriptionExpiresAt: new Date(Date.now() + 86400000).toISOString(),
    };

    await platformDb.restaurants.mutate((cur) => [...cur, restaurant]);

    const fetched = await platformDb.restaurants.get("REST000099");
    expect(fetched?.name).toBe("Test Diner");

    const all = await platformDb.restaurants.all();
    expect(all.some((r) => r.id === "REST000099")).toBe(true);
  });

  it("super_admin accounts (restaurantId: null) are isolated from every real tenant's staff list", async () => {
    await platformDb.superAdmins.mutate((cur) => [
      ...cur,
      {
        id: "admin-1",
        restaurantId: null,
        username: "superadmin",
        name: "Platform Admin",
        role: "super_admin",
        passwordHash: "x",
        passwordSalt: "y",
        createdAt: new Date().toISOString(),
        active: true,
      },
    ]);

    const admins = await platformDb.superAdmins.all();
    const tenantAStaff = await tenantDb("REST_A").users.all();

    expect(admins.some((a) => a.username === "superadmin")).toBe(true);
    // The super_admin must never show up when a tenant lists its own staff.
    expect(tenantAStaff.some((u) => u.username === "superadmin")).toBe(false);
  });

  it("default subscription plans seed on first read", async () => {
    const plans = await platformDb.plans.all();
    expect(plans.length).toBeGreaterThanOrEqual(4);
    expect(plans.some((p) => p.id === "free")).toBe(true);
    expect(plans.some((p) => p.id === "enterprise")).toBe(true);
  });
});
