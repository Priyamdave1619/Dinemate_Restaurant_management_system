import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import * as schema from "./schema";

/**
 * Neon HTTP driver — recommended for Next.js App Router route handlers.
 *
 * Security posture:
 * - DATABASE_URL must be set and must request TLS (`sslmode=require` or
 *   `verify-full`). Plain / prefer connections are rejected so credentials
 *   never leave the process in the clear.
 * - The connection string is never logged or returned from health endpoints.
 * - fetchConnectionCache keeps a small pool of HTTP connections warm without
 *   holding long-lived TCP sockets open (good for serverless).
 */

const DATABASE_URL = process.env.DATABASE_URL;

function assertSecureDatabaseUrl(url: string): void {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error("DATABASE_URL is not a valid URL");
  }

  if (parsed.protocol !== "postgresql:" && parsed.protocol !== "postgres:") {
    throw new Error("DATABASE_URL must use the postgres:// or postgresql:// scheme");
  }

  // Neon (and most managed Postgres) always speak TLS. Refuse anything that
  // explicitly disables it so a mis-copied connection string can't silently
  // fall back to cleartext.
  const sslmode = (parsed.searchParams.get("sslmode") || "").toLowerCase();
  const allowedSsl = new Set(["require", "verify-ca", "verify-full"]);
  if (sslmode && !allowedSsl.has(sslmode)) {
    throw new Error(
      `DATABASE_URL sslmode="${sslmode}" is not allowed. Use sslmode=require (or verify-full).`
    );
  }
  // If sslmode is missing in production, fail loud rather than risk a
  // cleartext connection.
  if (!sslmode && process.env.NODE_ENV === "production") {
    throw new Error(
      "DATABASE_URL must include sslmode=require (or verify-full) in production"
    );
  }
}

if (!DATABASE_URL) {
  throw new Error(
    "DATABASE_URL is not set. Add your Neon PostgreSQL connection string to .env.local " +
      "(see .env.example). Example: postgresql://user:pass@ep-xxx.region.aws.neon.tech/neondb?sslmode=require"
  );
}

assertSecureDatabaseUrl(DATABASE_URL);

const sql = neon(DATABASE_URL);
export const db = drizzle(sql, { schema });

/** Raw tagged-template SQL for one-off queries (stats aggregations, etc.). */
export const rawSql = sql;

export type Db = typeof db;

export type DbHealth = {
  ok: boolean;
  latencyMs: number;
  /** Postgres version string when the check succeeded */
  serverVersion?: string;
  /** High-level error class only — never includes connection string or query text */
  error?: string;
  checkedAt: string;
};

/**
 * Lightweight connectivity probe used by /api/health and /api/health/db.
 * Runs `SELECT 1` + version() so we know the pool can reach Postgres and
 * that auth/TLS succeeded. Never throws — callers decide how to surface
 * the result.
 */
export async function checkDatabaseHealth(timeoutMs = 5_000): Promise<DbHealth> {
  const started = Date.now();
  const checkedAt = new Date().toISOString();

  try {
    const result = await Promise.race([
      rawSql`SELECT 1 AS ok, version() AS version`,
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("database health check timed out")), timeoutMs)
      ),
    ]);

    const row = Array.isArray(result) ? result[0] : (result as { ok?: number; version?: string });
    return {
      ok: true,
      latencyMs: Date.now() - started,
      serverVersion: typeof row?.version === "string" ? row.version.split(" on ")[0] : undefined,
      checkedAt,
    };
  } catch (err) {
    // Strip anything that might echo the connection string or credentials.
    const message =
      err instanceof Error
        ? err.message.replace(/postgresql:\/\/[^\s]+/gi, "[redacted]").slice(0, 200)
        : "unknown database error";
    return {
      ok: false,
      latencyMs: Date.now() - started,
      error: message,
      checkedAt,
    };
  }
}
