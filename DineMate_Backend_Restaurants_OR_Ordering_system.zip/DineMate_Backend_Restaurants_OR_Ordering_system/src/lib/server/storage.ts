import { S3Client, PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { promises as fs } from "fs";
import path from "path";
import os from "os";

/**
 * Object storage for QR codes, logos, menu-import assets.
 * Production: Cloudflare R2 (S3-compatible).
 * Serverless without R2: /tmp (ephemeral — not shared across invocations).
 * Local dev: ./public
 *
 * Required env (R2):
 *   R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY,
 *   R2_BUCKET_NAME, R2_PUBLIC_URL
 */

const USE_R2 =
  !!process.env.R2_ACCOUNT_ID &&
  !!process.env.R2_ACCESS_KEY_ID &&
  !!process.env.R2_SECRET_ACCESS_KEY &&
  !!process.env.R2_BUCKET_NAME;

/** Vercel / AWS Lambda style — only /tmp is writable */
const IS_SERVERLESS =
  !!process.env.VERCEL ||
  !!process.env.AWS_LAMBDA_FUNCTION_NAME ||
  !!process.env.FUNCTION_NAME ||
  process.env.NEXT_RUNTIME === "nodejs" && process.cwd().startsWith("/var/task");

function getR2Client(): S3Client {
  const accountId = process.env.R2_ACCOUNT_ID!;
  return new S3Client({
    region: "auto",
    endpoint: `https://${accountId}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: process.env.R2_ACCESS_KEY_ID!,
      secretAccessKey: process.env.R2_SECRET_ACCESS_KEY!,
    },
  });
}

function publicUrlFor(key: string): string {
  const base = (process.env.R2_PUBLIC_URL || "").replace(/\/$/, "");
  return `${base}/${key}`;
}

function localRoot(): string {
  if (IS_SERVERLESS) return path.join(os.tmpdir(), "dinemate-storage");
  return path.join(process.cwd(), "public");
}

export async function readStoredFile(subPath: string): Promise<Buffer | null> {
  if (USE_R2) {
    try {
      const client = getR2Client();
      const res = await client.send(
        new GetObjectCommand({ Bucket: process.env.R2_BUCKET_NAME!, Key: subPath })
      );
      if (!res.Body) return null;
      const bytes = await res.Body.transformToByteArray();
      return Buffer.from(bytes);
    } catch {
      return null;
    }
  }
  const filePath = path.join(localRoot(), subPath);
  try {
    return await fs.readFile(filePath);
  } catch {
    return null;
  }
}

export async function writeStoredFile(
  subPath: string,
  buffer: Buffer,
  contentType: string
): Promise<string> {
  if (USE_R2) {
    const client = getR2Client();
    await client.send(
      new PutObjectCommand({
        Bucket: process.env.R2_BUCKET_NAME!,
        Key: subPath,
        Body: buffer,
        ContentType: contentType,
      })
    );
    return publicUrlFor(subPath);
  }
  const filePath = path.join(localRoot(), subPath);
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, buffer);
  if (IS_SERVERLESS) {
    // Not a public URL on serverless tmp
    return `tmp://${subPath}`;
  }
  return `/${subPath}`;
}

export function isR2Configured(): boolean {
  return USE_R2;
}

export function isServerlessRuntime(): boolean {
  return IS_SERVERLESS;
}
