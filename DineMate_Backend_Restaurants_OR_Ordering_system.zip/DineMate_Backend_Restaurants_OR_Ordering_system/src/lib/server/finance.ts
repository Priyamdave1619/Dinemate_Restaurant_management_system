import { eq } from "drizzle-orm";
import { drizzleDb } from "./pg-store";
import * as schema from "./schema";
import { getMonthlyStats, getYearlyStats } from "./reports";
import { Expense, ExpenseCategory, PeriodTotals, ProfitAndLoss } from "@/lib/types";

async function expensesForPeriod(restaurantId: string, field: "monthKey" | "yearKey", key: string): Promise<Expense[]> {
  const rows = await drizzleDb.select().from(schema.expenses).where(eq(schema.expenses.restaurantId, restaurantId));
  return rows.map((r) => r.data as Expense).filter((e) => (field === "monthKey" ? e.monthKey === key : e.yearKey === key));
}

function buildPnl(periodKey: string, totals: PeriodTotals, expenses: Expense[]): ProfitAndLoss {
  const expensesByCategory: Record<string, number> = {};
  let totalExpenses = 0;
  for (const e of expenses) {
    expensesByCategory[e.category] = (expensesByCategory[e.category] ?? 0) + e.amount;
    totalExpenses += e.amount;
  }
  const grossMarginPercent = totals.netSales > 0 ? (totals.grossProfit / totals.netSales) * 100 : 0;
  const netProfit = totals.grossProfit - totalExpenses;
  const netMarginPercent = totals.netSales > 0 ? (netProfit / totals.netSales) * 100 : 0;
  const averageOrderValue = totals.orderCount > 0 ? totals.totalCollected / totals.orderCount : 0;
  return {
    periodKey, grossSales: totals.grossSales, discounts: totals.discountTotal, netSales: totals.netSales,
    taxes: totals.taxTotal, cogs: totals.cogsTotal, grossProfit: totals.grossProfit, grossMarginPercent,
    totalExpenses, expensesByCategory, netProfit, netMarginPercent, orderCount: totals.orderCount, averageOrderValue,
  };
}

export async function getMonthlyPnl(restaurantId: string, monthKey: string): Promise<ProfitAndLoss> {
  const [stats, expenses] = await Promise.all([getMonthlyStats(restaurantId, monthKey), expensesForPeriod(restaurantId, "monthKey", monthKey)]);
  const totals: PeriodTotals = stats ?? { grossSales: 0, discountTotal: 0, netSales: 0, taxTotal: 0, totalCollected: 0, cogsTotal: 0, grossProfit: 0, orderCount: 0, itemsSold: 0 };
  return buildPnl(monthKey, totals, expenses);
}

export async function getYearlyPnl(restaurantId: string, yearKey: string): Promise<ProfitAndLoss> {
  const [totals, expenses] = await Promise.all([getYearlyStats(restaurantId, yearKey), expensesForPeriod(restaurantId, "yearKey", yearKey)]);
  return buildPnl(yearKey, totals, expenses);
}

export async function addExpense(restaurantId: string, input: { date: string; category: ExpenseCategory; description: string; amount: number; createdBy?: string }): Promise<Expense> {
  const d = new Date(input.date);
  const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  const yearKey = `${d.getFullYear()}`;
  const expense: Expense = {
    id: `exp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    restaurantId, date: input.date, monthKey, yearKey,
    category: input.category, description: input.description, amount: input.amount,
    createdAt: new Date().toISOString(), createdBy: input.createdBy,
  };
  await drizzleDb.insert(schema.expenses).values({ id: expense.id, restaurantId, monthKey, yearKey, date: d, data: expense });
  return expense;
}
