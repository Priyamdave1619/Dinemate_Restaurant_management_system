import { createHmac, timingSafeEqual } from "crypto";
import Razorpay from "razorpay";
import { platformDb } from "./db";
import { sendEmail, subscriptionRenewedEmail } from "./email";

/**
 * Subscription billing via Razorpay (the natural fit for an India-based,
 * INR-priced platform — swap providers here if that's not the right call
 * for your deployment). Fully env-gated: if RAZORPAY_KEY_ID/KEY_SECRET
 * aren't set, `createCheckoutOrder` returns a clear "not configured" error
 * instead of throwing or pretending to work — this is real integration
 * code, but it obviously can't be exercised end-to-end without real
 * Razorpay account credentials, which weren't provided.
 */

function getClient(): Razorpay | null {
  const keyId = process.env.RAZORPAY_KEY_ID;
  const keySecret = process.env.RAZORPAY_KEY_SECRET;
  if (!keyId || !keySecret) return null;
  return new Razorpay({ key_id: keyId, key_secret: keySecret });
}

export interface CheckoutResult {
  razorpayOrderId: string;
  amount: number; // in the smallest currency unit (paise for INR)
  currency: string;
  keyId: string;
  planId: string;
  restaurantId: string;
}

export async function createCheckoutOrder(
  restaurantId: string,
  planId: string
): Promise<{ ok: true; checkout: CheckoutResult } | { ok: false; status: number; error: string }> {
  const client = getClient();
  if (!client) {
    return { ok: false, status: 501, error: "Payments are not configured on this deployment yet" };
  }

  const plan = await platformDb.plans.get(planId);
  if (!plan) return { ok: false, status: 404, error: "Unknown plan" };
  if (plan.price <= 0) return { ok: false, status: 400, error: "This plan has no cost — no checkout needed" };

  const restaurant = await platformDb.restaurants.get(restaurantId);
  if (!restaurant) return { ok: false, status: 404, error: "Restaurant not found" };

  const amountInSmallestUnit = Math.round(plan.price * 100); // INR -> paise
  const order = await client.orders.create({
    amount: amountInSmallestUnit,
    currency: plan.currency,
    receipt: `${restaurantId}-${planId}-${Date.now()}`,
    notes: { restaurantId, planId },
  });

  return {
    ok: true,
    checkout: {
      razorpayOrderId: order.id,
      amount: amountInSmallestUnit,
      currency: plan.currency,
      keyId: process.env.RAZORPAY_KEY_ID!,
      planId,
      restaurantId,
    },
  };
}

/** Verifies the signature Razorpay's client SDK returns after a successful
 * checkout (`razorpay_order_id|razorpay_payment_id` HMAC-SHA256'd with your
 * key secret) — call this from the endpoint your frontend hits right after
 * checkout succeeds, before trusting the payment. */
export function verifyCheckoutSignature(orderId: string, paymentId: string, signature: string): boolean {
  const secret = process.env.RAZORPAY_KEY_SECRET;
  if (!secret) return false;
  const expected = createHmac("sha256", secret).update(`${orderId}|${paymentId}`).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(signature, "hex");
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

/** Verifies a Razorpay webhook's `X-Razorpay-Signature` header against the
 * raw request body (must be the untouched request text, not a re-serialized
 * JSON object — Razorpay signs the exact bytes it sent). */
export function verifyWebhookSignature(rawBody: string, signature: string): boolean {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret) return false;
  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(signature, "hex");
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

/** Applies a successful payment: extends the subscription by the plan's
 * duration, switches to that plan, marks the subscription active, and
 * emails the owner. Shared by both the client-side verify endpoint and the
 * webhook (Razorpay recommends trusting the webhook as the source of truth
 * and treating client-side verification as a fast-path UX improvement —
 * both paths funnel through this one function so the subscription is only
 * ever extended once real payment is confirmed, not just "checkout
 * started"). */
export async function applySuccessfulPayment(restaurantId: string, planId: string): Promise<void> {
  const plan = await platformDb.plans.get(planId);
  if (!plan) return;

  let found = false;
  const restaurants = await platformDb.restaurants.mutate((cur) =>
    cur.map((r) => {
      if (r.id !== restaurantId) return r;
      found = true;
      const base = new Date(r.subscriptionExpiresAt).getTime() > Date.now() ? new Date(r.subscriptionExpiresAt) : new Date();
      return {
        ...r,
        planId,
        subscriptionStatus: "active" as const,
        subscriptionExpiresAt: new Date(base.getTime() + plan.durationDays * 86400000).toISOString(),
        renewedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
    })
  );
  if (!found) return;
  const r = restaurants.find((x) => x.id === restaurantId)!;

  await platformDb.auditLogs.log({
    restaurantId,
    actorUserId: "system:razorpay",
    actorName: "Razorpay payment",
    actorRole: "owner",
    action: "subscription_change",
    entityType: "restaurant",
    entityId: restaurantId,
    details: { planId, source: "razorpay" },
  });

  if (r.email) {
    await sendEmail({
      ...subscriptionRenewedEmail({ ownerName: r.ownerName, expiresAt: r.subscriptionExpiresAt, planName: plan.name }),
      to: r.email,
    });
  }
}
