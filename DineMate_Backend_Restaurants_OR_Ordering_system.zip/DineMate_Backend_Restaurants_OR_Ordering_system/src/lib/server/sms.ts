import twilio from "twilio";

/**
 * SMS delivery via Twilio — same pattern as email.ts and payments.ts:
 * fully env-gated, real integration code, silently no-ops (with a console
 * warning) if credentials aren't set rather than breaking the caller.
 * Swap providers here (e.g. MSG91, which is common for India-only
 * deployments) if Twilio isn't the right fit; nothing outside this file
 * needs to change either way.
 */

let cachedClient: ReturnType<typeof twilio> | null | undefined;

function getClient(): ReturnType<typeof twilio> | null {
  if (cachedClient !== undefined) return cachedClient;
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  if (!sid || !token) {
    cachedClient = null;
    return null;
  }
  cachedClient = twilio(sid, token);
  return cachedClient;
}

export async function sendSms(to: string, body: string): Promise<{ sent: boolean; reason?: string }> {
  const client = getClient();
  const from = process.env.TWILIO_FROM_NUMBER;
  if (!client || !from) {
    console.warn(`[sms] Twilio not configured — skipped SMS to ${to}`);
    return { sent: false, reason: "Twilio not configured" };
  }

  try {
    await client.messages.create({ to, from, body });
    return { sent: true };
  } catch (err) {
    console.error("[sms] send failed", err);
    return { sent: false, reason: err instanceof Error ? err.message : "send failed" };
  }
}
