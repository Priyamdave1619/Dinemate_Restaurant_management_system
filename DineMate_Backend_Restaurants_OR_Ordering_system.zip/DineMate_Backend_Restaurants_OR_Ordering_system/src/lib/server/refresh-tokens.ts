import { randomUUID } from "crypto";
import { eq, and, isNull } from "drizzle-orm";
import { drizzleDb } from "./pg-store";
import * as schema from "./schema";
import { generateRefreshTokenValue, hashRefreshToken, REFRESH_TOKEN_TTL_DAYS } from "./auth";
import { UserRole } from "@/lib/types";

interface RefreshTokenRecord {
  id: string;
  userId: string;
  username: string;
  name: string;
  role: UserRole;
  restaurantId: string | null;
  tokenHash: string;
  createdAt: string;
  expiresAt: Date;
  revokedAt: string | null;
  replacedByTokenId: string | null;
}

function rowToRecord(row: typeof schema.refreshTokens.$inferSelect): RefreshTokenRecord {
  const data = row.data as {
    username: string;
    name: string;
    role: UserRole;
    restaurantId: string | null;
    createdAt: string;
  };
  return {
    id: row.id,
    userId: row.userId,
    username: data.username,
    name: data.name,
    role: data.role,
    restaurantId: data.restaurantId,
    tokenHash: row.tokenHash,
    createdAt: data.createdAt,
    expiresAt: row.expiresAt,
    revokedAt: row.revokedAt ? row.revokedAt.toISOString() : null,
    replacedByTokenId: row.replacedByTokenId,
  };
}

export async function issueRefreshToken(user: {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  restaurantId: string | null;
}): Promise<string> {
  const value = generateRefreshTokenValue();
  const now = new Date();
  const record: RefreshTokenRecord = {
    id: randomUUID(),
    userId: user.id,
    username: user.username,
    name: user.name,
    role: user.role,
    restaurantId: user.restaurantId,
    tokenHash: hashRefreshToken(value),
    createdAt: now.toISOString(),
    expiresAt: new Date(now.getTime() + REFRESH_TOKEN_TTL_DAYS * 86400000),
    revokedAt: null,
    replacedByTokenId: null,
  };
  await drizzleDb.insert(schema.refreshTokens).values({
    id: record.id,
    userId: record.userId,
    tokenHash: record.tokenHash,
    data: {
      username: record.username,
      name: record.name,
      role: record.role,
      restaurantId: record.restaurantId,
      createdAt: record.createdAt,
    },
    expiresAt: record.expiresAt,
    revokedAt: null,
    replacedByTokenId: null,
    createdAt: now,
  });
  return value;
}

export type RefreshResult =
  | { ok: true; record: RefreshTokenRecord; newValue: string }
  | { ok: false; reason: "not_found" | "expired" | "revoked" }
  | { ok: false; reason: "reused"; userId: string };

export async function rotateRefreshToken(presentedValue: string): Promise<RefreshResult> {
  const tokenHash = hashRefreshToken(presentedValue);
  const rows = await drizzleDb
    .select()
    .from(schema.refreshTokens)
    .where(eq(schema.refreshTokens.tokenHash, tokenHash))
    .limit(1);

  if (!rows[0]) return { ok: false, reason: "not_found" };
  const record = rowToRecord(rows[0]);

  if (record.revokedAt) return { ok: false, reason: "revoked" };
  if (record.replacedByTokenId) return { ok: false, reason: "reused", userId: record.userId };
  if (record.expiresAt.getTime() < Date.now()) return { ok: false, reason: "expired" };

  const newValue = generateRefreshTokenValue();
  const now = new Date();
  const next: RefreshTokenRecord = {
    id: randomUUID(),
    userId: record.userId,
    username: record.username,
    name: record.name,
    role: record.role,
    restaurantId: record.restaurantId,
    tokenHash: hashRefreshToken(newValue),
    createdAt: now.toISOString(),
    expiresAt: new Date(now.getTime() + REFRESH_TOKEN_TTL_DAYS * 86400000),
    revokedAt: null,
    replacedByTokenId: null,
  };

  await drizzleDb.insert(schema.refreshTokens).values({
    id: next.id,
    userId: next.userId,
    tokenHash: next.tokenHash,
    data: {
      username: next.username,
      name: next.name,
      role: next.role,
      restaurantId: next.restaurantId,
      createdAt: next.createdAt,
    },
    expiresAt: next.expiresAt,
    revokedAt: null,
    replacedByTokenId: null,
    createdAt: now,
  });

  await drizzleDb
    .update(schema.refreshTokens)
    .set({ replacedByTokenId: next.id })
    .where(eq(schema.refreshTokens.id, record.id));

  return { ok: true, record, newValue };
}

export async function revokeRefreshToken(presentedValue: string): Promise<void> {
  const tokenHash = hashRefreshToken(presentedValue);
  await drizzleDb
    .update(schema.refreshTokens)
    .set({ revokedAt: new Date() })
    .where(eq(schema.refreshTokens.tokenHash, tokenHash));
}

export async function revokeAllRefreshTokensForUser(userId: string): Promise<void> {
  await drizzleDb
    .update(schema.refreshTokens)
    .set({ revokedAt: new Date() })
    .where(and(eq(schema.refreshTokens.userId, userId), isNull(schema.refreshTokens.revokedAt)));
}
