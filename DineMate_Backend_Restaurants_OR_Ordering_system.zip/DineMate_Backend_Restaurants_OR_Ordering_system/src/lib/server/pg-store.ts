import { eq, inArray, isNull } from "drizzle-orm";
import { db, rawSql } from "./pg";
import * as schema from "./schema";
import { randomUUID } from "crypto";

type Scope = Record<string, unknown>;

const locks = new Map<string, Promise<unknown>>();

function lockKey(name: string, scope: Scope): string {
  return `${name}:${JSON.stringify(scope, Object.keys(scope).sort())}`;
}

async function withLock<T>(key: string, fn: () => Promise<T>): Promise<T> {
  const prev = locks.get(key) ?? Promise.resolve();
  let release!: () => void;
  const next = new Promise<void>((resolve) => (release = resolve));
  locks.set(key, prev.then(() => next));
  await prev;
  try {
    return await fn();
  } finally {
    release();
  }
}

const TABLE_MAP = {
  restaurants: schema.restaurants,
  subscriptionPlans: schema.subscriptionPlans,
  users: schema.users,
  categories: schema.categories,
  menuItems: schema.menuItems,
  tables: schema.tables,
  offers: schema.offers,
  orders: schema.orders,
  billedOrders: schema.billedOrders,
  soldItems: schema.soldItems,
  expenses: schema.expenses,
  notifications: schema.notifications,
  auditLogs: schema.auditLogs,
  loginHistory: schema.loginHistory,
  dailyStats: schema.dailyStats,
  monthlyStats: schema.monthlyStats,
  menuImportSessions: schema.menuImportSessions,
  menuFiles: schema.menuFiles,
} as const;

type CollectionName = keyof typeof TABLE_MAP;

function rowToDoc<T extends { id: string }>(row: { data: unknown; id?: string; restaurantId?: string | null }): T {
  const data = (row.data ?? {}) as Record<string, unknown>;
  const out: Record<string, unknown> = { ...data };
  if (row.id && !out.id) out.id = row.id;
  if ("restaurantId" in row && row.restaurantId !== undefined && out.restaurantId === undefined) {
    out.restaurantId = row.restaurantId;
  }
  return out as T;
}

function docToRow(name: CollectionName, doc: Record<string, unknown>, scope: Scope) {
  const id = String(doc.id ?? "");
  const restaurantId =
    (scope.restaurantId as string | undefined) ??
    (doc.restaurantId as string | null | undefined) ??
    null;

  switch (name) {
    case "restaurants":
      return {
        id,
        data: doc,
        status: String(doc.status ?? "pending"),
        planId: (doc.planId as string) ?? null,
        subscriptionExpiresAt: doc.subscriptionExpiresAt ? new Date(String(doc.subscriptionExpiresAt)) : null,
        createdAt: doc.createdAt ? new Date(String(doc.createdAt)) : new Date(),
        updatedAt: new Date(),
      };
    case "subscriptionPlans":
      return {
        id,
        data: doc,
        active: doc.active !== false,
        createdAt: doc.createdAt ? new Date(String(doc.createdAt)) : new Date(),
      };
    case "users":
      return {
        id,
        restaurantId,
        username: String(doc.username ?? "").toLowerCase(),
        data: doc,
        role: String(doc.role ?? "waiter"),
        active: doc.active !== false,
        createdAt: doc.createdAt ? new Date(String(doc.createdAt)) : new Date(),
      };
    case "categories":
    case "offers":
    case "notifications":
    case "menuImportSessions":
      return {
        id,
        restaurantId: restaurantId as string,
        data: doc,
        ...(name === "menuImportSessions"
          ? {
              status: String(doc.status ?? "uploaded"),
              createdAt: doc.createdAt ? new Date(String(doc.createdAt)) : new Date(),
              updatedAt: new Date(),
            }
          : {}),
      };
    case "menuFiles":
      return {
        id,
        restaurantId: restaurantId as string,
        fileName: String(doc.fileName ?? doc.file_name ?? ""),
        fileType: String(doc.fileType ?? doc.file_type ?? "application/octet-stream"),
        fileSize: Number(doc.fileSize ?? doc.file_size ?? 0),
        sha256: (doc.sha256 as string) ?? null,
        storageKey: (doc.storageKey as string) ?? (doc.storage_key as string) ?? null,
        fileUrl: (doc.fileUrl as string) ?? (doc.file_url as string) ?? null,
        contentBase64: (doc.contentBase64 as string) ?? (doc.content_base64 as string) ?? null,
        uploadedBy: (doc.uploadedBy as string) ?? (doc.uploaded_by as string) ?? null,
        status: String(doc.status ?? "uploaded"),
        data: doc.data && typeof doc.data === "object" ? doc.data : doc,
        createdAt: doc.createdAt ? new Date(String(doc.createdAt)) : new Date(),
        updatedAt: new Date(),
      };
    case "menuItems":
      return { id, restaurantId: restaurantId as string, categoryId: (doc.categoryId as string) ?? null, data: doc };
    case "tables":
      return { id, restaurantId: restaurantId as string, number: Number(doc.number ?? 0), data: doc };
    case "orders":
      return {
        id,
        restaurantId: restaurantId as string,
        status: String(doc.status ?? "accepted"),
        tableNumber: doc.tableNumber != null ? Number(doc.tableNumber) : null,
        billGenerated: !!doc.billGenerated,
        placedAt: doc.placedAt ? new Date(String(doc.placedAt)) : null,
        data: doc,
      };
    case "billedOrders":
      return {
        id,
        restaurantId: restaurantId as string,
        placedAt: doc.placedAt ? new Date(String(doc.placedAt)) : null,
        data: doc,
      };
    case "soldItems":
      return {
        id,
        restaurantId: restaurantId as string,
        orderId: (doc.orderId as string) ?? null,
        itemId: (doc.itemId as string) ?? null,
        dateKey: (doc.dateKey as string) ?? null,
        monthKey: (doc.monthKey as string) ?? null,
        data: doc,
      };
    case "expenses":
      return {
        id,
        restaurantId: restaurantId as string,
        monthKey: (doc.monthKey as string) ?? null,
        yearKey: (doc.yearKey as string) ?? null,
        date: doc.date ? new Date(String(doc.date)) : null,
        data: doc,
      };
    case "auditLogs":
      return {
        id: id || randomUUID(),
        restaurantId,
        data: doc,
        action: String(doc.action ?? "update"),
        createdAt: doc.createdAt ? new Date(String(doc.createdAt)) : new Date(),
      };
    case "loginHistory":
      return {
        id: id || randomUUID(),
        restaurantId,
        userId: (doc.userId as string) ?? null,
        data: doc,
        success: !!doc.success,
        createdAt: doc.createdAt ? new Date(String(doc.createdAt)) : new Date(),
      };
    default:
      return { id, data: doc };
  }
}

export async function readCollection<T extends { id: string }>(
  name: CollectionName | string,
  scope: Scope = {}
): Promise<T[]> {
  const tableName = name as CollectionName;
  const table = TABLE_MAP[tableName];
  if (!table) return [];

  if (tableName === "users" && scope.restaurantId === null) {
    const rows = await db.select().from(schema.users).where(isNull(schema.users.restaurantId));
    return rows.map((r) => rowToDoc<T>(r));
  }

  if (Object.keys(scope).length === 0) {
    const rows = await db.select().from(table);
    return rows.map((r) => rowToDoc<T>(r as never));
  }

  if ("restaurantId" in scope && scope.restaurantId != null) {
    const rid = String(scope.restaurantId);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const col = (table as any).restaurantId;
    if (col) {
      const rows = await db.select().from(table).where(eq(col, rid));
      return rows.map((r) => rowToDoc<T>(r as never));
    }
  }

  const rows = await db.select().from(table);
  const docs = rows.map((r) => rowToDoc<T>(r as never));
  return docs.filter((d) => {
    for (const [k, v] of Object.entries(scope)) {
      if ((d as Record<string, unknown>)[k] !== v) return false;
    }
    return true;
  });
}

export async function writeCollection<T extends { id: string }>(
  name: CollectionName | string,
  value: T[],
  scope: Scope = {}
): Promise<void> {
  await mutateCollection(name, () => value, scope);
}

export async function mutateCollection<T extends { id: string }>(
  name: CollectionName | string,
  fn: (current: T[]) => T[] | Promise<T[]>,
  scope: Scope = {}
): Promise<T[]> {
  const tableName = name as CollectionName;
  return withLock(lockKey(tableName, scope), async () => {
    const current = await readCollection<T>(tableName, scope);
    const next = await fn(current);
    await replaceAll(tableName, next, scope);
    return next;
  });
}

async function replaceAll<T extends { id: string }>(
  name: CollectionName,
  value: T[],
  scope: Scope
): Promise<void> {
  const table = TABLE_MAP[name];
  if (!table) return;

  const rid = scope.restaurantId != null ? String(scope.restaurantId) : null;

  if (name === "users" && scope.restaurantId === null) {
    await db.delete(schema.users).where(isNull(schema.users.restaurantId));
  } else if (name === "users" && rid) {
    await db.delete(schema.users).where(eq(schema.users.restaurantId, rid));
  } else if (rid != null) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const ridCol = (table as any).restaurantId;
    if (ridCol) await db.delete(table).where(eq(ridCol, rid));
  } else if (Object.keys(scope).length === 0) {
    await db.delete(table);
  }

  if (value.length === 0) return;

  const rows = value.map((v) => docToRow(name, v as unknown as Record<string, unknown>, scope));
  for (let i = 0; i < rows.length; i += 50) {
    const batch = rows.slice(i, i + 50);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await db.insert(table).values(batch as any).onConflictDoNothing();
  }
}

export async function seedCollectionOnce<T extends { id: string }>(
  name: CollectionName | string,
  seed: T[],
  scope: Scope = {}
): Promise<void> {
  if (seed.length === 0) return;
  const tableName = name as CollectionName;
  const table = TABLE_MAP[tableName];
  if (!table) return;
  const rows = seed.map((d) =>
    docToRow(tableName, { ...d, ...scope } as unknown as Record<string, unknown>, scope)
  );
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    await db.insert(table).values(rows as any).onConflictDoNothing();
  } catch {
    // ignore duplicate-key races
  }
}

export async function readSingleton<T>(name: string, seed: T): Promise<T> {
  const rows = await db.select().from(schema.singletons).where(eq(schema.singletons.key, name)).limit(1);
  if (rows[0]) return rows[0].data as T;
  await db.insert(schema.singletons).values({ key: name, data: seed as never }).onConflictDoNothing();
  return seed;
}

export async function writeSingleton<T>(name: string, value: T): Promise<void> {
  await db
    .insert(schema.singletons)
    .values({ key: name, data: value as never })
    .onConflictDoUpdate({ target: schema.singletons.key, set: { data: value as never } });
}

export async function nextCounter(key: string): Promise<number> {
  const result = await rawSql`
    INSERT INTO counters (key, value)
    VALUES (${key}, 1)
    ON CONFLICT (key) DO UPDATE SET value = counters.value + 1
    RETURNING value
  `;
  return Number(result[0]?.value ?? 1);
}

export { db as drizzleDb, rawSql };
