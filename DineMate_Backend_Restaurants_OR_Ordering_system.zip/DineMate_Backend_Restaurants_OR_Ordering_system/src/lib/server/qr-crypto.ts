/**
 * QR payload encryption — AES-256-GCM with a shared secret.
 *
 * Encoded URL shape (customer portal):
 *   {baseUrl}/q/{token}
 *
 * Token format (base64url):  iv(12) || ciphertext || tag(16)
 * Plaintext JSON: { r: restaurantId, t: tableNumber, v: 1 }
 *
 * The same key must be configured on the customer portal as
 * NEXT_PUBLIC_QR_SECRET (or QR_SECRET) so scanned codes can be decrypted
 * client-side without an extra round-trip. Backend also exposes
 * GET /api/qr/resolve?token=… for server-side resolution.
 */

import { createCipheriv, createDecipheriv, createHash, randomBytes } from "crypto";

export type QrPayload = {
  /** restaurantId */
  r: string;
  /** table number */
  t: number;
  /** schema version */
  v: 1;
};

const ALGO = "aes-256-gcm";
const IV_LEN = 12;
const TAG_LEN = 16;

function deriveKey(secret: string): Buffer {
  // Stable 32-byte key from any-length secret
  return createHash("sha256").update(secret, "utf8").digest();
}

function getSecret(): string {
  const secret =
    process.env.QR_SECRET ||
    process.env.NEXT_PUBLIC_QR_SECRET ||
    process.env.AUTH_SECRET ||
    "";
  if (!secret || secret.length < 16) {
    // Fallback for local dev only — production must set QR_SECRET
    return "dinemate-dev-qr-secret-change-me";
  }
  return secret;
}

function toBase64Url(buf: Buffer): string {
  return buf
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function fromBase64Url(s: string): Buffer {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  const b64 = s.replace(/-/g, "+").replace(/_/g, "/") + pad;
  return Buffer.from(b64, "base64");
}

/** Encrypt restaurant + table into an opaque URL-safe token. */
export function encryptQrPayload(restaurantId: string, tableNumber: number): string {
  const payload: QrPayload = {
    r: String(restaurantId).trim(),
    t: Number(tableNumber),
    v: 1,
  };
  if (!payload.r || !Number.isInteger(payload.t) || payload.t < 1) {
    throw new Error("Invalid QR payload");
  }
  const key = deriveKey(getSecret());
  const iv = randomBytes(IV_LEN);
  const cipher = createCipheriv(ALGO, key, iv);
  const plain = Buffer.from(JSON.stringify(payload), "utf8");
  const enc = Buffer.concat([cipher.update(plain), cipher.final()]);
  const tag = cipher.getAuthTag();
  return toBase64Url(Buffer.concat([iv, enc, tag]));
}

/** Decrypt token → { restaurantId, tableNumber } or null if invalid. */
export function decryptQrPayload(
  token: string
): { restaurantId: string; tableNumber: number } | null {
  try {
    const raw = (token || "").trim();
    if (!raw || raw.length < 40) return null;
    const buf = fromBase64Url(raw);
    if (buf.length < IV_LEN + TAG_LEN + 1) return null;
    const iv = buf.subarray(0, IV_LEN);
    const tag = buf.subarray(buf.length - TAG_LEN);
    const data = buf.subarray(IV_LEN, buf.length - TAG_LEN);
    const key = deriveKey(getSecret());
    const decipher = createDecipheriv(ALGO, key, iv);
    decipher.setAuthTag(tag);
    const plain = Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8");
    const parsed = JSON.parse(plain) as QrPayload;
    if (parsed?.v !== 1 || typeof parsed.r !== "string" || typeof parsed.t !== "number") {
      return null;
    }
    const restaurantId = parsed.r.trim();
    const tableNumber = Math.floor(parsed.t);
    if (!restaurantId || tableNumber < 1 || tableNumber > 9999) return null;
    return { restaurantId, tableNumber };
  } catch {
    return null;
  }
}

/**
 * Build the customer-facing QR target URL.
 * Canonical shape: {baseUrl}/q/{encryptedToken}
 * Also supports legacy plain paths for docs / tests.
 */
export function buildEncryptedTableUrl(
  baseUrl: string,
  restaurantId: string,
  tableNumber: number
): string {
  const base = (baseUrl || "http://localhost:3003").replace(/\/$/, "");
  const token = encryptQrPayload(restaurantId, tableNumber);
  return `${base}/q/${token}`;
}

/** Plain (non-encrypted) URL — kept for compatibility / debugging. */
export function buildPlainTableUrl(
  baseUrl: string,
  restaurantId: string,
  tableNumber: number
): string {
  const base = (baseUrl || "http://localhost:3003").replace(/\/$/, "");
  return `${base}/${encodeURIComponent(restaurantId)}/table/${tableNumber}`;
}
