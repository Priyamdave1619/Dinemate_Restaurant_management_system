import { tenantDb } from "./db";
import type { MenuItem, Order, SoldItemRecord } from "@/lib/types";
import { withAvailabilityFlags } from "./menu-availability";

export interface RankedMenuItem {
  item: MenuItem & { availableNow?: boolean; outsideSchedule?: boolean };
  score: number;
  reason: string;
}

export interface MenuRecommendations {
  bestsellers: RankedMenuItem[];
  recommended: RankedMenuItem[];
  /** itemId → other itemIds frequently ordered in the same bill */
  pairs: Record<string, Array<{ itemId: string; score: number }>>;
}

function qtyByItem(sold: SoldItemRecord[]): Map<string, number> {
  const map = new Map<string, number>();
  for (const s of sold) {
    map.set(s.itemId, (map.get(s.itemId) || 0) + (s.quantity || 0));
  }
  return map;
}

/** Co-occurrence: how often two items appear on the same billed order. */
function buildPairs(orders: Order[]): Record<string, Array<{ itemId: string; score: number }>> {
  const pairCount = new Map<string, number>(); // "a|b" sorted key
  for (const o of orders) {
    const ids = [
      ...new Set((o.items || []).map((it) => it.itemId).filter(Boolean)),
    ];
    for (let i = 0; i < ids.length; i++) {
      for (let j = i + 1; j < ids.length; j++) {
        const a = ids[i];
        const b = ids[j];
        const key = a < b ? `${a}|${b}` : `${b}|${a}`;
        pairCount.set(key, (pairCount.get(key) || 0) + 1);
      }
    }
  }

  const byItem = new Map<string, Array<{ itemId: string; score: number }>>();
  for (const [key, score] of pairCount) {
    const [a, b] = key.split("|");
    if (!byItem.has(a)) byItem.set(a, []);
    if (!byItem.has(b)) byItem.set(b, []);
    byItem.get(a)!.push({ itemId: b, score });
    byItem.get(b)!.push({ itemId: a, score });
  }
  const out: Record<string, Array<{ itemId: string; score: number }>> = {};
  for (const [id, list] of byItem) {
    out[id] = list.sort((x, y) => y.score - x.score).slice(0, 6);
  }
  return out;
}

function tagBoost(item: MenuItem): number {
  const tags = (item.tags || []).map((t) => t.toLowerCase());
  let boost = 0;
  if (tags.includes("bestseller") || tags.includes("popular")) boost += 50;
  if (tags.includes("recommended") || tags.includes("chef_special")) boost += 30;
  if (tags.includes("new")) boost += 15;
  return boost;
}

/**
 * Non-AI recommendations for the customer menu:
 * - Bestsellers from real sold quantity (+ tag boost)
 * - Recommended from tags + solid sellers not already in top list
 * - "Often ordered with" pairs from billed order co-occurrence
 */
export async function getMenuRecommendations(
  restaurantId: string,
  opts?: { bestsellerLimit?: number; recommendedLimit?: number }
): Promise<MenuRecommendations> {
  const bestsellerLimit = opts?.bestsellerLimit ?? 8;
  const recommendedLimit = opts?.recommendedLimit ?? 8;

  const db = tenantDb(restaurantId);
  const [menu, sold, billed, categories] = await Promise.all([
    db.menu.all(),
    db.soldItems.all(),
    db.billedOrders.all(),
    db.categories.all(),
  ]);

  const categoryById = new Map(categories.map((c) => [c.id, c]));
  const availableMenu = withAvailabilityFlags(
    menu.filter((m) => m.available !== false),
    new Date(),
    categoryById
  ).filter((m) => m.availableNow !== false);

  const menuById = new Map(availableMenu.map((m) => [m.id, m]));
  const qty = qtyByItem(sold);

  // Score = units sold + tag boost
  const scored = availableMenu
    .map((item) => {
      const units = qty.get(item.id) || 0;
      const boost = tagBoost(item);
      const score = units * 2 + boost;
      let reason = "Popular";
      if (units > 0) reason = `Ordered ${units}×`;
      const tags = (item.tags || []).map((t) => t.toLowerCase());
      if (tags.includes("bestseller")) reason = "Bestseller";
      else if (tags.includes("recommended") || tags.includes("chef_special")) reason = "Recommended";
      else if (tags.includes("new") && units === 0) reason = "New";
      return { item, score, reason, units };
    })
    .sort((a, b) => b.score - a.score || a.item.name.localeCompare(b.item.name));

  // If no sales yet, prefer tagged items then any available
  const bestsellers = scored
    .filter((r) => r.units > 0 || (r.item.tags || []).some((t) =>
      ["bestseller", "popular"].includes(t.toLowerCase())
    ))
    .slice(0, bestsellerLimit);

  // Fallback: if still empty, top by tag boost / name
  const bestFinal =
    bestsellers.length > 0
      ? bestsellers
      : scored.slice(0, Math.min(bestsellerLimit, 6));

  const bestIds = new Set(bestFinal.map((r) => r.item.id));

  const recommended = scored
    .filter((r) => !bestIds.has(r.item.id))
    .filter((r) => {
      const tags = (r.item.tags || []).map((t) => t.toLowerCase());
      return (
        tags.includes("recommended") ||
        tags.includes("chef_special") ||
        tags.includes("new") ||
        r.units > 0
      );
    })
    .slice(0, recommendedLimit);

  // Fallback recommended from remaining scored
  const recFinal =
    recommended.length > 0
      ? recommended
      : scored.filter((r) => !bestIds.has(r.item.id)).slice(0, recommendedLimit);

  const pairsRaw = buildPairs(billed);
  // Only keep pairs that still exist on the available menu
  const pairs: Record<string, Array<{ itemId: string; score: number }>> = {};
  for (const [id, list] of Object.entries(pairsRaw)) {
    if (!menuById.has(id)) continue;
    const filtered = list.filter((p) => menuById.has(p.itemId));
    if (filtered.length) pairs[id] = filtered;
  }

  return {
    bestsellers: bestFinal.map(({ item, score, reason }) => ({ item, score, reason })),
    recommended: recFinal.map(({ item, score, reason }) => ({ item, score, reason })),
    pairs,
  };
}
