import { NextResponse } from "next/server";

/**
 * Every response in this API follows one of these two shapes, per the
 * spec's API Standards section:
 *
 *   Success: { success: true, message, data, pagination? }
 *   Error:   { success: false, message, errors: [] }
 *
 * `pagination` is only included when the caller actually has pagination
 * metadata (page/pageSize/total/totalPages) to report — omitted entirely
 * otherwise, rather than sent as null/empty, so a client can reliably use
 * its presence to tell a paginated list response apart from a plain one.
 */

export interface Pagination {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export function apiSuccess<T>(
  data: T,
  message = "Success",
  options?: { status?: number; pagination?: Pagination; headers?: HeadersInit }
) {
  const body: { success: true; message: string; data: T; pagination?: Pagination } = {
    success: true,
    message,
    data,
  };
  if (options?.pagination) body.pagination = options.pagination;
  return NextResponse.json(body, { status: options?.status ?? 200, headers: options?.headers });
}

export function apiError(message: string, status: number, errors: string[] = [], headers?: HeadersInit) {
  return NextResponse.json({ success: false, message, errors }, { status, headers });
}

/**
 * Wraps a route handler so any unhandled exception (DB connection
 * failure, a bug, anything) still returns the spec's standard JSON error
 * envelope instead of an empty body / Next's bare default 500 — verified
 * live: before this existed, an unhandled exception in any route returned
 * `HTTP 500` with a completely empty response body, not JSON at all.
 *
 * The real error is logged server-side (so it's still debuggable) but
 * never sent to the client — an internal exception message/stack could
 * leak implementation details (DB connection strings, file paths, query
 * shapes) that have no business being in an API response.
 */
export function withErrorHandling<Args extends unknown[]>(
  handler: (...args: Args) => Promise<Response>
): (...args: Args) => Promise<Response> {
  return async (...args: Args) => {
    try {
      return await handler(...args);
    } catch (err) {
      console.error("[unhandled route error]", err);
      return apiError("An unexpected error occurred. Please try again.", 500);
    }
  };
}
