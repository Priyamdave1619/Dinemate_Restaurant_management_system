import { randomUUID } from "crypto";
import { tenantDb, platformDb } from "./db";
import { sendEmail, subscriptionExpiringEmail } from "./email";
import { sendSms } from "./sms";
import { AppNotification, NotificationType, UserRole } from "@/lib/types";

/**
 * In-app notifications are fully implemented and tenant-scoped (below).
 * Email delivery (`email.ts`) and SMS delivery (`sms.ts`) are both wired up
 * for the notification types where they matter — see `deliverExternal` —
 * via any SMTP provider / Twilio respectively, both configured through env
 * vars. Push is not wired up (no device-token infrastructure exists in
 * this backend-only repo — that needs a mobile/web client to register
 * tokens against first).
 */
export async function notify(
  restaurantId: string,
  input: {
    type: NotificationType;
    title: string;
    message: string;
    targetRole?: UserRole | null;
    relatedEntityType?: string;
    relatedEntityId?: string;
  }
): Promise<AppNotification> {
  const notification: AppNotification = {
    id: `notif-${randomUUID()}`,
    restaurantId,
    type: input.type,
    title: input.title,
    message: input.message,
    targetRole: input.targetRole ?? null,
    read: false,
    createdAt: new Date().toISOString(),
    relatedEntityType: input.relatedEntityType,
    relatedEntityId: input.relatedEntityId,
  };

  await tenantDb(restaurantId).notifications.mutate((cur) => [notification, ...cur].slice(0, 500));
  await deliverExternal(restaurantId, notification);
  return notification;
}

// Notification types worth an email (as opposed to in-app-only, high-
// frequency operational stuff like new_order — nobody wants an email per
// order). Keep this list deliberately short; every addition here is an
// email that will actually land in someone's inbox.
const EMAIL_WORTHY: NotificationType[] = ["subscription_expiring", "subscription_expired", "staff_added"];

// SMS is reserved for the single most time-critical case — a lapsed/about-
// to-lapse subscription, where email might sit unread but a text is far
// more likely to get immediate attention. Everything else stays email/in-
// app only; SMS costs money per message and shouldn't fire on routine
// events.
const SMS_WORTHY: NotificationType[] = ["subscription_expiring", "subscription_expired"];

async function deliverExternal(restaurantId: string, notification: AppNotification): Promise<void> {
  const emailWorthy = EMAIL_WORTHY.includes(notification.type);
  const smsWorthy = SMS_WORTHY.includes(notification.type);
  if (!emailWorthy && !smsWorthy) return;

  const restaurant = await platformDb.restaurants.get(restaurantId);
  if (!restaurant) return;

  if (smsWorthy && restaurant.mobile) {
    await sendSms(restaurant.mobile, `${notification.title}: ${notification.message}`);
  }

  if (!emailWorthy || !restaurant.email) return;

  // subscription_expiring already has a richer template with computed
  // days-left; everything else falls back to a generic in-app-title/message
  // email so new notification types get *some* email coverage automatically
  // without needing a bespoke template written for each one.
  if (notification.type === "subscription_expiring") {
    const daysLeft = Math.max(0, Math.ceil((new Date(restaurant.subscriptionExpiresAt).getTime() - Date.now()) / 86400000));
    await sendEmail({ ...subscriptionExpiringEmail({ ownerName: restaurant.ownerName, daysLeft }), to: restaurant.email });
    return;
  }

  await sendEmail({
    to: restaurant.email,
    subject: notification.title,
    html: `<p>${notification.message}</p>`,
  });
}

export async function listNotifications(
  restaurantId: string,
  forRole: UserRole,
  unreadOnly = false
): Promise<AppNotification[]> {
  const all = await tenantDb(restaurantId).notifications.all();
  return all
    .filter((n) => n.targetRole === null || n.targetRole === forRole)
    .filter((n) => !unreadOnly || !n.read)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function markNotificationRead(restaurantId: string, id: string): Promise<AppNotification[]> {
  return tenantDb(restaurantId).notifications.mutate((cur) => cur.map((n) => (n.id === id ? { ...n, read: true } : n)));
}

export async function markAllNotificationsRead(restaurantId: string): Promise<AppNotification[]> {
  return tenantDb(restaurantId).notifications.mutate((cur) => cur.map((n) => ({ ...n, read: true })));
}
