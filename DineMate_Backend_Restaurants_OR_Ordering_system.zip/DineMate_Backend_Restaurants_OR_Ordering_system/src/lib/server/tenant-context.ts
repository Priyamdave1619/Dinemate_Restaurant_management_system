import { NextRequest } from "next/server";
import { platformDb } from "./db";
import { getSession } from "./session";

export type PublicTenantResult =
  | { ok: true; restaurantId: string }
  | { ok: false; status: number; message: string };

/**
 * Menu browsing, order placement, KOT, and bill viewing are all reachable
 * by customers scanning a table QR code — there is no login for them, so
 * these routes can't rely on a session for tenant context the way staff
 * routes do.
 *
 * Resolution order:
 *   1. A logged-in staff session (owner/manager/waiter) — lets the admin
 *      dashboard reuse these same GET endpoints.
 *   2. `?restaurantId=REST000021` on the request — what the customer app
 *      must read out of the scanned QR URL and forward on every call.
 *
 * Either way, the restaurant's live status/subscription is checked on
 * every call, same as requireTenant() does for staff routes.
 */
export async function resolvePublicRestaurant(req: NextRequest): Promise<PublicTenantResult> {
  const session = await getSession();
  const restaurantId = session?.restaurantId || req.nextUrl.searchParams.get("restaurantId");

  if (!restaurantId) {
    return { ok: false, status: 400, message: "restaurantId is required (scan the table QR code again)" };
  }

  const restaurant = await platformDb.restaurants.get(restaurantId);
  if (!restaurant) return { ok: false, status: 404, message: "Restaurant not found" };
  if (restaurant.status === "suspended") return { ok: false, status: 403, message: "This restaurant is currently unavailable" };
  if (restaurant.status === "pending") return { ok: false, status: 403, message: "This restaurant is not yet active" };
  if (new Date(restaurant.subscriptionExpiresAt).getTime() < Date.now()) {
    return { ok: false, status: 402, message: "This restaurant's service is temporarily unavailable" };
  }

  return { ok: true, restaurantId };
}

/**
 * Order ids are minted as `ord-{restaurantId}-{n}` specifically so that
 * order-scoped customer routes (view order, add items, request KOT, view
 * bill) can resolve their tenant from the id alone — no restaurantId query
 * param needed once a customer already has an order id in hand.
 */
export function restaurantIdFromOrderId(orderId: string): string | null {
  const match = /^ord-(REST\d+)-\d+$/.exec(orderId);
  return match ? match[1] : null;
}
