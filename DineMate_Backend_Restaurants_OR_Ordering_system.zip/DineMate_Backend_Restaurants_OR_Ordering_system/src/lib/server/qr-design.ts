import QRCode from "qrcode";

// Builds a modern, branded, print-ready QR card as a single SVG string — a
// rounded-dot QR code (not plain black/white squares) set inside a card that
// carries the restaurant's name, the table number, and the site's signature
// ticket-edge perforation motif. Pure string/SVG composition — no native
// canvas dependency, so it works identically on Vercel and locally, and
// prints crisp at any size since it's vector.

const INK = "#1C1B1A";
const TURMERIC = "#E23744";
const CREAM = "#FFFDFB";
const STEEL_DIM = "#9C968F";
const SURFACE_3 = "#ECE7E2";

function moduleMatrix(text: string) {
  const qr = QRCode.create(text, { errorCorrectionLevel: "M" });
  return { size: qr.modules.size, data: qr.modules.data as Uint8Array };
}

/** Renders the QR itself as rounded-square "dots" instead of plain squares —
 * the modern look used by most branded QR generators — while keeping full
 * scan reliability (finder patterns get the same treatment, contrast and
 * quiet zone are preserved). Returns the dots path plus the module cell size
 * so the caller can size a properly spec'd quiet zone around it. */
function renderQrDots(text: string, boxSize: number, dark: string): { svg: string; cell: number; size: number } {
  const { size, data } = moduleMatrix(text);
  const cell = boxSize / size;
  const radius = cell * 0.32;
  let path = "";
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (data[row * size + col]) {
        const x = col * cell;
        const y = row * cell;
        path += `M${x + radius},${y}h${cell - 2 * radius}a${radius},${radius} 0 0 1 ${radius},${radius}v${
          cell - 2 * radius
        }a${radius},${radius} 0 0 1 -${radius},${radius}h-${cell - 2 * radius}a${radius},${radius} 0 0 1 -${radius},-${radius}v-${
          cell - 2 * radius
        }a${radius},${radius} 0 0 1 ${radius},-${radius}z `;
      }
    }
  }
  return { svg: `<path d="${path}" fill="${dark}" />`, cell, size };
}

export function buildQrCardSvg({
  targetUrl,
  tableNumber,
  restaurantName,
}: {
  targetUrl: string;
  tableNumber: number;
  restaurantName: string;
}): string {
  const W = 420;
  const headerH = 108;
  const qrBox = 268;
  const qrPad = (W - qrBox) / 2;
  const qrY = headerH + 34;
  const footerY = qrY + qrBox + 20;
  const H = footerY + 74;

  const { svg: qrDots, cell } = renderQrDots(targetUrl, qrBox, INK);
  const quietZone = cell * 4;

  // Perforation dots along the header's bottom edge — the site's ticket-edge
  // motif, reused here as the card's signature element.
  const perfDots: string[] = [];
  for (let x = 10; x < W - 10; x += 16) {
    perfDots.push(`<circle cx="${x}" cy="${headerH}" r="5" fill="${CREAM}" />`);
  }

  return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <clipPath id="cardClip">
      <rect x="0" y="0" width="${W}" height="${H}" rx="28" />
    </clipPath>
    <linearGradient id="headerFill" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="${TURMERIC}" />
      <stop offset="100%" stop-color="#CB202D" />
    </linearGradient>
  </defs>

  <g clip-path="url(#cardClip)">
    <rect x="0" y="0" width="${W}" height="${H}" fill="${CREAM}" />
    <rect x="0" y="0" width="${W}" height="${headerH}" fill="url(#headerFill)" />
    ${perfDots.join("\n    ")}

    <text x="${W / 2}" y="40" text-anchor="middle" font-family="'Avenir Next','Century Gothic',sans-serif" font-size="13" letter-spacing="2.5" fill="rgba(255,255,255,0.82)">SCAN TO ORDER</text>
    <text x="${W / 2}" y="72" text-anchor="middle" font-family="'Avenir Next','Century Gothic',sans-serif" font-weight="700" font-size="22" fill="#FFFFFF">${escapeXml(
      restaurantName
    )}</text>

    <g transform="translate(${qrPad}, ${qrY})">
      <rect x="${-quietZone}" y="${-quietZone}" width="${qrBox + quietZone * 2}" height="${
    qrBox + quietZone * 2
  }" rx="20" fill="#FFFFFF" stroke="${SURFACE_3}" stroke-width="1.5" />
      ${qrDots}
    </g>

    <g transform="translate(${W / 2}, ${qrY - 20})">
      <rect x="-46" y="-14" width="92" height="28" rx="14" fill="${TURMERIC}" />
      <text x="0" y="5" text-anchor="middle" font-family="'SFMono-Regular',Menlo,monospace" font-size="13" font-weight="600" fill="#FFFFFF">TABLE ${tableNumber}</text>
    </g>

    <text x="${W / 2}" y="${footerY + 26}" text-anchor="middle" font-family="'Segoe UI',sans-serif" font-size="13" fill="${INK}">Point your camera at the code</text>
    <text x="${W / 2}" y="${footerY + 46}" text-anchor="middle" font-family="'SFMono-Regular',Menlo,monospace" font-size="11" fill="${STEEL_DIM}">${escapeXml(
      targetUrl.replace(/^https?:\/\//, "")
    )}</text>
  </g>
</svg>`;
}

function escapeXml(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
