/**
 * OpenAPI 3.0 document for the entire backend. Served as JSON at
 * GET /api/openapi.json and rendered interactively at /swagger-ui
 * (self-hosted Swagger UI, see public/swagger-ui/index.html).
 *
 * This is hand-written rather than derived from the zod schemas in
 * validation.ts — deriving it automatically (e.g. via
 * @asteasolutions/zod-to-openapi) would need every schema re-registered
 * with extra OpenAPI metadata, which is a larger refactor than writing an
 * accurate spec directly against the routes as they exist. Kept in one
 * TS object (rather than a static JSON file) so the "common" schemas
 * below are actually shared/reused, not copy-pasted per endpoint.
 */

const errorResponse = {
  description: "Error",
  content: {
    "application/json": {
      schema: {
        type: "object",
        properties: {
          success: { type: "boolean", enum: [false] },
          message: { type: "string" },
          errors: { type: "array", items: { type: "string" } },
        },
        required: ["success", "message", "errors"],
      },
    },
  },
};

const bearerAuth = [{ bearerAuth: [] as string[] }];

const schemas = {
  LoginRequest: {
    type: "object",
    required: ["username", "password"],
    properties: {
      username: { type: "string", example: "REST000021" },
      password: { type: "string", format: "password" },
    },
  },
  AuthTokens: {
    type: "object",
    properties: {
      accessToken: { type: "string", description: "15-minute JWT — send as Authorization: Bearer <accessToken>" },
      refreshToken: { type: "string", description: "30-day opaque token — used only against /api/auth/refresh" },
    },
  },
  SessionUser: {
    type: "object",
    properties: {
      id: { type: "string" },
      username: { type: "string" },
      name: { type: "string" },
      role: { type: "string", enum: ["super_admin", "owner", "manager", "waiter"] },
      restaurantId: { type: "string", nullable: true },
    },
  },
  RegisterRestaurantRequest: {
    type: "object",
    required: ["name", "ownerName", "email", "mobile", "password"],
    properties: {
      name: { type: "string" },
      ownerName: { type: "string" },
      email: { type: "string", format: "email" },
      mobile: { type: "string" },
      password: { type: "string", format: "password", minLength: 8 },
      address: { type: "string" },
      gstNumber: { type: "string" },
      timezone: { type: "string" },
      currency: { type: "string", example: "INR" },
      logoUrl: { type: "string", format: "uri" },
      planId: { type: "string", example: "free" },
    },
  },
  Restaurant: {
    type: "object",
    properties: {
      id: { type: "string", example: "REST000021" },
      name: { type: "string" },
      ownerName: { type: "string" },
      email: { type: "string" },
      mobile: { type: "string" },
      address: { type: "string" },
      logoUrl: { type: "string" },
      gstNumber: { type: "string" },
      timezone: { type: "string" },
      currency: { type: "string" },
      status: { type: "string", enum: ["active", "suspended", "pending"] },
      planId: { type: "string" },
      subscriptionStatus: { type: "string", enum: ["trialing", "active", "expired", "cancelled"] },
      subscriptionExpiresAt: { type: "string", format: "date-time" },
      createdAt: { type: "string", format: "date-time" },
      updatedAt: { type: "string", format: "date-time" },
    },
  },
  SubscriptionPlan: {
    type: "object",
    properties: {
      id: { type: "string" },
      name: { type: "string" },
      durationDays: { type: "integer" },
      price: { type: "number" },
      currency: { type: "string" },
      productLimit: { type: "integer", description: "-1 = unlimited" },
      orderLimit: { type: "integer", description: "-1 = unlimited" },
      userLimit: { type: "integer", description: "-1 = unlimited" },
      storageLimitMb: { type: "integer" },
      features: { type: "array", items: { type: "string" } },
      active: { type: "boolean" },
    },
  },
  MenuCategory: {
    type: "object",
    properties: { id: { type: "string" }, name: { type: "string" }, icon: { type: "string" } },
  },
  MenuItem: {
    type: "object",
    properties: {
      id: { type: "string" },
      name: { type: "string" },
      description: { type: "string" },
      categoryId: { type: "string" },
      price: { type: "number" },
      costPrice: { type: "number" },
      image: { type: "string" },
      prepTimeMinutes: { type: "integer" },
      available: { type: "boolean" },
      spiceLevel: { type: "string", enum: ["mild", "medium", "hot"] },
      isVeg: { type: "boolean" },
      foodType: { type: "string", enum: ["veg", "non-veg", "egg", "other"] },
    },
  },
  RestaurantTable: {
    type: "object",
    properties: {
      id: { type: "string" },
      number: { type: "integer" },
      capacity: { type: "integer" },
      status: { type: "string", enum: ["available", "occupied", "cleaning"] },
      waiterName: { type: "string" },
      currentOrderId: { type: "string" },
    },
  },
  Offer: {
    type: "object",
    properties: {
      id: { type: "string" },
      name: { type: "string" },
      type: { type: "string", enum: ["bogo", "percent", "flat"] },
      active: { type: "boolean" },
      discountPercent: { type: "number" },
      discountAmount: { type: "number" },
      minOrderAmount: { type: "number" },
    },
  },
  OrderItemInput: {
    type: "object",
    required: ["itemId", "name"],
    properties: {
      itemId: { type: "string" },
      name: { type: "string" },
      quantity: { type: "integer", minimum: 1 },
      price: { type: "number" },
      variant: { type: "string" },
      note: { type: "string" },
    },
  },
  CreateOrderRequest: {
    type: "object",
    required: ["tableNumber", "items"],
    properties: {
      tableNumber: { type: "integer" },
      items: { type: "array", items: { $ref: "#/components/schemas/OrderItemInput" } },
      note: { type: "string" },
      customerName: { type: "string" },
      waiterName: { type: "string" },
    },
  },
  Order: {
    type: "object",
    properties: {
      id: { type: "string", example: "ord-REST000021-1042" },
      tableNumber: { type: "integer" },
      status: { type: "string", enum: ["accepted", "preparing", "ready", "completed", "cancelled"] },
      subtotal: { type: "number" },
      discountTotal: { type: "number" },
      taxAmount: { type: "number" },
      total: { type: "number" },
      billGenerated: { type: "boolean" },
      billNumber: { type: "string" },
      placedAt: { type: "string", format: "date-time" },
    },
  },
  AppUser: {
    type: "object",
    properties: {
      id: { type: "string" },
      username: { type: "string" },
      name: { type: "string" },
      role: { type: "string", enum: ["manager", "waiter"] },
      active: { type: "boolean" },
      createdAt: { type: "string", format: "date-time" },
    },
  },
  CreateUserRequest: {
    type: "object",
    required: ["username", "password", "name", "role"],
    properties: {
      username: { type: "string" },
      password: { type: "string", format: "password", minLength: 8 },
      name: { type: "string" },
      role: { type: "string", enum: ["manager", "waiter"] },
      permissions: { type: "array", items: { type: "string" } },
    },
  },
  RestaurantSettings: {
    type: "object",
    properties: {
      taxRatePercent: { type: "number" },
      restaurantName: { type: "string" },
      currency: { type: "string" },
      baseUrl: { type: "string" },
      openingTime: { type: "string" },
      closingTime: { type: "string" },
      billPrefix: { type: "string" },
    },
  },
  Expense: {
    type: "object",
    properties: {
      id: { type: "string" },
      date: { type: "string", format: "date" },
      category: {
        type: "string",
        enum: ["rent", "salaries", "utilities", "raw-materials", "maintenance", "marketing", "other"],
      },
      description: { type: "string" },
      amount: { type: "number" },
    },
  },
  ProfitAndLoss: {
    type: "object",
    properties: {
      periodKey: { type: "string" },
      grossSales: { type: "number" },
      netSales: { type: "number" },
      cogs: { type: "number" },
      grossProfit: { type: "number" },
      totalExpenses: { type: "number" },
      netProfit: { type: "number" },
      netMarginPercent: { type: "number" },
    },
  },
  Notification: {
    type: "object",
    properties: {
      id: { type: "string" },
      type: {
        type: "string",
        enum: [
          "new_order",
          "order_ready",
          "low_stock",
          "subscription_expiring",
          "subscription_expired",
          "staff_added",
          "announcement",
        ],
      },
      title: { type: "string" },
      message: { type: "string" },
      read: { type: "boolean" },
      createdAt: { type: "string", format: "date-time" },
    },
  },
  Pagination: {
    type: "object",
    properties: {
      page: { type: "integer" },
      pageSize: { type: "integer" },
      total: { type: "integer" },
      totalPages: { type: "integer" },
    },
  },
};

function jsonBody(schemaRef: string) {
  return { required: true, content: { "application/json": { schema: { $ref: `#/components/schemas/${schemaRef}` } } } };
}

// Wraps a "here's what's actually in `data`" schema into the real response
// envelope every route returns: { success, message, data, pagination? }.
// Pass `paginated: true` for list endpoints that also include a
// `pagination` block alongside `data` (see Pagination schema above).
function okJson(description: string, dataSchema: Record<string, unknown>, options?: { paginated?: boolean }) {
  const properties: Record<string, unknown> = {
    success: { type: "boolean", enum: [true] },
    message: { type: "string" },
    data: dataSchema,
  };
  if (options?.paginated) properties.pagination = { $ref: "#/components/schemas/Pagination" };
  return {
    description,
    content: {
      "application/json": {
        schema: { type: "object", properties, required: ["success", "message", "data"] },
      },
    },
  };
}

export const openApiSpec = {
  openapi: "3.0.3",
  info: {
    title: "Multi-Tenant Restaurant SaaS Platform API",
    version: "1.0.0",
    description:
      "Backend for a multi-tenant restaurant management SaaS platform. Every protected endpoint requires " +
      "`Authorization: Bearer <accessToken>` (see /api/auth/login). Endpoints marked public either need no " +
      "auth at all (customer-facing menu/order flows) or resolve their tenant from a `restaurantId` query " +
      "param / the order id itself — see MIGRATION_NOTES.md and API_REFERENCE.md in the repo for the full " +
      "narrative explanation this spec doesn't capture.",
  },
  servers: [{ url: "/", description: "Same origin as this spec is served from" }],
  components: {
    securitySchemes: {
      bearerAuth: { type: "http", scheme: "bearer", bearerFormat: "JWT" },
    },
    schemas,
  },
  security: bearerAuth,
  tags: [
    { name: "Health", description: "Liveness / readiness probes and database status (public, no auth)" },
    { name: "Auth" },
    { name: "Restaurants" },
    { name: "Super Admin" },
    { name: "Billing" },
    { name: "Menu" },
    { name: "Tables" },
    { name: "Orders" },
    { name: "Staff" },
    { name: "Settings" },
    { name: "Reports" },
    { name: "Finance" },
    { name: "Notifications" },
    { name: "Scheduled Jobs" },
  ],
  paths: {
    "/api/health": {
      get: {
        tags: ["Health"],
        summary: "Overall health (process + database)",
        description:
          "Returns 200 when the API process is up and Postgres is reachable; 503 when the database check fails. " +
          "Safe for load balancers and uptime monitors. No auth required. Never exposes connection strings.",
        security: [],
        responses: {
          "200": {
            description: "Healthy",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", enum: [true] },
                    message: { type: "string", example: "ok" },
                    data: {
                      type: "object",
                      properties: {
                        status: { type: "string", enum: ["ok"] },
                        uptimeSeconds: { type: "number" },
                        timestamp: { type: "string", format: "date-time" },
                        checks: {
                          type: "object",
                          properties: {
                            database: {
                              type: "object",
                              properties: {
                                ok: { type: "boolean" },
                                latencyMs: { type: "number" },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
          },
          "503": {
            description: "Degraded (database unreachable)",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", enum: [false] },
                    message: { type: "string", example: "degraded" },
                    data: { type: "object" },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/health/db": {
      get: {
        tags: ["Health"],
        summary: "Database connection status",
        description:
          "Detailed Postgres connectivity check: round-trip latency, server version, TLS required flag. " +
          "Public for post-deploy smoke tests. Credentials and connection string are never returned.",
        security: [],
        responses: {
          "200": {
            description: "Database reachable",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", enum: [true] },
                    message: { type: "string" },
                    data: {
                      type: "object",
                      properties: {
                        status: { type: "string", enum: ["ok"] },
                        latencyMs: { type: "number" },
                        serverVersion: { type: "string", nullable: true },
                        checkedAt: { type: "string", format: "date-time" },
                        tlsRequired: { type: "boolean", enum: [true] },
                      },
                    },
                  },
                },
              },
            },
          },
          "503": {
            description: "Database unreachable",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    success: { type: "boolean", enum: [false] },
                    message: { type: "string" },
                    data: {
                      type: "object",
                      properties: {
                        status: { type: "string", enum: ["error"] },
                        latencyMs: { type: "number" },
                        error: { type: "string" },
                        tlsRequired: { type: "boolean" },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/auth/login": {
      post: {
        tags: ["Auth"],
        summary: "Log in (all 4 roles use this same endpoint)",
        security: [],
        requestBody: jsonBody("LoginRequest"),
        responses: {
          "200": okJson("Logged in", {
            allOf: [{ $ref: "#/components/schemas/SessionUser" }, { $ref: "#/components/schemas/AuthTokens" }],
          }),
          "400": errorResponse,
          "401": errorResponse,
          "402": errorResponse,
          "403": errorResponse,
        },
      },
    },
    "/api/auth/refresh": {
      post: {
        tags: ["Auth"],
        summary: "Exchange a refresh token for a new access token (rotates the refresh token too)",
        security: [],
        requestBody: {
          required: false,
          content: {
            "application/json": {
              schema: { type: "object", properties: { refreshToken: { type: "string" } } },
            },
          },
        },
        responses: {
          "200": okJson("New token pair", { $ref: "#/components/schemas/AuthTokens" }),
          "401": errorResponse,
          "403": errorResponse,
        },
      },
    },
    "/api/auth/logout": {
      post: {
        tags: ["Auth"],
        summary: "Log out — revokes the refresh token server-side",
        responses: { "200": okJson("Logged out", { type: "object", properties: { ok: { type: "boolean" } } }) },
      },
    },
    "/api/auth/me": {
      get: {
        tags: ["Auth"],
        summary: "Current session + restaurant summary",
        responses: {
          "200": okJson("Session info (user is null if not logged in)", {
            type: "object",
            properties: { user: { $ref: "#/components/schemas/SessionUser" }, restaurant: { type: "object", nullable: true } },
          }),
        },
      },
    },

    "/api/restaurants/register": {
      post: {
        tags: ["Restaurants"],
        summary: "Public self-service sign-up — creates a tenant + owner login on a 14-day trial",
        security: [],
        requestBody: jsonBody("RegisterRestaurantRequest"),
        responses: {
          "201": okJson("Registered", { type: "object", properties: { restaurant: { $ref: "#/components/schemas/Restaurant" } } }),
          "400": errorResponse,
          "409": errorResponse,
        },
      },
    },
    "/api/restaurants/upload-logo": {
      post: {
        tags: ["Restaurants"],
        summary: "Upload a restaurant logo (multipart, max 300KB)",
        security: [],
        requestBody: {
          required: true,
          content: { "multipart/form-data": { schema: { type: "object", properties: { logo: { type: "string", format: "binary" } } } } },
        },
        responses: {
          "201": okJson("Uploaded", { type: "object", properties: { logoUrl: { type: "string" } } }),
          "400": errorResponse,
        },
      },
    },
    "/api/restaurants/me": {
      get: {
        tags: ["Restaurants"],
        summary: "This restaurant's profile",
        responses: { "200": okJson("Profile", { type: "object", properties: { restaurant: { $ref: "#/components/schemas/Restaurant" } } }), "401": errorResponse },
      },
      patch: {
        tags: ["Restaurants"],
        summary: "Update restaurant profile (owner only)",
        requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } },
        responses: { "200": okJson("Updated", { type: "object", properties: { restaurant: { $ref: "#/components/schemas/Restaurant" } } }), "400": errorResponse, "403": errorResponse },
      },
    },

    "/api/admin/dashboard": {
      get: { tags: ["Super Admin"], summary: "Platform-wide dashboard totals", responses: { "200": okJson("Dashboard", { type: "object" }), "403": errorResponse } },
    },
    "/api/admin/restaurants": {
      get: {
        tags: ["Super Admin"],
        summary: "List every restaurant on the platform",
        parameters: [
          { name: "status", in: "query", schema: { type: "string", enum: ["active", "suspended", "pending"] } },
          { name: "search", in: "query", schema: { type: "string" } },
          { name: "page", in: "query", schema: { type: "integer" } },
          { name: "pageSize", in: "query", schema: { type: "integer" } },
        ],
        responses: {
          "200": okJson(
            "Restaurants",
            { type: "object", properties: { restaurants: { type: "array", items: { $ref: "#/components/schemas/Restaurant" } }, summary: { type: "object" } } },
            { paginated: true }
          ),
          "403": errorResponse,
        },
      },
      post: {
        tags: ["Super Admin"],
        summary: "Directly provision a restaurant",
        requestBody: jsonBody("RegisterRestaurantRequest"),
        responses: { "201": okJson("Created", { $ref: "#/components/schemas/Restaurant" }), "400": errorResponse, "403": errorResponse },
      },
    },
    "/api/admin/restaurants/{id}": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      get: { tags: ["Super Admin"], summary: "Full detail incl. staff, login history, audit log", responses: { "200": okJson("Detail", { type: "object" }), "404": errorResponse } },
      patch: {
        tags: ["Super Admin"],
        summary: "Activate/suspend/renew/update a restaurant",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  status: { type: "string", enum: ["active", "suspended", "pending"] },
                  planId: { type: "string" },
                  renew: { type: "boolean" },
                  days: { type: "integer" },
                },
              },
            },
          },
        },
        responses: { "200": okJson("Updated", { $ref: "#/components/schemas/Restaurant" }), "400": errorResponse, "404": errorResponse },
      },
      delete: { tags: ["Super Admin"], summary: "Delete a restaurant record", responses: { "200": okJson("Deleted", { type: "object" }), "404": errorResponse } },
    },
    "/api/admin/plans": {
      get: { tags: ["Super Admin"], summary: "List subscription plans", responses: { "200": okJson("Plans", { type: "array", items: { $ref: "#/components/schemas/SubscriptionPlan" } }) } },
      post: { tags: ["Super Admin"], summary: "Create a plan", requestBody: { required: true, content: { "application/json": { schema: { $ref: "#/components/schemas/SubscriptionPlan" } } } }, responses: { "201": okJson("Created", { $ref: "#/components/schemas/SubscriptionPlan" }), "400": errorResponse } },
    },
    "/api/admin/plans/{id}": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      patch: { tags: ["Super Admin"], summary: "Edit a plan", requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } }, responses: { "200": okJson("Updated", { $ref: "#/components/schemas/SubscriptionPlan" }), "404": errorResponse } },
      delete: { tags: ["Super Admin"], summary: "Delete a plan (blocked if in use)", responses: { "200": okJson("Deleted", { type: "object" }), "404": errorResponse, "409": errorResponse } },
    },
    "/api/admin/audit-logs": {
      get: {
        tags: ["Super Admin"],
        summary: "Platform-wide audit log / login history",
        parameters: [
          { name: "restaurantId", in: "query", schema: { type: "string" } },
          { name: "kind", in: "query", schema: { type: "string", enum: ["audit", "logins"] } },
        ],
        responses: { "200": okJson("Logs", { type: "object" }) },
      },
    },

    "/api/billing/checkout": {
      post: {
        tags: ["Billing"],
        summary: "Start a paid plan checkout (Razorpay order)",
        requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["planId"], properties: { planId: { type: "string" } } } } } },
        responses: { "200": okJson("Checkout details", { type: "object" }), "400": errorResponse, "501": errorResponse },
      },
    },
    "/api/billing/verify": {
      post: {
        tags: ["Billing"],
        summary: "Client-side verification right after Razorpay Checkout succeeds",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                required: ["razorpayOrderId", "razorpayPaymentId", "razorpaySignature", "planId"],
                properties: {
                  razorpayOrderId: { type: "string" },
                  razorpayPaymentId: { type: "string" },
                  razorpaySignature: { type: "string" },
                  planId: { type: "string" },
                },
              },
            },
          },
        },
        responses: { "200": okJson("Verified", { type: "object", properties: { ok: { type: "boolean" } } }), "400": errorResponse },
      },
    },
    "/api/billing/webhook": {
      post: {
        tags: ["Billing"],
        summary: "Razorpay server-to-server webhook (HMAC-signature verified)",
        security: [],
        requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } },
        responses: { "200": okJson("Acknowledged", { type: "object" }), "400": errorResponse },
      },
    },

    "/api/categories": {
      get: {
        tags: ["Menu"],
        summary: "List categories (public menu browsing needs ?restaurantId=)",
        security: [],
        parameters: [{ name: "restaurantId", in: "query", schema: { type: "string" } }],
        responses: { "200": okJson("Categories", { type: "array", items: { $ref: "#/components/schemas/MenuCategory" } }) },
      },
      post: {
        tags: ["Menu"],
        summary: "Create a category",
        requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["name"], properties: { name: { type: "string" }, icon: { type: "string" } } } } } },
        responses: { "201": okJson("Created", { $ref: "#/components/schemas/MenuCategory" }), "400": errorResponse },
      },
    },
    "/api/categories/{id}": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      patch: { tags: ["Menu"], summary: "Update a category", requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } }, responses: { "200": okJson("Updated", { type: "object" }) } },
      delete: { tags: ["Menu"], summary: "Delete a category", responses: { "200": okJson("Deleted", { type: "object" }) } },
    },
    "/api/menu": {
      get: {
        tags: ["Menu"],
        summary: "List menu items (search/sort/optional pagination)",
        security: [],
        parameters: [
          { name: "restaurantId", in: "query", schema: { type: "string" } },
          { name: "categoryId", in: "query", schema: { type: "string" } },
          { name: "search", in: "query", schema: { type: "string" } },
          { name: "sort", in: "query", schema: { type: "string", enum: ["name", "price", "prepTimeMinutes"] } },
          { name: "order", in: "query", schema: { type: "string", enum: ["asc", "desc"] } },
          { name: "page", in: "query", schema: { type: "integer" } },
          { name: "pageSize", in: "query", schema: { type: "integer" } },
        ],
        responses: { "200": okJson("Menu items", { type: "array", items: { $ref: "#/components/schemas/MenuItem" } }) },
      },
      post: {
        tags: ["Menu"],
        summary: "Create a menu item (enforces plan's product limit)",
        requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["name", "categoryId", "price"], properties: { name: { type: "string" }, categoryId: { type: "string" }, price: { type: "number" } } } } } },
        responses: { "201": okJson("Created", { $ref: "#/components/schemas/MenuItem" }), "400": errorResponse, "402": errorResponse },
      },
    },
    "/api/menu/{id}": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      patch: { tags: ["Menu"], summary: "Update a menu item", requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } }, responses: { "200": okJson("Updated", { type: "object" }), "404": errorResponse } },
      delete: { tags: ["Menu"], summary: "Delete a menu item", responses: { "200": okJson("Deleted", { type: "object" }) } },
    },
    "/api/offers": {
      get: { tags: ["Menu"], summary: "List offers", security: [], parameters: [{ name: "restaurantId", in: "query", schema: { type: "string" } }], responses: { "200": okJson("Offers", { type: "array", items: { $ref: "#/components/schemas/Offer" } }) } },
      post: { tags: ["Menu"], summary: "Create an offer", requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["name", "type"] } } } }, responses: { "201": okJson("Created", { $ref: "#/components/schemas/Offer" }), "400": errorResponse } },
    },
    "/api/offers/{id}": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      patch: { tags: ["Menu"], summary: "Update an offer", requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } }, responses: { "200": okJson("Updated", { type: "object" }) } },
      delete: { tags: ["Menu"], summary: "Delete an offer", responses: { "200": okJson("Deleted", { type: "object" }) } },
    },

    "/api/tables": {
      get: { tags: ["Tables"], summary: "List tables", security: [], parameters: [{ name: "restaurantId", in: "query", schema: { type: "string" } }], responses: { "200": okJson("Tables", { type: "array", items: { $ref: "#/components/schemas/RestaurantTable" } }) } },
      post: { tags: ["Tables"], summary: "Create a table", requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["number"], properties: { number: { type: "integer" }, capacity: { type: "integer" } } } } } }, responses: { "201": okJson("Created", { $ref: "#/components/schemas/RestaurantTable" }), "409": errorResponse } },
    },
    "/api/tables/{id}": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      patch: { tags: ["Tables"], summary: "Update a table (waiters limited to status fields)", requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } }, responses: { "200": okJson("Updated", { type: "object" }) } },
      delete: { tags: ["Tables"], summary: "Delete a table", responses: { "200": okJson("Deleted", { type: "object" }) } },
    },
    "/api/tables/{id}/qr": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      get: {
        tags: ["Tables"],
        summary: "Get (or lazily generate) this table's QR code",
        parameters: [
          { name: "format", in: "query", schema: { type: "string", enum: ["png", "json"] } },
          { name: "regenerate", in: "query", schema: { type: "string", enum: ["1"] } },
        ],
        responses: { "200": { description: "SVG/PNG image, or JSON if ?format=json" } },
      },
      post: { tags: ["Tables"], summary: "Force-regenerate the QR code", responses: { "200": okJson("Regenerated", { type: "object" }) } },
    },

    "/api/orders": {
      get: {
        tags: ["Orders"],
        summary: "List orders for this restaurant (staff only)",
        parameters: [
          { name: "tableNumber", in: "query", schema: { type: "integer" } },
          { name: "active", in: "query", schema: { type: "string", enum: ["1"] } },
          { name: "includeArchived", in: "query", schema: { type: "string", enum: ["1"] } },
          { name: "search", in: "query", schema: { type: "string" } },
          { name: "page", in: "query", schema: { type: "integer" } },
          { name: "pageSize", in: "query", schema: { type: "integer" } },
        ],
        responses: {
          "200": okJson(
            "Orders",
            { type: "object", properties: { orders: { type: "array", items: { $ref: "#/components/schemas/Order" } } } },
            { paginated: true }
          ),
          "401": errorResponse,
        },
      },
      post: {
        tags: ["Orders"],
        summary: "Place a new order (public — customer QR ordering, or staff)",
        security: [],
        parameters: [{ name: "restaurantId", in: "query", schema: { type: "string" } }],
        requestBody: jsonBody("CreateOrderRequest"),
        responses: { "201": okJson("Created", { $ref: "#/components/schemas/Order" }), "400": errorResponse, "402": errorResponse, "404": errorResponse },
      },
    },
    "/api/orders/{id}": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      get: { tags: ["Orders"], summary: "Get one order (public — the id itself is the access token)", security: [], responses: { "200": okJson("Order", { $ref: "#/components/schemas/Order" }), "404": errorResponse } },
      patch: { tags: ["Orders"], summary: "Update order status/discount/payment (staff only)", requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } }, responses: { "200": okJson("Updated", { $ref: "#/components/schemas/Order" }), "404": errorResponse } },
    },
    "/api/orders/{id}/items": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      post: {
        tags: ["Orders"],
        summary: "Add items to an in-progress order (public)",
        security: [],
        requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["items"], properties: { items: { type: "array", items: { $ref: "#/components/schemas/OrderItemInput" } } } } } } },
        responses: { "200": okJson("Updated", { $ref: "#/components/schemas/Order" }), "404": errorResponse, "409": errorResponse },
      },
    },
    "/api/orders/{id}/kot": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      get: { tags: ["Orders"], summary: "Items not yet sent to the kitchen printer", security: [], responses: { "200": okJson("KOT items", { type: "object" }), "404": errorResponse } },
      post: { tags: ["Orders"], summary: "Mark pending items as printed", security: [], responses: { "200": okJson("Marked", { $ref: "#/components/schemas/Order" }), "404": errorResponse } },
    },
    "/api/orders/{id}/bill": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      get: {
        tags: ["Orders"],
        summary: "Get/finalize the bill (first call archives the order; later calls just read it back)",
        security: [],
        responses: { "200": okJson("Bill", { type: "object", properties: { order: { $ref: "#/components/schemas/Order" } } }), "404": errorResponse },
      },
    },

    "/api/users": {
      get: { tags: ["Staff"], summary: "List this restaurant's staff", responses: { "200": okJson("Staff", { type: "array", items: { $ref: "#/components/schemas/AppUser" } }) } },
      post: { tags: ["Staff"], summary: "Create a manager/waiter account", requestBody: jsonBody("CreateUserRequest"), responses: { "201": okJson("Created", { $ref: "#/components/schemas/AppUser" }), "400": errorResponse, "402": errorResponse, "403": errorResponse, "409": errorResponse } },
    },
    "/api/users/{id}": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      patch: { tags: ["Staff"], summary: "Update staff (name/active/permissions/password reset)", requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } }, responses: { "200": okJson("Updated", { type: "array", items: { $ref: "#/components/schemas/AppUser" } }), "403": errorResponse, "404": errorResponse } },
      delete: { tags: ["Staff"], summary: "Delete a staff account", responses: { "200": okJson("Deleted", { type: "object" }), "403": errorResponse, "404": errorResponse } },
    },

    "/api/settings": {
      get: { tags: ["Settings"], summary: "Get operational settings (tax rate, currency, hours)", security: [], parameters: [{ name: "restaurantId", in: "query", schema: { type: "string" } }], responses: { "200": okJson("Settings", { $ref: "#/components/schemas/RestaurantSettings" }) } },
      patch: { tags: ["Settings"], summary: "Update settings (owner only)", requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } }, responses: { "200": okJson("Updated", { $ref: "#/components/schemas/RestaurantSettings" }) } },
    },

    "/api/reports/daily": { get: { tags: ["Reports"], summary: "Daily stats", parameters: [{ name: "date", in: "query", schema: { type: "string", format: "date" } }, { name: "from", in: "query", schema: { type: "string" } }, { name: "to", in: "query", schema: { type: "string" } }], responses: { "200": okJson("Daily stats", { type: "object" }) } } },
    "/api/reports/weekly": { get: { tags: ["Reports"], summary: "Weekly stats", parameters: [{ name: "week", in: "query", schema: { type: "string", example: "2026-W30" } }], responses: { "200": okJson("Weekly stats", { type: "object" }) } } },
    "/api/reports/monthly": { get: { tags: ["Reports"], summary: "Monthly stats", parameters: [{ name: "month", in: "query", schema: { type: "string", example: "2026-07" } }, { name: "year", in: "query", schema: { type: "string" } }], responses: { "200": okJson("Monthly stats", { type: "object" }) } } },
    "/api/reports/yearly": { get: { tags: ["Reports"], summary: "Yearly stats", parameters: [{ name: "year", in: "query", schema: { type: "string" } }], responses: { "200": okJson("Yearly stats", { type: "object" }) } } },
    "/api/reports/items": { get: { tags: ["Reports"], summary: "Item/category/food-type performance", parameters: [{ name: "from", in: "query", schema: { type: "string" } }, { name: "to", in: "query", schema: { type: "string" } }, { name: "limit", in: "query", schema: { type: "integer" } }], responses: { "200": okJson("Item performance", { type: "object" }) } } },
    "/api/analytics": { get: { tags: ["Reports"], summary: "Dashboard analytics summary", responses: { "200": okJson("Analytics", { type: "object" }) } } },

    "/api/finance/expenses": {
      get: { tags: ["Finance"], summary: "List expenses (paginated)", parameters: [{ name: "month", in: "query", schema: { type: "string" } }, { name: "year", in: "query", schema: { type: "string" } }, { name: "page", in: "query", schema: { type: "integer" } }, { name: "pageSize", in: "query", schema: { type: "integer" } }], responses: { "200": okJson("Expenses", { type: "object", properties: { expenses: { type: "array", items: { $ref: "#/components/schemas/Expense" } } } }, { paginated: true }) } },
      post: { tags: ["Finance"], summary: "Log an expense", requestBody: { required: true, content: { "application/json": { schema: { type: "object", required: ["date", "category", "amount"] } } } }, responses: { "201": okJson("Created", { $ref: "#/components/schemas/Expense" }), "400": errorResponse } },
    },
    "/api/finance/expenses/{id}": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      patch: { tags: ["Finance"], summary: "Update an expense", requestBody: { required: true, content: { "application/json": { schema: { type: "object" } } } }, responses: { "200": okJson("Updated", { type: "object" }) } },
      delete: { tags: ["Finance"], summary: "Delete an expense", responses: { "200": okJson("Deleted", { type: "object" }) } },
    },
    "/api/finance/pnl": {
      get: { tags: ["Finance"], summary: "Profit & Loss statement", parameters: [{ name: "period", in: "query", schema: { type: "string", enum: ["monthly", "yearly"] } }, { name: "key", in: "query", schema: { type: "string" } }], responses: { "200": okJson("P&L", { $ref: "#/components/schemas/ProfitAndLoss" }) } },
    },

    "/api/notifications": {
      get: { tags: ["Notifications"], summary: "List notifications for the current user's role", parameters: [{ name: "unread", in: "query", schema: { type: "string", enum: ["1"] } }], responses: { "200": okJson("Notifications", { type: "array", items: { $ref: "#/components/schemas/Notification" } }) } },
      patch: { tags: ["Notifications"], summary: "Mark all as read", requestBody: { required: true, content: { "application/json": { schema: { type: "object", properties: { markAllRead: { type: "boolean" } } } } } }, responses: { "200": okJson("Updated", { type: "array", items: { $ref: "#/components/schemas/Notification" } }) } },
    },
    "/api/notifications/{id}": {
      parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
      patch: { tags: ["Notifications"], summary: "Mark one notification as read", responses: { "200": okJson("Updated", { type: "array", items: { $ref: "#/components/schemas/Notification" } }) } },
    },
    "/api/activity-logs": {
      get: { tags: ["Notifications"], summary: "This restaurant's own audit trail + login history", responses: { "200": okJson("Logs", { type: "object" }) } },
    },

    "/api/openapi.json": {
      get: {
        tags: ["Auth"],
        summary: "This OpenAPI document",
        security: [],
        responses: { "200": { description: "The OpenAPI 3.0 spec you're reading right now" } },
      },
    },
    "/api/cron/check-subscriptions": {
      get: {
        tags: ["Scheduled Jobs"],
        summary: "Proactive subscription-expiry check (protected by CRON_SECRET, not a normal user role)",
        security: [],
        parameters: [{ name: "Authorization", in: "header", required: true, schema: { type: "string", example: "Bearer <CRON_SECRET>" } }],
        responses: { "200": okJson("Summary", { type: "object", properties: { checked: { type: "integer" }, warned: { type: "integer" }, expired: { type: "integer" } } }), "401": errorResponse },
      },
    },
  },
};
