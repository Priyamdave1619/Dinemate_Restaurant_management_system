import { NextRequest } from "next/server";

export interface PageParams {
  page: number;
  pageSize: number;
}

/** Reads `?page=&pageSize=` off a request, clamped to sane bounds. */
export function readPageParams(req: NextRequest, defaultPageSize = 25, maxPageSize = 200): PageParams {
  const page = Math.max(1, Number(req.nextUrl.searchParams.get("page")) || 1);
  const pageSize = Math.min(maxPageSize, Math.max(1, Number(req.nextUrl.searchParams.get("pageSize")) || defaultPageSize));
  return { page, pageSize };
}

export interface Paginated<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export function paginate<T>(all: T[], { page, pageSize }: PageParams): Paginated<T> {
  const total = all.length;
  const start = (page - 1) * pageSize;
  return {
    items: all.slice(start, start + pageSize),
    page,
    pageSize,
    total,
    totalPages: Math.max(1, Math.ceil(total / pageSize)),
  };
}

/** Generic ascending/descending sort by a set of allowed field names —
 * keeps `?sort=field` / `?order=asc|desc` from being able to reach into
 * arbitrary object internals. */
export function applySort<T>(
  items: T[],
  req: NextRequest,
  allowedFields: readonly (keyof T & string)[],
  defaultField?: keyof T & string
): T[] {
  const sortParam = req.nextUrl.searchParams.get("sort");
  const field = (allowedFields as unknown as string[]).includes(sortParam || "") ? (sortParam as keyof T & string) : defaultField;
  if (!field) return items;

  const order = req.nextUrl.searchParams.get("order") === "desc" ? -1 : 1;
  return [...items].sort((a, b) => {
    const av = a[field];
    const bv = b[field];
    if (typeof av === "number" && typeof bv === "number") return (av - bv) * order;
    return String(av).localeCompare(String(bv)) * order;
  });
}
