import { randomUUID } from "crypto";
import { platformDb, tenantDb, seedNewTenantContent } from "./db";
import { hashPassword } from "./auth";
import { sendEmail, welcomeEmail } from "./email";
import { AppUser, Restaurant } from "@/lib/types";

const TRIAL_DAYS = 14;

/** Sequential, zero-padded, globally unique tenant id — REST000001, REST000002, ... */
export async function generateRestaurantId(): Promise<string> {
  const n = await platformDb.counters.next("restaurant_id");
  return `REST${String(n).padStart(6, "0")}`;
}

export interface RegisterRestaurantInput {
  name: string;
  ownerName: string;
  email: string;
  mobile: string;
  password: string;
  address?: string;
  gstNumber?: string;
  timezone?: string;
  currency?: string;
  logoUrl?: string; // pre-uploaded elsewhere; this route just stores the URL (see note in the route file re: 300KB limit)
  planId?: string; // defaults to "free" trial
}

export interface RegisterRestaurantResult {
  restaurant: Restaurant;
  owner: AppUser;
}

/** Username must be unique across the ENTIRE platform (not just one
 * restaurant) — waiter/manager login has no restaurant selector, so a
 * clash between two different restaurants' staff usernames would be
 * ambiguous at login time. Enforced here for every new account. */
export async function isUsernameTaken(username: string): Promise<boolean> {
  const existing = await platformDb.users.findByUsername(username);
  return !!existing;
}

/** Restaurant registration email uniqueness (a support/comms identifier —
 * not itself a login credential, since login always uses username). */
export async function isEmailRegistered(email: string): Promise<boolean> {
  const restaurants = await platformDb.restaurants.all();
  return restaurants.some((r) => r.email.toLowerCase() === email.toLowerCase());
}

/**
 * Full restaurant onboarding: allocates a restaurant id, creates the
 * Restaurant record on a free trial, and creates the Owner's login (whose
 * username IS the restaurant id — "Restaurant ID + Password" login is just
 * this account).
 */
export async function registerRestaurant(input: RegisterRestaurantInput): Promise<RegisterRestaurantResult> {
  const restaurantId = await generateRestaurantId();

  if (await isUsernameTaken(restaurantId)) {
    // Astronomically unlikely (counter is monotonic + unique), but never
    // silently collide on a login identity.
    throw new Error("Could not allocate a unique restaurant id — please retry");
  }

  const now = new Date();
  const expires = new Date(now.getTime() + TRIAL_DAYS * 86400000);
  const planId = input.planId && (await platformDb.plans.get(input.planId)) ? input.planId : "free";

  const restaurant: Restaurant = {
    id: restaurantId,
    name: input.name,
    ownerName: input.ownerName,
    email: input.email.toLowerCase(),
    mobile: input.mobile,
    address: input.address,
    gstNumber: input.gstNumber,
    logoUrl: input.logoUrl,
    timezone: input.timezone || "Asia/Kolkata",
    currency: input.currency || "INR",
    status: "active",
    createdAt: now.toISOString(),
    updatedAt: now.toISOString(),
    planId,
    subscriptionStatus: "trialing",
    subscriptionStartedAt: now.toISOString(),
    subscriptionExpiresAt: expires.toISOString(),
  };

  await platformDb.restaurants.mutate((cur) => [...cur, restaurant]);

  const { hash, salt } = hashPassword(input.password);
  const owner: AppUser = {
    id: randomUUID(),
    restaurantId,
    username: restaurantId,
    name: input.ownerName,
    role: "owner",
    passwordHash: hash,
    passwordSalt: salt,
    createdAt: now.toISOString(),
    active: true,
  };

  await tenantDb(restaurantId).users.mutate((cur) => [...cur, owner]);

  // Insert the tenant's starter demo content EXACTLY ONCE, right now,
  // unconditionally (registration only ever runs once per restaurant, so
  // there's no ambiguity to resolve here — unlike the old approach this
  // replaced, which relied on "insert if currently empty" and had a real,
  // verified bug: a restaurant that later deleted every item in a
  // collection would see the demo content silently reappear on their next
  // read). See seedNewTenantContent / seedCollectionOnce for the full story.
  await seedNewTenantContent(restaurantId);
  const db = tenantDb(restaurantId);
  await db.settings.save({
    restaurantId,
    taxRatePercent: 5,
    restaurantName: input.name,
    address: input.address,
    phone: input.mobile,
    gstin: input.gstNumber,
    currency: restaurant.currency,
    baseUrl: process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3003",
  });

  await platformDb.auditLogs.log({
    restaurantId,
    actorUserId: owner.id,
    actorName: owner.name,
    actorRole: "owner",
    action: "restaurant_created",
    entityType: "restaurant",
    entityId: restaurantId,
  });

  await sendEmail({ ...welcomeEmail({ ownerName: owner.name, restaurantId, restaurantName: restaurant.name }), to: restaurant.email });

  return { restaurant, owner };
}

/**
 * Ensures at least one super_admin account exists. Reads
 * SUPER_ADMIN_USERNAME / SUPER_ADMIN_PASSWORD from the environment on
 * first run — see .env.example. Safe to call on every cold start.
 */
export async function ensureSuperAdminBootstrap(): Promise<void> {
  const username = process.env.SUPER_ADMIN_USERNAME;
  const password = process.env.SUPER_ADMIN_PASSWORD;
  if (!username || !password) return;

  let existing;
  try {
    existing = await platformDb.users.findByUsername(username);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg.includes("does not exist") || msg.includes("42P01")) {
      throw new Error(
        'Database tables are missing (relation "users" does not exist). ' +
          "Run: npm run db:setup   then try login again (or npm run create-superadmin)."
      );
    }
    throw err;
  }
  if (existing) return;

  const { hash, salt } = hashPassword(password);
  const admin: AppUser = {
    id: randomUUID(),
    restaurantId: null,
    username: username.toLowerCase(),
    name: "Platform Super Admin",
    role: "super_admin",
    passwordHash: hash,
    passwordSalt: salt,
    createdAt: new Date().toISOString(),
    active: true,
  };
  await platformDb.superAdmins.mutate((cur) => [...cur, admin]);
}
