import { z } from "zod";

export const orderItemInputSchema = z.object({
  itemId: z.string().trim().min(1, "Each item needs an itemId"),
  name: z.string().trim().min(1, "Each item needs a name"),
  quantity: z.number().int().positive().max(999).optional(),
  price: z.number().nonnegative().optional(),
  variant: z.string().trim().max(120).optional(),
  note: z.string().trim().max(300).optional(),
  preparation: z.enum(["regular", "jain"]).optional(),
  spiceLevelSelected: z.string().trim().max(40).optional(),
  addOnIds: z.array(z.string().trim().min(1).max(64)).max(20).optional(),
  cookingRequest: z.string().trim().max(250).optional(),
});

export const createOrderSchema = z.object({
  tableNumber: z.number().int().positive("A valid tableNumber is required"),
  items: z.array(orderItemInputSchema).min(1, "At least one item is required"),
  note: z.string().trim().max(500).optional(),
  customerName: z.string().trim().max(120).optional(),
  waiterName: z.string().trim().max(120).optional(),
});

export const addOrderItemsSchema = z.object({
  items: z.array(orderItemInputSchema).min(1, "At least one item is required"),
});

const hhmmSchema = z
  .string()
  .trim()
  .regex(/^([01]\d|2[0-3]):([0-5]\d)$/, "Time must be HH:mm (24-hour)");

/** Base object — kept separate so `.partial()` works for PATCH schemas.
 *  ZodEffects (from superRefine) does not expose `.partial()`. */
const menuItemFieldsSchema = z.object({
  name: z.string().trim().min(1, "name is required").max(150),
  categoryId: z.string().trim().min(1, "categoryId is required"),
  price: z.number().nonnegative("price must be 0 or more"),
  description: z.string().trim().max(500).optional(),
  image: z.string().trim().url().max(500).optional(),
  prepTimeMinutes: z.number().int().nonnegative().max(180).optional(),
  available: z.boolean().optional(),
  spiceLevel: z.enum(["mild", "medium", "hot"]).optional(),
  isVeg: z.boolean().optional(),
  foodType: z.enum(["veg", "non-veg", "egg", "vegan", "other"]).optional(),
  costPrice: z.number().nonnegative().optional(),
  variants: z
    .array(z.object({ id: z.string(), label: z.string(), priceDelta: z.number() }))
    .max(20)
    .optional(),
  jainAvailable: z.boolean().optional(),
  jainOnly: z.boolean().optional(),
  enableSpiceLevel: z.boolean().optional(),
  spiceOptions: z
    .array(z.enum(["none", "mild", "medium", "spicy", "extra_spicy"]))
    .max(10)
    .optional(),
  enableCookingRequest: z.boolean().optional(),
  maxCookingRequestLength: z.number().int().min(20).max(500).optional(),
  addOns: z
    .array(
      z.object({
        id: z.string(),
        label: z.string().trim().min(1).max(80),
        priceDelta: z.number(),
        available: z.boolean().optional(),
      })
    )
    .max(30)
    .optional(),
  tags: z.array(z.string().trim().max(40)).max(20).optional(),
  ingredients: z.array(z.string().trim().max(60)).max(40).optional(),
  allergens: z.array(z.string().trim().max(40)).max(20).optional(),
  /** When true, item is only orderable between availableFrom and availableTo */
  scheduleEnabled: z.boolean().optional(),
  availableFrom: z.union([hhmmSchema, z.literal("")]).optional(),
  availableTo: z.union([hhmmSchema, z.literal("")]).optional(),
});

function refineMenuSchedule(
  data: { scheduleEnabled?: boolean; availableFrom?: string; availableTo?: string },
  ctx: z.RefinementCtx
) {
  if (!data.scheduleEnabled) return;
  const from = data.availableFrom?.trim();
  const to = data.availableTo?.trim();
  if (!from) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "availableFrom is required when schedule is enabled",
      path: ["availableFrom"],
    });
  }
  if (!to) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "availableTo is required when schedule is enabled",
      path: ["availableTo"],
    });
  }
}

export const createMenuItemSchema = menuItemFieldsSchema.superRefine(refineMenuSchedule);

const categoryFieldsSchema = z.object({
  name: z.string().trim().min(1, "name is required").max(80),
  icon: z.string().trim().max(20).optional(),
  scheduleEnabled: z.boolean().optional(),
  availableFrom: z.union([hhmmSchema, z.literal("")]).optional(),
  availableTo: z.union([hhmmSchema, z.literal("")]).optional(),
});

export const createCategorySchema = categoryFieldsSchema.superRefine(refineMenuSchedule);

export const createTableSchema = z.object({
  number: z.number().int().positive("A valid table number is required"),
  capacity: z.number().int().positive().max(50).optional(),
});

export const createOfferSchema = z
  .object({
    name: z.string().trim().min(1, "name is required").max(150),
    type: z.enum(["percent", "flat", "bogo", "combo", "category", "item", "happy_hour", "coupon"]),
    description: z.string().trim().max(500).optional(),
    image: z.string().trim().url().max(500).optional().or(z.literal("")),
    active: z.boolean().optional(),
    itemId: z.string().trim().optional(),
    categoryId: z.string().trim().optional(),
    itemIds: z.array(z.string().trim().min(1)).max(200).optional(),
    categoryIds: z.array(z.string().trim().min(1)).max(50).optional(),
    excludeItemIds: z.array(z.string().trim().min(1)).max(200).optional(),
    buyQty: z.number().int().positive().max(100).optional(),
    getQty: z.number().int().positive().max(100).optional(),
    discountPercent: z.number().min(0).max(100).optional(),
    discountAmount: z.number().nonnegative().max(1_000_000).optional(),
    maxDiscountAmount: z.number().nonnegative().max(1_000_000).optional(),
    minOrderAmount: z.number().nonnegative().max(1_000_000).optional(),
    startsAt: z.string().datetime({ offset: true }).optional().or(z.string().min(1).optional()),
    endsAt: z.string().datetime({ offset: true }).optional().or(z.string().min(1).optional()),
    daysOfWeek: z.array(z.number().int().min(0).max(6)).max(7).optional(),
    timeFrom: z.union([hhmmSchema, z.literal("")]).optional(),
    timeTo: z.union([hhmmSchema, z.literal("")]).optional(),
    usageLimit: z.number().int().positive().max(1_000_000).optional(),
    perCustomerLimit: z.number().int().positive().max(1000).optional(),
    couponCode: z
      .string()
      .trim()
      .toUpperCase()
      .max(32)
      .regex(/^[A-Z0-9_-]*$/, "Coupon code: letters, numbers, _ and - only")
      .optional()
      .or(z.literal("")),
    autoApply: z.boolean().optional(),
    stackable: z.boolean().optional(),
    priority: z.number().int().min(0).max(1000).optional(),
  })
  .superRefine((data, ctx) => {
    if (data.type === "percent" || data.type === "happy_hour" || data.type === "category" || data.type === "item") {
      if (data.discountPercent == null && data.discountAmount == null) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: "discountPercent or discountAmount is required", path: ["discountPercent"] });
      }
    }
    if (data.type === "flat" && (data.discountAmount == null || data.discountAmount <= 0)) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: "discountAmount is required for flat offers", path: ["discountAmount"] });
    }
    if (data.type === "bogo" && (!data.buyQty || !data.getQty)) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: "buyQty and getQty are required for BOGO", path: ["buyQty"] });
    }
    if (data.startsAt && data.endsAt && new Date(data.startsAt) > new Date(data.endsAt)) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: "startsAt must be before endsAt", path: ["endsAt"] });
    }
    if ((data.timeFrom && !data.timeTo) || (!data.timeFrom && data.timeTo)) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Both timeFrom and timeTo are required for a time slot", path: ["timeTo"] });
    }
  });

export const createUserSchema = z.object({
  username: z
    .string()
    .trim()
    .toLowerCase()
    .min(3, "username must be at least 3 characters")
    .max(40)
    .regex(/^[a-z0-9._-]+$/, "username can only contain letters, numbers, dots, dashes and underscores"),
  password: z.string().min(8, "password must be at least 8 characters").max(200),
  name: z.string().trim().min(1, "name is required").max(120),
  role: z.enum(["manager", "waiter"]),
  permissions: z.array(z.string()).optional(),
});

export const createExpenseSchema = z.object({
  date: z.string().trim().min(1, "date is required"),
  category: z.enum(["rent", "salaries", "utilities", "raw-materials", "maintenance", "marketing", "other"]),
  description: z.string().trim().max(300).optional(),
  amount: z.number().positive("amount must be greater than 0"),
});

// ---------------------------------------------------------------------------
// Partial-update ("PATCH") schemas. Every field optional (`.partial()`),
// but any field that IS present must still be the right type — this closes
// a real gap where these 4 PATCH routes previously spread the raw request
// body directly onto the stored document with zero validation (id/
// restaurantId were already correctly pinned post-spread so tenant-hopping
// wasn't possible, but nothing stopped e.g. `price: "not a number"` from
// corrupting a document).
// ---------------------------------------------------------------------------

export const updateCategorySchema = categoryFieldsSchema.partial().superRefine((data, ctx) => {
  if (data.scheduleEnabled === true) refineMenuSchedule(data, ctx);
});
export const updateOfferSchema = z.object({
  name: z.string().trim().min(1).max(150).optional(),
  type: z.enum(["percent", "flat", "bogo", "combo", "category", "item", "happy_hour", "coupon"]).optional(),
  description: z.string().trim().max(500).optional(),
  image: z.string().trim().max(500).optional(),
  active: z.boolean().optional(),
  itemId: z.string().trim().optional(),
  categoryId: z.string().trim().optional(),
  itemIds: z.array(z.string()).optional(),
  categoryIds: z.array(z.string()).optional(),
  excludeItemIds: z.array(z.string()).optional(),
  buyQty: z.number().int().positive().optional(),
  getQty: z.number().int().positive().optional(),
  discountPercent: z.number().min(0).max(100).optional(),
  discountAmount: z.number().nonnegative().optional(),
  maxDiscountAmount: z.number().nonnegative().optional(),
  minOrderAmount: z.number().nonnegative().optional(),
  startsAt: z.string().optional(),
  endsAt: z.string().optional(),
  daysOfWeek: z.array(z.number().int().min(0).max(6)).optional(),
  timeFrom: z.string().optional(),
  timeTo: z.string().optional(),
  usageLimit: z.number().int().positive().optional(),
  perCustomerLimit: z.number().int().positive().optional(),
  couponCode: z.string().trim().toUpperCase().max(32).optional(),
  autoApply: z.boolean().optional(),
  stackable: z.boolean().optional(),
  priority: z.number().int().min(0).max(1000).optional(),
}).strict();
export const updateMenuItemSchema = menuItemFieldsSchema.partial().superRefine((data, ctx) => {
  // Only enforce schedule times when the patch explicitly enables the schedule
  if (data.scheduleEnabled === true) refineMenuSchedule(data, ctx);
});
export const updateExpenseSchema = createExpenseSchema.partial();
