// Deterministic calendar-key derivation shared by the sales archival path
// and every reporting/analytics aggregation. Using the same helper
// everywhere guarantees a sale is always bucketed into the same day/week/
// month/year no matter which endpoint computed it.

function pad(n: number, len = 2) {
  return String(n).padStart(len, "0");
}

export interface TimeKeys {
  dateKey: string; // YYYY-MM-DD
  weekKey: string; // YYYY-Www (ISO week)
  monthKey: string; // YYYY-MM
  yearKey: string; // YYYY
  hour: number; // 0-23
  weekday: number; // 0(Sun)-6(Sat)
}

// ISO 8601 week number.
function isoWeek(d: Date): { week: number; year: number } {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((date.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return { week, year: date.getUTCFullYear() };
}

export function deriveTimeKeys(iso: string | Date): TimeKeys {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  const { week, year } = isoWeek(d);
  return {
    dateKey: `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`,
    weekKey: `${year}-W${pad(week)}`,
    monthKey: `${d.getFullYear()}-${pad(d.getMonth() + 1)}`,
    yearKey: `${d.getFullYear()}`,
    hour: d.getHours(),
    weekday: d.getDay(),
  };
}

export function todayKeys(): TimeKeys {
  return deriveTimeKeys(new Date());
}
