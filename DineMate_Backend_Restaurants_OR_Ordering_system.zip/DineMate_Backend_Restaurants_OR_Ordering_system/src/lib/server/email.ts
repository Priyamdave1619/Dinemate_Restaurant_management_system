import nodemailer, { Transporter } from "nodemailer";

/**
 * Generic SMTP email delivery — works with any provider that speaks SMTP
 * (Gmail, SendGrid's SMTP relay, AWS SES SMTP, Postmark, your own mail
 * server, etc.), configured entirely through environment variables so no
 * provider-specific SDK/lock-in is required. See .env.example for the
 * variables this reads.
 *
 * If SMTP isn't configured, `sendEmail` logs and no-ops instead of
 * throwing — notification triggers elsewhere in the app should never fail
 * a request just because email isn't set up yet.
 */

let cachedTransporter: Transporter | null | undefined;

function getTransporter(): Transporter | null {
  if (cachedTransporter !== undefined) return cachedTransporter;

  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT || 587);
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (!host || !user || !pass) {
    cachedTransporter = null;
    return null;
  }

  cachedTransporter = nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
  });
  return cachedTransporter;
}

export interface EmailInput {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmail(input: EmailInput): Promise<{ sent: boolean; reason?: string }> {
  const transporter = getTransporter();
  if (!transporter) {
    console.warn(`[email] SMTP not configured — skipped "${input.subject}" to ${input.to}`);
    return { sent: false, reason: "SMTP not configured" };
  }

  const from = process.env.EMAIL_FROM || process.env.SMTP_USER!;
  try {
    await transporter.sendMail({ from, to: input.to, subject: input.subject, html: input.html, text: input.text });
    return { sent: true };
  } catch (err) {
    console.error("[email] send failed", err);
    return { sent: false, reason: err instanceof Error ? err.message : "send failed" };
  }
}

// ---------------------------------------------------------------------------
// A few ready-made templates for the events this backend already knows
// about. Kept intentionally plain (inline HTML, no template engine) — swap
// for a proper templating solution if the email surface grows.
// ---------------------------------------------------------------------------

export function welcomeEmail(params: { ownerName: string; restaurantId: string; restaurantName: string }): EmailInput {
  return {
    to: "",
    subject: `Welcome to the platform, ${params.restaurantName}!`,
    html: `<p>Hi ${params.ownerName},</p>
<p>Your restaurant <strong>${params.restaurantName}</strong> is now registered.</p>
<p>Your Restaurant ID (also your login username) is: <strong>${params.restaurantId}</strong></p>
<p>You're on a 14-day free trial — you can upgrade anytime from your dashboard.</p>`,
  };
}

export function subscriptionExpiringEmail(params: { ownerName: string; daysLeft: number }): EmailInput {
  return {
    to: "",
    subject: "Your subscription is expiring soon",
    html: `<p>Hi ${params.ownerName},</p>
<p>Your subscription expires in ${params.daysLeft} day(s). Renew from your dashboard to avoid any interruption to
logins, orders, or dashboard access.</p>`,
  };
}

export function subscriptionRenewedEmail(params: { ownerName: string; expiresAt: string; planName: string }): EmailInput {
  return {
    to: "",
    subject: "Subscription renewed",
    html: `<p>Hi ${params.ownerName},</p>
<p>Your <strong>${params.planName}</strong> plan has been renewed, valid until
${new Date(params.expiresAt).toLocaleDateString()}.</p>`,
  };
}

export function restaurantSuspendedEmail(params: { ownerName: string; restaurantName: string }): EmailInput {
  return {
    to: "",
    subject: "Your restaurant account has been suspended",
    html: `<p>Hi ${params.ownerName},</p>
<p><strong>${params.restaurantName}</strong>'s account has been suspended by the platform. Contact support for
details on reinstating access.</p>`,
  };
}
