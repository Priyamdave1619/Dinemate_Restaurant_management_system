/**
 * Groq vision menu extraction — adapted from FoodChow OCR Menu Caption Generator.
 *
 * Key lessons from FoodChow model.py:
 * - Vision model: meta-llama/llama-4-scout-17b-16e-instruct
 * - Do NOT use response_format json_object (vision models reject it)
 * - Prompt asks for a JSON array of items
 * - clean_json extracts [ ... ] from the response
 * - Retry on failure
 */

import { randomUUID } from "crypto";
import { ExtractedMenuItem, FoodType } from "@/lib/types";
import {
  MenuExtractionProvider,
  ExtractionInput,
  ExtractionResult,
  registerExtractionProvider,
} from "./extraction-provider";
import {
  isGroqExtractionEnabled,
  resolveGroqApiKey,
  resolveGroqVisionModel,
} from "@/lib/server/secrets";

const GROQ_CHAT_URL = "https://api.groq.com/openai/v1/chat/completions";

/** FoodChow-style default vision model (Llama 4 Scout). */
/** Current Groq vision model (Llama 4 Scout shut down 2026-07-17). */
export const FOODCHOW_VISION_MODEL = "qwen/qwen3.6-27b";

/**
 * FoodChow OPTIMIZED_PROMPT — extract ALL items as a JSON array.
 * Extended slightly for variants/add-ons used by DineMate.
 */
const FOODCHOW_PROMPT = `You are a menu extraction AI. Extract ALL menu items from this image as a JSON array. Extract ALL menu items. NEVER skip ANY category.

CRITICAL: Your response must be ONLY a valid JSON array, nothing else. No markdown, no explanations.

For each item, create an object with these exact fields:
{
  "category": "inferred category (e.g., Appetizers, Main Course, Desserts, Starters, Beverages)",
  "item_name": "exact dish name",
  "description": "ingredients/details or empty string",
  "is_veg": "yes or no",
  "is_alcohol": "yes or no",
  "price": numeric value only (e.g., 12.99 or 249),
  "variants": [{"label": "Half", "price": 150}, {"label": "Full", "price": 249}],
  "add_ons": [{"label": "Extra Cheese", "price": 50}],
  "jain_available": "yes or no or unknown"
}

Rules:
- Output ONLY the JSON array starting with [ and ending with ]
- No markdown code blocks
- No explanatory text
- If no items found, return empty array: []
- Handle blurry/rotated images
- Infer vegetarian from indicators like 🌱 🟢 or "veg" text; non-veg from 🔴 chicken mutton fish
- Detect exact category names as shown in image
- Keep spelling SAME as menu
- Extract EVERY row — do not skip small text or second columns
- Half/Full/Small/Medium/Large go in variants, not as separate items
- price is the main/regular price (number only, no ₹ or Rs)
- variants and add_ons may be empty arrays if not shown

Example output:
[{"category":"Appetizers","item_name":"Spring Rolls","description":"Crispy vegetable rolls","is_veg":"yes","is_alcohol":"no","price":8.99,"variants":[],"add_ons":[],"jain_available":"unknown"}]`;

function normalizeName(s: string): string {
  return s
    .trim()
    .replace(/\s+/g, " ")
    .replace(/^[•\-\*\d.)\s]+/, "")
    .split(" ")
    .map((w) => (w.length ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w))
    .join(" ");
}

function parsePrice(v: unknown): number {
  if (typeof v === "number" && Number.isFinite(v)) return v;
  if (typeof v === "string") {
    const s = v.replace(/,/g, "").trim();
    const m = s.match(/(\d+(?:\.\d{1,2})?)/);
    if (m) {
      let n = parseFloat(m[1]);
      if (n > 9999) n = n % 1000;
      return n;
    }
  }
  return 0;
}

/** FoodChow clean_json_response — extract JSON array from model output */
function cleanJsonArray(content: string): string {
  if (!content) return "[]";
  let s = content.replace(/```json\s*/gi, "").replace(/```\s*/g, "");
  s = s.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
  const start = s.indexOf("[");
  const end = s.lastIndexOf("]");
  if (start === -1 || end === -1 || end <= start) return "[]";
  return s.slice(start, end + 1).trim();
}

function isVegFlag(v: unknown): boolean {
  const s = String(v ?? "").toLowerCase().trim();
  return s === "yes" || s === "true" || s === "veg" || s === "1";
}

function asFoodType(item: Record<string, unknown>): FoodType {
  if (item.foodType || item.food_type) {
    const t = String(item.foodType || item.food_type).toLowerCase();
    if (t.includes("non")) return "non-veg";
    if (t.includes("vegan")) return "vegan";
    if (t.includes("egg")) return "egg";
    if (t.includes("veg")) return "veg";
  }
  if (isVegFlag(item.is_veg) || isVegFlag(item.isVeg)) return "veg";
  const name = String(item.item_name || item.name || "").toLowerCase();
  if (/\b(chicken|mutton|fish|prawn|shrimp|meat|lamb|beef|pork|egg)\b/.test(name)) {
    if (/\begg\b/.test(name) && !/\b(chicken|mutton|fish|meat)\b/.test(name)) return "egg";
    return "non-veg";
  }
  if (/\b(paneer|dal|sabzi|aloo|gobi|veg)\b/.test(name)) return "veg";
  if (String(item.is_veg || "").toLowerCase() === "no") return "non-veg";
  return "veg";
}

function mapFoodchowItems(items: unknown[], fileName: string): {
  items: ExtractedMenuItem[];
  categories: string[];
} {
  const cats = new Set<string>();
  const out: ExtractedMenuItem[] = [];

  for (const row of items) {
    if (!row || typeof row !== "object") continue;
    const r = row as Record<string, unknown>;
    const name = normalizeName(String(r.item_name || r.name || r.item || r.title || ""));
    if (!name || name.length < 2) continue;

    const price = parsePrice(r.price ?? r.amount ?? r.rate);
    const categoryName =
      String(r.category || r.categoryName || r.section || "Uncategorized").trim() || "Uncategorized";
    cats.add(categoryName);
    const foodType = asFoodType(r);
    const conf = 0.9;

    let jainAvailable: boolean | "needs_review" = "needs_review";
    const jain = String(r.jain_available ?? r.jainAvailable ?? "").toLowerCase();
    if (jain === "yes" || jain === "true") jainAvailable = true;
    else if (jain === "no" || jain === "false") jainAvailable = false;

    const variantsRaw = Array.isArray(r.variants) ? r.variants : [];
    const variants = variantsRaw
      .filter((v): v is Record<string, unknown> => !!v && typeof v === "object")
      .map((v) => ({
        label: String(v.label || v.name || "Regular"),
        price: parsePrice(v.price ?? price),
        confidence: conf,
      }))
      .filter((v) => v.label);

    const addOnsRaw = Array.isArray(r.add_ons)
      ? r.add_ons
      : Array.isArray(r.addOns)
        ? r.addOns
        : [];
    const addOns = addOnsRaw
      .filter((a): a is Record<string, unknown> => !!a && typeof a === "object")
      .map((a) => ({
        label: String(a.label || a.name || "Extra"),
        price: parsePrice(a.price),
        confidence: conf,
      }))
      .filter((a) => a.label);

    out.push({
      id: `ext-${randomUUID()}`,
      name,
      description: r.description ? String(r.description) : "",
      price,
      categoryName,
      foodType,
      jainAvailable,
      variants: variants.length ? variants : undefined,
      addOns: addOns.length ? addOns : undefined,
      tags: String(r.is_alcohol || "").toLowerCase() === "yes" ? ["alcohol"] : undefined,
      sourceFile: fileName,
      confidence: {
        name: conf,
        price: price > 0 ? conf : 0.35,
        category: conf * 0.95,
        foodType: conf * 0.9,
        overall: conf,
      },
      status: price > 0 ? "extracted" : "needs_review",
    });
  }

  return { items: out, categories: [...cats] };
}


/**
 * Shrink menu photos so free-tier Groq TPM (8k) can accept the request.
 * Vision token cost scales with resolution — long side capped, JPEG re-encoded.
 * Uses `sharp` when available (common on Next/Vercel); otherwise returns original.
 */
async function compressImageForVision(
  buffer: Buffer,
  mimeType: string
): Promise<{ buffer: Buffer; mimeType: string }> {
  try {
    // dynamic import — optional dependency
    const sharpMod = await import("sharp").catch(() => null);
    if (!sharpMod) return { buffer, mimeType };

    const sharp = sharpMod.default;
    let pipeline = sharp(buffer, { failOn: "none" }).rotate(); // EXIF orient
    const meta = await pipeline.metadata();
    const w = meta.width || 0;
    const h = meta.height || 0;
    const maxSide = 1024; // keeps most menus readable, cuts vision tokens hard

    if (w > maxSide || h > maxSide) {
      pipeline = pipeline.resize({
        width: w >= h ? maxSide : undefined,
        height: h > w ? maxSide : undefined,
        fit: "inside",
        withoutEnlargement: true,
      });
    }

    const out = await pipeline
      .jpeg({ quality: 72, mozjpeg: true })
      .toBuffer();

    // If still huge (> ~1.2MB), compress harder
    if (out.length > 1_200_000) {
      const smaller = await sharp(out)
        .resize({ width: 768, fit: "inside", withoutEnlargement: true })
        .jpeg({ quality: 60, mozjpeg: true })
        .toBuffer();
      return { buffer: smaller, mimeType: "image/jpeg" };
    }
    return { buffer: out, mimeType: "image/jpeg" };
  } catch {
    return { buffer, mimeType };
  }
}

async function callGroqVision(opts: {
  apiKey: string;
  model: string;
  dataUrl: string;
  fileName: string;
}): Promise<{ content: string } | { error: string }> {
  const res = await fetch(GROQ_CHAT_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${opts.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: opts.model,
      temperature: 0.1,
      max_tokens: 4096,
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: FOODCHOW_PROMPT },
            { type: "image_url", image_url: { url: opts.dataUrl } },
          ],
        },
      ],
    }),
  });

  const body = (await res.json().catch(() => ({}))) as {
    error?: { message?: string };
    choices?: Array<{ message?: { content?: string } }>;
  };

  if (!res.ok) {
    return { error: body?.error?.message || `Groq HTTP ${res.status}` };
  }

  const content = body.choices?.[0]?.message?.content?.trim() || "";
  if (!content) return { error: "Groq returned empty content" };
  return { content };
}

export class GroqVisionExtractionProvider implements MenuExtractionProvider {
  name = "groq-vision";

  supports(mimeType: string, fileName: string): boolean {
    const lower = fileName.toLowerCase();
    return (
      mimeType.startsWith("image/") ||
      lower.endsWith(".jpg") ||
      lower.endsWith(".jpeg") ||
      lower.endsWith(".png") ||
      lower.endsWith(".webp") ||
      mimeType === "application/pdf" ||
      lower.endsWith(".pdf")
    );
  }

  async extract(input: ExtractionInput): Promise<ExtractionResult> {
    if (!(await isGroqExtractionEnabled())) {
      return {
        items: [],
        categories: [],
        provider: this.name,
        error: "Groq API is not configured. Set GROQ_API_KEY on the backend.",
      };
    }

    const apiKey = await resolveGroqApiKey();
    if (!apiKey) {
      return {
        items: [],
        categories: [],
        provider: this.name,
        error: "Groq API key missing or could not be decrypted.",
      };
    }

    if (
      input.mimeType === "application/pdf" ||
      input.fileName.toLowerCase().endsWith(".pdf")
    ) {
      return {
        items: [],
        categories: [],
        provider: this.name,
        error:
          "PDF not supported by vision OCR. Export each page as JPG/PNG and upload those images.",
      };
    }

    // Env > DB config > current Groq vision default (qwen/qwen3.6-27b)
    const envModel = (process.env.GROQ_VISION_MODEL || "").trim();
    let model = envModel || FOODCHOW_VISION_MODEL;
    try {
      const configured = (await resolveGroqVisionModel())?.trim();
      if (envModel) {
        model = envModel;
      } else if (configured && !/llama-4-scout|llama-4-maverick|llama-3\.2-.*vision/i.test(configured)) {
        model = configured;
      } else {
        // Deprecated vision models → use current default
        model = FOODCHOW_VISION_MODEL;
      }
    } catch {
      model = FOODCHOW_VISION_MODEL;
    }

    let mime = input.mimeType.startsWith("image/") ? input.mimeType : "image/jpeg";
    if (mime === "image/jpg") mime = "image/jpeg";

    if (input.buffer.length > 12 * 1024 * 1024) {
      return {
        items: [],
        categories: [],
        provider: this.name,
        error: "Image too large (max ~12MB). Compress and retry.",
      };
    }

    // Shrink for Groq free-tier TPM (8k). Large photos often request 10k+ tokens.
    const compressed = await compressImageForVision(input.buffer, mime);
    mime = compressed.mimeType;
    const dataUrl = `data:${mime};base64,${compressed.buffer.toString("base64")}`;
    const retryCount = 2;
    let lastError = "Extraction failed";

    for (let attempt = 0; attempt <= retryCount; attempt++) {
      try {
        const result = await callGroqVision({
          apiKey,
          model,
          dataUrl,
          fileName: input.fileName,
        });

        if ("error" in result) {
          lastError = result.error;
          // Auto-switch if deprecated / inaccessible model
          if (/does not exist|do not have access|model_not_found|decommissioned/i.test(result.error)) {
            if (model !== FOODCHOW_VISION_MODEL) {
              model = FOODCHOW_VISION_MODEL;
              continue;
            }
          }
          if (/Request too large|tokens per minute|TPM|reduce your message size/i.test(result.error)) {
            lastError =
              "Image is too large for your Groq plan (token limit). " +
              "Use a smaller/clearer photo (under ~1MB, one page), or upgrade Groq at https://console.groq.com/settings/billing";
            // already compressed; further retries unlikely to help without upgrade
            break;
          }
          if (attempt < retryCount) {
            await new Promise((r) => setTimeout(r, 1200));
            continue;
          }
          break;
        }

        const jsonStr = cleanJsonArray(result.content);
        let parsed: unknown;
        try {
          parsed = JSON.parse(jsonStr);
        } catch {
          lastError = `Invalid JSON from model: ${result.content.slice(0, 120)}`;
          if (attempt < retryCount) {
            await new Promise((r) => setTimeout(r, 1200));
            continue;
          }
          break;
        }

        if (!Array.isArray(parsed)) {
          lastError = "Model did not return a JSON array";
          if (attempt < retryCount) {
            await new Promise((r) => setTimeout(r, 1200));
            continue;
          }
          break;
        }

        const mapped = mapFoodchowItems(parsed, input.fileName);
        if (mapped.items.length === 0) {
          lastError = "Model returned an empty item list";
          if (attempt < retryCount) {
            await new Promise((r) => setTimeout(r, 1200));
            continue;
          }
          break;
        }

        return {
          items: mapped.items,
          categories: mapped.categories,
          provider: this.name,
          rawText: result.content.slice(0, 5000),
        };
      } catch (e) {
        lastError = e instanceof Error ? e.message : "Groq request failed";
        if (attempt < retryCount) {
          await new Promise((r) => setTimeout(r, 1200));
          continue;
        }
      }
    }

    return {
      items: [],
      categories: [],
      provider: this.name,
      error: lastError,
    };
  }
}

let registered = false;
export function ensureGroqProviderRegistered(): void {
  if (registered) return;
  registerExtractionProvider(new GroqVisionExtractionProvider());
  registered = true;
}

ensureGroqProviderRegistered();
