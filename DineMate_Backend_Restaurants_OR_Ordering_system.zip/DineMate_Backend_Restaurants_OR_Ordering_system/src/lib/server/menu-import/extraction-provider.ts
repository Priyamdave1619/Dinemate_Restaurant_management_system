/**
 * Abstraction for menu extraction providers (OCR / AI Vision / CSV parsers).
 * Swap implementations without touching the import pipeline.
 */

import { ExtractedMenuItem, FoodType } from "@/lib/types";
import { randomUUID } from "crypto";

export interface ExtractionInput {
  buffer: Buffer;
  fileName: string;
  mimeType: string;
}

export interface ExtractionResult {
  items: ExtractedMenuItem[];
  categories: string[];
  rawText?: string;
  provider: string;
  error?: string;
}

export interface MenuExtractionProvider {
  name: string;
  supports(mimeType: string, fileName: string): boolean;
  extract(input: ExtractionInput): Promise<ExtractionResult>;
}

function normalizeName(s: string): string {
  return s
    .trim()
    .replace(/\s+/g, " ")
    .replace(/^\W+|\W+$/g, "")
    .split(" ")
    .map((w) => (w.length ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w))
    .join(" ");
}

function detectFoodType(name: string, description = "", category = ""): { type: FoodType; confidence: number } {
  const text = `${name} ${description} ${category}`.toLowerCase();
  if (/\bvegan\b/.test(text)) return { type: "vegan", confidence: 0.9 };
  if (/\b(chicken|mutton|fish|prawn|shrimp|meat|non[\s-]?veg|lamb|beef|pork|egg)\b/.test(text)) {
    if (/\begg\b/.test(text) && !/\b(chicken|mutton|fish|meat)\b/.test(text)) return { type: "egg", confidence: 0.85 };
    return { type: "non-veg", confidence: 0.88 };
  }
  if (/\b(paneer|veg|vegetable|dal|sabzi|aloo|gobi|mushroom|tofu)\b/.test(text)) {
    return { type: "veg", confidence: 0.9 };
  }
  return { type: "veg", confidence: 0.45 }; // low confidence default
}

function parsePrice(raw: string): number | null {
  const m = raw.replace(/,/g, "").match(/(?:₹|rs\.?\s*|inr\s*)?(\d+(?:\.\d{1,2})?)/i);
  if (!m) return null;
  const n = parseFloat(m[1]);
  return Number.isFinite(n) ? n : null;
}

/** Heuristic / mock extractor for structured files and simple text menus. */
export class HeuristicExtractionProvider implements MenuExtractionProvider {
  name = "heuristic";

  supports(mimeType: string, fileName: string): boolean {
    const lower = fileName.toLowerCase();
    return (
      mimeType.startsWith("text/") ||
      mimeType === "application/json" ||
      mimeType === "text/csv" ||
      mimeType.includes("spreadsheet") ||
      mimeType.includes("excel") ||
      lower.endsWith(".csv") ||
      lower.endsWith(".json") ||
      lower.endsWith(".xlsx") ||
      lower.endsWith(".xls")
    );
  }

  async extract(input: ExtractionInput): Promise<ExtractionResult> {
    const { buffer, fileName, mimeType } = input;
    const lower = fileName.toLowerCase();

    try {
      if (lower.endsWith(".json") || mimeType === "application/json") {
        return this.fromJson(buffer, fileName);
      }
      if (lower.endsWith(".csv") || mimeType === "text/csv") {
        return this.fromCsv(buffer, fileName);
      }
      // Images / PDF: do NOT invent items from filename — only Groq vision should handle these
      if (mimeType.startsWith("image/") || mimeType === "application/pdf") {
        return {
          items: [],
          categories: [],
          provider: this.name,
          error:
            "No OCR result for this image. Ensure GROQ_API_KEY is set and GROQ_VISION_MODEL=meta-llama/llama-4-scout-17b-16e-instruct, then re-upload.",
        };
      }
      // Fallback text
      const text = buffer.toString("utf8");
      return this.fromPlainText(text, fileName);
    } catch (e) {
      return {
        items: [],
        categories: [],
        provider: this.name,
        error: e instanceof Error ? e.message : "Extraction failed",
      };
    }
  }

  private fromJson(buffer: Buffer, fileName: string): ExtractionResult {
    const data = JSON.parse(buffer.toString("utf8"));
    const list = Array.isArray(data) ? data : data.items || data.menu || [];
    const items: ExtractedMenuItem[] = [];
    const cats = new Set<string>();

    for (const row of list) {
      const name = normalizeName(String(row.name || row.item || row.title || ""));
      if (!name) continue;
      const price = Number(row.price ?? row.amount ?? 0) || 0;
      const categoryName = row.category || row.categoryName || "Uncategorized";
      cats.add(String(categoryName));
      const ft = detectFoodType(name, row.description || "", categoryName);
      items.push({
        id: `ext-${randomUUID()}`,
        name,
        description: row.description || "",
        price,
        categoryName: String(categoryName),
        foodType: (row.foodType as FoodType) || ft.type,
        jainAvailable: row.jainAvailable === true ? true : row.jainAvailable === false ? false : "needs_review",
        variants: Array.isArray(row.variants)
          ? row.variants.map((v: { label?: string; name?: string; price?: number; priceDelta?: number }) => ({
              label: String(v.label || v.name || "Regular"),
              price: Number(v.price ?? price + (v.priceDelta || 0)),
              confidence: 0.95,
            }))
          : undefined,
        addOns: Array.isArray(row.addOns)
          ? row.addOns.map((a: { label?: string; name?: string; price?: number; priceDelta?: number }) => ({
              label: String(a.label || a.name || "Extra"),
              price: Number(a.price ?? a.priceDelta ?? 0),
              confidence: 0.9,
            }))
          : undefined,
        tags: row.tags,
        ingredients: row.ingredients,
        prepTimeMinutes: row.prepTimeMinutes,
        sourceFile: fileName,
        confidence: {
          name: 0.99,
          price: price > 0 ? 0.99 : 0.3,
          category: 0.95,
          foodType: ft.confidence,
          overall: 0.92,
        },
        status: price > 0 ? "extracted" : "needs_review",
      });
    }

    return { items, categories: [...cats], provider: this.name };
  }

  private fromCsv(buffer: Buffer, fileName: string): ExtractionResult {
    const text = buffer.toString("utf8");
    const lines = text.split(/\r?\n/).filter((l) => l.trim());
    if (lines.length < 2) return { items: [], categories: [], provider: this.name };

    const header = lines[0].split(",").map((h) => h.trim().toLowerCase().replace(/"/g, ""));
    const nameIdx = header.findIndex((h) => /name|item|title/.test(h));
    const priceIdx = header.findIndex((h) => /price|amount|cost/.test(h));
    const catIdx = header.findIndex((h) => /categor/.test(h));
    const descIdx = header.findIndex((h) => /desc/.test(h));
    const typeIdx = header.findIndex((h) => /type|veg|food/.test(h));

    const items: ExtractedMenuItem[] = [];
    const cats = new Set<string>();

    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].match(/(".*?"|[^,]+)/g)?.map((c) => c.replace(/^"|"$/g, "").trim()) || [];
      const name = normalizeName(cols[nameIdx] || "");
      if (!name) continue;
      const price = parsePrice(cols[priceIdx] || "0") ?? 0;
      const categoryName = cols[catIdx] || "Uncategorized";
      cats.add(categoryName);
      const desc = cols[descIdx] || "";
      const ft = detectFoodType(name, desc, categoryName);
      const explicitType = (cols[typeIdx] || "").toLowerCase();
      let foodType = ft.type;
      if (explicitType.includes("non")) foodType = "non-veg";
      else if (explicitType.includes("egg")) foodType = "egg";
      else if (explicitType.includes("vegan")) foodType = "vegan";
      else if (explicitType.includes("veg")) foodType = "veg";

      items.push({
        id: `ext-${randomUUID()}`,
        name,
        description: desc,
        price,
        categoryName,
        foodType,
        jainAvailable: "needs_review",
        sourceFile: fileName,
        confidence: {
          name: 0.95,
          price: price > 0 ? 0.95 : 0.3,
          category: catIdx >= 0 ? 0.9 : 0.5,
          foodType: typeIdx >= 0 ? 0.9 : ft.confidence,
          overall: 0.85,
        },
        status: price > 0 ? "extracted" : "needs_review",
      });
    }

    return { items, categories: [...cats], provider: this.name };
  }

  private fromPlainText(text: string, fileName: string): ExtractionResult {
    const items: ExtractedMenuItem[] = [];
    const cats = new Set<string>();
    let currentCategory = "Uncategorized";
    const lines = text.split(/\r?\n/);

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;

      // Category headers often ALL CAPS or end with :
      if (/^[A-Z][A-Z\s&]{2,}$/.test(trimmed) || /^[A-Za-z\s&]+:$/.test(trimmed)) {
        currentCategory = normalizeName(trimmed.replace(/:$/, ""));
        cats.add(currentCategory);
        continue;
      }

      // Item + price patterns
      const priceMatch = trimmed.match(/(.+?)\s+(?:₹|Rs\.?\s*)?(\d+(?:\.\d{1,2})?)\s*$/i);
      if (priceMatch) {
        const name = normalizeName(priceMatch[1]);
        const price = parseFloat(priceMatch[2]);
        if (name && price > 0) {
          const ft = detectFoodType(name, "", currentCategory);
          items.push({
            id: `ext-${randomUUID()}`,
            name,
            price,
            categoryName: currentCategory,
            foodType: ft.type,
            jainAvailable: "needs_review",
            sourceFile: fileName,
            confidence: {
              name: 0.8,
              price: 0.85,
              category: 0.7,
              foodType: ft.confidence,
              overall: 0.75,
            },
            status: "extracted",
          });
        }
      }
    }

    return { items, categories: [...cats], provider: this.name, rawText: text.slice(0, 2000) };
  }

  /** For images/PDFs without a real vision model, produce a low-confidence placeholder based on filename. */
  private mockFromImageName(fileName: string): ExtractionResult {
    const base = fileName.replace(/\.[^.]+$/, "").replace(/[-_]/g, " ");
    const name = normalizeName(base);
    if (!name || name.length < 2) {
      return {
        items: [],
        categories: [],
        provider: this.name,
        error:
          "Image/PDF OCR requires a configured AI Vision provider (OpenAI, Google Vision, or Tesseract). Filename alone is insufficient for reliable extraction.",
      };
    }
    const ft = detectFoodType(name);
    return {
      items: [
        {
          id: `ext-${randomUUID()}`,
          name,
          price: 0,
          categoryName: "Needs Review",
          foodType: ft.type,
          jainAvailable: "needs_review",
          sourceFile: fileName,
          confidence: {
            name: 0.4,
            price: 0.1,
            category: 0.2,
            foodType: ft.confidence,
            overall: 0.25,
          },
          status: "needs_review",
          errorMessage: "Extracted from filename only — please review and fill price/category. Configure AI Vision for full OCR.",
        },
      ],
      categories: ["Needs Review"],
      provider: this.name,
    };
  }
}

/** Registry — add real providers (OpenAI Vision, Google Document AI, etc.) here. */
const providers: MenuExtractionProvider[] = [new HeuristicExtractionProvider()];

export function getExtractionProvider(mimeType: string, fileName: string): MenuExtractionProvider | null {
  return providers.find((p) => p.supports(mimeType, fileName)) ?? null;
}

/** All providers that claim support for this file, in priority order (first = preferred). */
export function getExtractionProviders(mimeType: string, fileName: string): MenuExtractionProvider[] {
  return providers.filter((p) => p.supports(mimeType, fileName));
}

export function registerExtractionProvider(provider: MenuExtractionProvider): void {
  providers.unshift(provider);
}
