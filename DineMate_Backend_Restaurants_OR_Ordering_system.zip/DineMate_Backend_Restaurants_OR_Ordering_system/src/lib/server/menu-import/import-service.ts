/**
 * Bulk Menu Import service — orchestration, normalization, duplicate detection,
 * validation, and safe commit into tenant menu tables.
 */

import { randomUUID } from "crypto";
import { createHash } from "crypto";
import {
  MenuImportSession,
  ExtractedMenuItem,
  MenuItem,
  MenuCategory,
  FoodType,
  Variant,
  MenuAddOn,
} from "@/lib/types";
import { tenantDb } from "@/lib/server/db";
import { writeStoredFile } from "@/lib/server/storage";
import { getExtractionProviders, ExtractionInput } from "./extraction-provider";
// Registers Groq vision provider (images) ahead of heuristic fallback
import "./groq-vision-provider";

const MAX_IMAGE_BYTES = 15 * 1024 * 1024;
const MAX_PDF_BYTES = 50 * 1024 * 1024;
const MAX_TABULAR_BYTES = 20 * 1024 * 1024;

const ALLOWED_MIME = new Set([
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
  "application/pdf",
  "text/csv",
  "application/json",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-excel",
  "text/plain",
]);

function isAllowedMime(mime: string, name: string): boolean {
  const lower = name.toLowerCase();
  if (ALLOWED_MIME.has(mime)) return true;
  if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return true;
  if (lower.endsWith(".png") || lower.endsWith(".webp")) return true;
  if (lower.endsWith(".pdf")) return true;
  if (lower.endsWith(".csv") || lower.endsWith(".json")) return true;
  if (lower.endsWith(".xlsx") || lower.endsWith(".xls")) return true;
  return false;
}

function maxSizeFor(mime: string, name: string): number {
  if (mime.startsWith("image/") || /\.(jpe?g|png|webp)$/i.test(name)) return MAX_IMAGE_BYTES;
  if (mime === "application/pdf" || name.toLowerCase().endsWith(".pdf")) return MAX_PDF_BYTES;
  return MAX_TABULAR_BYTES;
}

function sanitizeFileName(name: string): string {
  return name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 180);
}

function normalizeCategoryName(name: string): string {
  return name
    .trim()
    .replace(/\s+/g, " ")
    .replace(/&/g, "and")
    .toLowerCase()
    .replace(/\bstarters?\b|\bsnacks?\b/g, "starters")
    .replace(/\bmain\s*course\b|\bmains?\b/g, "main course")
    .replace(/\bbeverages?\b|\bdrinks?\b/g, "beverages");
}

export function validateUploadFile(
  fileName: string,
  mimeType: string,
  size: number
): { ok: true } | { ok: false; error: string } {
  if (!isAllowedMime(mimeType, fileName)) {
    return { ok: false, error: `Unsupported file type: ${mimeType || fileName}` };
  }
  const max = maxSizeFor(mimeType, fileName);
  if (size > max) {
    return { ok: false, error: `File exceeds maximum size of ${Math.round(max / 1024 / 1024)} MB` };
  }
  if (size === 0) return { ok: false, error: "Empty file" };
  return { ok: true };
}

export async function createImportSession(
  restaurantId: string,
  userId: string,
  files: Array<{ name: string; size: number; mimeType: string; buffer: Buffer }>
): Promise<MenuImportSession> {
  const id = `imp-${randomUUID()}`;
  const now = new Date().toISOString();

  const fileMeta: MenuImportSession["files"] = [];
  for (const f of files) {
    const check = validateUploadFile(f.name, f.mimeType, f.size);
    if (!check.ok) {
      fileMeta.push({
        name: f.name,
        size: f.size,
        mimeType: f.mimeType,
        status: "error",
        error: check.error,
      });
      continue;
    }
    const safe = sanitizeFileName(f.name);
    const hash = createHash("sha256").update(f.buffer).digest("hex").slice(0, 16);
    const key = `menu-import/${restaurantId}/${id}/${hash}-${safe}`;

    // Always keep a base64 copy in the session for serverless (upload + process
    // are separate invocations; /tmp is not shared). Cap ~4MB binary per file.
    const MAX_INLINE = 4 * 1024 * 1024;
    const inline =
      f.buffer.length <= MAX_INLINE ? f.buffer.toString("base64") : undefined;

    let storageKey: string | undefined;
    try {
      await writeStoredFile(key, f.buffer, f.mimeType);
      storageKey = key;
    } catch (e) {
      // On Vercel without R2, disk write fails — inline base64 is enough for process
      if (!inline) {
        fileMeta.push({
          name: f.name,
          size: f.size,
          mimeType: f.mimeType,
          status: "error",
          error:
            e instanceof Error
              ? `${e.message}. Configure R2 storage or upload smaller images (<4MB).`
              : "Storage failed",
        });
        continue;
      }
    }

    fileMeta.push({
      name: f.name,
      size: f.size,
      mimeType: f.mimeType,
      storageKey,
      contentBase64: inline,
      status: "uploaded",
    });
  }

  const session: MenuImportSession = {
    id,
    restaurantId,
    createdBy: userId,
    status: "uploaded",
    totalFiles: files.length,
    totalItems: 0,
    processedItems: 0,
    successfulItems: 0,
    failedItems: fileMeta.filter((f) => f.status === "error").length,
    duplicateItems: 0,
    needsReviewItems: 0,
    files: fileMeta,
    items: [],
    categoriesDetected: [],
    createdAt: now,
    updatedAt: now,
  };

  const db = tenantDb(restaurantId);
  await db.menuImportSessions.mutate((list) => [...list, session]);
  return session;
}

export async function processImportSession(restaurantId: string, sessionId: string): Promise<MenuImportSession> {
  const db = tenantDb(restaurantId);
  const session = await db.menuImportSessions.get(sessionId);
  if (!session) throw new Error("Import session not found");
  if (session.restaurantId !== restaurantId) throw new Error("Tenant isolation violation");

  const start = Date.now();
  session.status = "processing";
  session.updatedAt = new Date().toISOString();
  await db.menuImportSessions.mutate((list) => list.map((s) => (s.id === sessionId ? session : s)));

  const allItems: ExtractedMenuItem[] = [];
  const allCats = new Set<string>();
  const existingMenu = await db.menu.all();
  const existingByNorm = new Map(
    existingMenu.map((m) => [normalizeCategoryName(m.name) + "|" + m.categoryId, m])
  );

  for (const file of session.files) {
    if (file.status === "error") continue;
    if (!file.storageKey && !file.contentBase64) {
      file.status = "error";
      file.error = "No file data available for processing";
      continue;
    }
    file.status = "processing";

    let buffer: Buffer | null = null;
    if (file.contentBase64) {
      try {
        buffer = Buffer.from(file.contentBase64, "base64");
      } catch {
        buffer = null;
      }
    }
    if (!buffer && file.storageKey) {
      const { readStoredFile } = await import("@/lib/server/storage");
      buffer = await readStoredFile(file.storageKey);
    }
    if (!buffer || buffer.length === 0) {
      file.status = "error";
      file.error =
        "Could not read uploaded file. On Vercel, configure R2 object storage or keep images under 4MB.";
      continue;
    }

    const candidates = getExtractionProviders(file.mimeType, file.name);
    if (candidates.length === 0) {
      file.status = "error";
      file.error = "No extraction provider for this file type";
      continue;
    }

    let result: Awaited<ReturnType<(typeof candidates)[0]["extract"]>> | null = null;
    const errors: string[] = [];
    for (const provider of candidates) {
      const attempt = await provider.extract({
        buffer,
        fileName: file.name,
        mimeType: file.mimeType,
      });
      if (attempt.items.length > 0) {
        result = attempt;
        break;
      }
      if (attempt.error) errors.push(`${provider.name}: ${attempt.error}`);
      // Prefer a successful empty parse over hard fail only if no items from any provider
      if (!result) result = attempt;
    }

    if (!result || result.items.length === 0) {
      file.status = "error";
      file.error =
        errors.join(" | ") ||
        result?.error ||
        "No menu items detected. Use a clear full-page photo (JPG/PNG), good lighting, readable text.";
      continue;
    }

    for (const item of result.items) {
      // Duplicate detection against existing menu
      const norm = normalizeCategoryName(item.name);
      const possible = existingMenu.find(
        (m) =>
          normalizeCategoryName(m.name) === norm ||
          (m.name.toLowerCase().includes(item.name.toLowerCase()) && item.name.length > 4)
      );
      if (possible) {
        item.status = "duplicate";
        item.duplicateOfId = possible.id;
      } else if (item.confidence.overall < 0.6 || item.price <= 0) {
        item.status = "needs_review";
      }

      // Prefer the uploaded menu page image as the item photo when only one image was provided
      if (!item.imageUrl && file.mimeType.startsWith("image/") && file.storageKey) {
        item.imageStorageKey = file.storageKey;
      }

      allItems.push(item);
    }
    result.categories.forEach((c) => allCats.add(c));
    file.status = "done";
  }

  // Drop inline file bytes after extraction to keep session JSON small
  for (const file of session.files) {
    delete file.contentBase64;
  }

  session.items = allItems;
  session.categoriesDetected = [...allCats];
  session.totalItems = allItems.length;
  session.processedItems = allItems.length;
  session.duplicateItems = allItems.filter((i) => i.status === "duplicate").length;
  session.needsReviewItems = allItems.filter((i) => i.status === "needs_review").length;
  session.failedItems = session.files.filter((f) => f.status === "error").length;
  session.successfulItems = allItems.filter((i) => i.status === "extracted" || i.status === "approved").length;
  session.errorSummary = session.files
    .filter((f) => f.status === "error" && f.error)
    .map((f) => `${f.name}: ${f.error}`)
    .join(" | ")
    .slice(0, 1000);
  session.status =
    session.needsReviewItems > 0 || session.duplicateItems > 0 ? "review_required" : "ready";
  session.processingTimeMs = Date.now() - start;
  session.updatedAt = new Date().toISOString();

  await db.menuImportSessions.mutate((list) => list.map((s) => (s.id === sessionId ? { ...session } : s)));
  return session;
}

export async function updateImportItem(
  restaurantId: string,
  sessionId: string,
  itemId: string,
  patch: Partial<ExtractedMenuItem>
): Promise<MenuImportSession> {
  const db = tenantDb(restaurantId);
  const session = await db.menuImportSessions.get(sessionId);
  if (!session || session.restaurantId !== restaurantId) throw new Error("Session not found");

  session.items = session.items.map((it): ExtractedMenuItem => {
    if (it.id !== itemId) return it;
    const next: ExtractedMenuItem = { ...it, ...patch };
    // overrides only accepts boolean jainAvailable (not "needs_review")
    const overridePatch: NonNullable<ExtractedMenuItem["overrides"]> = { ...it.overrides };
    if (patch.name !== undefined) overridePatch.name = patch.name;
    if (patch.description !== undefined) overridePatch.description = patch.description;
    if (patch.price !== undefined) overridePatch.price = patch.price;
    if (patch.categoryName !== undefined) overridePatch.categoryName = patch.categoryName;
    if (patch.categoryId !== undefined) overridePatch.categoryId = patch.categoryId;
    if (patch.foodType !== undefined) overridePatch.foodType = patch.foodType;
    if (typeof patch.jainAvailable === "boolean") overridePatch.jainAvailable = patch.jainAvailable;
    next.overrides = overridePatch;
    if (next.price > 0 && next.name) {
      if (next.status === "error" || next.status === "needs_review") next.status = "approved";
    }
    return next;
  });
  session.needsReviewItems = session.items.filter((i) => i.status === "needs_review").length;
  session.updatedAt = new Date().toISOString();
  if (session.status === "review_required" && session.needsReviewItems === 0) {
    session.status = "ready";
  }

  await db.menuImportSessions.mutate((list) => list.map((s) => (s.id === sessionId ? session : s)));
  return session;
}

export async function bulkUpdateImportItems(
  restaurantId: string,
  sessionId: string,
  itemIds: string[],
  patch: Partial<{ categoryName: string; foodType: FoodType; jainAvailable: boolean; status: ExtractedMenuItem["status"] }>
): Promise<MenuImportSession> {
  const db = tenantDb(restaurantId);
  const session = await db.menuImportSessions.get(sessionId);
  if (!session || session.restaurantId !== restaurantId) throw new Error("Session not found");

  const idSet = new Set(itemIds);
  session.items = session.items.map((it): ExtractedMenuItem => {
    if (!idSet.has(it.id)) return it;
    const overridePatch: NonNullable<ExtractedMenuItem["overrides"]> = { ...it.overrides };
    if (patch.categoryName !== undefined) overridePatch.categoryName = patch.categoryName;
    if (patch.foodType !== undefined) overridePatch.foodType = patch.foodType;
    if (typeof patch.jainAvailable === "boolean") overridePatch.jainAvailable = patch.jainAvailable;
    return {
      ...it,
      ...patch,
      overrides: overridePatch,
      status: patch.status || (it.status === "needs_review" ? "approved" : it.status),
    };
  });
  session.needsReviewItems = session.items.filter((i) => i.status === "needs_review").length;
  session.updatedAt = new Date().toISOString();
  await db.menuImportSessions.mutate((list) => list.map((s) => (s.id === sessionId ? session : s)));
  return session;
}

/**
 * Final commit — only approved / extracted items enter the live menu.
 * Categories are reused by normalized name match.
 */
export async function commitImport(
  restaurantId: string,
  sessionId: string,
  options?: { skipDuplicates?: boolean; approveAllReady?: boolean }
): Promise<{
  session: MenuImportSession;
  createdCategories: number;
  createdItems: number;
  skipped: number;
  failed: number;
}> {
  const db = tenantDb(restaurantId);
  const session = await db.menuImportSessions.get(sessionId);
  if (!session || session.restaurantId !== restaurantId) throw new Error("Session not found");

  session.status = "importing";
  session.updatedAt = new Date().toISOString();
  await db.menuImportSessions.mutate((list) => list.map((s) => (s.id === sessionId ? session : s)));

  const existingCats = await db.categories.all();
  const catByNorm = new Map(existingCats.map((c) => [normalizeCategoryName(c.name), c]));
  let createdCategories = 0;
  let createdItems = 0;
  let skipped = 0;
  let failed = 0;

  // Ensure categories exist
  for (const catName of session.categoriesDetected) {
    const norm = normalizeCategoryName(catName);
    if (!catByNorm.has(norm)) {
      const newCat: MenuCategory = {
        id: `cat-${randomUUID()}`,
        restaurantId,
        name: catName.trim() || "Uncategorized",
        icon: "🍽️",
      };
      existingCats.push(newCat);
      catByNorm.set(norm, newCat);
      createdCategories++;
    }
  }
  // Also from items that may have custom category after edit
  for (const it of session.items) {
    const cn = it.overrides?.categoryName || it.categoryName || "Uncategorized";
    const norm = normalizeCategoryName(cn);
    if (!catByNorm.has(norm)) {
      const newCat: MenuCategory = {
        id: `cat-${randomUUID()}`,
        restaurantId,
        name: cn.trim(),
        icon: "🍽️",
      };
      existingCats.push(newCat);
      catByNorm.set(norm, newCat);
      createdCategories++;
    }
  }
  if (createdCategories > 0) {
    await db.categories.save(existingCats);
  }

  const toImport = session.items.filter((it) => {
    if (it.status === "skipped") {
      skipped++;
      return false;
    }
    if (it.status === "duplicate" && options?.skipDuplicates !== false) {
      skipped++;
      return false;
    }
    if (it.status === "error") {
      failed++;
      return false;
    }
    if (options?.approveAllReady && (it.status === "extracted" || it.status === "approved" || it.status === "needs_review")) {
      return true;
    }
    return it.status === "approved" || it.status === "extracted";
  });

  const existingMenu = await db.menu.all();
  const newItems: MenuItem[] = [];

  for (const it of toImport) {
    try {
      const name = (it.overrides?.name || it.name || "").trim();
      const price = it.overrides?.price ?? it.price;
      if (!name || price <= 0) {
        failed++;
        it.status = "error";
        it.errorMessage = "Missing name or price";
        continue;
      }
      const catName = it.overrides?.categoryName || it.categoryName || "Uncategorized";
      const cat = catByNorm.get(normalizeCategoryName(catName));
      const categoryId = it.overrides?.categoryId || it.categoryId || cat?.id || existingCats[0]?.id || "uncategorized";

      const foodType: FoodType = (it.overrides?.foodType || it.foodType || "veg") as FoodType;
      const jain =
        typeof it.overrides?.jainAvailable === "boolean"
          ? it.overrides.jainAvailable
          : it.jainAvailable === true;

      const variants: Variant[] | undefined = it.variants?.map((v) => ({
        id: `v-${randomUUID()}`,
        label: v.label,
        priceDelta: v.price - price,
      }));

      const addOns: MenuAddOn[] | undefined = it.addOns?.map((a) => ({
        id: `ao-${randomUUID()}`,
        label: a.label,
        priceDelta: a.price,
        available: true,
      }));

      let image = "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&q=80";
      if (it.imageUrl) image = it.imageUrl;
      else if (it.imageStorageKey) {
        // storage key already public via writeStoredFile return; reconstruct if needed
        image = `/${it.imageStorageKey}`;
      }

      const item: MenuItem = {
        id: `item-${randomUUID()}`,
        restaurantId,
        name,
        description: it.overrides?.description ?? it.description ?? "",
        categoryId,
        price,
        image,
        prepTimeMinutes: it.prepTimeMinutes ?? 15,
        available: it.overrides?.available ?? true,
        spiceLevel: "medium",
        isVeg: foodType === "veg" || foodType === "vegan",
        foodType,
        jainAvailable: jain,
        variants,
        addOns,
        tags: it.tags,
        ingredients: it.ingredients,
        importSessionId: sessionId,
      };
      newItems.push(item);
      it.status = "imported";
      createdItems++;
    } catch {
      failed++;
      it.status = "error";
    }
  }

  if (newItems.length > 0) {
    await db.menu.mutate((list) => [...list, ...newItems]);
  }

  session.successfulItems = createdItems;
  session.failedItems = failed;
  session.duplicateItems = session.items.filter((i) => i.status === "duplicate").length;
  session.status = failed > 0 && createdItems > 0 ? "partially_completed" : createdItems > 0 ? "completed" : "failed";
  (session as MenuImportSession & { createdItemIds?: string[] }).createdItemIds = newItems.map((i) => i.id);
  session.completedAt = new Date().toISOString();
  session.updatedAt = session.completedAt;
  await db.menuImportSessions.mutate((list) => list.map((s) => (s.id === sessionId ? session : s)));

  return { session, createdCategories, createdItems, skipped, failed };
}


export async function deleteImportItems(
  restaurantId: string,
  sessionId: string,
  itemIds: string[]
): Promise<MenuImportSession> {
  const db = tenantDb(restaurantId);
  const session = await db.menuImportSessions.get(sessionId);
  if (!session || session.restaurantId !== restaurantId) throw new Error("Session not found");

  const idSet = new Set(itemIds);
  session.items = session.items.filter((it) => !idSet.has(it.id));
  session.totalItems = session.items.length;
  session.processedItems = session.items.length;
  session.duplicateItems = session.items.filter((i) => i.status === "duplicate").length;
  session.needsReviewItems = session.items.filter((i) => i.status === "needs_review").length;
  session.successfulItems = session.items.filter(
    (i) => i.status === "extracted" || i.status === "approved"
  ).length;
  session.updatedAt = new Date().toISOString();
  if (session.needsReviewItems === 0 && session.status === "review_required") {
    session.status = session.totalItems > 0 ? "ready" : "uploaded";
  }

  await db.menuImportSessions.mutate((list) => list.map((s) => (s.id === sessionId ? session : s)));
  return session;
}


/**
 * Delete an import session. If it was completed, also remove menu items
 * created by that import (matched via importSessionId or createdItemIds).
 */
export async function deleteImportSessionWithCascade(
  restaurantId: string,
  sessionId: string,
  opts?: { deleteMenuItems?: boolean }
): Promise<{ deletedSession: boolean; deletedMenuItems: number }> {
  const db = tenantDb(restaurantId);
  const session = await db.menuImportSessions.get(sessionId);
  if (!session || session.restaurantId !== restaurantId) {
    throw new Error("Import session not found");
  }
  if (session.status === "importing" || session.status === "processing") {
    throw new Error("Cannot delete an import that is still in progress");
  }

  let deletedMenuItems = 0;
  const shouldCascade = opts?.deleteMenuItems !== false && (session.status === "completed" || session.status === "partially_completed");

  if (shouldCascade) {
    const createdIds = new Set(
      ((session as MenuImportSession & { createdItemIds?: string[] }).createdItemIds || []).filter(Boolean)
    );
    const all = await db.menu.all();
    const remaining = all.filter((m) => {
      const fromSession =
        (m as MenuItem).importSessionId === sessionId || createdIds.has(m.id);
      if (fromSession) {
        deletedMenuItems++;
        return false;
      }
      return true;
    });
    if (deletedMenuItems > 0) {
      await db.menu.save(remaining);
    }
  }

  await db.menuImportSessions.mutate((list) => list.filter((s) => s.id !== sessionId));
  return { deletedSession: true, deletedMenuItems };
}
