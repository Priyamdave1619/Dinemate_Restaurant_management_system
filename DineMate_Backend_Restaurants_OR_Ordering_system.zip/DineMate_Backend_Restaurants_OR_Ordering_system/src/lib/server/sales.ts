import { randomUUID } from "crypto";
import { eq, and } from "drizzle-orm";
import { tenantDb } from "./db";
import { drizzleDb, rawSql } from "./pg-store";
import * as schema from "./schema";
import { deriveTimeKeys } from "./time-keys";
import { MenuItem, Order, SoldItemRecord } from "@/lib/types";

export async function archiveBilledOrder(
  restaurantId: string,
  order: Order,
  menu: MenuItem[],
  billedAtIso: string
): Promise<{ order: Order; soldItems: SoldItemRecord[]; cogsTotal: number }> {
  const menuById = new Map(menu.map((m) => [m.id, m]));
  const keys = deriveTimeKeys(billedAtIso);

  let cogsTotal = 0;
  const soldItems: SoldItemRecord[] = order.items.map((it) => {
    const menuItem = menuById.get(it.itemId);
    const foodType = it.foodType ?? menuItem?.foodType ?? "other";
    const categoryId = it.categoryId ?? menuItem?.categoryId ?? "uncategorized";
    const unitCost = it.costPrice ?? menuItem?.costPrice ?? 0;
    const lineRevenue = it.price * it.quantity;
    const lineCost = unitCost * it.quantity;
    cogsTotal += lineCost;
    return {
      id: `si-${randomUUID()}`,
      restaurantId,
      orderId: order.id,
      billNumber: order.billNumber ?? order.id,
      tableNumber: order.tableNumber,
      waiterName: order.waiterName,
      itemId: it.itemId,
      itemName: it.name,
      categoryId,
      foodType,
      quantity: it.quantity,
      unitPrice: it.price,
      lineRevenue,
      unitCost,
      lineCost,
      lineProfit: lineRevenue - lineCost,
      soldAt: billedAtIso,
      dateKey: keys.dateKey,
      weekKey: keys.weekKey,
      monthKey: keys.monthKey,
      yearKey: keys.yearKey,
      hour: keys.hour,
      weekday: keys.weekday,
    };
  });

  const archivedOrder: Order = { ...order, restaurantId, cogsTotal, billedAt: billedAtIso };

  await Promise.all([
    soldItems.length > 0
      ? drizzleDb.insert(schema.soldItems).values(
          soldItems.map((s) => ({
            id: s.id,
            restaurantId,
            orderId: s.orderId,
            itemId: s.itemId,
            dateKey: s.dateKey,
            monthKey: s.monthKey,
            data: s,
          }))
        )
      : Promise.resolve(),
    drizzleDb
      .insert(schema.billedOrders)
      .values({
        id: order.id,
        restaurantId,
        placedAt: order.placedAt ? new Date(order.placedAt) : null,
        data: archivedOrder,
      })
      .onConflictDoUpdate({
        target: [schema.billedOrders.restaurantId, schema.billedOrders.id],
        set: { data: archivedOrder, placedAt: order.placedAt ? new Date(order.placedAt) : null },
      }),
    drizzleDb
      .delete(schema.orders)
      .where(and(eq(schema.orders.id, order.id), eq(schema.orders.restaurantId, restaurantId))),
    bumpPeriodStats(restaurantId, keys.dateKey, keys.weekKey, keys.monthKey, keys.yearKey, {
      grossSales: order.subtotal,
      discountTotal: order.discountTotal,
      taxTotal: order.taxAmount,
      cogsTotal,
      orderCount: 1,
      itemsSold: order.items.reduce((s, i) => s + i.quantity, 0),
    }),
  ]);

  return { order: archivedOrder, soldItems, cogsTotal };
}

interface Delta {
  grossSales: number;
  discountTotal: number;
  taxTotal: number;
  cogsTotal: number;
  orderCount: number;
  itemsSold: number;
}

async function bumpPeriodStats(
  restaurantId: string,
  dateKey: string,
  weekKey: string,
  monthKey: string,
  yearKey: string,
  delta: Delta
) {
  const now = new Date().toISOString();
  const netSales = delta.grossSales - delta.discountTotal;
  const grossProfit = netSales - delta.cogsTotal;
  const totalCollected = netSales + delta.taxTotal;

  const base = {
    grossSales: delta.grossSales,
    discountTotal: delta.discountTotal,
    netSales,
    taxTotal: delta.taxTotal,
    totalCollected,
    cogsTotal: delta.cogsTotal,
    grossProfit,
    orderCount: delta.orderCount,
    itemsSold: delta.itemsSold,
    updatedAt: now,
    weekKey,
    monthKey,
    yearKey,
    restaurantId,
  };

  await rawSql`
    INSERT INTO daily_stats (restaurant_id, date_key, data)
    VALUES (${restaurantId}, ${dateKey}, ${JSON.stringify({ ...base, dateKey })}::jsonb)
    ON CONFLICT (restaurant_id, date_key) DO UPDATE SET
      data = (
        SELECT jsonb_object_agg(key, CASE
          WHEN key IN ('grossSales','discountTotal','netSales','taxTotal','totalCollected','cogsTotal','grossProfit','orderCount','itemsSold')
          THEN to_jsonb(COALESCE((daily_stats.data->>key)::numeric, 0) + COALESCE((EXCLUDED.data->>key)::numeric, 0))
          ELSE EXCLUDED.data->key
        END)
        FROM jsonb_each(daily_stats.data || EXCLUDED.data)
      )
  `;

  await rawSql`
    INSERT INTO monthly_stats (restaurant_id, month_key, data)
    VALUES (${restaurantId}, ${monthKey}, ${JSON.stringify({ ...base, monthKey })}::jsonb)
    ON CONFLICT (restaurant_id, month_key) DO UPDATE SET
      data = (
        SELECT jsonb_object_agg(key, CASE
          WHEN key IN ('grossSales','discountTotal','netSales','taxTotal','totalCollected','cogsTotal','grossProfit','orderCount','itemsSold')
          THEN to_jsonb(COALESCE((monthly_stats.data->>key)::numeric, 0) + COALESCE((EXCLUDED.data->>key)::numeric, 0))
          ELSE EXCLUDED.data->key
        END)
        FROM jsonb_each(monthly_stats.data || EXCLUDED.data)
      )
  `;
}

export async function archiveOrderById(restaurantId: string, orderId: string): Promise<Order | null> {
  const tdb = tenantDb(restaurantId);
  const [orders, menu] = await Promise.all([tdb.orders.all(), tdb.menu.all()]);
  const order = orders.find((o) => o.id === orderId);
  if (!order) return null;
  const { order: archived } = await archiveBilledOrder(restaurantId, order, menu, new Date().toISOString());
  return archived;
}
