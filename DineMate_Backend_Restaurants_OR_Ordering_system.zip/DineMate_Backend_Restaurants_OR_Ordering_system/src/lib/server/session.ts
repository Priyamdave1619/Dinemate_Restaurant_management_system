import { cookies, headers } from "next/headers";
import { SESSION_COOKIE, SessionPayload, verifySessionToken } from "./auth";
import { platformDb } from "./db";

/**
 * Every API accepts `Authorization: Bearer <access-token>` — this is the
 * primary, spec-required mechanism, and it's what non-browser clients
 * (mobile apps, server-to-server integrations, Postman/testing) should
 * always use, since the access token is only otherwise visible as an
 * httpOnly cookie a script can't read.
 *
 * The httpOnly cookie set by /api/auth/login is also still accepted as a
 * fallback purely for browser convenience (so a same-origin web app
 * doesn't have to manually attach the header on every fetch) — but Bearer
 * takes priority whenever both are present, and it's the one every client
 * should actually rely on.
 */
export async function getSession(): Promise<SessionPayload | null> {
  const hdrs = await headers();
  const authHeader = hdrs.get("authorization");
  if (authHeader?.startsWith("Bearer ")) {
    const token = authHeader.slice("Bearer ".length).trim();
    if (token) return verifySessionToken(token);
  }

  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return verifySessionToken(token);
}

/**
 * Role gate only — does NOT check restaurant/subscription status. Use this
 * for platform-level (super_admin) routes, or when a route needs the
 * session but does its own tenant lookups (e.g. the public order-by-id
 * routes, which derive restaurantId from the order id itself).
 */
export async function requireRole(
  roles: Array<SessionPayload["role"]>
): Promise<{ ok: true; session: SessionPayload } | { ok: false; status: number; message: string }> {
  const session = await getSession();
  if (!session) return { ok: false, status: 401, message: "Not authenticated" };
  if (!roles.includes(session.role)) return { ok: false, status: 403, message: "Not authorized" };
  return { ok: true, session };
}

/**
 * The gate every restaurant-scoped route (menu, orders, tables, staff,
 * reports, ...) should use. On top of the role check, this:
 *   - rejects super_admin (they have no restaurantId — use requireRole
 *     with an /api/admin/* route instead for platform actions)
 *   - re-checks the restaurant's live status/subscription on every request
 *     (not just at login) so a suspension or expiry takes effect
 *     immediately instead of waiting for the JWT to expire
 */
export async function requireTenant(
  roles: Array<SessionPayload["role"]>
): Promise<
  | { ok: true; session: SessionPayload & { restaurantId: string } }
  | { ok: false; status: number; message: string }
> {
  const session = await getSession();
  if (!session) return { ok: false, status: 401, message: "Not authenticated" };
  if (!roles.includes(session.role)) return { ok: false, status: 403, message: "Not authorized" };
  if (!session.restaurantId) return { ok: false, status: 403, message: "This account has no restaurant" };

  const restaurant = await platformDb.restaurants.get(session.restaurantId);
  if (!restaurant) return { ok: false, status: 401, message: "Restaurant no longer exists" };
  if (restaurant.status === "suspended") {
    return { ok: false, status: 403, message: "This restaurant's account has been suspended" };
  }
  if (restaurant.status === "pending") {
    return { ok: false, status: 403, message: "This restaurant's account is pending approval" };
  }
  if (new Date(restaurant.subscriptionExpiresAt).getTime() < Date.now()) {
    return { ok: false, status: 402, message: "Subscription expired — please renew to continue" };
  }

  return { ok: true, session: session as SessionPayload & { restaurantId: string } };
}
