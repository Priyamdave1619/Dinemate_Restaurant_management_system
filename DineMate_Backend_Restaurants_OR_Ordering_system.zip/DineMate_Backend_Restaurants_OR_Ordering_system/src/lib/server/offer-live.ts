import { Offer } from "@/lib/types";
import { isWithinWindow } from "@/lib/server/menu-availability";

/** Whether an offer is currently live (active + schedule + usage). */
export function isOfferLive(offer: Offer, now: Date = new Date()): boolean {
  if (!offer.active) return false;
  if (offer.usageLimit != null && (offer.usageCount ?? 0) >= offer.usageLimit) return false;

  if (offer.startsAt) {
    const start = new Date(offer.startsAt);
    if (!Number.isNaN(start.getTime()) && now < start) return false;
  }
  if (offer.endsAt) {
    const end = new Date(offer.endsAt);
    if (!Number.isNaN(end.getTime()) && now > end) return false;
  }

  if (offer.daysOfWeek && offer.daysOfWeek.length > 0) {
    if (!offer.daysOfWeek.includes(now.getDay())) return false;
  }

  if (offer.timeFrom && offer.timeTo) {
    if (!isWithinWindow(offer.timeFrom, offer.timeTo, now)) return false;
  }

  return true;
}

export function offerStatus(offer: Offer, now: Date = new Date()): "active" | "scheduled" | "expired" | "inactive" | "exhausted" {
  if (!offer.active) return "inactive";
  if (offer.usageLimit != null && (offer.usageCount ?? 0) >= offer.usageLimit) return "exhausted";
  if (offer.startsAt) {
    const start = new Date(offer.startsAt);
    if (!Number.isNaN(start.getTime()) && now < start) return "scheduled";
  }
  if (offer.endsAt) {
    const end = new Date(offer.endsAt);
    if (!Number.isNaN(end.getTime()) && now > end) return "expired";
  }
  if (isOfferLive(offer, now)) return "active";
  return "inactive";
}
