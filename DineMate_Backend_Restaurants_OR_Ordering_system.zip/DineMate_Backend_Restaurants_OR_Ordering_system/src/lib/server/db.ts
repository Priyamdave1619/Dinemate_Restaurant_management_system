import { randomUUID } from "crypto";
import {
  mutateCollection,
  nextCounter,
  readCollection,
  readSingleton,
  seedCollectionOnce,
  writeCollection,
  writeSingleton,
  drizzleDb,
  rawSql,
} from "./pg-store";
import {
  AppUser,
  AppNotification,
  Expense,
  MenuCategory,
  MenuItem,
  Offer,
  Order,
  Restaurant,
  RestaurantSettings,
  RestaurantTable,
  SoldItemRecord,
  SubscriptionPlan,
} from "@/lib/types";
import { hashPassword } from "./auth";
import { eq, desc } from "drizzle-orm";
import * as schema from "./schema";

// ---------------------------------------------------------------------------
// Starter/demo content, inserted EXACTLY ONCE per tenant by
// seedNewTenantContent() below, called only from restaurants.ts at
// registration. `readCollection`/`mutateCollection` never auto-seed on
// their own anymore — see the comment on seedCollectionOnce in
// mongo-store.ts for why that used to be a real bug.
// ---------------------------------------------------------------------------

const SEED_CATEGORIES: Omit<MenuCategory, "restaurantId">[] = [
  { id: "sev-usal", name: "Sev Usal", icon: "🌶️" },
  { id: "chaat", name: "Chaat", icon: "🥟" },
  { id: "farsan", name: "Farsan", icon: "🍘" },
  { id: "beverages", name: "Beverages", icon: "🥤" },
  { id: "sweets", name: "Sweets", icon: "🍮" },
];

const SEED_MENU_ITEMS: Omit<MenuItem, "restaurantId">[] = [
  { id: "item-classic-sev-usal", name: "Classic Sev Usal", description: "Sprouted matki curry simmered in a spiced kat, topped with crushed farsan sev, onion, and lime.", categoryId: "sev-usal", price: 90, costPrice: 32, image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=600&q=80", prepTimeMinutes: 8, available: true, spiceLevel: "hot", isVeg: true, foodType: "veg", variants: [{ id: "v-half", label: "Half", priceDelta: -20 }, { id: "v-full", label: "Full", priceDelta: 0 }, { id: "v-extra-sev", label: "Extra Sev", priceDelta: 15 }] },
  { id: "item-butter-sev-usal", name: "Butter Sev Usal", description: "The classic finished with a knob of table butter and extra farsan for a richer bite.", categoryId: "sev-usal", price: 110, costPrice: 40, image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=600&q=80", prepTimeMinutes: 8, available: true, spiceLevel: "medium", isVeg: true, foodType: "veg", variants: [{ id: "v-full", label: "Full", priceDelta: 0 }, { id: "v-extra-butter", label: "Extra Butter", priceDelta: 20 }] },
  { id: "item-misal-pav", name: "Misal Pav", description: "Fiery sprout curry with pav, sev, onion, and a side of curd to cool it down.", categoryId: "sev-usal", price: 100, costPrice: 35, image: "https://images.unsplash.com/photo-1626132647523-66f5bf380027?w=600&q=80", prepTimeMinutes: 10, available: true, spiceLevel: "hot", isVeg: true, foodType: "veg" },
  { id: "item-sev-puri", name: "Sev Puri", description: "Crisp puris loaded with potato, chutneys, onion, and a heavy hand of sev.", categoryId: "chaat", price: 70, costPrice: 24, image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&q=80", prepTimeMinutes: 6, available: true, spiceLevel: "medium", isVeg: true, foodType: "veg" },
  { id: "item-khaman-dhokla", name: "Khaman Dhokla", description: "Steamed and tempered gram flour cakes, soft and lightly sweet-sour.", categoryId: "farsan", price: 60, costPrice: 20, image: "https://images.unsplash.com/photo-1666190092208-2a6d1b90f6ba?w=600&q=80", prepTimeMinutes: 5, available: true, spiceLevel: "mild", isVeg: true, foodType: "veg" },
  { id: "item-masala-chaas", name: "Masala Chaas", description: "Spiced buttermilk with roasted cumin, curry leaf, and fresh coriander.", categoryId: "beverages", price: 45, costPrice: 14, image: "https://images.unsplash.com/photo-1626132647958-1b1a5f5a6b1c?w=600&q=80", prepTimeMinutes: 3, available: true, spiceLevel: "mild", isVeg: true, foodType: "veg" },
  { id: "item-shrikhand", name: "Kesar Shrikhand", description: "Hung curd sweetened with saffron and cardamom, chilled.", categoryId: "sweets", price: 65, costPrice: 22, image: "https://images.unsplash.com/photo-1567337710282-00832b415979?w=600&q=80", prepTimeMinutes: 3, available: true, spiceLevel: "mild", isVeg: true, foodType: "veg" },
];

const SEED_TABLES: Omit<RestaurantTable, "restaurantId">[] = Array.from({ length: 8 }, (_, i) => ({
  id: `t${i + 1}`,
  number: i + 1,
  capacity: [2, 4, 4, 2, 6, 4, 2, 4][i] ?? 4,
  status: "available" as const,
}));

const SEED_OFFERS: Omit<Offer, "restaurantId">[] = [
  {
    id: "offer-weekday-discount",
    name: "10% off orders above ₹500",
    type: "percent",
    active: true,
    discountPercent: 10,
    minOrderAmount: 500,
    createdAt: new Date().toISOString(),
  },
];

function defaultSettings(restaurantId: string, restaurantName: string): RestaurantSettings {
  return {
    restaurantId,
    taxRatePercent: 5,
    restaurantName,
    currency: "INR",
    baseUrl: process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3003",
  };
}

// ---------------------------------------------------------------------------
// Subscription plans (platform-wide, seeded once).
// ---------------------------------------------------------------------------

export const DEFAULT_PLANS: SubscriptionPlan[] = [
  { id: "free", name: "Free", durationDays: 14, price: 0, currency: "INR", productLimit: 20, orderLimit: 200, userLimit: 3, storageLimitMb: 100, features: ["Core POS", "Basic reports"], active: true, createdAt: new Date(0).toISOString() },
  { id: "starter", name: "Starter", durationDays: 30, price: 999, currency: "INR", productLimit: 100, orderLimit: 2000, userLimit: 10, storageLimitMb: 1024, features: ["Core POS", "Full reports", "KOT printing", "QR ordering"], active: true, createdAt: new Date(0).toISOString() },
  { id: "professional", name: "Professional", durationDays: 30, price: 2499, currency: "INR", productLimit: 500, orderLimit: 20000, userLimit: 30, storageLimitMb: 5120, features: ["Everything in Starter", "Advanced analytics", "Coupons & offers", "Priority support"], active: true, createdAt: new Date(0).toISOString() },
  { id: "enterprise", name: "Enterprise", durationDays: 30, price: 7999, currency: "INR", productLimit: -1, orderLimit: -1, userLimit: -1, storageLimitMb: 51200, features: ["Everything in Professional", "Unlimited usage", "Dedicated support", "Custom integrations"], active: true, createdAt: new Date(0).toISOString() },
];

// ---------------------------------------------------------------------------
// platformDb — unscoped, cross-tenant access. Only ever called from
// super_admin routes (/api/admin/**) and internal bootstrapping
// (restaurants.ts). Never expose these to a tenant-scoped route.
// ---------------------------------------------------------------------------

export const platformDb = {
  restaurants: {
    all: () => readCollection<Restaurant>("restaurants"),
    get: async (id: string) => (await readCollection<Restaurant>("restaurants")).find((r) => r.id === id) ?? null,
    mutate: (fn: (v: Restaurant[]) => Restaurant[]) => mutateCollection<Restaurant>("restaurants", fn),
  },
  plans: {
    all: async () => {
      const plans = await readCollection<SubscriptionPlan>("subscriptionPlans");
      if (plans.length === 0) {
        // Bootstraps the 4 default plans exactly once, the first time
        // anything asks for the plan list on a fresh deployment — NOT on
        // every empty read (see seedCollectionOnce's comment). If a
        // super_admin later deletes every plan on purpose, this will
        // technically re-seed once more since there's no other signal to
        // distinguish "brand new deployment" from "deliberately emptied" at
        // the platform level the way restaurant registration gives us for
        // tenant content — an acceptable tradeoff here since a platform
        // with zero subscription plans isn't a valid intentional state the
        // way an empty tenant menu is.
        await seedCollectionOnce("subscriptionPlans", DEFAULT_PLANS);
        return readCollection<SubscriptionPlan>("subscriptionPlans");
      }
      return plans;
    },
    get: async (id: string) => (await platformDb.plans.all()).find((p) => p.id === id) ?? null,
    mutate: (fn: (v: SubscriptionPlan[]) => SubscriptionPlan[]) => mutateCollection<SubscriptionPlan>("subscriptionPlans", fn),
  },
  // Super-admin accounts live in the same `users` collection as everyone
  // else, isolated by `restaurantId: null` as their scope — this keeps
  // them completely outside any tenant's read/write/rewrite operations.
  superAdmins: {
    all: () => readCollection<AppUser>("users", { restaurantId: null }),
    mutate: (fn: (v: AppUser[]) => AppUser[]) => mutateCollection<AppUser>("users", fn, { restaurantId: null }),
  },
  /** Cross-tenant user lookup used only by login (usernames are globally
   * unique by policy — see restaurants.ts / users route validation). */
  users: {
    findByUsername: async (username: string): Promise<AppUser | null> => {
      const rows = await drizzleDb
        .select()
        .from(schema.users)
        .where(eq(schema.users.username, username.toLowerCase()))
        .limit(1);
      if (!rows[0]) return null;
      return { ...(rows[0].data as AppUser), id: rows[0].id, restaurantId: rows[0].restaurantId };
    },
    /** Super-admin dashboard only: every user across every tenant. */
    all: () => readCollection<AppUser>("users"),
  },
  counters: {
    next: (key: string) => nextCounter(key),
  },
  auditLogs: {
    log: async (entry: Omit<import("@/lib/types").AuditLogEntry, "id" | "createdAt">) => {
      const doc: import("@/lib/types").AuditLogEntry = {
        ...entry,
        id: `audit-${randomUUID()}`,
        createdAt: new Date().toISOString(),
      };
      await drizzleDb.insert(schema.auditLogs).values({
        id: doc.id,
        restaurantId: entry.restaurantId ?? null,
        data: doc,
        action: doc.action,
        createdAt: new Date(doc.createdAt),
      });
      return doc;
    },
    list: async (filter: { restaurantId?: string; actorUserId?: string }, limit = 200) => {
      if (filter.restaurantId) {
        const rows = await drizzleDb
          .select()
          .from(schema.auditLogs)
          .where(eq(schema.auditLogs.restaurantId, filter.restaurantId))
          .orderBy(desc(schema.auditLogs.createdAt))
          .limit(limit);
        return rows.map((r) => r.data as import("@/lib/types").AuditLogEntry);
      }
      const rows = await drizzleDb
        .select()
        .from(schema.auditLogs)
        .orderBy(desc(schema.auditLogs.createdAt))
        .limit(limit);
      return rows.map((r) => r.data as import("@/lib/types").AuditLogEntry);
    },
  },
  loginHistory: {
    log: async (entry: {
      restaurantId: string | null;
      userId: string;
      username: string;
      role: string;
      success: boolean;
      ip?: string;
      userAgent?: string;
    }) => {
      const id = `login-${randomUUID()}`;
      const createdAt = new Date().toISOString();
      const doc = { id, ...entry, createdAt };
      await drizzleDb.insert(schema.loginHistory).values({
        id,
        restaurantId: entry.restaurantId,
        userId: entry.userId,
        data: doc,
        success: entry.success,
        createdAt: new Date(createdAt),
      });
    },
    list: async (filter: { restaurantId?: string; userId?: string }, limit = 200) => {
      if (filter.restaurantId) {
        const rows = await drizzleDb
          .select()
          .from(schema.loginHistory)
          .where(eq(schema.loginHistory.restaurantId, filter.restaurantId))
          .orderBy(desc(schema.loginHistory.createdAt))
          .limit(limit);
        return rows.map((r) => r.data);
      }
      if (filter.userId) {
        const rows = await drizzleDb
          .select()
          .from(schema.loginHistory)
          .where(eq(schema.loginHistory.userId, filter.userId))
          .orderBy(desc(schema.loginHistory.createdAt))
          .limit(limit);
        return rows.map((r) => r.data);
      }
      const rows = await drizzleDb
        .select()
        .from(schema.loginHistory)
        .orderBy(desc(schema.loginHistory.createdAt))
        .limit(limit);
      return rows.map((r) => r.data);
    },
  },
};

// ---------------------------------------------------------------------------
// tenantDb(restaurantId) — every business-data collection, transparently
// scoped to one restaurant. This is what every /api/(categories|menu|
// tables|offers|orders|users|settings|expenses)/** route should use.
// ---------------------------------------------------------------------------

export function tenantDb(restaurantId: string) {
  const scope = { restaurantId };

  return {
    categories: {
      all: () => readCollection<MenuCategory>("categories", scope),
      save: (v: MenuCategory[]) => writeCollection("categories", v, scope),
      mutate: (fn: (v: MenuCategory[]) => MenuCategory[]) => mutateCollection("categories", fn, scope),
    },
    menu: {
      all: () => readCollection<MenuItem>("menuItems", scope),
      save: (v: MenuItem[]) => writeCollection("menuItems", v, scope),
      mutate: (fn: (v: MenuItem[]) => MenuItem[]) => mutateCollection("menuItems", fn, scope),
    },
    menuImportSessions: {
      all: () => readCollection<import("@/lib/types").MenuImportSession>("menuImportSessions", scope),
      save: (v: import("@/lib/types").MenuImportSession[]) => writeCollection("menuImportSessions", v, scope),
      mutate: (fn: (v: import("@/lib/types").MenuImportSession[]) => import("@/lib/types").MenuImportSession[]) =>
        mutateCollection("menuImportSessions", fn, scope),
      get: async (id: string) => {
        const all = await readCollection<import("@/lib/types").MenuImportSession>("menuImportSessions", scope);
        return all.find((s) => s.id === id) ?? null;
      },
    },
    tables: {
      all: () => readCollection<RestaurantTable>("tables", scope),
      save: (v: RestaurantTable[]) => writeCollection("tables", v, scope),
      mutate: (fn: (v: RestaurantTable[]) => RestaurantTable[]) => mutateCollection("tables", fn, scope),
    },
    // The live/active billing queue. Once a bill is generated the order is
    // archived (see archiveBilledOrder in sales.ts) and removed from here —
    // it is never deleted from the database, only moved out of the active
    // queue.
    orders: {
      all: () => readCollection<Order>("orders", scope),
      save: (v: Order[]) => writeCollection("orders", v, scope),
      mutate: (fn: (v: Order[]) => Order[]) => mutateCollection("orders", fn, scope),
    },
    // Permanent, immutable archive of every billed order — the audit trail.
    billedOrders: {
      all: () => readCollection<Order>("billedOrders", scope),
    },
    // One document per sold line-item, written at bill time. This is the
    // fact table that all analytics/reporting aggregations run against.
    soldItems: {
      all: () => readCollection<SoldItemRecord>("soldItems", scope),
    },
    offers: {
      all: () => readCollection<Offer>("offers", scope),
      save: (v: Offer[]) => writeCollection("offers", v, scope),
      mutate: (fn: (v: Offer[]) => Offer[]) => mutateCollection("offers", fn, scope),
    },
    // Staff of this restaurant only (owner/manager/waiter). Super_admins
    // never appear here — see platformDb.superAdmins.
    users: {
      all: () => readCollection<AppUser>("users", scope),
      save: (v: AppUser[]) => writeCollection("users", v, scope),
      mutate: (fn: (v: AppUser[]) => AppUser[]) => mutateCollection("users", fn, scope),
    },
    settings: {
      get: () => readSingleton<RestaurantSettings>(`settings:${restaurantId}`, defaultSettings(restaurantId, restaurantId)),
      save: (v: RestaurantSettings) => writeSingleton(`settings:${restaurantId}`, v),
    },
    expenses: {
      all: () => readCollection<Expense>("expenses", scope),
      mutate: (fn: (v: Expense[]) => Expense[]) => mutateCollection("expenses", fn, scope),
    },
    notifications: {
      all: () => readCollection<AppNotification>("notifications", scope),
      mutate: (fn: (v: AppNotification[]) => AppNotification[]) => mutateCollection<AppNotification>("notifications", fn, scope),
    },
    counters: {
      // Prefixed so every tenant has its own independent order/bill number
      // sequence starting at 1, instead of sharing one platform-wide counter.
      next: (key: string) => nextCounter(`${restaurantId}:${key}`),
    },
  };
}

export type TenantDb = ReturnType<typeof tenantDb>;

/**
 * Inserts the starter/demo menu (categories, menu items, tables, offers)
 * for a brand-new tenant — called EXACTLY ONCE, from restaurants.ts at
 * registration. This is the only place seed content is ever inserted;
 * `tenantDb()`'s accessors above never do it implicitly (see
 * seedCollectionOnce's comment in pg-store.ts for why that used to be
 * a real, verified bug: deleting everything in a collection silently
 * brought the demo content back on the next read).
 */
export async function seedNewTenantContent(restaurantId: string): Promise<void> {
  const scope = { restaurantId };
  await Promise.all([
    seedCollectionOnce("categories", SEED_CATEGORIES as MenuCategory[], scope),
    seedCollectionOnce("menuItems", SEED_MENU_ITEMS as MenuItem[], scope),
    seedCollectionOnce("tables", SEED_TABLES as RestaurantTable[], scope),
    seedCollectionOnce("offers", SEED_OFFERS as Offer[], scope),
  ]);
}

// ---------------------------------------------------------------------------
// Raw Mongo access — used by analytics/reports/finance modules that need
// real aggregation pipelines instead of the array-style helpers above.
// ---------------------------------------------------------------------------

export { drizzleDb as getRawDb, rawSql, hashPassword };
