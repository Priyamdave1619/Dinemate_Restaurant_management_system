export type OrderStatus =
  | "pending"
  | "accepted"
  | "preparing"
  | "ready"
  | "served"
  | "completed"
  | "cancelled";

export type TableStatus = "available" | "occupied" | "reserved" | "cleaning";

export type SpiceLevel = "mild" | "medium" | "hot";

// ---------------------------------------------------------------------------
// Roles — this is a multi-tenant SaaS platform.
//
//   super_admin  Platform owner. Not tied to any restaurant (restaurantId is
//                null on their user record). Cross-tenant visibility only.
//   owner        Restaurant Admin. One per restaurant (created at
//                registration). Full control of their own restaurant only.
//   manager      Belongs to exactly one restaurant. Operational access
//                (orders/products/inventory/staff-viewing) but cannot touch
//                billing, subscription, or delete the restaurant.
//   waiter       Belongs to exactly one restaurant. Floor operations only
//                (orders, tables, bills). Logs in with username, not email.
// ---------------------------------------------------------------------------
export type UserRole = "super_admin" | "owner" | "manager" | "waiter";

/** Roles that manage a single restaurant's back office (menu, tables, etc). */
export const RESTAURANT_STAFF_ROLES: UserRole[] = ["owner", "manager", "waiter"];

// ---------------------------------------------------------------------------
// Food classification — shown on billing, menu management, reports & analytics
// ---------------------------------------------------------------------------

export type FoodType = "veg" | "non-veg" | "egg" | "vegan" | "other";

export const FOOD_TYPE_META: Record<FoodType, { label: string; emoji: string; colorClass: string }> = {
  veg: { label: "Veg", emoji: "🟢", colorClass: "text-green-600 border-green-600" },
  "non-veg": { label: "Non-Veg", emoji: "🔴", colorClass: "text-red-600 border-red-600" },
  egg: { label: "Egg", emoji: "🟡", colorClass: "text-yellow-600 border-yellow-600" },
  vegan: { label: "Vegan", emoji: "🟣", colorClass: "text-purple-600 border-purple-600" },
  other: { label: "Other", emoji: "⚪", colorClass: "text-steel border-steel" },
};

export interface Variant {
  id: string;
  label: string;
  priceDelta: number;
}

/** Paid or free add-on / extra selectable on an item (e.g. Extra Cheese +₹40). */
export interface MenuAddOn {
  id: string;
  label: string;
  priceDelta: number;
  available?: boolean;
}

export type PreparationType = "regular" | "jain";

export type SpiceOption = "none" | "mild" | "medium" | "spicy" | "extra_spicy";

export type MenuTag =
  | "bestseller"
  | "recommended"
  | "chef_special"
  | "new"
  | "spicy"
  | "jain_available"
  | "healthy"
  | "vegan";

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  description: string;
  categoryId: string;
  price: number;
  image: string;
  prepTimeMinutes: number;
  available: boolean;
  spiceLevel: SpiceLevel;
  isVeg: boolean;
  /** Explicit classification (veg/non-veg/egg/vegan/other) — the source of truth for badges. */
  foodType: FoodType;
  /** Cost price per unit (for COGS / gross-profit calculations). Defaults to 0 if unset. */
  costPrice?: number;
  variants?: Variant[];
  /** Customer can choose Regular vs Jain preparation */
  jainAvailable?: boolean;
  /** Item is Jain-only (no Regular option) */
  jainOnly?: boolean;
  /** Show spice-level picker on customize sheet */
  enableSpiceLevel?: boolean;
  /** Allowed spice options when enableSpiceLevel is true */
  spiceOptions?: SpiceOption[];
  /** Allow free-text cooking request */
  enableCookingRequest?: boolean;
  /** Max chars for cooking request (default 250) */
  maxCookingRequestLength?: number;
  /** Selectable extras / add-ons */
  addOns?: MenuAddOn[];
  /** Marketing / dietary tags (known values in MenuTag, freeform allowed) */
  tags?: string[];
  /** Set when item was created via Bulk Menu Import — used for cascade delete of an import session */
  importSessionId?: string;
  ingredients?: string[];
  allergens?: string[];
  /**
   * Optional daily time window when the item can be ordered (restaurant local time).
   * Example: Thali availableFrom "11:00" availableTo "15:00".
   * When scheduleEnabled is true, both from/to are required for the window to apply.
   */
  scheduleEnabled?: boolean;
  /** Start of availability window, 24h "HH:mm" (e.g. "11:00"). */
  availableFrom?: string;
  /** End of availability window, 24h "HH:mm" (e.g. "15:00"). Inclusive. */
  availableTo?: string;
}

export interface MenuCategory {
  id: string;
  restaurantId: string;
  name: string;
  icon: string;
  /**
   * Optional daily time window for the whole category (restaurant local time).
   * Example: "Lunch" category availableFrom "11:00" availableTo "15:00".
   * Items under this category inherit the restriction unless the item itself is unavailable.
   */
  scheduleEnabled?: boolean;
  availableFrom?: string;
  availableTo?: string;
}

export interface CartLine {
  lineId: string;
  itemId: string;
  name: string;
  price: number;
  quantity: number;
  variant?: string;
  note?: string;
}

export interface OrderItem {
  id: string;
  itemId: string;
  name: string;
  quantity: number;
  /** Final unit price = base + variant delta + add-on deltas (server-calculated). */
  price: number;
  variant?: string;
  note?: string;
  /** Regular or Jain preparation */
  preparation?: PreparationType;
  /** Selected spice level label */
  spiceLevelSelected?: string;
  /** Selected add-on labels (snapshotted) */
  addOns?: Array<{ id: string; label: string; priceDelta: number }>;
  /** Free-text cooking request / special instructions */
  cookingRequest?: string;
  addedBy?: "customer" | "waiter";
  kotPrinted?: boolean;
  /** Snapshotted at order time so historical bills/reports never change retroactively. */
  foodType?: FoodType;
  categoryId?: string;
  /** Snapshotted per-unit cost price, for COGS on this line. */
  costPrice?: number;
}

export interface AppliedOffer {
  offerId: string;
  name: string;
  amount: number;
}

export interface Order {
  id: string;
  restaurantId: string;
  tableNumber: number;
  items: OrderItem[];
  status: OrderStatus;
  placedAt: string;
  updatedAt: string;
  customerName?: string;
  waiterName?: string;
  note?: string;
  estimatedMinutes: number;
  subtotal: number;
  manualDiscountPercent: number;
  appliedOffers: AppliedOffer[];
  discountTotal: number;
  taxRatePercent: number;
  taxAmount: number;
  total: number;
  kotBatches: number;
  billGenerated: boolean;
  billNumber?: string;
  billedAt?: string;
  paymentMethod?: "cash" | "card" | "upi";
  /** Total cost-of-goods-sold for this order, snapshotted at bill time. */
  cogsTotal?: number;
}

export interface RestaurantTable {
  id: string;
  restaurantId: string;
  number: number;
  capacity: number;
  status: TableStatus;
  currentOrderId?: string;
  waiterName?: string;
  qrPath?: string;
}

export type OfferType =
  | "percent"
  | "flat"
  | "bogo"
  | "combo"
  | "category"
  | "item"
  | "happy_hour"
  | "coupon";

export interface Offer {
  id: string;
  restaurantId: string;
  name: string;
  description?: string;
  /** Optional banner / image URL */
  image?: string;
  type: OfferType;
  active: boolean;

  /** Scope — prefer arrays; legacy itemId/categoryId still accepted */
  itemIds?: string[];
  categoryIds?: string[];
  excludeItemIds?: string[];
  /** @deprecated use itemIds */
  itemId?: string;
  /** @deprecated use categoryIds */
  categoryId?: string;

  buyQty?: number;
  getQty?: number;
  discountPercent?: number;
  discountAmount?: number;
  /** Cap on discount amount (e.g. 20% off max ₹100) */
  maxDiscountAmount?: number;
  minOrderAmount?: number;

  /** Schedule */
  startsAt?: string; // ISO
  endsAt?: string; // ISO
  /** 0=Sun … 6=Sat; empty/undefined = every day */
  daysOfWeek?: number[];
  /** Daily time window HH:mm for happy hours */
  timeFrom?: string;
  timeTo?: string;

  usageLimit?: number;
  usageCount?: number;
  perCustomerLimit?: number;

  couponCode?: string;
  /** When true, applied automatically if eligible (no code needed) */
  autoApply?: boolean;
  /** When false, cannot combine with other offers */
  stackable?: boolean;
  /** Higher runs first when multiple apply */
  priority?: number;

  createdAt: string;
  updatedAt?: string;
}

export interface AppUser {
  id: string;
  /** null only for role "super_admin" — every restaurant-scoped role must have one. */
  restaurantId: string | null;
  /**
   * Login handle. For role "owner" this is always equal to the restaurant's
   * id (e.g. "REST000021") so "Restaurant ID + Password" login is really
   * just username+password login against this same table. Unique per
   * restaurant for manager/waiter; globally unique for super_admin.
   */
  username: string;
  name: string;
  role: UserRole;
  passwordHash: string;
  passwordSalt: string;
  createdAt: string;
  active: boolean;
  /** Free-form module permissions for managers/waiters (Staff module). Owners & super_admin implicitly have all. */
  permissions?: string[];
  lastLoginAt?: string;
}

export interface RestaurantSettings {
  restaurantId: string;
  taxRatePercent: number;
  restaurantName: string;
  address?: string;
  /** Contact phone shown on customer bills */
  phone?: string;
  /** Food licence / FSSAI number shown on customer bills */
  foodLicence?: string;
  gstin?: string;
  baseUrl: string;
  currency?: string;
  openingTime?: string;
  closingTime?: string;
  billPrefix?: string;
}

// ---------------------------------------------------------------------------
// Platform / multi-tenant SaaS layer
// ---------------------------------------------------------------------------

export type RestaurantStatus = "active" | "suspended" | "pending";

/** One row per tenant. This is the root of the multi-tenant tree — every
 * business table hangs off `restaurantId` referencing `Restaurant.id`. */
export interface Restaurant {
  /** Public-facing tenant id & owner login, e.g. "REST000021". Globally unique. */
  id: string;
  name: string;
  ownerName: string;
  email: string;
  mobile: string;
  address?: string;
  logoUrl?: string;
  gstNumber?: string;
  timezone?: string;
  currency: string;
  status: RestaurantStatus;
  createdAt: string;
  updatedAt: string;
  createdBy?: string; // super_admin id, if provisioned from the admin panel
  // --- Subscription (kept inline for simplicity; one active plan at a time) ---
  planId: string;
  subscriptionStatus: "trialing" | "active" | "expired" | "cancelled";
  subscriptionStartedAt: string;
  subscriptionExpiresAt: string;
  renewedAt?: string;
}

export interface SubscriptionPlan {
  id: string; // "free" | "starter" | "professional" | "enterprise" | custom
  name: string;
  durationDays: number;
  price: number;
  currency: string;
  productLimit: number; // -1 = unlimited
  orderLimit: number; // per month, -1 = unlimited
  userLimit: number; // staff seats, -1 = unlimited
  storageLimitMb: number;
  features: string[];
  active: boolean;
  createdAt: string;
}

export type AuditAction =
  | "login"
  | "logout"
  | "create"
  | "update"
  | "delete"
  | "subscription_change"
  | "role_change"
  | "password_reset"
  | "password_change"
  | "profile_update"
  | "restaurant_created"
  | "restaurant_deleted"
  | "restaurant_activated"
  | "restaurant_suspended";

/** Append-only audit trail. Written for every sensitive action across the platform. */
export interface AuditLogEntry {
  id: string;
  /** null for platform-level actions performed by a super_admin. */
  restaurantId: string | null;
  actorUserId: string;
  actorName: string;
  actorRole: UserRole;
  action: AuditAction;
  entityType: string;
  entityId?: string;
  details?: Record<string, unknown>;
  ip?: string;
  userAgent?: string;
  createdAt: string;
}

// ---------------------------------------------------------------------------
// Sales / reporting / analytics / finance
// ---------------------------------------------------------------------------

/**
 * One document per menu item sold on a bill. Written once, permanently, when
 * a bill is generated — this is the audit-safe, denormalized fact table that
 * every analytics & reporting aggregation reads from, so heavy reporting
 * queries never need to touch the (much smaller, mutable) live orders queue.
 */
export interface SoldItemRecord {
  id: string;
  restaurantId: string;
  orderId: string;
  billNumber: string;
  tableNumber: number;
  waiterName?: string;
  itemId: string;
  itemName: string;
  categoryId: string;
  foodType: FoodType;
  quantity: number;
  unitPrice: number;
  lineRevenue: number;
  unitCost: number;
  lineCost: number;
  lineProfit: number;
  soldAt: string; // ISO timestamp of bill generation
  dateKey: string; // YYYY-MM-DD (local)
  weekKey: string; // ISO week, e.g. 2026-W30
  monthKey: string; // YYYY-MM
  yearKey: string; // YYYY
  hour: number; // 0-23, local hour of sale — used for peak-hour analysis
  weekday: number; // 0(Sun)-6(Sat)
}

export interface PeriodTotals {
  /** Sum of order subtotals, before discounts and tax. */
  grossSales: number;
  discountTotal: number;
  /** grossSales - discountTotal */
  netSales: number;
  /** GST collected — a pass-through liability, not revenue. */
  taxTotal: number;
  /** netSales + taxTotal — what customers actually paid. */
  totalCollected: number;
  cogsTotal: number;
  /** netSales - cogsTotal */
  grossProfit: number;
  orderCount: number;
  itemsSold: number;
}

/** One permanent record per calendar day that has had at least one bill. */
export interface DailyStats extends PeriodTotals {
  restaurantId: string;
  dateKey: string; // YYYY-MM-DD
  weekKey: string; // ISO week, e.g. 2026-W30
  monthKey: string;
  yearKey: string;
  updatedAt: string;
}

/** Weekly rollups, computed on demand by aggregating DailyStats. */
export interface WeeklyStats extends PeriodTotals {
  weekKey: string; // e.g. 2026-W30
  updatedAt: string;
}

/**
 * One permanent record per calendar month. Never deleted — this is the
 * durable historical archive that yearly reports are aggregated from.
 */
export interface MonthlyStats extends PeriodTotals {
  restaurantId: string;
  monthKey: string; // YYYY-MM
  yearKey: string;
  updatedAt: string;
}

/** Yearly rollups, computed on demand by aggregating MonthlyStats. */
export interface YearlyStats extends PeriodTotals {
  yearKey: string; // YYYY
  updatedAt: string;
}

export type ExpenseCategory =
  | "rent"
  | "salaries"
  | "utilities"
  | "raw-materials"
  | "maintenance"
  | "marketing"
  | "other";

/** Manually logged operating expenses, used alongside COGS for P&L. */
export interface Expense {
  id: string;
  restaurantId: string;
  date: string; // ISO date
  monthKey: string;
  yearKey: string;
  category: ExpenseCategory;
  description: string;
  amount: number;
  createdAt: string;
  createdBy?: string;
}

export type NotificationType =
  | "new_order"
  | "order_ready"
  | "low_stock"
  | "subscription_expiring"
  | "subscription_expired"
  | "staff_added"
  | "announcement";

/** In-app notification, scoped to one restaurant (never cross-tenant). A
 * `targetRole` of null means "visible to every staff role at this
 * restaurant"; otherwise only that role sees it (e.g. a kitchen alert only
 * needs to reach managers/waiters, not necessarily every login). */
export interface AppNotification {
  id: string;
  restaurantId: string;
  type: NotificationType;
  title: string;
  message: string;
  targetRole: UserRole | null;
  read: boolean;
  createdAt: string;
  relatedEntityType?: string;
  relatedEntityId?: string;
}

export interface ProfitAndLoss {
  periodKey: string;
  grossSales: number;
  discounts: number;
  netSales: number;
  taxes: number;
  cogs: number;
  grossProfit: number;
  grossMarginPercent: number;
  totalExpenses: number;
  expensesByCategory: Record<string, number>;
  netProfit: number;
  netMarginPercent: number;
  orderCount: number;
  averageOrderValue: number;
}

// ---------------------------------------------------------------------------
// Bulk Menu Import — AI-assisted onboarding
// ---------------------------------------------------------------------------

export type MenuImportStatus =
  | "uploaded"
  | "processing"
  | "review_required"
  | "ready"
  | "importing"
  | "completed"
  | "partially_completed"
  | "failed";

export type ImportItemStatus =
  | "pending"
  | "extracted"
  | "needs_review"
  | "duplicate"
  | "error"
  | "approved"
  | "skipped"
  | "imported";

export interface ExtractedVariant {
  label: string;
  price: number;
  confidence?: number;
}

export interface ExtractedAddOn {
  label: string;
  price: number;
  confidence?: number;
}

export interface ExtractedMenuItem {
  id: string;
  name: string;
  description?: string;
  price: number;
  categoryName?: string;
  categoryId?: string;
  foodType?: FoodType;
  jainAvailable?: boolean | "needs_review";
  jainPrice?: number;
  variants?: ExtractedVariant[];
  addOns?: ExtractedAddOn[];
  tags?: string[];
  ingredients?: string[];
  prepTimeMinutes?: number;
  imageUrl?: string;
  imageStorageKey?: string;
  sourceFile?: string;
  confidence: {
    name: number;
    price: number;
    category: number;
    foodType: number;
    overall: number;
  };
  status: ImportItemStatus;
  duplicateOfId?: string;
  errorMessage?: string;
  /** Admin edits applied during review */
  overrides?: Partial<{
    name: string;
    description: string;
    price: number;
    categoryName: string;
    categoryId: string;
    foodType: FoodType;
    jainAvailable: boolean;
    available: boolean;
  }>;
}

export interface MenuImportSession {
  id: string;
  restaurantId: string;
  createdBy: string;
  status: MenuImportStatus;
  totalFiles: number;
  totalItems: number;
  processedItems: number;
  successfulItems: number;
  failedItems: number;
  duplicateItems: number;
  needsReviewItems: number;
  files: Array<{
    name: string;
    size: number;
    mimeType: string;
    storageKey?: string;
    /** Base64 bytes when R2 is unavailable (serverless). Cleared after process. */
    contentBase64?: string;
    status: "uploaded" | "processing" | "done" | "error";
    error?: string;
  }>;
  items: ExtractedMenuItem[];
  categoriesDetected: string[];
  createdAt: string;
  updatedAt: string;
  completedAt?: string;
  processingTimeMs?: number;
  errorSummary?: string;
}

// ---------------------------------------------------------------------------
// Menu file uploads (metadata stored in PostgreSQL)
// ---------------------------------------------------------------------------

export type MenuFileStatus = "uploaded" | "processing" | "ready" | "failed" | "deleted";

export interface MenuFileRecord {
  id: string;
  restaurantId: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  sha256?: string;
  storageKey?: string;
  fileUrl?: string;
  /** Present only when stored inline (small files / no R2). Omitted from list APIs. */
  contentBase64?: string;
  uploadedBy?: string;
  status: MenuFileStatus;
  createdAt: string;
  updatedAt: string;
}
