import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DineMate Backend API",
  description: "Multi-tenant restaurant POS backend — API status, docs & health",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0 }}>{children}</body>
    </html>
  );
}