const docs = [
  {
    href: "/swagger-ui/index.html",
    title: "Swagger UI",
    badge: "Interactive",
    description:
      "Try every endpoint live. Click Authorize and paste an access token from POST /api/auth/login.",
  },
  {
    href: "/api/openapi.json",
    title: "OpenAPI 3.0",
    badge: "JSON",
    description: "Raw specification for Postman, Insomnia, or client SDK generators.",
    code: "GET /api/openapi.json",
  },
];

const health = [
  {
    href: "/api/health",
    title: "Service health",
    code: "GET /api/health",
    description: "Process + database. Returns 200 when healthy, 503 when degraded.",
  },
  {
    href: "/api/health/db",
    title: "Database status",
    code: "GET /api/health/db",
    description: "Latency, Postgres version, and TLS requirement flag.",
  },
];

function Card({
  href,
  title,
  description,
  badge,
  code,
}: {
  href: string;
  title: string;
  description: string;
  badge?: string;
  code?: string;
}) {
  return (
    <a
      href={href}
      className="group relative flex flex-col gap-2 rounded-2xl border border-zinc-800/80 bg-zinc-900/50 p-5 shadow-sm backdrop-blur transition hover:border-emerald-500/40 hover:bg-zinc-900 hover:shadow-emerald-500/5"
    >
      <div className="flex items-start justify-between gap-3">
        <h3 className="text-base font-semibold tracking-tight text-zinc-50 group-hover:text-emerald-300">
          {title}
        </h3>
        {badge ? (
          <span className="shrink-0 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-0.5 text-[11px] font-medium uppercase tracking-wide text-emerald-400">
            {badge}
          </span>
        ) : null}
      </div>
      {code ? (
        <code className="w-fit rounded-md bg-zinc-950/80 px-2 py-1 font-mono text-xs text-emerald-400/90 ring-1 ring-zinc-800">
          {code}
        </code>
      ) : null}
      <p className="text-sm leading-relaxed text-zinc-400">{description}</p>
      <span className="mt-1 inline-flex items-center gap-1 text-xs font-medium text-zinc-500 transition group-hover:text-emerald-400">
        Open
        <svg
          className="h-3.5 w-3.5 transition group-hover:translate-x-0.5"
          viewBox="0 0 16 16"
          fill="none"
          aria-hidden
        >
          <path
            d="M3.5 8h9m0 0L9 4.5M12.5 8 9 11.5"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </span>
    </a>
  );
}

export default function StatusPage() {
  return (
    <main className="mx-auto flex min-h-screen max-w-3xl flex-col px-6 py-16 sm:px-8 sm:py-20">
      {/* Header */}
      <header className="mb-12">
        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900/60 px-3 py-1 text-xs font-medium text-zinc-400">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-40" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
          </span>
          API service
        </div>

        <h1 className="text-3xl font-semibold tracking-tight text-white sm:text-4xl">
          DineMate Backend
        </h1>
        <p className="mt-3 max-w-xl text-base leading-relaxed text-zinc-400">
          Multi-tenant restaurant POS backend. JSON API only — interactive docs and health
          probes below.
        </p>
      </header>

      {/* Docs */}
      <section className="mb-10">
        <div className="mb-4 flex items-center gap-2">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-500">
            Interactive docs
          </h2>
          <div className="h-px flex-1 bg-gradient-to-r from-zinc-800 to-transparent" />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {docs.map((item) => (
            <Card key={item.href} {...item} />
          ))}
        </div>
      </section>

      {/* Health */}
      <section className="mb-12">
        <div className="mb-4 flex items-center gap-2">
          <h2 className="text-sm font-semibold uppercase tracking-wider text-zinc-500">
            Health checks
          </h2>
          <div className="h-px flex-1 bg-gradient-to-r from-zinc-800 to-transparent" />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {health.map((item) => (
            <Card key={item.href} {...item} />
          ))}
        </div>
      </section>

      {/* Footer strip */}
      <footer className="mt-auto border-t border-zinc-800/80 pt-6">
        <p className="text-sm text-zinc-500">
          Base path for all business endpoints:{" "}
          <code className="rounded bg-zinc-900 px-1.5 py-0.5 font-mono text-xs text-zinc-300 ring-1 ring-zinc-800">
            /api/*
          </code>
        </p>
      </footer>
    </main>
  );
}
