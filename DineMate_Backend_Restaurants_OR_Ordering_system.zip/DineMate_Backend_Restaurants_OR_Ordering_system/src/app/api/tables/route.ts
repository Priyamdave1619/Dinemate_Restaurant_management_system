import { NextRequest } from "next/server";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { resolvePublicRestaurant } from "@/lib/server/tenant-context";
import { createTableSchema } from "@/lib/server/validation";
import { RestaurantTable } from "@/lib/types";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

async function getImpl(req: NextRequest) {
  const tenant = await resolvePublicRestaurant(req);
  if (!tenant.ok) return apiError(tenant.message, tenant.status);

  const tables = await tenantDb(tenant.restaurantId).tables.all();
  return apiSuccess({ tables }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);

async function postImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const parsed = createTableSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const input = parsed.data;

  const db = tenantDb(auth.session.restaurantId);
  const tables = await db.tables.all();
  if (tables.some((t) => t.number === input.number)) {
    return apiError("A table with that number already exists", 409);
  }

  const table: RestaurantTable = {
    id: `t${input.number}-${Date.now()}`,
    restaurantId: auth.session.restaurantId,
    number: input.number,
    capacity: input.capacity ?? 4,
    status: "available",
  };

  const next = await db.tables.mutate((cur) => [...cur, table]);

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "create",
    entityType: "table",
    entityId: table.id,
  });

  return apiSuccess({ table, tables: next }, "Created successfully", { status: 201 });
}

export const POST = withErrorHandling(postImpl);
