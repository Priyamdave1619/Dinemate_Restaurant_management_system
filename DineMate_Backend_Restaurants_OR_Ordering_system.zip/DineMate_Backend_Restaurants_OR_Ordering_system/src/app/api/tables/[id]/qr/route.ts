import { NextRequest, NextResponse } from "next/server";
import QRCode from "qrcode";
import { tenantDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { buildQrCardSvg } from "@/lib/server/qr-design";
import { readStoredFile, writeStoredFile } from "@/lib/server/storage";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { RESTAURANT_STAFF_ROLES } from "@/lib/types";
import { buildEncryptedTableUrl, buildPlainTableUrl } from "@/lib/server/qr-crypto";

export const runtime = "nodejs";

/**
 * Generates (or regenerates) a QR code for a table.
 * Encodes encrypted customer URL: {baseUrl}/q/{token}
 * Customer portal decrypts and redirects to /{restaurantId}/table/{n}
 * so the browser address bar shows the plain menu URL.
 */

async function getImpl(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(RESTAURANT_STAFF_ROLES);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await ctx.params;
  if (!id) return apiError("Table id required", 400);

  const restaurantId = auth.session.restaurantId;
  const db = tenantDb(restaurantId);
  const tables = await db.tables.all();
  const table = tables.find((t) => t.id === id);
  if (!table) return apiError("Table not found", 404);

  const settings = await db.settings.get();
  // Prefer env so production customer origin is always used
  const envBase = (process.env.NEXT_PUBLIC_BASE_URL || "").trim();
  const settingsBase = (settings?.baseUrl || "").trim();
  const baseUrl = (envBase || settingsBase || "http://localhost:3003").replace(/\/$/, "");

  let targetUrl: string;
  let plainUrl: string;
  try {
    targetUrl = buildEncryptedTableUrl(baseUrl, restaurantId, table.number);
    plainUrl = buildPlainTableUrl(baseUrl, restaurantId, table.number);
  } catch (err) {
    console.error("[qr] encrypt failed, falling back to plain URL", err);
    plainUrl = buildPlainTableUrl(baseUrl, restaurantId, table.number);
    targetUrl = plainUrl;
  }

  const regenerate = req.nextUrl.searchParams.get("regenerate") === "1";
  const wantsPng = req.nextUrl.searchParams.get("format") === "png";
  const wantsJson = req.nextUrl.searchParams.get("format") === "json";
  const wantsPlain = req.nextUrl.searchParams.get("plain") === "1";

  const svgPath = `qrcodes/table-${restaurantId}-${table.number}.svg`;
  const pngPath = `qrcodes/table-${restaurantId}-${table.number}.png`;

  // ---- JSON (restaurant portal): never depend on file storage ----
  if (wantsJson) {
    // Best-effort cache of SVG for later downloads; failures are non-fatal
    if (regenerate) {
      void persistQrAssets({
        svgPath,
        pngPath,
        targetUrl,
        tableNumber: table.number,
        restaurantName: settings?.restaurantName || restaurantId,
        restaurantId,
        tableId: id,
        db,
      }).catch((e) => console.error("[qr] persist failed", e));
    }
    return apiSuccess(
      {
        qrPath: `/${svgPath}`,
        targetUrl: wantsPlain ? plainUrl : targetUrl,
        encryptedUrl: targetUrl,
        plainUrl,
      },
      "Operation successful"
    );
  }

  // ---- PNG download ----
  if (wantsPng) {
    try {
      let pngBuffer = regenerate ? null : await readStoredFile(pngPath);
      if (!pngBuffer) {
        pngBuffer = await QRCode.toBuffer(targetUrl, {
          width: 640,
          margin: 3,
          color: { dark: "#1C1B1A", light: "#FFFDFB" },
          errorCorrectionLevel: "M",
        });
        try {
          await writeStoredFile(pngPath, pngBuffer, "image/png");
        } catch (e) {
          console.error("[qr] png store failed", e);
        }
      }
      return new NextResponse(new Uint8Array(pngBuffer), {
        headers: {
          "Content-Type": "image/png",
          "Cache-Control": "no-store",
          "Content-Disposition": `attachment; filename="table-${table.number}-qr.png"`,
        },
      });
    } catch (err) {
      console.error("[qr] png generation failed", err);
      return apiError("Could not generate QR image", 500);
    }
  }

  // ---- SVG (default) ----
  try {
    let svgBuffer = regenerate ? null : await readStoredFile(svgPath);
    let publicPath = `/${svgPath}`;
    if (!svgBuffer) {
      const svg = buildQrCardSvg({
        targetUrl,
        tableNumber: table.number,
        restaurantName: settings?.restaurantName || restaurantId,
      });
      svgBuffer = Buffer.from(svg, "utf-8");
      try {
        publicPath = await writeStoredFile(svgPath, svgBuffer, "image/svg+xml");
        await db.tables.mutate((cur) =>
          cur.map((t) => (t.id === id ? { ...t, qrPath: publicPath } : t))
        );
      } catch (e) {
        console.error("[qr] svg store failed", e);
        // still return the SVG bytes even if storage failed
      }
    }
    return new NextResponse(new Uint8Array(svgBuffer), {
      headers: {
        "Content-Type": "image/svg+xml",
        "Cache-Control": "no-store",
        "Content-Disposition": `inline; filename="table-${restaurantId}-${table.number}.svg"`,
      },
    });
  } catch (err) {
    console.error("[qr] svg generation failed", err);
    return apiError("Could not generate QR card", 500);
  }
}

async function persistQrAssets(opts: {
  svgPath: string;
  pngPath: string;
  targetUrl: string;
  tableNumber: number;
  restaurantName: string;
  restaurantId: string;
  tableId: string;
  db: ReturnType<typeof tenantDb>;
}) {
  const svg = buildQrCardSvg({
    targetUrl: opts.targetUrl,
    tableNumber: opts.tableNumber,
    restaurantName: opts.restaurantName,
  });
  const svgBuffer = Buffer.from(svg, "utf-8");
  const publicPath = await writeStoredFile(opts.svgPath, svgBuffer, "image/svg+xml");
  await opts.db.tables.mutate((cur) =>
    cur.map((t) => (t.id === opts.tableId ? { ...t, qrPath: publicPath } : t))
  );
  const pngBuffer = await QRCode.toBuffer(opts.targetUrl, {
    width: 640,
    margin: 3,
    color: { dark: "#1C1B1A", light: "#FFFDFB" },
    errorCorrectionLevel: "M",
  });
  await writeStoredFile(opts.pngPath, pngBuffer, "image/png");
}

export const GET = withErrorHandling(getImpl);

async function postImpl(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const url = new URL(req.url);
  url.searchParams.set("regenerate", "1");
  url.searchParams.set("format", "json");
  return GET(new NextRequest(url, req), ctx);
}

export const POST = withErrorHandling(postImpl);
