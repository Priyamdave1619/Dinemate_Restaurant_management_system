import { NextRequest } from "next/server";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { RESTAURANT_STAFF_ROLES } from "@/lib/types";

async function patchImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(RESTAURANT_STAFF_ROLES);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const { id } = await params;
  const patch = await req.json().catch(() => null);
  if (!patch) return apiError("Invalid body", 400);

  // Waiters may only update floor-level fields (per Staff Module spec);
  // full edits (capacity, number) are owner/manager-only.
  const allowed =
    auth.session.role === "owner" || auth.session.role === "manager"
      ? patch
      : { status: patch.status, waiterName: patch.waiterName, currentOrderId: patch.currentOrderId };

  const tables = await tenantDb(auth.session.restaurantId).tables.mutate((cur) =>
    cur.map((t) => (t.id === id ? { ...t, ...allowed, id: t.id, restaurantId: t.restaurantId } : t))
  );
  return apiSuccess({ tables }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);

async function deleteImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const { id } = await params;
  const tables = await tenantDb(auth.session.restaurantId).tables.mutate((cur) => cur.filter((t) => t.id !== id));

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "delete",
    entityType: "table",
    entityId: id,
  });

  return apiSuccess({ tables }, "Operation successful");
}

export const DELETE = withErrorHandling(deleteImpl);
