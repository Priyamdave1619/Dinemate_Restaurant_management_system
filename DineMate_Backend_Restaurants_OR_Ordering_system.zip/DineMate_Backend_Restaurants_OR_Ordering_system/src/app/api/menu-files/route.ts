import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import {
  saveMenuFile,
  listMenuFiles,
  toPublicMenuFile,
  validateMenuUploadFile,
} from "@/lib/server/menu-files/menu-file-service";

/**
 * POST /api/menu-files
 * Multipart upload of one or more menu images/PDFs.
 * Stores metadata (+ content or storage ref) in PostgreSQL.
 * Owner/manager only. No OCR.
 */
async function postImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const form = await req.formData().catch(() => null);
  if (!form) return apiError("Expected multipart/form-data with field 'file' or 'files'", 400);

  const uploaded: ReturnType<typeof toPublicMenuFile>[] = [];
  const errors: string[] = [];

  for (const [key, value] of form.entries()) {
    if (key !== "file" && key !== "files") continue;
    if (typeof value === "string") continue;
    const f = value as File;
    const buffer = Buffer.from(await f.arrayBuffer());
    const mime = f.type || "application/octet-stream";
    const check = validateMenuUploadFile(f.name, mime, buffer.length);
    if (!check.ok) {
      errors.push(`${f.name}: ${check.error}`);
      continue;
    }
    try {
      const record = await saveMenuFile({
        restaurantId: auth.session.restaurantId,
        uploadedBy: auth.session.sub,
        fileName: f.name,
        mimeType: mime,
        buffer,
      });
      uploaded.push(toPublicMenuFile(record));
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Upload failed";
      if (/menu_files|does not exist|relation/i.test(msg)) {
        return apiError(
          "Database table menu_files is missing. Run migration drizzle/0002_menu_files.sql on Postgres, then retry.",
          500
        );
      }
      errors.push(`${f.name}: ${msg}`);
    }
  }

  if (uploaded.length === 0) {
    return apiError(errors[0] || "No valid files uploaded", 400);
  }

  return apiSuccess(
    {
      files: uploaded,
      count: uploaded.length,
      errors: errors.length ? errors : undefined,
    },
    uploaded.length === 1 ? "Menu file uploaded successfully" : `${uploaded.length} menu files uploaded successfully`
  );
}

/**
 * GET /api/menu-files?limit=&offset=
 * List uploaded menu files for the authenticated restaurant.
 */
async function getImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const limit = Number(req.nextUrl.searchParams.get("limit") || 50);
  const offset = Number(req.nextUrl.searchParams.get("offset") || 0);

  try {
    const result = await listMenuFiles(auth.session.restaurantId, { limit, offset });
    return apiSuccess(result, "OK");
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (/menu_files|does not exist|relation/i.test(msg)) {
      return apiError(
        "Database table menu_files is missing. Run migration drizzle/0002_menu_files.sql on Postgres.",
        500
      );
    }
    throw e;
  }
}

export const POST = withErrorHandling(postImpl);
export const GET = withErrorHandling(getImpl);
