import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import {
  getMenuFile,
  deleteMenuFile,
  toPublicMenuFile,
} from "@/lib/server/menu-files/menu-file-service";

/**
 * GET /api/menu-files/:id
 * Fetch one menu file metadata (tenant-scoped).
 * Optional ?includeContent=1 returns contentBase64 when stored inline.
 */
async function getImpl(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await ctx.params;
  const includeContent = req.nextUrl.searchParams.get("includeContent") === "1";

  const file = await getMenuFile(auth.session.restaurantId, id, { includeContent });
  if (!file) return apiError("Menu file not found", 404);

  if (includeContent && file.contentBase64) {
    return apiSuccess({ file }, "OK");
  }
  return apiSuccess({ file: toPublicMenuFile(file) }, "OK");
}

/**
 * DELETE /api/menu-files/:id
 * Soft-delete a menu file for the authenticated restaurant.
 */
async function deleteImpl(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await ctx.params;
  const ok = await deleteMenuFile(auth.session.restaurantId, id);
  if (!ok) return apiError("Menu file not found", 404);
  return apiSuccess({ id, deleted: true }, "Menu file deleted");
}

export const GET = withErrorHandling(getImpl);
export const DELETE = withErrorHandling(deleteImpl);
