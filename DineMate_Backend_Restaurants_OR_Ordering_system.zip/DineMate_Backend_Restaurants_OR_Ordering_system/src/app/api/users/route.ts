import { NextRequest } from "next/server";
import { randomUUID } from "crypto";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { hashPassword } from "@/lib/server/auth";
import { isUsernameTaken } from "@/lib/server/restaurants";
import { notify } from "@/lib/server/notifications";
import { createUserSchema } from "@/lib/server/validation";
import { AppUser } from "@/lib/types";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

function toPublic(u: AppUser) {
  return { id: u.id, username: u.username, name: u.name, role: u.role, active: u.active, createdAt: u.createdAt };
}

// The Staff module — every account here belongs to exactly one restaurant
// (the owner's own account is created at registration, not through this
// route). Only owner/manager can view or manage staff; waiters cannot.
async function getImpl() {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const users = await tenantDb(auth.session.restaurantId).users.all();
  return apiSuccess({ users: users.map(toPublic) }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);

async function postImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const parsed = createUserSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const input = parsed.data;

  // Managers may only create waiters, not other managers (per Staff Module
  // spec: Manager cannot manage roles above their own level).
  if (auth.session.role === "manager" && input.role !== "waiter") {
    return apiError("Managers can only create waiter accounts", 403);
  }

  // Usernames are unique across the WHOLE platform, not just this
  // restaurant — see restaurants.ts for why (waiter/manager login has no
  // restaurant selector).
  if (await isUsernameTaken(input.username)) {
    return apiError("Username already taken", 409);
  }

  const db = tenantDb(auth.session.restaurantId);
  const restaurant = await platformDb.restaurants.get(auth.session.restaurantId);
  const plan = restaurant ? await platformDb.plans.get(restaurant.planId) : null;
  if (plan && plan.userLimit >= 0) {
    const current = await db.users.all();
    // +1 to account for the owner, who isn't stored in this tenant-scoped
    // users list (their account lives here too, actually — the owner IS
    // included in db.users, so no +1 needed).
    if (current.length >= plan.userLimit) {
      return apiError(`Your ${plan.name} plan allows up to ${plan.userLimit} staff accounts — upgrade to add more`, 402);
    }
  }

  const { hash, salt } = hashPassword(input.password);
  const user: AppUser = {
    id: randomUUID(),
    restaurantId: auth.session.restaurantId,
    username: input.username,
    name: input.name,
    role: input.role,
    passwordHash: hash,
    passwordSalt: salt,
    createdAt: new Date().toISOString(),
    active: true,
    permissions: input.permissions,
  };

  const users = await db.users.mutate((cur) => [...cur, user]);

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "create",
    entityType: "user",
    entityId: user.id,
    details: { role: user.role },
  });

  await notify(auth.session.restaurantId, {
    type: "staff_added",
    title: "New staff account created",
    message: `${user.name} was added as ${user.role} by ${auth.session.name}`,
    targetRole: "owner",
    relatedEntityType: "user",
    relatedEntityId: user.id,
  });

  return apiSuccess({ user: toPublic(user), users: users.map(toPublic) }, "Created successfully", { status: 201 });
}

export const POST = withErrorHandling(postImpl);
