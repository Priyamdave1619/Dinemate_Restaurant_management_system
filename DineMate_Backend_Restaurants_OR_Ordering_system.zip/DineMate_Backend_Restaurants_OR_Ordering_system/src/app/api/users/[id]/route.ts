import { NextRequest } from "next/server";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { hashPassword } from "@/lib/server/auth";
import { revokeAllRefreshTokensForUser } from "@/lib/server/refresh-tokens";
import { AppUser } from "@/lib/types";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

function toPublic(u: AppUser) {
  return { id: u.id, username: u.username, name: u.name, role: u.role, active: u.active, createdAt: u.createdAt };
}

async function patchImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const { id } = await params;
  const patch = await req.json().catch(() => null);
  if (!patch) return apiError("Invalid body", 400);

  const db = tenantDb(auth.session.restaurantId);
  let target: AppUser | undefined;
  let forbidden = false;
  let shouldRevokeSessions = false;

  const users = await db.users.mutate((cur) =>
    cur.map((u) => {
      if (u.id !== id) return u;
      // Nobody edits the owner account through the Staff module, and a
      // manager may only edit waiter accounts (not other managers).
      if (u.role === "owner" || (auth.session.role === "manager" && u.role !== "waiter")) {
        forbidden = true;
        return u;
      }
      target = u;
      const next = { ...u };
      if (typeof patch.name === "string") next.name = patch.name;
      if (typeof patch.active === "boolean") {
        next.active = patch.active;
        // Being deactivated should end any session already in progress —
        // not just block the next full login.
        if (patch.active === false) shouldRevokeSessions = true;
      }
      if (Array.isArray(patch.permissions)) next.permissions = patch.permissions.map(String);
      if (typeof patch.password === "string" && patch.password.length > 0) {
        const { hash, salt } = hashPassword(patch.password);
        next.passwordHash = hash;
        next.passwordSalt = salt;
        // A password reset should force every existing session (including
        // one an attacker who had the old password might be holding) to
        // re-authenticate, not silently keep refreshing on the old creds.
        shouldRevokeSessions = true;
      }
      target = next;
      return next;
    })
  );

  if (forbidden) return apiError("Not authorized to edit this account", 403);
  if (!target) return apiError("User not found", 404);

  if (shouldRevokeSessions) {
    await revokeAllRefreshTokensForUser(target.id);
  }

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: typeof patch.password === "string" && patch.password ? "password_reset" : "update",
    entityType: "user",
    entityId: id,
  });

  return apiSuccess({ users: users.map(toPublic) }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);

async function deleteImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const { id } = await params;

  const db = tenantDb(auth.session.restaurantId);
  const existing = (await db.users.all()).find((u) => u.id === id);
  if (!existing) return apiError("User not found", 404);
  if (existing.role === "owner" || (auth.session.role === "manager" && existing.role !== "waiter")) {
    return apiError("Not authorized to delete this account", 403);
  }

  const users = await db.users.mutate((cur) => cur.filter((u) => u.id !== id));
  await revokeAllRefreshTokensForUser(id);

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "delete",
    entityType: "user",
    entityId: id,
  });

  return apiSuccess({ users: users.map(toPublic) }, "Operation successful");
}

export const DELETE = withErrorHandling(deleteImpl);
