import { NextRequest } from "next/server";
import { tenantDb, platformDb } from "@/lib/server/db";
import { getSession, requireTenant } from "@/lib/server/session";
import { resolvePublicRestaurant } from "@/lib/server/tenant-context";
import { priceOrder } from "@/lib/server/pricing";
import { notify } from "@/lib/server/notifications";
import { createOrderSchema } from "@/lib/server/validation";
import { readPageParams, paginate } from "@/lib/server/pagination";
import { Order, OrderItem, RESTAURANT_STAFF_ROLES } from "@/lib/types";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { isMenuItemOrderableNow, availabilityMessage } from "@/lib/server/menu-availability";

// Listing every order for a restaurant is a staff-only operation — unlike
// menu/table/settings browsing, this exposes customer names, table
// numbers, and totals across the whole restaurant, not just the one order
// a customer already knows the id of. (An earlier pass of this file
// wrongly used resolvePublicRestaurant here, which would have let anyone
// who knew a restaurantId list every order with no login at all — fixed.)
async function getImpl(req: NextRequest) {
  const auth = await requireTenant(RESTAURANT_STAFF_ROLES);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const db = tenantDb(auth.session.restaurantId);

  const tableNumber = req.nextUrl.searchParams.get("tableNumber");
  const active = req.nextUrl.searchParams.get("active");
  const search = req.nextUrl.searchParams.get("search")?.toLowerCase();
  // includeArchived=1 also pulls in already-billed orders (for admin/order
  // history views) — the active billing queue on its own only ever
  // contains not-yet-billed orders.
  const includeArchived = req.nextUrl.searchParams.get("includeArchived");

  let result = await db.orders.all();
  if (includeArchived === "1") {
    result = [...result, ...(await db.billedOrders.all())];
  }

  if (tableNumber) {
    result = result.filter((o) => o.tableNumber === Number(tableNumber));
  }
  if (active === "1") {
    result = result.filter((o) => o.status !== "completed" && o.status !== "cancelled");
  }
  if (search) {
    result = result.filter(
      (o) =>
        o.id.toLowerCase().includes(search) ||
        o.billNumber?.toLowerCase().includes(search) ||
        o.customerName?.toLowerCase().includes(search) ||
        o.waiterName?.toLowerCase().includes(search)
    );
  }

  result = [...result].sort((a, b) => new Date(b.placedAt).getTime() - new Date(a.placedAt).getTime());

  const page = readPageParams(req);
  const paged = paginate(result, page);
  return apiSuccess(
    { orders: paged.items },
    "Operation successful",
    { pagination: { page: paged.page, pageSize: paged.pageSize, total: paged.total, totalPages: paged.totalPages } }
  );
}

export const GET = withErrorHandling(getImpl);

async function postImpl(req: NextRequest) {
  const tenant = await resolvePublicRestaurant(req);
  if (!tenant.ok) return apiError(tenant.message, tenant.status);
  const restaurantId = tenant.restaurantId;
  const db = tenantDb(restaurantId);

  const body = await req.json().catch(() => null);
  const parsed = createOrderSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const input = parsed.data;
  const tableNumber = input.tableNumber;
  const rawItems = input.items;

  const tables = await db.tables.all();
  const table = tables.find((t) => t.number === tableNumber);
  if (!table) return apiError("Unknown table", 404);

  const session = await getSession();
  const addedBy: OrderItem["addedBy"] =
    session?.role === "waiter" || session?.role === "owner" || session?.role === "manager" ? "waiter" : "customer";

  // Enforce the plan's monthly order limit (a light guard — full metering
  // would count only the current billing month, this checks the tenant's
  // whole live+archived history for simplicity).
  const restaurant = await platformDb.restaurants.get(restaurantId);
  const plan = restaurant ? await platformDb.plans.get(restaurant.planId) : null;
  if (plan && plan.orderLimit >= 0) {
    const [live, archived] = await Promise.all([db.orders.all(), db.billedOrders.all()]);
    if (live.length + archived.length >= plan.orderLimit) {
      return apiError(`Your ${plan.name} plan's order limit has been reached — upgrade to keep taking orders`, 402);
    }
  }

  const [offers, menu, settings, categories] = await Promise.all([
    db.offers.all(),
    db.menu.all(),
    db.settings.get(),
    db.categories.all(),
  ]);
  const menuById = new Map(menu.map((m) => [m.id, m]));
  const categoryById = new Map(categories.map((c) => [c.id, c]));

  const checkAt = new Date();
  for (const raw of rawItems) {
    const menuItem = menuById.get(raw.itemId);
    if (!menuItem) {
      return apiError(`Unknown menu item: ${raw.name || raw.itemId}`, 400);
    }
    const cat = categoryById.get(menuItem.categoryId);
    if (!isMenuItemOrderableNow(menuItem, checkAt, cat)) {
      return apiError(availabilityMessage(menuItem, cat), 400);
    }
  }

  const items: OrderItem[] = rawItems.map((i, idx: number) => {
    const menuItem = menuById.get(i.itemId);
    // Server-side unit price: base + variant delta + selected add-ons (never trust client price)
    let unit = menuItem?.price ?? 0;
    let variantLabel = i.variant;
    if (menuItem?.variants?.length && i.variant) {
      const v =
        menuItem.variants.find((x) => x.id === i.variant || x.label === i.variant) ||
        null;
      if (v) {
        unit += v.priceDelta || 0;
        variantLabel = v.label;
      }
    }
    const selectedAddOns: Array<{ id: string; label: string; priceDelta: number }> = [];
    if (menuItem?.addOns?.length && Array.isArray(i.addOnIds)) {
      for (const aid of i.addOnIds) {
        const a = menuItem.addOns.find((x) => x.id === aid && x.available !== false);
        if (a) {
          selectedAddOns.push({ id: a.id, label: a.label, priceDelta: a.priceDelta || 0 });
          unit += a.priceDelta || 0;
        }
      }
    }
    let preparation = i.preparation as "regular" | "jain" | undefined;
    if (menuItem?.jainOnly) preparation = "jain";
    else if (preparation === "jain" && !menuItem?.jainAvailable) preparation = "regular";

    let cookingRequest = (i.cookingRequest || "").trim() || undefined;
    if (cookingRequest && menuItem?.enableCookingRequest === false) cookingRequest = undefined;
    const maxCR = menuItem?.maxCookingRequestLength ?? 250;
    if (cookingRequest && cookingRequest.length > maxCR) {
      cookingRequest = cookingRequest.slice(0, maxCR);
    }

    // Compose kitchen-friendly note from customizations + free note
    const noteParts: string[] = [];
    if (preparation === "jain") noteParts.push("Jain");
    if (i.spiceLevelSelected) noteParts.push(`Spice: ${i.spiceLevelSelected}`);
    if (selectedAddOns.length) noteParts.push(`Extras: ${selectedAddOns.map((a) => a.label).join(", ")}`);
    if (cookingRequest) noteParts.push(`Request: ${cookingRequest}`);
    if (i.note?.trim()) noteParts.push(i.note.trim());

    return {
      id: `oi-${Date.now()}-${idx}`,
      itemId: i.itemId,
      name: i.name || menuItem?.name || "Item",
      quantity: i.quantity ?? 1,
      price: unit,
      variant: variantLabel,
      note: noteParts.length ? noteParts.join(" · ") : undefined,
      preparation,
      spiceLevelSelected: i.spiceLevelSelected || undefined,
      addOns: selectedAddOns.length ? selectedAddOns : undefined,
      cookingRequest,
      addedBy,
      kotPrinted: false,
      foodType: menuItem?.foodType ?? "other",
      categoryId: menuItem?.categoryId,
      costPrice: menuItem?.costPrice ?? 0,
    };
  });
  const pricing = priceOrder(items, offers, menu, 0, settings.taxRatePercent);

  // Order ids are namespaced by restaurantId — this is what lets the
  // unauthenticated, order-scoped customer routes (items/kot/bill) resolve
  // their tenant straight from the id, with no query param needed.
  const n = await db.counters.next("order");
  const id = `ord-${restaurantId}-${1000 + n}`;
  const now = new Date().toISOString();
  const estimatedMinutes = Math.max(8, ...items.map(() => 0)) + Math.ceil(items.length / 2) * 2;

  const order: Order = {
    id,
    restaurantId,
    tableNumber,
    items,
    status: "accepted",
    placedAt: now,
    updatedAt: now,
    note: input.note,
    customerName: input.customerName,
    waiterName: input.waiterName || table.waiterName,
    estimatedMinutes,
    subtotal: pricing.subtotal,
    manualDiscountPercent: 0,
    appliedOffers: pricing.appliedOffers,
    discountTotal: pricing.discountTotal,
    taxRatePercent: settings.taxRatePercent,
    taxAmount: pricing.taxAmount,
    total: pricing.total,
    kotBatches: 0,
    billGenerated: false,
  };

  await db.orders.mutate((cur) => [order, ...cur]);
  await db.tables.mutate((cur) =>
    cur.map((t) => (t.number === tableNumber ? { ...t, status: "occupied", currentOrderId: order.id } : t))
  );

  // Only notify staff when a customer places the order themselves — a
  // waiter placing it on their own device doesn't need to be told about
  // their own action.
  if (addedBy === "customer") {
    await notify(restaurantId, {
      type: "new_order",
      title: `New order — Table ${tableNumber}`,
      message: `${items.length} item(s), ₹${pricing.total.toFixed(0)} — placed by customer`,
      targetRole: null,
      relatedEntityType: "order",
      relatedEntityId: order.id,
    });
  }

  return apiSuccess({ order }, "Created successfully", { status: 201 });
}

export const POST = withErrorHandling(postImpl);
