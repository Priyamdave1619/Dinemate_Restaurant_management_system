import { NextRequest } from "next/server";
import { tenantDb } from "@/lib/server/db";
import { getSession } from "@/lib/server/session";
import { restaurantIdFromOrderId } from "@/lib/server/tenant-context";
import { priceOrder } from "@/lib/server/pricing";
import { addOrderItemsSchema } from "@/lib/server/validation";
import { OrderItem } from "@/lib/types";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { isMenuItemOrderableNow, availabilityMessage } from "@/lib/server/menu-availability";

// Add items to an already-placed order — used by both the customer table
// page (before the bill is finalized) and the waiter panel. No login is
// required here by design (customers never authenticate); the order id
// itself encodes its tenant and, known only to that table's session, acts
// as the access token.
async function postImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const restaurantId = restaurantIdFromOrderId(id);
  if (!restaurantId) return apiError("Order not found", 404);
  const db = tenantDb(restaurantId);

  const body = await req.json().catch(() => null);
  const parsed = addOrderItemsSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const rawItems = parsed.data.items;

  const session = await getSession();
  const addedBy: OrderItem["addedBy"] =
    session?.role === "waiter" || session?.role === "owner" || session?.role === "manager" ? "waiter" : "customer";

  const [offers, menu, settings, categories] = await Promise.all([
    db.offers.all(),
    db.menu.all(),
    db.settings.get(),
    db.categories.all(),
  ]);
  const menuById = new Map(menu.map((m) => [m.id, m]));
  const categoryById = new Map(categories.map((c) => [c.id, c]));

  const now = new Date();
  for (const raw of rawItems) {
    const menuItem = menuById.get(raw.itemId);
    if (!menuItem) {
      return apiError(`Unknown menu item: ${raw.name || raw.itemId}`, 400);
    }
    const cat = categoryById.get(menuItem.categoryId);
    if (!isMenuItemOrderableNow(menuItem, now, cat)) {
      return apiError(availabilityMessage(menuItem, cat), 400);
    }
  }

  let updated: import("@/lib/types").Order | undefined;
  let errorMsg: string | null = null;

  const orders = await db.orders.mutate((cur) =>
    cur.map((o) => {
      if (o.id !== id) return o;
      if (o.status === "completed" || o.status === "cancelled") {
        errorMsg = "This order is already finalized — items can no longer be added.";
        return o;
      }

      const newItems: OrderItem[] = rawItems.map((i, idx: number) => {
        const menuItem = menuById.get(i.itemId);
        let unit = menuItem?.price ?? 0;
        let variantLabel = i.variant;
        if (menuItem?.variants?.length && i.variant) {
          const v = menuItem.variants.find((x) => x.id === i.variant || x.label === i.variant);
          if (v) {
            unit += v.priceDelta || 0;
            variantLabel = v.label;
          }
        }
        const selectedAddOns: Array<{ id: string; label: string; priceDelta: number }> = [];
        if (menuItem?.addOns?.length && Array.isArray(i.addOnIds)) {
          for (const aid of i.addOnIds) {
            const a = menuItem.addOns.find((x) => x.id === aid && x.available !== false);
            if (a) {
              selectedAddOns.push({ id: a.id, label: a.label, priceDelta: a.priceDelta || 0 });
              unit += a.priceDelta || 0;
            }
          }
        }
        let preparation = i.preparation as "regular" | "jain" | undefined;
        if (menuItem?.jainOnly) preparation = "jain";
        else if (preparation === "jain" && !menuItem?.jainAvailable) preparation = "regular";
        let cookingRequest = (i.cookingRequest || "").trim() || undefined;
        if (cookingRequest && menuItem?.enableCookingRequest === false) cookingRequest = undefined;
        const maxCR = menuItem?.maxCookingRequestLength ?? 250;
        if (cookingRequest && cookingRequest.length > maxCR) cookingRequest = cookingRequest.slice(0, maxCR);
        const noteParts: string[] = [];
        if (preparation === "jain") noteParts.push("Jain");
        if (i.spiceLevelSelected) noteParts.push(`Spice: ${i.spiceLevelSelected}`);
        if (selectedAddOns.length) noteParts.push(`Extras: ${selectedAddOns.map((a) => a.label).join(", ")}`);
        if (cookingRequest) noteParts.push(`Request: ${cookingRequest}`);
        if (i.note?.trim()) noteParts.push(i.note.trim());
        return {
          id: `oi-${Date.now()}-${idx}`,
          itemId: i.itemId,
          name: i.name || menuItem?.name || "Item",
          quantity: i.quantity ?? 1,
          price: unit,
          variant: variantLabel,
          note: noteParts.length ? noteParts.join(" · ") : undefined,
          preparation,
          spiceLevelSelected: i.spiceLevelSelected || undefined,
          addOns: selectedAddOns.length ? selectedAddOns : undefined,
          cookingRequest,
          addedBy,
          kotPrinted: false,
          foodType: menuItem?.foodType ?? "other",
          categoryId: menuItem?.categoryId,
          costPrice: menuItem?.costPrice ?? 0,
        };
      });

      const items = [...o.items, ...newItems];
      const pricing = priceOrder(items, offers, menu, o.manualDiscountPercent, settings.taxRatePercent);

      updated = {
        ...o,
        items,
        subtotal: pricing.subtotal,
        appliedOffers: pricing.appliedOffers,
        discountTotal: pricing.discountTotal,
        taxAmount: pricing.taxAmount,
        total: pricing.total,
        updatedAt: new Date().toISOString(),
      };
      return updated;
    })
  );

  if (errorMsg) return apiError(errorMsg, 409);
  if (!updated) return apiError("Order not found", 404);

  return apiSuccess({ order: updated, orders }, "Operation successful");
}

export const POST = withErrorHandling(postImpl);
