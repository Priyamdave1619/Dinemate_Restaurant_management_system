import { NextRequest } from "next/server";
import { tenantDb, platformDb } from "@/lib/server/db";
import { restaurantIdFromOrderId } from "@/lib/server/tenant-context";
import { archiveBilledOrder } from "@/lib/server/sales";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// Returns (and, on first call, finalizes/numbers/archives) the bill for an
// order. This is what both the waiter's "Print bill" action and the
// customer's "Download bill" button on the table page call. Public — no
// login required, the order id (which encodes its tenant) is the access
// token, same as the other order-scoped routes.
//
// On the FIRST call for a given order, once the bill is generated:
//   - the order is stamped `billGenerated`/`billNumber`/`billedAt`
//   - every line item is written permanently into the sales fact table
//   - daily & monthly stats are incremented
//   - the order is removed from the *active* billing queue (`orders`
//     collection) — but never deleted; it lives on in `billedOrders`
//     forever for reporting, analytics, and audit.
//
// Subsequent calls (e.g. the customer re-opening the bill link) just read
// the already-archived order back out.

/** Merge restaurant profile address/phone into settings for bill display. */
async function settingsForBill(restaurantId: string) {
  const db = tenantDb(restaurantId);
  const settings = await db.settings.get();
  const restaurant = await platformDb.restaurants.get(restaurantId);
  return {
    ...settings,
    restaurantName: (restaurant?.name || settings.restaurantName || restaurantId).trim(),
    address: (restaurant?.address || settings.address || "").trim() || undefined,
    phone: (settings.phone || restaurant?.mobile || "").trim() || undefined,
    foodLicence: (settings.foodLicence || "").trim() || undefined,
    gstin: settings.gstin || undefined,
  };
}

async function getImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const restaurantId = restaurantIdFromOrderId(id);
  if (!restaurantId) return apiError("Order not found", 404);
  const db = tenantDb(restaurantId);

  const settings = await settingsForBill(restaurantId);
  const active = (await db.orders.all()).find((o) => o.id === id);

  if (active) {
    if (active.billGenerated) {
      // Already numbered but somehow still active (shouldn't normally
      // happen) — just return it as-is.
      return apiSuccess({ order: active, settings }, "Operation successful");
    }

    // Bill numbers are per-tenant (via tenantDb's prefixed counter), so
    // every restaurant's sequence starts at its own #0001.
    const n = await db.counters.next("bill");
    const billPrefix = settings.billPrefix || restaurantId;
    const billNumber = `${billPrefix}-${new Date().getFullYear()}-${String(n).padStart(4, "0")}`;
    const billedAt = new Date().toISOString();
    const menu = await db.menu.all();

    const toArchive = {
      ...active,
      billGenerated: true,
      billNumber,
      status: active.status === "cancelled" ? active.status : ("completed" as const),
      updatedAt: billedAt,
    };

    const { order: archived } = await archiveBilledOrder(restaurantId, toArchive, menu, billedAt);

    // Free the table for the next guest once the bill is finalized.
    await db.tables.mutate((cur) =>
      cur.map((t) =>
        t.currentOrderId === id || t.number === active.tableNumber
          ? { ...t, status: "available", currentOrderId: undefined }
          : t
      )
    );

    return apiSuccess({ order: archived, settings }, "Operation successful");
  }

  // Not in the active queue anymore — look it up in the permanent archive.
  const archived = (await db.billedOrders.all()).find((o) => o.id === id);
  if (!archived) return apiError("Order not found", 404);

  return apiSuccess({ order: archived, settings }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);
