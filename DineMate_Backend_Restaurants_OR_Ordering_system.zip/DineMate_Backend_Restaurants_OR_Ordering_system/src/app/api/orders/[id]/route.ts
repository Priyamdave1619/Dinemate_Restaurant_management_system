import { NextRequest } from "next/server";
import { tenantDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { restaurantIdFromOrderId } from "@/lib/server/tenant-context";
import { priceOrder } from "@/lib/server/pricing";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { RESTAURANT_STAFF_ROLES } from "@/lib/types";

// Public: a customer polling their own order needs no login, just the
// order id they were given at creation — which itself encodes the tenant.
async function getImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const restaurantId = restaurantIdFromOrderId(id);
  if (!restaurantId) return apiError("Order not found", 404);

  const db = tenantDb(restaurantId);
  const active = (await db.orders.all()).find((o) => o.id === id);
  if (active) return apiSuccess({ order: active }, "Operation successful");

  // Already billed & archived — still readable (e.g. the customer's order
  // tracker keeps polling this id right after the bill is printed), just no
  // longer part of the active queue.
  const archived = (await db.billedOrders.all()).find((o) => o.id === id);
  if (archived) return apiSuccess({ order: archived }, "Operation successful");

  return apiError("Order not found", 404);
}

export const GET = withErrorHandling(getImpl);

async function patchImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(RESTAURANT_STAFF_ROLES);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  const db = tenantDb(auth.session.restaurantId);
  const patch = await req.json().catch(() => null);
  if (!patch) return apiError("Invalid body", 400);

  const [offers, menu, settings] = await Promise.all([db.offers.all(), db.menu.all(), db.settings.get()]);

  let updated: import("@/lib/types").Order | undefined;
  const orders = await db.orders.mutate((cur) =>
    cur.map((o) => {
      if (o.id !== id) return o;

      const manualDiscountPercent =
        typeof patch.manualDiscountPercent === "number" ? patch.manualDiscountPercent : o.manualDiscountPercent;
      const status = patch.status ?? o.status;
      const paymentMethod = patch.paymentMethod ?? o.paymentMethod;
      const waiterName = patch.waiterName ?? o.waiterName;
      const note = patch.note ?? o.note;

      const pricing = priceOrder(o.items, offers, menu, manualDiscountPercent, settings.taxRatePercent);

      updated = {
        ...o,
        status,
        paymentMethod,
        waiterName,
        note,
        manualDiscountPercent,
        subtotal: pricing.subtotal,
        appliedOffers: pricing.appliedOffers,
        discountTotal: pricing.discountTotal,
        taxAmount: pricing.taxAmount,
        total: pricing.total,
        updatedAt: new Date().toISOString(),
      };
      return updated;
    })
  );

  if (!updated) return apiError("Order not found", 404);

  // Free up / recycle the table once an order is finished (billing still
  // happens separately via the bill route, which is what actually archives
  // the order out of the active queue).
  if (patch.status === "completed" || patch.status === "cancelled") {
    await db.tables.mutate((cur) =>
      cur.map((t) =>
        t.currentOrderId === id
          ? { ...t, status: patch.status === "completed" ? "cleaning" : "available", currentOrderId: undefined }
          : t
      )
    );
  }

  return apiSuccess({ order: updated, orders }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);
