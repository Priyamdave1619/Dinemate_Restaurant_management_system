import { NextRequest } from "next/server";
import { tenantDb } from "@/lib/server/db";
import { restaurantIdFromOrderId } from "@/lib/server/tenant-context";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET returns just the items that haven't been sent to the kitchen printer
// yet (so a re-print only shows what's new since the last KOT batch).
async function getImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const restaurantId = restaurantIdFromOrderId(id);
  if (!restaurantId) return apiError("Order not found", 404);

  const orders = await tenantDb(restaurantId).orders.all();
  const order = orders.find((o) => o.id === id);
  if (!order) return apiError("Order not found", 404);
  const itemsToPrint = order.items.filter((i) => !i.kotPrinted);
  return apiSuccess({ order, itemsToPrint }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);

// POST marks the current pending items as printed and bumps the KOT batch
// counter — call this right after the browser print dialog is confirmed.
async function postImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const restaurantId = restaurantIdFromOrderId(id);
  if (!restaurantId) return apiError("Order not found", 404);

  let updated: import("@/lib/types").Order | undefined;
  const db = tenantDb(restaurantId);

  await db.orders.mutate((cur) =>
    cur.map((o) => {
      if (o.id !== id) return o;
      updated = {
        ...o,
        items: o.items.map((i) => ({ ...i, kotPrinted: true })),
        kotBatches: o.kotBatches + 1,
        updatedAt: new Date().toISOString(),
      };
      return updated;
    })
  );

  if (!updated) return apiError("Order not found", 404);
  return apiSuccess({ order: updated }, "Operation successful");
}

export const POST = withErrorHandling(postImpl);
