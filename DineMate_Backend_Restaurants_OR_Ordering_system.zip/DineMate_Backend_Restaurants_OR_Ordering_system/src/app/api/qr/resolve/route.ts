import { NextRequest } from "next/server";
import { decryptQrPayload } from "@/lib/server/qr-crypto";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

/**
 * Public endpoint: resolve an encrypted QR token to restaurantId + tableNumber.
 * Used by the customer portal when client-side decryption is unavailable
 * or as a trusted server-side fallback.
 *
 * GET /api/qr/resolve?token=...
 */
async function getImpl(req: NextRequest) {
  const token =
    req.nextUrl.searchParams.get("token") ||
    req.nextUrl.searchParams.get("t") ||
    "";
  if (!token.trim()) {
    return apiError("Missing token", 400);
  }

  const resolved = decryptQrPayload(token);
  if (!resolved) {
    return apiError("Invalid or corrupted QR token", 400);
  }

  return apiSuccess(
    {
      restaurantId: resolved.restaurantId,
      tableNumber: resolved.tableNumber,
    },
    "OK"
  );
}

export const GET = withErrorHandling(getImpl);
