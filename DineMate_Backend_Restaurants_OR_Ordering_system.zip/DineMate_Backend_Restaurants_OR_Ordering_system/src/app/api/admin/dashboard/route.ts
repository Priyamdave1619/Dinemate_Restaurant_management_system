import { platformDb } from "@/lib/server/db";
import { drizzleDb } from "@/lib/server/pg-store";
import * as schema from "@/lib/server/schema";
import { eq } from "drizzle-orm";
import { requireRole } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/admin/dashboard — the numbers a Product Owner lands on:
// restaurant counts by status, today's platform-wide orders/revenue,
// per-plan breakdown, and the most recently registered restaurants.
async function getImpl() {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const restaurants = await platformDb.restaurants.all();
  const users = await platformDb.users.all();
  const now = Date.now();
  const todayKey = new Date().toISOString().slice(0, 10);
  const monthKey = new Date().toISOString().slice(0, 7);

  const [todayRows, monthRows] = await Promise.all([
    drizzleDb.select().from(schema.dailyStats).where(eq(schema.dailyStats.dateKey, todayKey)),
    drizzleDb.select().from(schema.monthlyStats).where(eq(schema.monthlyStats.monthKey, monthKey)),
  ]);

  const todayStats = todayRows.map((r) => r.data as { orderCount?: number; netRevenue?: number; grossSales?: number; netSales?: number });
  const monthStats = monthRows.map((r) => r.data as { orderCount?: number; netRevenue?: number; grossSales?: number; netSales?: number });

  const todaysOrders = todayStats.reduce((s, d) => s + (d.orderCount || 0), 0);
  const todaysRevenue = todayStats.reduce((s, d) => s + (d.netSales || d.netRevenue || d.grossSales || 0), 0);
  const monthlyRevenue = monthStats.reduce((s, d) => s + (d.netSales || d.netRevenue || d.grossSales || 0), 0);

  const planCounts: Record<string, number> = {};
  for (const r of restaurants) planCounts[r.planId] = (planCounts[r.planId] || 0) + 1;

  const recentRegistrations = [...restaurants]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 10)
    .map((r) => ({ id: r.id, name: r.name, ownerName: r.ownerName, status: r.status, createdAt: r.createdAt, planId: r.planId }));

  return apiSuccess(
    {
      restaurants: {
        total: restaurants.length,
        active: restaurants.filter((r) => r.status === "active").length,
        suspended: restaurants.filter((r) => r.status === "suspended").length,
        pending: restaurants.filter((r) => r.status === "pending").length,
        expiredSubscriptions: restaurants.filter((r) => new Date(r.subscriptionExpiresAt).getTime() < now).length,
      },
      staff: {
        managers: users.filter((u) => u.role === "manager").length,
        waiters: users.filter((u) => u.role === "waiter").length,
        owners: users.filter((u) => u.role === "owner").length,
      },
      today: { orders: todaysOrders, revenue: todaysRevenue },
      monthlyRevenue,
      plansInUse: planCounts,
      recentRegistrations,
    },
    "Dashboard fetched"
  );
}

export const GET = withErrorHandling(getImpl);
