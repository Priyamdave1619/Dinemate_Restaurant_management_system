import { NextRequest } from "next/server";
import { platformDb } from "@/lib/server/db";
import { requireRole } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/admin/audit-logs?restaurantId=REST000021 — platform-wide by
// default, or filtered to one tenant. Also serves as the Login History /
// Activity Log view the spec calls for.
async function getImpl(req: NextRequest) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const restaurantId = req.nextUrl.searchParams.get("restaurantId") || undefined;
  const kind = req.nextUrl.searchParams.get("kind") === "logins" ? "logins" : "audit";

  if (kind === "logins") {
    const logins = await platformDb.loginHistory.list(restaurantId ? { restaurantId } : {}, 200);
    return apiSuccess({ logins }, "Operation successful");
  }

  const logs = await platformDb.auditLogs.list(restaurantId ? { restaurantId } : {}, 200);
  return apiSuccess({ logs }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);
