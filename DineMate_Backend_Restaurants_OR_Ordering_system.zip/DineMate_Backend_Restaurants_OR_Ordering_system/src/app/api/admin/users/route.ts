import { NextRequest } from "next/server";
import { randomUUID } from "crypto";
import { z } from "zod";
import { platformDb } from "@/lib/server/db";
import { requireRole } from "@/lib/server/session";
import { hashPassword } from "@/lib/server/auth";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

async function getImpl(req: NextRequest) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const sp = req.nextUrl.searchParams;
  const role = sp.get("role") || undefined;
  const restaurantId = sp.get("restaurantId") || undefined;
  const search = (sp.get("search") || "").trim().toLowerCase();
  const activeParam = sp.get("active");
  const page = Math.max(1, Number(sp.get("page")) || 1);
  const pageSize = Math.min(1000, Math.max(1, Number(sp.get("pageSize")) || 25));

  let users = await platformDb.users.all();

  if (role) users = users.filter((u) => u.role === role);
  if (restaurantId) users = users.filter((u) => u.restaurantId === restaurantId);
  if (activeParam === "true") users = users.filter((u) => u.active !== false);
  if (activeParam === "false") users = users.filter((u) => u.active === false);
  if (search) {
    users = users.filter(
      (u) =>
        u.username?.toLowerCase().includes(search) ||
        u.name?.toLowerCase().includes(search) ||
        u.id?.toLowerCase().includes(search)
    );
  }

  const sanitized = users.map((u) => ({
    id: u.id,
    username: u.username,
    name: u.name,
    role: u.role,
    restaurantId: u.restaurantId ?? null,
    active: u.active !== false,
    createdAt: u.createdAt,
    lastLoginAt: (u as { lastLoginAt?: string }).lastLoginAt,
  }));

  const total = sanitized.length;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const start = (page - 1) * pageSize;
  const pageUsers = sanitized.slice(start, start + pageSize);

  const byRole = {
    super_admin: sanitized.filter((u) => u.role === "super_admin").length,
    owner: sanitized.filter((u) => u.role === "owner").length,
    manager: sanitized.filter((u) => u.role === "manager").length,
    waiter: sanitized.filter((u) => u.role === "waiter").length,
  };

  return apiSuccess(
    { users: pageUsers, summary: { total, byRole } },
    "Users fetched",
    { pagination: { page, pageSize, total, totalPages } }
  );
}

export const GET = withErrorHandling(getImpl);

const createSchema = z.object({
  name: z.string().trim().min(1).max(120),
  username: z
    .string()
    .trim()
    .min(3)
    .max(100)
    .regex(/^[a-zA-Z0-9._@-]+$/, "Username may only contain letters, numbers, and . _ @ -"),
  password: z.string().min(8, "Password must be at least 8 characters").max(200),
  // Platform-level admins only — both map to super_admin in the data model
  role: z.enum(["super_admin", "admin"]).default("admin"),
});

// POST /api/admin/users — create a platform Super Admin / Admin account
async function postImpl(req: NextRequest) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }

  const username = parsed.data.username.toLowerCase();
  const existing = await platformDb.users.findByUsername(username);
  if (existing) {
    return apiError("Username is already taken", 409);
  }

  const { hash, salt } = hashPassword(parsed.data.password);
  const now = new Date().toISOString();
  const user = {
    id: `user-${randomUUID()}`,
    username,
    name: parsed.data.name.trim(),
    role: "super_admin" as const,
    restaurantId: null as string | null,
    passwordHash: hash,
    passwordSalt: salt,
    active: true,
    permissions: [] as string[],
    createdAt: now,
  };

  await platformDb.superAdmins.mutate((cur) => [...cur, user]);

  await platformDb.auditLogs.log({
    restaurantId: null,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: "super_admin",
    action: "create",
    entityType: "user",
    entityId: user.id,
    details: { username: user.username, role: user.role, label: parsed.data.role },
  });

  return apiSuccess(
    {
      user: {
        id: user.id,
        username: user.username,
        name: user.name,
        role: user.role,
        restaurantId: null,
        active: true,
        createdAt: user.createdAt,
      },
    },
    "Admin account created",
    { status: 201 }
  );
}

export const POST = withErrorHandling(postImpl);
