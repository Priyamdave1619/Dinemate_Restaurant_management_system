import { NextRequest } from "next/server";
import { platformDb } from "@/lib/server/db";
import { drizzleDb } from "@/lib/server/pg-store";
import * as schema from "@/lib/server/schema";
import { eq } from "drizzle-orm";
import { requireRole } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/admin/reports/revenue?month=2026-08
// Restaurant-wise revenue report for Super Admin.
async function getImpl(req: NextRequest) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const month =
    req.nextUrl.searchParams.get("month") || new Date().toISOString().slice(0, 7);

  const restaurants = await platformDb.restaurants.all();
  const monthRows = await drizzleDb
    .select()
    .from(schema.monthlyStats)
    .where(eq(schema.monthlyStats.monthKey, month));

  const byRestaurant = new Map<
    string,
    { netSales: number; grossSales: number; orderCount: number; taxTotal: number }
  >();

  for (const row of monthRows) {
    const d = row.data as {
      netSales?: number;
      netRevenue?: number;
      grossSales?: number;
      orderCount?: number;
      taxTotal?: number;
    };
    byRestaurant.set(row.restaurantId, {
      netSales: d.netSales || d.netRevenue || 0,
      grossSales: d.grossSales || 0,
      orderCount: d.orderCount || 0,
      taxTotal: d.taxTotal || 0,
    });
  }

  const rows = restaurants
    .map((r) => {
      const stats = byRestaurant.get(r.id) || {
        netSales: 0,
        grossSales: 0,
        orderCount: 0,
        taxTotal: 0,
      };
      return {
        restaurantId: r.id,
        name: r.name,
        ownerName: r.ownerName,
        status: r.status,
        planId: r.planId,
        ...stats,
      };
    })
    .sort((a, b) => b.netSales - a.netSales);

  const totals = rows.reduce(
    (acc, r) => ({
      netSales: acc.netSales + r.netSales,
      grossSales: acc.grossSales + r.grossSales,
      orderCount: acc.orderCount + r.orderCount,
      taxTotal: acc.taxTotal + r.taxTotal,
    }),
    { netSales: 0, grossSales: 0, orderCount: 0, taxTotal: 0 }
  );

  return apiSuccess({ month, rows, totals }, "Revenue report");
}

export const GET = withErrorHandling(getImpl);
