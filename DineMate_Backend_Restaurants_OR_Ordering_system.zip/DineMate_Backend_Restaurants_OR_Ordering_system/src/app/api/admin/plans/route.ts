import { NextRequest } from "next/server";
import { randomUUID } from "crypto";
import { platformDb } from "@/lib/server/db";
import { requireRole } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

async function getImpl() {
  const auth = await requireRole(["super_admin", "owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  // Every role can view plans (owners need this to self-serve upgrades);
  // only super_admin can create/edit them (POST/PATCH below).
  const plans = await platformDb.plans.all();
  return apiSuccess({ plans }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);

async function postImpl(req: NextRequest) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const required = ["name", "durationDays", "price"] as const;
  for (const field of required) {
    if (body?.[field] === undefined) return apiError(`${field} is required`, 400);
  }

  const plan = {
    id: typeof body.id === "string" && body.id ? body.id : randomUUID(),
    name: String(body.name),
    durationDays: Number(body.durationDays),
    price: Number(body.price),
    currency: typeof body.currency === "string" ? body.currency : "INR",
    productLimit: Number(body.productLimit ?? -1),
    orderLimit: Number(body.orderLimit ?? -1),
    userLimit: Number(body.userLimit ?? -1),
    storageLimitMb: Number(body.storageLimitMb ?? 1024),
    features: Array.isArray(body.features) ? body.features.map(String) : [],
    active: body.active !== false,
    createdAt: new Date().toISOString(),
  };

  const plans = await platformDb.plans.mutate((cur) => {
    if (cur.some((p) => p.id === plan.id)) throw new Error("A plan with this id already exists");
    return [...cur, plan];
  });

  return apiSuccess({ plans, plan }, "Created successfully", { status: 201 });
}

export const POST = withErrorHandling(postImpl);
