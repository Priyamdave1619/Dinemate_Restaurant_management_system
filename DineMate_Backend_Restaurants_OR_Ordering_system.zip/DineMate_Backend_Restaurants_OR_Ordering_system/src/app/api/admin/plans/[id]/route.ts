import { NextRequest } from "next/server";
import { platformDb } from "@/lib/server/db";
import { requireRole } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

async function patchImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (!body) return apiError("Invalid body", 400);

  let found = false;
  const plans = await platformDb.plans.mutate((cur) =>
    cur.map((p) => {
      if (p.id !== id) return p;
      found = true;
      return {
        ...p,
        ...(typeof body.name === "string" ? { name: body.name } : {}),
        ...(body.durationDays !== undefined ? { durationDays: Number(body.durationDays) } : {}),
        ...(body.price !== undefined ? { price: Number(body.price) } : {}),
        ...(body.productLimit !== undefined ? { productLimit: Number(body.productLimit) } : {}),
        ...(body.orderLimit !== undefined ? { orderLimit: Number(body.orderLimit) } : {}),
        ...(body.userLimit !== undefined ? { userLimit: Number(body.userLimit) } : {}),
        ...(body.storageLimitMb !== undefined ? { storageLimitMb: Number(body.storageLimitMb) } : {}),
        ...(Array.isArray(body.features) ? { features: body.features.map(String) } : {}),
        ...(body.active !== undefined ? { active: !!body.active } : {}),
      };
    })
  );

  if (!found) return apiError("Plan not found", 404);
  return apiSuccess({ plans, plan: plans.find((p) => p.id === id) }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);

async function deleteImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  const inUse = (await platformDb.restaurants.all()).some((r) => r.planId === id);
  if (inUse) {
    return apiError("Plan is in use by at least one restaurant — deactivate it instead", 409);
  }

  let found = false;
  const plans = await platformDb.plans.mutate((cur) => {
    const next = cur.filter((p) => p.id !== id);
    found = next.length !== cur.length;
    return next;
  });

  if (!found) return apiError("Plan not found", 404);
  return apiSuccess({ plans }, "Operation successful");
}

export const DELETE = withErrorHandling(deleteImpl);
