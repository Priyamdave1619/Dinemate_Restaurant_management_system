import { NextRequest } from "next/server";
import { platformDb } from "@/lib/server/db";
import { requireRole } from "@/lib/server/session";
import { registerRestaurant } from "@/lib/server/restaurants";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/admin/restaurants?status=active&search=blue+lagoon
// Cross-tenant restaurant list for the Super Admin dashboard, with basic
// pagination/search/filtering as required by the platform spec.
async function getImpl(req: NextRequest) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const status = req.nextUrl.searchParams.get("status");
  const planId = req.nextUrl.searchParams.get("planId");
  const search = req.nextUrl.searchParams.get("search")?.toLowerCase();
  const page = Math.max(1, Number(req.nextUrl.searchParams.get("page")) || 1);
  const pageSize = Math.min(1000, Math.max(1, Number(req.nextUrl.searchParams.get("pageSize")) || 20));

  let restaurants = await platformDb.restaurants.all();
  if (status) restaurants = restaurants.filter((r) => r.status === status);
  if (planId) restaurants = restaurants.filter((r) => r.planId === planId);
  if (search) {
    restaurants = restaurants.filter(
      (r) =>
        r.name.toLowerCase().includes(search) ||
        r.id.toLowerCase().includes(search) ||
        r.email.toLowerCase().includes(search) ||
        r.ownerName.toLowerCase().includes(search)
    );
  }
  const sortBy = req.nextUrl.searchParams.get("sortBy") || "createdAt";
  const sortDir = req.nextUrl.searchParams.get("sortDir") === "asc" ? 1 : -1;
  restaurants = [...restaurants].sort((a, b) => {
    if (sortBy === "name") return a.name.localeCompare(b.name) * sortDir;
    if (sortBy === "status") return a.status.localeCompare(b.status) * sortDir;
    if (sortBy === "planId") return String(a.planId).localeCompare(String(b.planId)) * sortDir;
    if (sortBy === "subscriptionExpiresAt") {
      return (new Date(a.subscriptionExpiresAt).getTime() - new Date(b.subscriptionExpiresAt).getTime()) * sortDir;
    }
    return (new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()) * sortDir;
  });

  const total = restaurants.length;
  const start = (page - 1) * pageSize;
  const pageItems = restaurants.slice(start, start + pageSize);

  const summary = {
    total,
    active: restaurants.filter((r) => r.status === "active").length,
    suspended: restaurants.filter((r) => r.status === "suspended").length,
    pending: restaurants.filter((r) => r.status === "pending").length,
    expiredSubscriptions: restaurants.filter((r) => new Date(r.subscriptionExpiresAt).getTime() < Date.now()).length,
  };

  return apiSuccess(
    { restaurants: pageItems, summary },
    "Operation successful",
    { pagination: { page, pageSize, total, totalPages: Math.max(1, Math.ceil(total / pageSize)) } }
  );
}

export const GET = withErrorHandling(getImpl);

// POST /api/admin/restaurants — Super Admin directly provisions a
// restaurant + owner login (same underlying logic as public self-signup).
async function postImpl(req: NextRequest) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const required = ["name", "ownerName", "email", "mobile", "password"] as const;
  for (const field of required) {
    if (!body?.[field] || typeof body[field] !== "string") {
      return apiError(`${field} is required`, 400);
    }
  }

  const { restaurant, owner } = await registerRestaurant({
    name: body.name,
    ownerName: body.ownerName,
    email: body.email,
    mobile: body.mobile,
    password: body.password,
    address: body.address,
    gstNumber: body.gstNumber,
    timezone: body.timezone,
    currency: body.currency,
    planId: body.planId,
  });

  await platformDb.auditLogs.log({
    restaurantId: restaurant.id,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: "super_admin",
    action: "restaurant_created",
    entityType: "restaurant",
    entityId: restaurant.id,
    details: { provisionedBySuperAdmin: true },
  });

  return apiSuccess({ restaurant, owner: { username: owner.username, name: owner.name } }, "Restaurant provisioned successfully", { status: 201 });
}

export const POST = withErrorHandling(postImpl);
