import { NextRequest } from "next/server";
import { platformDb } from "@/lib/server/db";
import { requireRole } from "@/lib/server/session";
import { sendEmail, restaurantSuspendedEmail, subscriptionRenewedEmail } from "@/lib/server/email";
import { AuditAction } from "@/lib/types";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

async function getImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  const restaurant = await platformDb.restaurants.get(id);
  if (!restaurant) return apiError("Restaurant not found", 404);

  const [staff, loginHistory, auditLogs] = await Promise.all([
    (await platformDb.users.all()).filter((u) => u.restaurantId === id),
    platformDb.loginHistory.list({ restaurantId: id }, 50),
    platformDb.auditLogs.list({ restaurantId: id }, 50),
  ]);

  return apiSuccess(
    {
      restaurant,
      staff: staff.map((u) => ({ id: u.id, username: u.username, name: u.name, role: u.role, active: u.active })),
      loginHistory,
      auditLogs,
    },
    "Restaurant detail fetched"
  );
}

export const GET = withErrorHandling(getImpl);

// PATCH /api/admin/restaurants/[id]
// Body can include any of: { status, planId, extendDays, name, ownerName,
// email, mobile, address, gstNumber }. `status` transitions to "active" |
// "suspended". Renewing a subscription is `{ renew: true, days: 30 }` (or
// pass a new `planId` to upgrade/downgrade at the same time).
async function patchImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (!body) return apiError("Invalid body", 400);

  if (body.status && !["active", "suspended", "pending"].includes(body.status)) {
    return apiError("status must be active, suspended, or pending", 400);
  }
  if (body.planId && !(await platformDb.plans.get(body.planId))) {
    return apiError("Unknown planId", 400);
  }

  let found = false;
  let statusChanged: "restaurant_activated" | "restaurant_suspended" | null = null;
  let planChanged = false;
  const restaurants = await platformDb.restaurants.mutate((cur) =>
    cur.map((r) => {
      if (r.id !== id) return r;
      found = true;
      const next = { ...r, updatedAt: new Date().toISOString() };

      if (typeof body.name === "string") next.name = body.name;
      if (typeof body.ownerName === "string") next.ownerName = body.ownerName;
      if (typeof body.email === "string") next.email = body.email.toLowerCase();
      if (typeof body.mobile === "string") next.mobile = body.mobile;
      if (typeof body.address === "string") next.address = body.address;
      if (typeof body.gstNumber === "string") next.gstNumber = body.gstNumber;

      if (body.status && body.status !== r.status) {
        next.status = body.status;
        if (body.status === "active" && r.status === "suspended") statusChanged = "restaurant_activated";
        if (body.status === "suspended") statusChanged = "restaurant_suspended";
      }

      if (body.planId && body.planId !== r.planId) {
        next.planId = body.planId;
        planChanged = true;
      }

      if (body.renew) {
        const days = Number(body.days) || 30;
        const base = new Date(r.subscriptionExpiresAt).getTime() > Date.now() ? new Date(r.subscriptionExpiresAt) : new Date();
        next.subscriptionExpiresAt = new Date(base.getTime() + days * 86400000).toISOString();
        next.subscriptionStatus = "active";
        next.renewedAt = new Date().toISOString();
      }

      return next;
    })
  );

  if (!found) return apiError("Restaurant not found", 404);
  const restaurant = restaurants.find((r) => r.id === id)!;

  if (statusChanged === "restaurant_suspended" && restaurant.email) {
    await sendEmail({
      ...restaurantSuspendedEmail({ ownerName: restaurant.ownerName, restaurantName: restaurant.name }),
      to: restaurant.email,
    });
  }
  if (body.renew && restaurant.email) {
    const plan = await platformDb.plans.get(restaurant.planId);
    await sendEmail({
      ...subscriptionRenewedEmail({
        ownerName: restaurant.ownerName,
        expiresAt: restaurant.subscriptionExpiresAt,
        planName: plan?.name ?? restaurant.planId,
      }),
      to: restaurant.email,
    });
  }

  const actions: AuditAction[] = [];
  if (statusChanged) actions.push(statusChanged);
  if (planChanged || body.renew) actions.push("subscription_change");
  for (const action of actions.length ? actions : (["update"] as AuditAction[])) {
    await platformDb.auditLogs.log({
      restaurantId: id,
      actorUserId: auth.session.sub,
      actorName: auth.session.name,
      actorRole: "super_admin",
      action,
      entityType: "restaurant",
      entityId: id,
      details: body,
    });
  }

  return apiSuccess({ restaurant }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);

// DELETE /api/admin/restaurants/[id] — permanently removes the restaurant
// record. Business data (orders, menu, etc.) is left in place under its
// restaurantId scope for audit/compliance purposes rather than hard-deleted
// here; wire up a retention job if full data erasure is required.
async function deleteImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  let found = false;
  const restaurants = await platformDb.restaurants.mutate((cur) => {
    const next = cur.filter((r) => r.id !== id);
    found = next.length !== cur.length;
    return next;
  });

  if (!found) return apiError("Restaurant not found", 404);

  await platformDb.auditLogs.log({
    restaurantId: id,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: "super_admin",
    action: "restaurant_deleted",
    entityType: "restaurant",
    entityId: id,
  });

  return apiSuccess({ restaurants }, "Operation successful");
}

export const DELETE = withErrorHandling(deleteImpl);
