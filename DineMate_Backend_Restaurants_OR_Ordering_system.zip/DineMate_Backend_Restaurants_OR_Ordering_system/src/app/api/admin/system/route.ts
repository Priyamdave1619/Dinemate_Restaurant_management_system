import { NextRequest } from "next/server";
import { platformDb } from "@/lib/server/db";
import { requireRole } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/admin/system — Super Admin system health & platform metrics
async function getImpl(_req: NextRequest) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const started = Date.now();
  let dbOk = false;
  let dbLatencyMs = 0;
  let restaurantCount = 0;
  let userCount = 0;
  let planCount = 0;

  try {
    const t0 = Date.now();
    const [restaurants, users, plans] = await Promise.all([
      platformDb.restaurants.all(),
      platformDb.users.all(),
      platformDb.plans.all(),
    ]);
    dbLatencyMs = Date.now() - t0;
    dbOk = true;
    restaurantCount = restaurants.length;
    userCount = users.length;
    planCount = plans.length;
  } catch {
    dbOk = false;
  }

  const memory = process.memoryUsage();
  const uptimeSec = Math.floor(process.uptime());

  return apiSuccess(
    {
      status: dbOk ? "healthy" : "degraded",
      checkedAt: new Date().toISOString(),
      responseTimeMs: Date.now() - started,
      database: {
        connected: dbOk,
        latencyMs: dbLatencyMs,
      },
      process: {
        nodeVersion: process.version,
        uptimeSec,
        memory: {
          rssMb: Math.round(memory.rss / 1024 / 1024),
          heapUsedMb: Math.round(memory.heapUsed / 1024 / 1024),
          heapTotalMb: Math.round(memory.heapTotal / 1024 / 1024),
        },
      },
      platform: {
        restaurants: restaurantCount,
        users: userCount,
        plans: planCount,
      },
      env: {
        nodeEnv: process.env.NODE_ENV || "development",
        hasRazorpay: Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET),
        hasCronSecret: Boolean(process.env.CRON_SECRET),
        hasS3: Boolean(process.env.S3_BUCKET || process.env.R2_BUCKET),
      },
    },
    "System status"
  );
}

export const GET = withErrorHandling(getImpl);
