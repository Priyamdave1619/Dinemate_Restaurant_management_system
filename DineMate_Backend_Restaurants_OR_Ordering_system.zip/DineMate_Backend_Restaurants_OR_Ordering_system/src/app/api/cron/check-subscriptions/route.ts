import { NextRequest } from "next/server";
import { platformDb, tenantDb } from "@/lib/server/db";
import { notify } from "@/lib/server/notifications";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/cron/check-subscriptions
//
// The subscription-expiry check in /api/auth/login is reactive — it only
// warns an owner once they log in, which is exactly the thing an expired
// restaurant CAN'T do anymore. This endpoint is the proactive counterpart:
// scan every restaurant daily and notify owners approaching (or past)
// expiry regardless of whether anyone logs in.
//
// Wire this up with a scheduler that hits it once a day, e.g. Vercel Cron
// (add to vercel.json: {"crons":[{"path":"/api/cron/check-subscriptions",
// "schedule":"0 3 * * *"}]}) or any external cron service. Protected by
// CRON_SECRET so it can't be triggered by anyone who finds the URL.
async function getImpl(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  const provided = req.headers.get("authorization")?.replace("Bearer ", "");
  if (!secret || provided !== secret) {
    return apiError("Unauthorized", 401);
  }

  const restaurants = await platformDb.restaurants.all();
  const now = Date.now();
  const todayKey = new Date().toISOString().slice(0, 10);

  let warned = 0;
  let expired = 0;

  for (const r of restaurants) {
    if (r.status !== "active") continue;
    const daysLeft = (new Date(r.subscriptionExpiresAt).getTime() - now) / 86400000;
    const notifType = daysLeft < 0 ? "subscription_expired" : daysLeft <= 5 ? "subscription_expiring" : null;
    if (!notifType) continue;

    const existing = await tenantDb(r.id).notifications.all();
    const alreadySentToday = existing.some((n) => n.type === notifType && n.createdAt.slice(0, 10) === todayKey);
    if (alreadySentToday) continue;

    await notify(r.id, {
      type: notifType,
      title: notifType === "subscription_expired" ? "Subscription expired" : "Subscription expiring soon",
      message:
        notifType === "subscription_expired"
          ? "Your subscription has expired — renew now to restore login, orders, and dashboard access."
          : `Your plan expires in ${Math.max(0, Math.ceil(daysLeft))} day(s) — renew to avoid any interruption.`,
      targetRole: "owner",
    });

    if (notifType === "subscription_expired") expired += 1;
    else warned += 1;
  }

  return apiSuccess({ checked: restaurants.length, warned, expired }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);
