import { NextRequest } from "next/server";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { updateMenuItemSchema } from "@/lib/server/validation";

async function patchImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  const body = await req.json().catch(() => null);
  const parsed = updateMenuItemSchema.safeParse(body);
  if (!parsed.success) return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  const patch = parsed.data;

  let found = false;
  const items = await tenantDb(auth.session.restaurantId).menu.mutate((cur) =>
    cur.map((i) => {
      if (i.id !== id) return i;
      found = true;
      return { ...i, ...patch, id: i.id, restaurantId: i.restaurantId };
    })
  );

  if (!found) return apiError("Item not found", 404);

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "update",
    entityType: "menuItem",
    entityId: id,
  });

  return apiSuccess({ items }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);

async function deleteImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  const items = await tenantDb(auth.session.restaurantId).menu.mutate((cur) => cur.filter((i) => i.id !== id));

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "delete",
    entityType: "menuItem",
    entityId: id,
  });

  return apiSuccess({ items }, "Operation successful");
}

export const DELETE = withErrorHandling(deleteImpl);
