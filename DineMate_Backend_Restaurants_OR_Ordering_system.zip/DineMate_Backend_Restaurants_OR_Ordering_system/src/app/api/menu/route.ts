import { NextRequest } from "next/server";
import { randomUUID } from "crypto";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { resolvePublicRestaurant } from "@/lib/server/tenant-context";
import { createMenuItemSchema } from "@/lib/server/validation";
import { readPageParams, paginate, applySort } from "@/lib/server/pagination";
import { MenuItem } from "@/lib/types";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { withAvailabilityFlags } from "@/lib/server/menu-availability";

// GET supports optional ?search=, ?categoryId=, ?sort=name|price&order=,
// and ?page=&pageSize= — all optional and additive. Pagination is
// deliberately opt-in (only applied when `page` or `pageSize` is actually
// passed) rather than defaulted, since the primary caller of this endpoint
// is the public customer menu page, which wants the *entire* menu on one
// screen, not page 1 of N. A staff-side "manage 500 products" view can
// pass page/pageSize/search/sort explicitly to get a manageable list.
async function getImpl(req: NextRequest) {
  const tenant = await resolvePublicRestaurant(req);
  if (!tenant.ok) return apiError(tenant.message, tenant.status);

  let items = await tenantDb(tenant.restaurantId).menu.all();

  const categoryId = req.nextUrl.searchParams.get("categoryId");
  if (categoryId) items = items.filter((i) => i.categoryId === categoryId);

  const search = req.nextUrl.searchParams.get("search")?.toLowerCase();
  if (search) {
    items = items.filter((i) => i.name.toLowerCase().includes(search) || i.description?.toLowerCase().includes(search));
  }

  items = applySort(items, req, ["name", "price", "prepTimeMinutes"] as const);

  const wantsPagination = req.nextUrl.searchParams.has("page") || req.nextUrl.searchParams.has("pageSize");
  const cats = await tenantDb(tenant.restaurantId).categories.all();
  const categoryById = new Map(cats.map((c) => [c.id, c]));
  const annotated = withAvailabilityFlags(items, new Date(), categoryById);
  if (!wantsPagination) return apiSuccess({ items: annotated }, "Operation successful");

  const paged = paginate(annotated, readPageParams(req));
  return apiSuccess(
    { items: paged.items },
    "Operation successful",
    { pagination: { page: paged.page, pageSize: paged.pageSize, total: paged.total, totalPages: paged.totalPages } }
  );
}

export const GET = withErrorHandling(getImpl);

async function postImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const parsed = createMenuItemSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const input = parsed.data;

  const db = tenantDb(auth.session.restaurantId);

  const restaurant = await platformDb.restaurants.get(auth.session.restaurantId);
  const plan = restaurant ? await platformDb.plans.get(restaurant.planId) : null;
  if (plan && plan.productLimit >= 0) {
    const current = await db.menu.all();
    if (current.length >= plan.productLimit) {
      return apiError(`Your ${plan.name} plan allows up to ${plan.productLimit} products — upgrade to add more`, 402);
    }
  }

  const item: MenuItem = {
    id: `item-${randomUUID()}`,
    restaurantId: auth.session.restaurantId,
    name: input.name,
    description: input.description || "",
    categoryId: input.categoryId,
    price: input.price,
    image: input.image || "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&q=80",
    prepTimeMinutes: input.prepTimeMinutes ?? 8,
    available: input.available ?? true,
    spiceLevel: input.spiceLevel || "mild",
    isVeg: input.isVeg ?? true,
    foodType: input.foodType || (input.isVeg === false ? "non-veg" : "veg"),
    costPrice: input.costPrice ?? 0,
    variants: input.variants,
    jainAvailable: input.jainAvailable,
    jainOnly: input.jainOnly,
    enableSpiceLevel: input.enableSpiceLevel,
    spiceOptions: input.spiceOptions,
    enableCookingRequest: input.enableCookingRequest,
    maxCookingRequestLength: input.maxCookingRequestLength,
    addOns: input.addOns,
    tags: input.tags,
    ingredients: input.ingredients,
    allergens: input.allergens,
    scheduleEnabled: input.scheduleEnabled ?? false,
    availableFrom: input.scheduleEnabled ? input.availableFrom : undefined,
    availableTo: input.scheduleEnabled ? input.availableTo : undefined,
  };

  const items = await db.menu.mutate((cur) => [...cur, item]);
  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "create",
    entityType: "menuItem",
    entityId: item.id,
  });
  return apiSuccess({ item, items }, "Created successfully", { status: 201 });
}

export const POST = withErrorHandling(postImpl);
