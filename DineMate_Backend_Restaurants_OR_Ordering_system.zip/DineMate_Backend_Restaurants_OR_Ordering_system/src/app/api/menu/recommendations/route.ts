import { NextRequest } from "next/server";
import { resolvePublicRestaurant } from "@/lib/server/tenant-context";
import { getMenuRecommendations } from "@/lib/server/recommendations";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

/** Public — customer menu bestsellers + non-AI recommendations. */
async function getImpl(req: NextRequest) {
  const tenant = await resolvePublicRestaurant(req);
  if (!tenant.ok) return apiError(tenant.message, tenant.status);

  const data = await getMenuRecommendations(tenant.restaurantId);
  return apiSuccess(data, "Operation successful");
}

export const GET = withErrorHandling(getImpl);
