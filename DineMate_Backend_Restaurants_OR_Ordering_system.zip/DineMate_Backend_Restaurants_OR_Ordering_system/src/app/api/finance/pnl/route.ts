import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { getMonthlyPnl, getYearlyPnl } from "@/lib/server/finance";
import { todayKeys } from "@/lib/server/time-keys";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/finance/pnl?period=monthly&key=2026-07
// GET /api/finance/pnl?period=yearly&key=2026
//
// Computes gross sales, discounts, GST, COGS, gross profit, operating
// expenses, net profit and margins for the requested month or year.
async function getImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const restaurantId = auth.session.restaurantId;

  const period = req.nextUrl.searchParams.get("period") === "yearly" ? "yearly" : "monthly";
  const today = todayKeys();
  const key = req.nextUrl.searchParams.get("key") ?? (period === "yearly" ? today.yearKey : today.monthKey);

  const pnl = period === "yearly" ? await getYearlyPnl(restaurantId, key) : await getMonthlyPnl(restaurantId, key);
  return apiSuccess({ period, pnl }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);
