import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { tenantDb, platformDb } from "@/lib/server/db";
import { addExpense } from "@/lib/server/finance";
import { createExpenseSchema } from "@/lib/server/validation";
import { readPageParams, paginate } from "@/lib/server/pagination";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/finance/expenses?month=2026-07 or ?year=2026
async function getImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const month = req.nextUrl.searchParams.get("month");
  const year = req.nextUrl.searchParams.get("year");

  let expenses = await tenantDb(auth.session.restaurantId).expenses.all();
  if (month) expenses = expenses.filter((e) => e.monthKey === month);
  else if (year) expenses = expenses.filter((e) => e.yearKey === year);
  expenses.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const paged = paginate(expenses, readPageParams(req));
  return apiSuccess(
    { expenses: paged.items },
    "Operation successful",
    { pagination: { page: paged.page, pageSize: paged.pageSize, total: paged.total, totalPages: paged.totalPages } }
  );
}

export const GET = withErrorHandling(getImpl);

async function postImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const parsed = createExpenseSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const input = parsed.data;

  const expense = await addExpense(auth.session.restaurantId, {
    date: input.date,
    category: input.category,
    description: input.description || "",
    amount: input.amount,
    createdBy: auth.session.name,
  });

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "create",
    entityType: "expense",
    entityId: expense.id,
    details: { category: expense.category, amount: expense.amount },
  });

  return apiSuccess({ expense }, "Created successfully", { status: 201 });
}

export const POST = withErrorHandling(postImpl);
