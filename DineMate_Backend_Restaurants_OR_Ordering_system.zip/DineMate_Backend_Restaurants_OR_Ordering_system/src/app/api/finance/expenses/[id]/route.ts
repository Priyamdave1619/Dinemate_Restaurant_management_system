import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { tenantDb, platformDb } from "@/lib/server/db";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { updateExpenseSchema } from "@/lib/server/validation";

async function patchImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  const body = await req.json().catch(() => null);
  const parsed = updateExpenseSchema.safeParse(body);
  if (!parsed.success) return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  const patch = parsed.data;

  let found = false;
  const expenses = await tenantDb(auth.session.restaurantId).expenses.mutate((cur) =>
    cur.map((e) => {
      if (e.id !== id) return e;
      found = true;
      return { ...e, ...patch, id: e.id, restaurantId: e.restaurantId };
    })
  );

  if (!found) return apiError("Expense not found", 404);

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "update",
    entityType: "expense",
    entityId: id,
  });

  return apiSuccess({ expenses }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);

async function deleteImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  const expenses = await tenantDb(auth.session.restaurantId).expenses.mutate((cur) => cur.filter((e) => e.id !== id));

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "delete",
    entityType: "expense",
    entityId: id,
  });

  return apiSuccess({ expenses }, "Operation successful");
}

export const DELETE = withErrorHandling(deleteImpl);
