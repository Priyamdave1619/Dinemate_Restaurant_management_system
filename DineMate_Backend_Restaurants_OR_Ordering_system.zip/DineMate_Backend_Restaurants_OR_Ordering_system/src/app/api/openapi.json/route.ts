import { NextResponse } from "next/server";
import { openApiSpec } from "@/lib/server/openapi-spec";

// GET /api/openapi.json — the raw OpenAPI 3.0 document. Consumed by the
// self-hosted Swagger UI at /swagger-ui/index.html, and usable directly by
// any other OpenAPI tool (Postman import, client SDK generators, etc).
export async function GET() {
  return NextResponse.json(openApiSpec, {
    headers: { "Cache-Control": "no-store" },
  });
}
