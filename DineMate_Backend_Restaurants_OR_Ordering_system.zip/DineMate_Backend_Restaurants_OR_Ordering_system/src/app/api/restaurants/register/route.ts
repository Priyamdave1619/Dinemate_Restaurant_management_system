import { NextRequest } from "next/server";
import { z } from "zod";
import { registerRestaurant, isEmailRegistered } from "@/lib/server/restaurants";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

const registerSchema = z.object({
  name: z.string().trim().min(2, "Restaurant name is too short").max(120),
  ownerName: z.string().trim().min(2, "Owner name is too short").max(120),
  email: z.string().trim().email("A valid email is required").max(200),
  mobile: z
    .string()
    .trim()
    .regex(/^[+]?[0-9\s-]{7,15}$/, "A valid mobile number is required"),
  password: z.string().min(8, "Password must be at least 8 characters").max(200),
  address: z.string().trim().max(500).optional(),
  gstNumber: z.string().trim().max(30).optional(),
  timezone: z.string().trim().max(60).optional(),
  currency: z.string().trim().length(3, "Currency must be a 3-letter code, e.g. INR").optional(),
  // NOTE on the logo: the spec caps the restaurant logo at 300KB. This
  // route accepts an already-hosted URL (upload it via your storage of
  // choice first, e.g. this backend's /api/tables/[id]/qr pattern using
  // @vercel/blob) rather than raw file bytes, keeping this endpoint a
  // simple JSON POST. Direct multipart upload + the 300KB enforcement is a
  // small, separate follow-up to this route if you want it done here too.
  logoUrl: z.string().trim().url().max(500).optional(),
  planId: z.string().trim().max(60).optional(),
});

// Public restaurant sign-up. Creates the tenant (on a 14-day free trial)
// plus its Owner login in one call. The response's `restaurant.id` (e.g.
// "REST000021") IS the owner's login username going forward — there is no
// separate credential to remember.
async function postImpl(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = registerSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const input = parsed.data;

  // Emails also act as a soft uniqueness signal (support/comms channel),
  // though usernames — not emails — are what's used to log in.
  if (await isEmailRegistered(input.email)) {
    return apiError("An account with this email already exists", 409);
  }

  try {
    const { restaurant, owner } = await registerRestaurant(input);

    return apiSuccess(
      {
        restaurant: {
          id: restaurant.id,
          name: restaurant.name,
          status: restaurant.status,
          planId: restaurant.planId,
          subscriptionStatus: restaurant.subscriptionStatus,
          subscriptionExpiresAt: restaurant.subscriptionExpiresAt,
        },
        owner: { username: owner.username, name: owner.name, role: owner.role },
      },
      `Registration successful. Your Restaurant ID is ${restaurant.id} — use it with your password to log in.`,
      { status: 201 }
    );
  } catch (err) {
    return apiError(err instanceof Error ? err.message : "Registration failed", 500);
  }
}

export const POST = withErrorHandling(postImpl);
