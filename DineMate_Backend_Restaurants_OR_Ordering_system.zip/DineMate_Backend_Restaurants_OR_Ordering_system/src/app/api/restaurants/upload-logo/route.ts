import { NextRequest } from "next/server";
import { randomUUID } from "crypto";
import { writeStoredFile } from "@/lib/server/storage";
import { getSession } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

const MAX_LOGO_BYTES = 300 * 1024; // 300 KB, per spec
const ALLOWED_TYPES = new Set(["image/png", "image/jpeg", "image/webp", "image/svg+xml"]);

// POST /api/restaurants/upload-logo — multipart/form-data with a single
// "logo" file field. Returns { logoUrl } to pass into
// POST /api/restaurants/register (public, before an owner account exists)
// or PATCH-equivalent restaurant settings update (logged in as owner).
//
// This is deliberately a separate endpoint from registration rather than
// bundled into it — registration stays a plain JSON POST (see that route's
// zod schema), and this one owns the one thing multipart handling and the
// 300KB limit actually need: the file itself.
async function postImpl(req: NextRequest) {
  const contentType = req.headers.get("content-type") || "";
  if (!contentType.includes("multipart/form-data")) {
    return apiError("Send the logo as multipart/form-data with a 'logo' field", 400);
  }

  const form = await req.formData().catch(() => null);
  const file = form?.get("logo");
  if (!file || !(file instanceof File)) {
    return apiError("A 'logo' file is required", 400);
  }

  if (!ALLOWED_TYPES.has(file.type)) {
    return apiError("Logo must be PNG, JPEG, WEBP, or SVG", 400);
  }
  if (file.size > MAX_LOGO_BYTES) {
    return apiError("Logo must be 300KB or smaller", 400);
  }

  // Registration flow has no session yet (the restaurant doesn't exist
  // until after this call), so this endpoint is intentionally public. If
  // it's an existing owner replacing their logo, tag the file with their
  // restaurantId for traceability — otherwise it's just a random id that
  // gets attached to the restaurant record moments later at registration.
  const session = await getSession();
  const ext = file.type === "image/svg+xml" ? "svg" : file.type.split("/")[1];
  const ownerTag = session?.restaurantId ?? "pending";
  const fileName = `logos/${ownerTag}-${randomUUID()}.${ext}`;

  const buffer = Buffer.from(await file.arrayBuffer());
  const logoUrl = await writeStoredFile(fileName, buffer, file.type);

  return apiSuccess({ logoUrl }, "Logo uploaded", { status: 201 });
}

export const POST = withErrorHandling(postImpl);
