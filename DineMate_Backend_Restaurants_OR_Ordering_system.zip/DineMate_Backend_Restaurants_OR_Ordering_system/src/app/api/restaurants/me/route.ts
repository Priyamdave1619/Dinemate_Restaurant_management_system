import { NextRequest } from "next/server";
import { z } from "zod";
import { platformDb, tenantDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { RESTAURANT_STAFF_ROLES } from "@/lib/types";

// The owner-facing restaurant PROFILE (name, logo, GST, contact info,
// address) — distinct from /api/settings, which covers operational
// settings (tax rate, currency, opening hours). This is the platform-level
// Restaurant record; only its own owner (not managers/waiters) can edit it,
// and never its status/subscription/plan fields — those are Super Admin
// only (see /api/admin/restaurants/[id]).
async function getImpl() {
  const auth = await requireTenant(RESTAURANT_STAFF_ROLES);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const restaurant = await platformDb.restaurants.get(auth.session.restaurantId);
  if (!restaurant) return apiError("Restaurant not found", 404);
  return apiSuccess({ restaurant }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);

const updateSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  ownerName: z.string().trim().min(2).max(120).optional(),
  email: z.string().trim().email().max(200).optional(),
  mobile: z
    .string()
    .trim()
    .regex(/^[+]?[0-9\s-]{7,15}$/)
    .optional(),
  address: z.string().trim().max(500).optional(),
  gstNumber: z.string().trim().max(30).optional(),
  // 300KB is enforced at upload time by /api/restaurants/upload-logo — this
  // route just stores whatever URL that returned.
  logoUrl: z.string().trim().url().max(500).optional(),
  timezone: z.string().trim().max(60).optional(),
  currency: z.string().trim().length(3).optional(),
});

async function patchImpl(req: NextRequest) {
  const auth = await requireTenant(["owner"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }

  let found = false;
  const restaurants = await platformDb.restaurants.mutate((cur) =>
    cur.map((r) => {
      if (r.id !== auth.session.restaurantId) return r;
      found = true;
      return { ...r, ...parsed.data, updatedAt: new Date().toISOString() };
    })
  );

  if (!found) return apiError("Restaurant not found", 404);

  // Sync operational settings display fields so customer menu shows the same name
  const patch = parsed.data;
  if (patch.name || patch.address !== undefined || patch.mobile || patch.gstNumber !== undefined) {
    const db = tenantDb(auth.session.restaurantId);
    const current = await db.settings.get();
    await db.settings.save({
      ...current,
      restaurantId: auth.session.restaurantId,
      ...(patch.name ? { restaurantName: patch.name.trim() } : {}),
      ...(patch.address !== undefined ? { address: patch.address } : {}),
      ...(patch.mobile ? { phone: patch.mobile } : {}),
      ...(patch.gstNumber !== undefined ? { gstin: patch.gstNumber } : {}),
    });
  }

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "update",
    entityType: "restaurant",
    entityId: auth.session.restaurantId,
  });

  return apiSuccess({ restaurant: restaurants.find((r) => r.id === auth.session.restaurantId) }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);
