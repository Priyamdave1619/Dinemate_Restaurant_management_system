import { NextRequest } from "next/server";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { updateOfferSchema } from "@/lib/server/validation";

async function patchImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const { id } = await params;
  const body = await req.json().catch(() => null);
  const parsed = updateOfferSchema.safeParse(body);
  if (!parsed.success) return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  const patch = { ...parsed.data } as Record<string, unknown>;

  if (typeof patch.couponCode === "string") {
    patch.couponCode = String(patch.couponCode).trim().toUpperCase() || undefined;
  }

  const db = tenantDb(auth.session.restaurantId);
  if (patch.couponCode) {
    const all = await db.offers.all();
    if (all.some((o) => o.id !== id && o.couponCode?.toUpperCase() === patch.couponCode)) {
      return apiError("Coupon code already in use", 409);
    }
  }

  let found = false;
  const offers = await db.offers.mutate((cur) =>
    cur.map((o) => {
      if (o.id !== id) return o;
      found = true;
      return {
        ...o,
        ...patch,
        id: o.id,
        restaurantId: o.restaurantId,
        updatedAt: new Date().toISOString(),
      };
    })
  );
  if (!found) return apiError("Offer not found", 404);

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "update",
    entityType: "offer",
    entityId: id,
  });

  return apiSuccess({ offers }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);

async function deleteImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const { id } = await params;
  const offers = await tenantDb(auth.session.restaurantId).offers.mutate((cur) =>
    cur.filter((o) => o.id !== id)
  );

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "delete",
    entityType: "offer",
    entityId: id,
  });

  return apiSuccess({ offers }, "Operation successful");
}

export const DELETE = withErrorHandling(deleteImpl);
