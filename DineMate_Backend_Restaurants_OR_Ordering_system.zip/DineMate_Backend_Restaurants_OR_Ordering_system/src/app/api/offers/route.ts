import { NextRequest } from "next/server";
import { randomUUID } from "crypto";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { resolvePublicRestaurant } from "@/lib/server/tenant-context";
import { createOfferSchema } from "@/lib/server/validation";
import { Offer } from "@/lib/types";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { isOfferLive, offerStatus } from "@/lib/server/offer-live";

async function getImpl(req: NextRequest) {
  const tenant = await resolvePublicRestaurant(req);
  if (!tenant.ok) return apiError(tenant.message, tenant.status);

  const activeOnly = req.nextUrl.searchParams.get("active") === "1";
  const liveOnly = req.nextUrl.searchParams.get("live") === "1";

  let offers = await tenantDb(tenant.restaurantId).offers.all();
  if (activeOnly) offers = offers.filter((o) => o.active);
  if (liveOnly) offers = offers.filter((o) => isOfferLive(o));

  const now = new Date();
  const enriched = offers.map((o) => ({
    ...o,
    status: offerStatus(o, now),
    live: isOfferLive(o, now),
  }));

  return apiSuccess({ offers: enriched }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);

async function postImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const parsed = createOfferSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const input = parsed.data;
  const db = tenantDb(auth.session.restaurantId);

  const code = input.couponCode?.trim().toUpperCase() || undefined;
  if (code) {
    const existing = await db.offers.all();
    if (existing.some((o) => o.couponCode?.toUpperCase() === code)) {
      return apiError("Coupon code already in use", 409);
    }
  }

  const now = new Date().toISOString();
  const offer: Offer = {
    id: `offer-${randomUUID()}`,
    restaurantId: auth.session.restaurantId,
    name: input.name,
    description: input.description,
    image: input.image || undefined,
    type: input.type,
    active: input.active ?? true,
    itemId: input.itemId,
    categoryId: input.categoryId,
    itemIds: input.itemIds,
    categoryIds: input.categoryIds,
    excludeItemIds: input.excludeItemIds,
    buyQty: input.buyQty,
    getQty: input.getQty,
    discountPercent: input.discountPercent,
    discountAmount: input.discountAmount,
    maxDiscountAmount: input.maxDiscountAmount,
    minOrderAmount: input.minOrderAmount,
    startsAt: input.startsAt || undefined,
    endsAt: input.endsAt || undefined,
    daysOfWeek: input.daysOfWeek,
    timeFrom: input.timeFrom || undefined,
    timeTo: input.timeTo || undefined,
    usageLimit: input.usageLimit,
    usageCount: 0,
    perCustomerLimit: input.perCustomerLimit,
    couponCode: code,
    autoApply: input.autoApply ?? true,
    stackable: input.stackable ?? true,
    priority: input.priority ?? 0,
    createdAt: now,
    updatedAt: now,
  };

  const offers = await db.offers.mutate((cur) => [offer, ...cur]);

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "create",
    entityType: "offer",
    entityId: offer.id,
  });

  return apiSuccess({ offer, offers }, "Created successfully", { status: 201 });
}

export const POST = withErrorHandling(postImpl);
