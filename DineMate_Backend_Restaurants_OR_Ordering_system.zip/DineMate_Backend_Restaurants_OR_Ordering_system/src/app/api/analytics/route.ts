import { requireTenant } from "@/lib/server/session";
import { tenantDb } from "@/lib/server/db";
import {
  getBestAndLeastSellers,
  getBusiestWeekdays,
  getCategoryWiseSales,
  getCustomerTrends,
  getFoodTypeWiseSales,
  getPeakHours,
} from "@/lib/server/analytics";
import { listDailyStats, listMonthlyStats } from "@/lib/server/reports";
import { deriveTimeKeys, todayKeys } from "@/lib/server/time-keys";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// Restaurant-wide analytics dashboard. Sourced from the permanent sales
// archive (billedOrders / soldItems / dailyStats) rather than the live
// billing queue, so numbers never disappear once an order is billed.
async function getImpl() {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const restaurantId = auth.session.restaurantId;
  const db = tenantDb(restaurantId);

  const [menu, tables, activeOrders] = await Promise.all([db.menu.all(), db.tables.all(), db.orders.all()]);

  const today = todayKeys();

  // Last 7 calendar days (including days with zero sales, at 0), built from
  // the permanent daily stats records.
  const sevenDaysAgo = deriveTimeKeys(new Date(Date.now() - 6 * 86400000)).dateKey;
  const recentDaily = await listDailyStats(restaurantId, sevenDaysAgo, today.dateKey);
  const byDateKey = new Map(recentDaily.map((d) => [d.dateKey, d]));
  const revenueByDay: { date: string; label: string; revenue: number; orders: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const keys = deriveTimeKeys(d);
    const stat = byDateKey.get(keys.dateKey);
    revenueByDay.push({
      date: keys.dateKey,
      label: d.toLocaleDateString("en-IN", { weekday: "short" }),
      revenue: stat?.totalCollected ?? 0,
      orders: stat?.orderCount ?? 0,
    });
  }

  const todaysStat = byDateKey.get(today.dateKey);
  const todaysRevenue = todaysStat?.totalCollected ?? 0;
  const todaysOrderCount = todaysStat?.orderCount ?? 0;
  const avgTicket = todaysOrderCount ? Math.round(todaysRevenue / todaysOrderCount) : 0;

  const [{ bestSelling, leastSelling }, categorySales, foodTypeSales, peakHours, busiestWeekdays, customerTrends] =
    await Promise.all([
      getBestAndLeastSellers(restaurantId, menu, undefined, 5),
      getCategoryWiseSales(restaurantId),
      getFoodTypeWiseSales(restaurantId),
      getPeakHours(restaurantId),
      getBusiestWeekdays(restaurantId),
      getCustomerTrends(restaurantId),
    ]);

  const occupied = tables.filter((t) => t.status === "occupied").length;
  const activeOrderCount = activeOrders.filter((o) => o.status !== "completed" && o.status !== "cancelled").length;

  // All-time order count, for the "totalOrdersAllTime" stat card — cheap to
  // derive from the permanent monthly stats rather than scanning every order.
  const allMonths = await listMonthlyStats(restaurantId);
  const totalOrdersAllTime = allMonths.reduce((s, m) => s + m.orderCount, 0);

  return apiSuccess(
    {
      todaysRevenue,
      todaysOrderCount,
      avgTicket,
      tablesOccupied: occupied,
      tablesTotal: tables.length,
      activeOrders: activeOrderCount,
      // Backward-compatible shape for the existing admin dashboard widgets.
      bestSellers: bestSelling.map((s) => ({ itemId: s.itemId, name: s.itemName, qty: s.quantitySold, revenue: s.revenue })),
      slowMovers: leastSelling.map((s) => ({ itemId: s.itemId, name: s.itemName, qty: s.quantitySold, revenue: s.revenue })),
      revenueByDay,
      revenueByCategory: categorySales.map((c) => ({ categoryId: c.categoryId, revenue: c.revenue })),
      totalOrdersAllTime,
      // Extended analytics.
      categorySales,
      foodTypeSales,
      peakHours,
      busiestWeekdays,
      customerTrends,
    },
    "Analytics fetched"
  );
}

export const GET = withErrorHandling(getImpl);
