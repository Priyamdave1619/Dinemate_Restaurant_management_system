import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { createImportSession, validateUploadFile } from "@/lib/server/menu-import/import-service";

async function postImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const form = await req.formData().catch(() => null);
  if (!form) return apiError("Expected multipart form data", 400);

  const files: Array<{ name: string; size: number; mimeType: string; buffer: Buffer }> = [];
  for (const [key, value] of form.entries()) {
    if (key !== "files" && key !== "file") continue;
    if (typeof value === "string") continue;
    const f = value as File;
    const buf = Buffer.from(await f.arrayBuffer());
    const mime = f.type || "application/octet-stream";
    const check = validateUploadFile(f.name, mime, buf.length);
    if (!check.ok) {
      return apiError(`${f.name}: ${check.error}`, 400);
    }
    files.push({ name: f.name, size: buf.length, mimeType: mime, buffer: buf });
  }

  if (files.length === 0) return apiError("No valid files uploaded", 400);
  if (files.length > 100) return apiError("Maximum 100 files per import", 400);

  try {
    const session = await createImportSession(auth.session.restaurantId, auth.session.sub, files);
    return apiSuccess({ session }, "Files uploaded. Call process to start extraction.");
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error("[menu-import/upload]", msg);
    if (/menu_import_sessions|does not exist|relation .* does not exist/i.test(msg)) {
      return apiError(
        "Database table menu_import_sessions is missing. Run migration drizzle/0001_menu_import_sessions.sql on Postgres, then retry.",
        500
      );
    }
    if (/permission denied|EACCES|ENOSPC/i.test(msg)) {
      return apiError("Could not store uploaded file. Check storage/R2 configuration.", 500);
    }
    return apiError(msg.length < 200 ? msg : "Upload failed. Check server logs.", 500);
  }
}

export const POST = withErrorHandling(postImpl);
