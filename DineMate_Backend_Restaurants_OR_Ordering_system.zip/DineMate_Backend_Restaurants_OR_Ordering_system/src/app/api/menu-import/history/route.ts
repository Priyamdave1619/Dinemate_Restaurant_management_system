import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { tenantDb } from "@/lib/server/db";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

async function getImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const sessions = await tenantDb(auth.session.restaurantId).menuImportSessions.all();
  const sorted = [...sessions].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  // Lightweight list for history (omit full items payload)
  const history = sorted.map((s) => ({
    id: s.id,
    status: s.status,
    totalFiles: s.totalFiles,
    totalItems: s.totalItems,
    successfulItems: s.successfulItems,
    failedItems: s.failedItems,
    duplicateItems: s.duplicateItems,
    needsReviewItems: s.needsReviewItems,
    createdAt: s.createdAt,
    completedAt: s.completedAt,
    processingTimeMs: s.processingTimeMs,
    createdBy: s.createdBy,
  }));

  return apiSuccess({ history }, "OK");
}

export const GET = withErrorHandling(getImpl);
