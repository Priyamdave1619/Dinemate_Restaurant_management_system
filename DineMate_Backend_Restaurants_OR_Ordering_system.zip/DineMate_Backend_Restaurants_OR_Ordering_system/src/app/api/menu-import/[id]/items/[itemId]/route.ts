import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { updateImportItem, deleteImportItems } from "@/lib/server/menu-import/import-service";

async function patchImpl(req: NextRequest, ctx: { params: Promise<{ id: string; itemId: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id, itemId } = await ctx.params;
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") return apiError("Invalid body", 400);

  try {
    const session = await updateImportItem(auth.session.restaurantId, id, itemId, body);
    return apiSuccess({ session }, "Item updated");
  } catch (e) {
    return apiError(e instanceof Error ? e.message : "Update failed", 400);
  }
}

async function deleteImpl(_req: NextRequest, ctx: { params: Promise<{ id: string; itemId: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id, itemId } = await ctx.params;
  try {
    const session = await deleteImportItems(auth.session.restaurantId, id, [itemId]);
    return apiSuccess({ session }, "Item deleted");
  } catch (e) {
    return apiError(e instanceof Error ? e.message : "Delete failed", 400);
  }
}

export const PATCH = withErrorHandling(patchImpl);
export const DELETE = withErrorHandling(deleteImpl);
