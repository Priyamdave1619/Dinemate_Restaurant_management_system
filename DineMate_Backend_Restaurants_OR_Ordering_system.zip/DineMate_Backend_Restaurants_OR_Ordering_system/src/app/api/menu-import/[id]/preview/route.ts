import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { tenantDb } from "@/lib/server/db";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

async function getImpl(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await ctx.params;
  const session = await tenantDb(auth.session.restaurantId).menuImportSessions.get(id);
  if (!session) return apiError("Import session not found", 404);

  const filter = req.nextUrl.searchParams.get("filter") || "all";
  let items = session.items;
  if (filter === "valid") items = items.filter((i) => i.status === "extracted" || i.status === "approved");
  else if (filter === "needs_review") items = items.filter((i) => i.status === "needs_review");
  else if (filter === "duplicate") items = items.filter((i) => i.status === "duplicate");
  else if (filter === "error") items = items.filter((i) => i.status === "error");
  else if (filter === "new") items = items.filter((i) => i.status !== "duplicate");

  const summary = {
    categoriesFound: session.categoriesDetected.length,
    foodItemsFound: session.totalItems,
    variantsFound: session.items.reduce((n, i) => n + (i.variants?.length || 0), 0),
    addOnsFound: session.items.reduce((n, i) => n + (i.addOns?.length || 0), 0),
    imagesFound: session.files.filter((f) => f.mimeType.startsWith("image/")).length,
    duplicates: session.duplicateItems,
    errors: session.items.filter((i) => i.status === "error").length + session.files.filter((f) => f.status === "error").length,
    needsReview: session.needsReviewItems,
  };

  return apiSuccess({ session: { ...session, items }, summary }, "Preview ready");
}

export const GET = withErrorHandling(getImpl);
