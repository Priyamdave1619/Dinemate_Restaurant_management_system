import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { tenantDb } from "@/lib/server/db";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { deleteImportSessionWithCascade } from "@/lib/server/menu-import/import-service";

async function getImpl(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await ctx.params;
  const session = await tenantDb(auth.session.restaurantId).menuImportSessions.get(id);
  if (!session) return apiError("Import session not found", 404);

  return apiSuccess({ session }, "OK");
}

/**
 * DELETE /api/menu-import/:id
 * Removes the import session from history.
 * Query: ?deleteItems=1 (default) also deletes menu products created by this import.
 */
async function deleteImpl(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await ctx.params;
  const deleteItems = req.nextUrl.searchParams.get("deleteItems") !== "0";

  try {
    const result = await deleteImportSessionWithCascade(auth.session.restaurantId, id, {
      deleteMenuItems: deleteItems,
    });
    return apiSuccess(
      result,
      result.deletedMenuItems > 0
        ? `Import deleted and ${result.deletedMenuItems} menu item(s) removed`
        : "Import session deleted"
    );
  } catch (e) {
    return apiError(e instanceof Error ? e.message : "Delete failed", 400);
  }
}

export const GET = withErrorHandling(getImpl);
export const DELETE = withErrorHandling(deleteImpl);
