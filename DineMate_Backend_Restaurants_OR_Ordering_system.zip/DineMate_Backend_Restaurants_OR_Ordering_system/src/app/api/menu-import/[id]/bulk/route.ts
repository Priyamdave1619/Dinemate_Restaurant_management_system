import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { bulkUpdateImportItems, deleteImportItems } from "@/lib/server/menu-import/import-service";

async function postImpl(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await ctx.params;
  const body = await req.json().catch(() => null);
  if (!body || !Array.isArray(body.itemIds) || body.itemIds.length === 0) {
    return apiError("itemIds array required", 400);
  }

  try {
    if (body.action === "delete") {
      const session = await deleteImportItems(auth.session.restaurantId, id, body.itemIds);
      return apiSuccess({ session }, "Items deleted");
    }
    const session = await bulkUpdateImportItems(
      auth.session.restaurantId,
      id,
      body.itemIds,
      body.patch || {}
    );
    return apiSuccess({ session }, "Bulk update applied");
  } catch (e) {
    return apiError(e instanceof Error ? e.message : "Bulk update failed", 400);
  }
}

export const POST = withErrorHandling(postImpl);
