import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { commitImport } from "@/lib/server/menu-import/import-service";
import { platformDb } from "@/lib/server/db";

async function postImpl(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));

  try {
    const result = await commitImport(auth.session.restaurantId, id, {
      skipDuplicates: body.skipDuplicates !== false,
      approveAllReady: body.approveAllReady === true,
    });

    // Audit log
    try {
      await platformDb.auditLogs.log({
        restaurantId: auth.session.restaurantId,
        action: "menu_import_commit",
        actorUserId: auth.session.sub,
        details: {
          importId: id,
          createdItems: result.createdItems,
          createdCategories: result.createdCategories,
        },
      } as never);
    } catch {
      // non-fatal
    }

    return apiSuccess(result, "Import committed successfully");
  } catch (e) {
    return apiError(e instanceof Error ? e.message : "Commit failed", 400);
  }
}

export const POST = withErrorHandling(postImpl);
