import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { processImportSession } from "@/lib/server/menu-import/import-service";

async function postImpl(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await ctx.params;
  try {
    const session = await processImportSession(auth.session.restaurantId, id);
    return apiSuccess({ session }, "Processing complete. Review items before committing.");
  } catch (e) {
    return apiError(e instanceof Error ? e.message : "Processing failed", 400);
  }
}

export const POST = withErrorHandling(postImpl);
