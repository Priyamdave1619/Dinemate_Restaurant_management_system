import { NextResponse } from "next/server";
import { checkDatabaseHealth } from "@/lib/server/pg";
import { withErrorHandling } from "@/lib/server/api-response";

/**
 * GET /api/health/db
 *
 * Detailed database status for operators. Returns Postgres version and
 * round-trip latency when healthy. Still public (useful for post-deploy
 * smoke tests) but never leaks the connection string, credentials, host
 * internals beyond what `version()` already exposes, or query text.
 */
async function getImpl() {
  const db = await checkDatabaseHealth();

  const body = {
    success: db.ok,
    message: db.ok ? "Database connection healthy" : "Database connection failed",
    data: {
      status: db.ok ? "ok" : "error",
      latencyMs: db.latencyMs,
      serverVersion: db.serverVersion ?? null,
      checkedAt: db.checkedAt,
      // Confirm TLS was required by the driver config without revealing the URL.
      tlsRequired: true,
      ...(db.ok ? {} : { error: db.error }),
    },
  };

  return NextResponse.json(body, {
    status: db.ok ? 200 : 503,
    headers: { "Cache-Control": "no-store" },
  });
}

export const GET = withErrorHandling(getImpl);
