import { NextResponse } from "next/server";
import { checkDatabaseHealth } from "@/lib/server/pg";
import { withErrorHandling } from "@/lib/server/api-response";

/**
 * GET /api/health
 *
 * Liveness + readiness probe for load balancers, uptime monitors, and
 * local smoke tests. Returns 200 when the process is up AND Postgres is
 * reachable; 503 when the database is down (so orchestrators stop routing
 * traffic). Never exposes connection strings, env vars, or stack traces.
 *
 * Public — no auth required (probes cannot carry Bearer tokens easily).
 */
async function getImpl() {
  const db = await checkDatabaseHealth();
  const body = {
    success: db.ok,
    message: db.ok ? "ok" : "degraded",
    data: {
      status: db.ok ? "ok" : "degraded",
      uptimeSeconds: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
      checks: {
        database: {
          ok: db.ok,
          latencyMs: db.latencyMs,
          ...(db.ok ? {} : { error: db.error }),
        },
      },
    },
  };

  return NextResponse.json(body, {
    status: db.ok ? 200 : 503,
    headers: { "Cache-Control": "no-store" },
  });
}

export const GET = withErrorHandling(getImpl);
