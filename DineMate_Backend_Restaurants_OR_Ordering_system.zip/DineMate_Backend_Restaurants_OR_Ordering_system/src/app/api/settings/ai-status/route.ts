import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { getSafeAiConfigPublic, testGroqConnection } from "@/lib/server/secrets";

/**
 * Restaurant staff can see whether AI menu extraction is available.
 * Never exposes the API key — only configured yes/no and model name.
 *
 * Optional: ?probe=1 runs a live Groq connectivity check (models list).
 */
async function getImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const config = await getSafeAiConfigPublic();
  const probe = req.nextUrl.searchParams.get("probe") === "1";

  const base = {
    aiExtractionAvailable: config.groqConfigured && config.groqEnabled,
    provider: config.groqConfigured ? "groq" : null,
    model: config.groqConfigured ? config.groqVisionModel : null,
    source: config.groqSource,
  };

  if (!probe) {
    return apiSuccess(base, "OK");
  }

  const connection = await testGroqConnection();
  return apiSuccess(
    {
      ...base,
      connection: {
        ok: connection.ok,
        message: connection.message,
        latencyMs: connection.latencyMs,
        model: connection.model,
      },
    },
    connection.ok ? "Groq connected" : "Groq check failed"
  );
}

export const GET = withErrorHandling(getImpl);
