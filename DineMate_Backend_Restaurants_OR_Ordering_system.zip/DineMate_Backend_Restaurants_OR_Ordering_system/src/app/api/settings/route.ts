import { NextRequest } from "next/server";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { resolvePublicRestaurant } from "@/lib/server/tenant-context";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// Public GET (customer menu page reads tax rate/currency/restaurant name)
// + staff GET both flow through resolvePublicRestaurant.
async function getImpl(req: NextRequest) {
  const tenant = await resolvePublicRestaurant(req);
  if (!tenant.ok) return apiError(tenant.message, tenant.status);
  const restaurantId = tenant.restaurantId;
  const settings = await tenantDb(restaurantId).settings.get();
  const restaurant = await platformDb.restaurants.get(restaurantId);
  // Profile `restaurant.name` is the source of truth for public display name.
  // Settings.restaurantName is kept in sync when profile/settings are saved.
  const enriched = {
    ...settings,
    restaurantName: (restaurant?.name || settings.restaurantName || restaurantId).trim(),
    address: (restaurant?.address || settings.address || "").trim() || undefined,
    phone: (settings.phone || restaurant?.mobile || "").trim() || undefined,
  };
  return apiSuccess({ settings: enriched }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);

async function patchImpl(req: NextRequest) {
  const auth = await requireTenant(["owner"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const patch = await req.json().catch(() => null);
  if (!patch) return apiError("Invalid body", 400);

  const db = tenantDb(auth.session.restaurantId);
  const current = await db.settings.get();
  // restaurantId is never patchable — it's the scope key, not a setting.
  const { restaurantId: _ignore, ...safePatch } = patch;
  void _ignore;
  const next = { ...current, ...safePatch, restaurantId: auth.session.restaurantId };
  await db.settings.save(next);

  // Keep platform restaurant record in sync so customer app & profile match
  if (typeof safePatch.restaurantName === "string" && safePatch.restaurantName.trim()) {
    const name = safePatch.restaurantName.trim();
    await platformDb.restaurants.mutate((cur) =>
      cur.map((r) =>
        r.id === auth.session.restaurantId
          ? { ...r, name, updatedAt: new Date().toISOString() }
          : r
      )
    );
  }
  if (typeof safePatch.address === "string") {
    await platformDb.restaurants.mutate((cur) =>
      cur.map((r) =>
        r.id === auth.session.restaurantId
          ? { ...r, address: safePatch.address, updatedAt: new Date().toISOString() }
          : r
      )
    );
  }

  return apiSuccess({ settings: next }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);
