import { NextRequest } from "next/server";
import { z } from "zod";
import { requireTenant } from "@/lib/server/session";
import { createCheckoutOrder } from "@/lib/server/payments";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

const schema = z.object({ planId: z.string().trim().min(1) });

// POST /api/billing/checkout { planId } — owner starts a paid plan
// upgrade/renewal. Returns everything Razorpay Checkout.js needs on the
// frontend (order id, amount, currency, publishable key id). Nothing is
// applied to the subscription yet — that only happens once payment is
// confirmed, via /api/billing/verify (client-side fast path) and/or
// /api/billing/webhook (source of truth).
async function postImpl(req: NextRequest) {
  const auth = await requireTenant(["owner"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }

  const result = await createCheckoutOrder(auth.session.restaurantId, parsed.data.planId);
  if (!result.ok) return apiError(result.error, result.status);

  return apiSuccess({ checkout: result.checkout }, "Operation successful");
}

export const POST = withErrorHandling(postImpl);
