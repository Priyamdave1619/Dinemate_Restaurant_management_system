import { NextRequest } from "next/server";
import { verifyWebhookSignature, applySuccessfulPayment } from "@/lib/server/payments";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// POST /api/billing/webhook — configure this URL in your Razorpay
// dashboard (Settings -> Webhooks), subscribed to at least the
// `payment.captured` event, with RAZORPAY_WEBHOOK_SECRET set to match.
// This is the source of truth for payments — unlike /api/billing/verify
// (which trusts the browser), this is server-to-server and can't be
// spoofed by a compromised or malicious client.
async function postImpl(req: NextRequest) {
  const signature = req.headers.get("x-razorpay-signature");
  const rawBody = await req.text();

  if (!signature || !verifyWebhookSignature(rawBody, signature)) {
    return apiError("Invalid signature", 400);
  }

  const event = JSON.parse(rawBody);
  if (event.event === "payment.captured" || event.event === "order.paid") {
    const notes = event.payload?.payment?.entity?.notes ?? event.payload?.order?.entity?.notes;
    const restaurantId = notes?.restaurantId;
    const planId = notes?.planId;
    if (restaurantId && planId) {
      await applySuccessfulPayment(restaurantId, planId);
    }
  }

  // Razorpay expects a 2xx quickly, or it will retry — always acknowledge
  // even for event types we don't act on.
  return apiSuccess({ received: true }, "Operation successful");
}

export const POST = withErrorHandling(postImpl);
