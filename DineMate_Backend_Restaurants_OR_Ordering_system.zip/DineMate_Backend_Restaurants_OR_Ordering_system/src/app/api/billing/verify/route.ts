import { NextRequest } from "next/server";
import { z } from "zod";
import { requireTenant } from "@/lib/server/session";
import { verifyCheckoutSignature, applySuccessfulPayment } from "@/lib/server/payments";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

const schema = z.object({
  razorpayOrderId: z.string().trim().min(1),
  razorpayPaymentId: z.string().trim().min(1),
  razorpaySignature: z.string().trim().min(1),
  planId: z.string().trim().min(1),
});

// POST /api/billing/verify — called by the frontend immediately after
// Razorpay Checkout succeeds, so the UI can reflect the upgrade right away
// instead of waiting for the webhook to arrive. The webhook
// (/api/billing/webhook) is still the source of truth and will apply the
// same change idempotently if this call is ever skipped or spoofed.
async function postImpl(req: NextRequest) {
  const auth = await requireTenant(["owner"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const { razorpayOrderId, razorpayPaymentId, razorpaySignature, planId } = parsed.data;

  if (!verifyCheckoutSignature(razorpayOrderId, razorpayPaymentId, razorpaySignature)) {
    return apiError("Payment signature verification failed", 400);
  }

  await applySuccessfulPayment(auth.session.restaurantId, planId);
  return apiSuccess({ ok: true }, "Operation successful");
}

export const POST = withErrorHandling(postImpl);
