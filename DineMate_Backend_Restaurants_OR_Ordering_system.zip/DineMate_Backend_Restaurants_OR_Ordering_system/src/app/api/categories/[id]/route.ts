import { NextRequest } from "next/server";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { updateCategorySchema } from "@/lib/server/validation";

async function patchImpl(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const { id } = await params;
  const body = await req.json().catch(() => null);
  const parsed = updateCategorySchema.safeParse(body);
  if (!parsed.success) return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  const patch = parsed.data;
  const categories = await tenantDb(auth.session.restaurantId).categories.mutate((cur) =>
    cur.map((c) => (c.id === id ? { ...c, ...patch, id: c.id, restaurantId: c.restaurantId } : c))
  );

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "update",
    entityType: "category",
    entityId: id,
  });

  return apiSuccess({ categories }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);

async function deleteImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const { id } = await params;
  const categories = await tenantDb(auth.session.restaurantId).categories.mutate((cur) => cur.filter((c) => c.id !== id));

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "delete",
    entityType: "category",
    entityId: id,
  });

  return apiSuccess({ categories }, "Operation successful");
}

export const DELETE = withErrorHandling(deleteImpl);
