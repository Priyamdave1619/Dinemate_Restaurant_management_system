import { NextRequest } from "next/server";
import { randomUUID } from "crypto";
import { tenantDb, platformDb } from "@/lib/server/db";
import { requireTenant } from "@/lib/server/session";
import { resolvePublicRestaurant } from "@/lib/server/tenant-context";
import { createCategorySchema } from "@/lib/server/validation";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { withCategoryAvailabilityFlags } from "@/lib/server/menu-availability";

// Public (customer QR menu) + staff both read this — see
// resolvePublicRestaurant for how the tenant is determined either way.
async function getImpl(req: NextRequest) {
  const tenant = await resolvePublicRestaurant(req);
  if (!tenant.ok) return apiError(tenant.message, tenant.status);

  const categories = withCategoryAvailabilityFlags(
    await tenantDb(tenant.restaurantId).categories.all()
  );
  return apiSuccess({ categories }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);

async function postImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  const parsed = createCategorySchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }

  const category = {
    id: `cat-${randomUUID()}`,
    restaurantId: auth.session.restaurantId,
    name: parsed.data.name,
    icon: parsed.data.icon || "🍽️",
    scheduleEnabled: parsed.data.scheduleEnabled ?? false,
    availableFrom: parsed.data.scheduleEnabled ? (parsed.data.availableFrom || undefined) : undefined,
    availableTo: parsed.data.scheduleEnabled ? (parsed.data.availableTo || undefined) : undefined,
  };
  const categories = await tenantDb(auth.session.restaurantId).categories.mutate((cur) => [...cur, category]);

  await platformDb.auditLogs.log({
    restaurantId: auth.session.restaurantId,
    actorUserId: auth.session.sub,
    actorName: auth.session.name,
    actorRole: auth.session.role,
    action: "create",
    entityType: "category",
    entityId: category.id,
  });

  return apiSuccess({ category, categories }, "Created successfully", { status: 201 });
}

export const POST = withErrorHandling(postImpl);
