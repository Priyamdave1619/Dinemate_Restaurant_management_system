import { NextRequest } from "next/server";
import { cookies } from "next/headers";
import { authCookieOptions, createSessionToken, REFRESH_COOKIE, REFRESH_TOKEN_TTL_DAYS, SESSION_COOKIE } from "@/lib/server/auth";
import { rotateRefreshToken, revokeAllRefreshTokensForUser } from "@/lib/server/refresh-tokens";
import { platformDb } from "@/lib/server/db";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// POST /api/auth/refresh — exchanges a refresh token for a new 15-minute
// access token, and rotates the refresh token itself (old one is marked
// used, a new one is issued). Call this whenever a request comes back 401
// with an expired access token, then retry the original request — the
// standard "silent refresh" pattern, no re-entering username/password
// needed until the refresh token itself expires (30 days) or is revoked.
//
// The refresh token can be presented three ways, checked in this order:
//   1. `Authorization: Bearer <refreshToken>` header — the primary
//      mechanism for non-browser clients (mobile apps, server-to-server).
//   2. `{ "refreshToken": "..." }` in the JSON body — an alternative for
//      clients where setting a custom header is inconvenient.
//   3. The httpOnly refresh cookie — browser convenience fallback.
async function postImpl(req: NextRequest) {
  const store = await cookies();

  let refreshValue: string | undefined;
  const authHeader = req.headers.get("authorization");
  if (authHeader?.startsWith("Bearer ")) {
    refreshValue = authHeader.slice("Bearer ".length).trim() || undefined;
  }
  if (!refreshValue) {
    const body = await req.json().catch(() => null);
    if (typeof body?.refreshToken === "string" && body.refreshToken) refreshValue = body.refreshToken;
  }
  if (!refreshValue) {
    refreshValue = store.get(REFRESH_COOKIE)?.value;
  }

  if (!refreshValue) {
    return apiError("No refresh token present — please log in again", 401);
  }

  const result = await rotateRefreshToken(refreshValue);

  if (!result.ok) {
    // Clear both cookies on any failure so a browser client falls back to
    // a full login instead of retry-looping against a dead refresh token.
    store.delete(SESSION_COOKIE);
    store.delete(REFRESH_COOKIE);

    if (result.reason === "reused") {
      // The already-rotated-out token was presented again — a strong
      // signal it was stolen and the thief tried to use it after the
      // legitimate client had already refreshed past it. Revoke every
      // refresh token for this user immediately, forcing a real
      // username+password login before any session (legitimate or not)
      // can continue.
      await revokeAllRefreshTokensForUser(result.userId);
    }
    return apiError("Session expired — please log in again", 401);
  }

  const { record, newValue } = result;

  // Re-check the account/restaurant is still in good standing on every
  // refresh too, not just at the original login — a suspension or
  // deactivation should cut off silent refresh immediately, not just block
  // the next full login.
  if (record.role !== "super_admin") {
    if (!record.restaurantId) {
      await revokeAllRefreshTokensForUser(record.userId);
      store.delete(SESSION_COOKIE);
      store.delete(REFRESH_COOKIE);
      return apiError("Account is not linked to a restaurant", 403);
    }
    const restaurant = await platformDb.restaurants.get(record.restaurantId);
    if (!restaurant || restaurant.status === "suspended" || new Date(restaurant.subscriptionExpiresAt).getTime() < Date.now()) {
      await revokeAllRefreshTokensForUser(record.userId);
      store.delete(SESSION_COOKIE);
      store.delete(REFRESH_COOKIE);
      return apiError("This account can no longer refresh its session", 403);
    }
  }

  const token = await createSessionToken({
    sub: record.userId,
    username: record.username,
    name: record.name,
    role: record.role,
    restaurantId: record.restaurantId,
  });

  store.set(SESSION_COOKIE, token, authCookieOptions(60 * 15));
  store.set(REFRESH_COOKIE, newValue, authCookieOptions(60 * 60 * 24 * REFRESH_TOKEN_TTL_DAYS));

  return apiSuccess(
    // Returned in `data` too, same reasoning as login — Bearer clients
    // need these values directly, they can't read an httpOnly cookie.
    { accessToken: token, refreshToken: newValue },
    "Token refreshed",
    { headers: { "Cache-Control": "no-store" } }
  );
}

export const POST = withErrorHandling(postImpl);
