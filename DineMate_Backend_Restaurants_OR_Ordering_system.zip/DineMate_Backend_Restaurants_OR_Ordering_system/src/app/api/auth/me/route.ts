import { getSession } from "@/lib/server/session";
import { platformDb } from "@/lib/server/db";
import { apiSuccess, withErrorHandling } from "@/lib/server/api-response";

// Never cache this — it's the source of truth for "who is logged in", and a
// cached response would show a stale user (or a stale "logged out") to
// whoever's browser/CDN happens to have it.
export const dynamic = "force-dynamic";

async function getImpl() {
  const session = await getSession();
  if (!session) {
    return apiSuccess({ user: null }, "Not authenticated", { headers: { "Cache-Control": "no-store" } });
  }

  let restaurant = null;
  if (session.restaurantId) {
    const r = await platformDb.restaurants.get(session.restaurantId);
    if (r) {
      restaurant = {
        id: r.id,
        name: r.name,
        status: r.status,
        subscriptionStatus: r.subscriptionStatus,
        subscriptionExpiresAt: r.subscriptionExpiresAt,
        planId: r.planId,
      };
    }
  }

  return apiSuccess(
    {
      user: {
        id: session.sub,
        username: session.username,
        name: session.name,
        role: session.role,
        restaurantId: session.restaurantId,
      },
      restaurant,
    },
    "Session fetched",
    { headers: { "Cache-Control": "no-store" } }
  );
}

export const GET = withErrorHandling(getImpl);
