import { NextRequest } from "next/server";
import { z } from "zod";
import { platformDb, tenantDb } from "@/lib/server/db";
import { getSession } from "@/lib/server/session";
import { createSessionToken, SESSION_COOKIE, authCookieOptions } from "@/lib/server/auth";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { cookies } from "next/headers";
import type { AppUser } from "@/lib/types";

const schema = z.object({
  name: z.string().trim().min(1).max(120).optional(),
  username: z
    .string()
    .trim()
    .min(3, "Username must be at least 3 characters")
    .max(100)
    .regex(/^[a-zA-Z0-9._@-]+$/, "Username may only contain letters, numbers, and . _ @ -")
    .optional(),
});

// PATCH /api/auth/profile — update current user's name and/or username.
async function patchImpl(req: NextRequest) {
  const session = await getSession();
  if (!session) return apiError("Unauthorized", 401);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }

  const newName = parsed.data.name?.trim();
  const rawUsername = parsed.data.username?.trim();
  const newUsername = rawUsername ? rawUsername.toLowerCase() : undefined;

  if (!newName && !newUsername) {
    return apiError("Nothing to update", 400);
  }

  // Uniqueness: usernames are global across the platform
  if (newUsername && newUsername !== session.username.toLowerCase()) {
    const existing = await platformDb.users.findByUsername(newUsername);
    if (existing && existing.id !== session.sub) {
      return apiError("This username is already taken", 409);
    }
  }

  const applyUser = (u: AppUser): AppUser => {
    if (u.id !== session.sub) return u;
    return {
      ...u,
      ...(newName ? { name: newName } : {}),
      ...(newUsername ? { username: newUsername } : {}),
    };
  };

  let found = false;
  if (session.role === "super_admin" || !session.restaurantId) {
    await platformDb.superAdmins.mutate((cur) =>
      cur.map((u) => {
        if (u.id === session.sub) found = true;
        return applyUser(u);
      })
    );
  } else {
    await tenantDb(session.restaurantId).users.mutate((cur) =>
      cur.map((u) => {
        if (u.id === session.sub) found = true;
        return applyUser(u);
      })
    );
  }

  if (!found) {
    const all = await platformDb.users.all();
    const user = all.find((u) => u.id === session.sub);
    if (!user) return apiError("User not found", 404);
    if (user.restaurantId) {
      await tenantDb(user.restaurantId).users.mutate((cur) => cur.map(applyUser));
    } else {
      await platformDb.superAdmins.mutate((cur) => cur.map(applyUser));
    }
  }

  const finalName = newName ?? session.name;
  const finalUsername = newUsername ?? session.username.toLowerCase();

  await platformDb.auditLogs.log({
    restaurantId: session.restaurantId,
    actorUserId: session.sub,
    actorName: finalName,
    actorRole: session.role,
    action: "profile_update",
    entityType: "user",
    entityId: session.sub,
    details: {
      ...(newName ? { name: newName } : {}),
      ...(newUsername ? { username: newUsername } : {}),
    },
  });

  const token = await createSessionToken({
    sub: session.sub,
    username: finalUsername,
    name: finalName,
    role: session.role,
    restaurantId: session.restaurantId,
  });

  const store = await cookies();
  store.set(SESSION_COOKIE, token, authCookieOptions(60 * 15));

  return apiSuccess(
    {
      user: {
        id: session.sub,
        username: finalUsername,
        name: finalName,
        role: session.role,
        restaurantId: session.restaurantId,
      },
      accessToken: token,
    },
    "Profile updated"
  );
}

export const PATCH = withErrorHandling(patchImpl);
