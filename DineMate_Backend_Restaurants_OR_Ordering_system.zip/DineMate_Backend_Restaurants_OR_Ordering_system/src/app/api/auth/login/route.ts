import { NextRequest } from "next/server";
import { cookies } from "next/headers";
import { z } from "zod";
import { platformDb, tenantDb } from "@/lib/server/db";
import { authCookieOptions, createSessionToken, REFRESH_COOKIE, REFRESH_TOKEN_TTL_DAYS, SESSION_COOKIE, verifyPassword } from "@/lib/server/auth";
import { issueRefreshToken } from "@/lib/server/refresh-tokens";
import { notify } from "@/lib/server/notifications";
import { ensureSuperAdminBootstrap } from "@/lib/server/restaurants";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

const loginSchema = z.object({
  username: z.string().trim().min(1, "Username is required").max(100),
  password: z.string().min(1, "Password is required").max(200),
});

// Single login endpoint for every role. There is no separate "restaurant
// login" vs "waiter login" vs "admin login" form — they all POST
// {username, password} here:
//   - Product Owner (super_admin): a platform username (see .env SUPER_ADMIN_USERNAME)
//   - Restaurant Owner:            username = their Restaurant ID (e.g. REST000021)
//   - Manager / Waiter:            username assigned by their restaurant owner
// Usernames are globally unique across the whole platform (enforced at
// creation time), so a single lookup is enough to find the right account
// and, from it, the right restaurant.
async function postImpl(req: NextRequest) {
  // Idempotent (checks whether the account already exists before doing
  // anything) — safe and cheap to call on every login attempt. This is
  // what actually makes SUPER_ADMIN_USERNAME/SUPER_ADMIN_PASSWORD in
  // .env.example do something: without a call site somewhere, that
  // bootstrap function was previously dead code and no super_admin
  // account would ever get created on a fresh deployment.
  await ensureSuperAdminBootstrap();

  const body = await req.json().catch(() => null);
  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const username = parsed.data.username.toLowerCase();
  const password = parsed.data.password;

  const ip = req.headers.get("x-forwarded-for") || req.headers.get("x-real-ip") || undefined;
  const userAgent = req.headers.get("user-agent") || undefined;

  const user = await platformDb.users.findByUsername(username);

  if (!user || !user.active || !verifyPassword(password, user.passwordHash, user.passwordSalt)) {
    if (user) {
      await platformDb.loginHistory.log({
        restaurantId: user.restaurantId,
        userId: user.id,
        username: user.username,
        role: user.role,
        success: false,
        ip,
        userAgent,
      });
    }
    return apiError("Invalid username or password", 401);
  }

  // Restaurant-scoped roles: block login if the tenant is suspended,
  // pending, or its subscription has expired. Super_admin bypasses this
  // entirely (no restaurant).
  let restaurant = null;
  if (user.role !== "super_admin") {
    if (!user.restaurantId) {
      return apiError("Account is not linked to a restaurant", 403);
    }
    restaurant = await platformDb.restaurants.get(user.restaurantId);
    if (!restaurant) {
      return apiError("Restaurant no longer exists", 403);
    }
    if (restaurant.status === "suspended") {
      return apiError("This restaurant has been suspended by the platform", 403);
    }
    if (restaurant.status === "pending") {
      return apiError("This restaurant's account is pending approval", 403);
    }
    if (new Date(restaurant.subscriptionExpiresAt).getTime() < Date.now()) {
      return apiError("Subscription expired — please renew your plan to log in", 402);
    }
  }

  // Give the owner (not managers/waiters — billing is an owner-only
  // concern per the RBAC model) a heads-up once the subscription is within
  // 5 days of expiring, without spamming a fresh notification on every
  // single login.
  if (user.role === "owner" && restaurant) {
    const daysLeft = (new Date(restaurant.subscriptionExpiresAt).getTime() - Date.now()) / 86400000;
    if (daysLeft <= 5) {
      const existing = await tenantDb(restaurant.id).notifications.all();
      const alreadyWarnedToday = existing.some(
        (n) => n.type === "subscription_expiring" && n.createdAt.slice(0, 10) === new Date().toISOString().slice(0, 10)
      );
      if (!alreadyWarnedToday) {
        await notify(restaurant.id, {
          type: "subscription_expiring",
          title: "Subscription expiring soon",
          message: `Your plan expires in ${Math.max(0, Math.ceil(daysLeft))} day(s) — renew to avoid any interruption.`,
          targetRole: "owner",
        });
      }
    }
  }

  const token = await createSessionToken({
    sub: user.id,
    username: user.username,
    name: user.name,
    role: user.role,
    restaurantId: user.restaurantId,
  });
  const refreshValue = await issueRefreshToken({
    id: user.id,
    username: user.username,
    name: user.name,
    role: user.role,
    restaurantId: user.restaurantId,
  });

  const store = await cookies();
  // 15-minute access token — the browser transparently refreshes it via
  // POST /api/auth/refresh using the long-lived refresh cookie below, so
  // this short lifetime costs nothing in UX while limiting how long a
  // leaked access token stays useful.
  store.set(SESSION_COOKIE, token, authCookieOptions(60 * 15));
  store.set(REFRESH_COOKIE, refreshValue, authCookieOptions(60 * 60 * 24 * REFRESH_TOKEN_TTL_DAYS));

  await platformDb.loginHistory.log({
    restaurantId: user.restaurantId,
    userId: user.id,
    username: user.username,
    role: user.role,
    success: true,
    ip,
    userAgent,
  });
  await platformDb.auditLogs.log({
    restaurantId: user.restaurantId,
    actorUserId: user.id,
    actorName: user.name,
    actorRole: user.role,
    action: "login",
    entityType: "user",
    entityId: user.id,
    ip,
    userAgent,
  });

  return apiSuccess(
    {
      id: user.id,
      username: user.username,
      name: user.name,
      role: user.role,
      restaurantId: user.restaurantId,
      restaurant: restaurant
        ? { id: restaurant.id, name: restaurant.name, status: restaurant.status, subscriptionStatus: restaurant.subscriptionStatus }
        : null,
      // Also returned in `data` (not just set as cookies) for non-browser
      // clients — mobile apps, server-to-server integrations, API testing
      // — which should send `Authorization: Bearer <accessToken>` on every
      // request. Browser clients can ignore these two fields entirely and
      // rely on the cookies that were just set instead.
      accessToken: token,
      refreshToken: refreshValue,
    },
    "Login successful",
    { headers: { "Cache-Control": "no-store" } }
  );
}

export const POST = withErrorHandling(postImpl);
