import { NextRequest } from "next/server";
import { z } from "zod";
import { platformDb, tenantDb } from "@/lib/server/db";
import { getSession } from "@/lib/server/session";
import { hashPassword, verifyPassword } from "@/lib/server/auth";
import { revokeAllRefreshTokensForUser } from "@/lib/server/refresh-tokens";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

const schema = z.object({
  currentPassword: z.string().min(1).max(200),
  newPassword: z.string().min(8, "New password must be at least 8 characters").max(200),
});

// POST /api/auth/change-password — authenticated user changes their own password.
// Revokes all refresh tokens so other sessions must re-login.
async function postImpl(req: NextRequest) {
  const session = await getSession();
  if (!session) return apiError("Unauthorized", 401);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return apiError(parsed.error.issues[0]?.message ?? "Invalid request", 400);
  }
  const { currentPassword, newPassword } = parsed.data;

  if (currentPassword === newPassword) {
    return apiError("New password must be different from the current password", 400);
  }

  const user = await platformDb.users.findByUsername(session.username);
  if (!user || user.id !== session.sub) {
    return apiError("User not found", 404);
  }

  if (!verifyPassword(currentPassword, user.passwordHash, user.passwordSalt)) {
    return apiError("Current password is incorrect", 400);
  }

  const { hash, salt } = hashPassword(newPassword);

  if (user.role === "super_admin" || !user.restaurantId) {
    await platformDb.superAdmins.mutate((cur) =>
      cur.map((u) => (u.id === user.id ? { ...u, passwordHash: hash, passwordSalt: salt } : u))
    );
  } else {
    await tenantDb(user.restaurantId).users.mutate((cur) =>
      cur.map((u) => (u.id === user.id ? { ...u, passwordHash: hash, passwordSalt: salt } : u))
    );
  }

  await revokeAllRefreshTokensForUser(user.id);

  await platformDb.auditLogs.log({
    restaurantId: user.restaurantId ?? null,
    actorUserId: session.sub,
    actorName: session.name,
    actorRole: session.role,
    action: "password_change",
    entityType: "user",
    entityId: user.id,
  });

  return apiSuccess({ ok: true }, "Password changed. Please sign in again on other devices.");
}

export const POST = withErrorHandling(postImpl);
