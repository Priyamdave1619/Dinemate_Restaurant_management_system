import { NextRequest } from "next/server";
import { cookies } from "next/headers";
import { authCookieOptions, REFRESH_COOKIE, SESSION_COOKIE } from "@/lib/server/auth";
import { revokeRefreshToken } from "@/lib/server/refresh-tokens";
import { apiSuccess, withErrorHandling } from "@/lib/server/api-response";

// Accepts the refresh token to revoke the same three ways /api/auth/refresh
// does (Bearer header, JSON body, or cookie) — a Bearer-only client (no
// cookies at all) still needs a way to explicitly invalidate its refresh
// token on logout, not just discard it client-side.
async function postImpl(req: NextRequest) {
  const store = await cookies();

  let refreshValue: string | undefined;
  const authHeader = req.headers.get("authorization");
  if (authHeader?.startsWith("Bearer ")) {
    refreshValue = authHeader.slice("Bearer ".length).trim() || undefined;
  }
  if (!refreshValue) {
    const body = await req.json().catch(() => null);
    if (typeof body?.refreshToken === "string" && body.refreshToken) refreshValue = body.refreshToken;
  }
  if (!refreshValue) {
    refreshValue = store.get(REFRESH_COOKIE)?.value;
  }

  if (refreshValue) {
    // Revoke server-side too, not just clear the cookie — otherwise the
    // still-valid refresh token could mint fresh access tokens for anyone
    // who'd copied it before logout (e.g. from a compromised device).
    await revokeRefreshToken(refreshValue);
  }

  // Match every attribute used when the cookies were set — a mismatched
  // path or sameSite/secure value means the browser treats this as a
  // different cookie and silently ignores the deletion, so the old session
  // survives.
  store.set(SESSION_COOKIE, "", { ...authCookieOptions(0) });
  store.set(REFRESH_COOKIE, "", { ...authCookieOptions(0) });

  return apiSuccess({ ok: true }, "Logged out successfully", { headers: { "Cache-Control": "no-store" } });
}

export const POST = withErrorHandling(postImpl);
