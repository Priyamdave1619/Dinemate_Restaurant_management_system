import { requireTenant } from "@/lib/server/session";
import { platformDb } from "@/lib/server/db";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/activity-logs — this restaurant's own audit trail + login
// history (owner/manager only). Same underlying data the Super Admin sees
// at /api/admin/audit-logs?restaurantId=..., scoped down to just this
// tenant so an owner can self-serve "who changed what, and when".
async function getImpl() {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const [logs, logins] = await Promise.all([
    platformDb.auditLogs.list({ restaurantId: auth.session.restaurantId }, 100),
    platformDb.loginHistory.list({ restaurantId: auth.session.restaurantId }, 100),
  ]);

  return apiSuccess({ logs, logins }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);
