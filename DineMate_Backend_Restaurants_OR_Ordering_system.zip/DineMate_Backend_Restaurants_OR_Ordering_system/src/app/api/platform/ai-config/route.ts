import { NextRequest } from "next/server";
import { requireRole } from "@/lib/server/session";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import {
  getSafeAiConfigPublic,
  updatePlatformAiConfig,
  testGroqConnection,
} from "@/lib/server/secrets";
import { platformDb } from "@/lib/server/db";

/**
 * Platform AI integration config (Groq API token, vision model).
 * Super-admin only. The raw API key is never returned — only a masked hint.
 */

async function getImpl(req: NextRequest) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const config = await getSafeAiConfigPublic();
  const skipProbe = req.nextUrl.searchParams.get("probe") === "0";
  const connection = skipProbe ? undefined : await testGroqConnection();
  return apiSuccess({ config, connection }, connection?.ok === false ? "Groq check failed" : "OK");
}

async function putImpl(req: NextRequest) {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") return apiError("Invalid body", 400);

  try {
    const config = await updatePlatformAiConfig({
      groqApiKey: body.groqApiKey === undefined ? undefined : body.groqApiKey,
      groqVisionModel: body.groqVisionModel,
      groqEnabled: body.groqEnabled,
      updatedBy: auth.session.sub,
    });

    try {
      await platformDb.auditLogs.log({
        restaurantId: null,
        action: "platform_ai_config_update",
        actorUserId: auth.session.sub,
        details: {
          groqConfigured: config.groqConfigured,
          groqSource: config.groqSource,
          groqVisionModel: config.groqVisionModel,
          groqEnabled: config.groqEnabled,
          keyRotated: body.groqApiKey != null && body.groqApiKey !== "",
        },
      } as never);
    } catch {
      // non-fatal
    }

    return apiSuccess({ config }, "AI configuration saved");
  } catch (e) {
    return apiError(e instanceof Error ? e.message : "Failed to save AI config", 400);
  }
}

/** Clear stored key (env key still wins if present). */
async function deleteImpl() {
  const auth = await requireRole(["super_admin"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const config = await updatePlatformAiConfig({
    groqApiKey: null,
    updatedBy: auth.session.sub,
  });
  return apiSuccess({ config }, "Stored Groq API key cleared");
}

export const GET = withErrorHandling(getImpl);
export const PUT = withErrorHandling(putImpl);
export const DELETE = withErrorHandling(deleteImpl);
