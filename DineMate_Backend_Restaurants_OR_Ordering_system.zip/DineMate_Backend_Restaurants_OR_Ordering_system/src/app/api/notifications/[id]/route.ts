import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { markNotificationRead } from "@/lib/server/notifications";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { RESTAURANT_STAFF_ROLES } from "@/lib/types";

async function patchImpl(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireTenant(RESTAURANT_STAFF_ROLES);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const { id } = await params;
  const notifications = await markNotificationRead(auth.session.restaurantId, id);
  return apiSuccess({ notifications }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);
