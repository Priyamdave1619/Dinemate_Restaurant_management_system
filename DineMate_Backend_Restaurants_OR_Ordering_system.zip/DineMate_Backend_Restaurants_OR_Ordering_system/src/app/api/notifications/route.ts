import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { listNotifications, markAllNotificationsRead } from "@/lib/server/notifications";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";
import { RESTAURANT_STAFF_ROLES } from "@/lib/types";

// GET /api/notifications?unread=1
async function getImpl(req: NextRequest) {
  const auth = await requireTenant(RESTAURANT_STAFF_ROLES);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const unreadOnly = req.nextUrl.searchParams.get("unread") === "1";
  const notifications = await listNotifications(auth.session.restaurantId, auth.session.role, unreadOnly);
  return apiSuccess({ notifications }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);

// PATCH /api/notifications  { markAllRead: true }
async function patchImpl(req: NextRequest) {
  const auth = await requireTenant(RESTAURANT_STAFF_ROLES);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const body = await req.json().catch(() => null);
  if (!body?.markAllRead) return apiError("Nothing to update", 400);

  const notifications = await markAllNotificationsRead(auth.session.restaurantId);
  return apiSuccess({ notifications }, "Operation successful");
}

export const PATCH = withErrorHandling(patchImpl);
