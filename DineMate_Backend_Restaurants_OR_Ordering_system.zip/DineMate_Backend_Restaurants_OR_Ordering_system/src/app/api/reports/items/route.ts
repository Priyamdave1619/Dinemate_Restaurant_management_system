import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { tenantDb } from "@/lib/server/db";
import { getBestAndLeastSellers, getCategoryWiseSales, getFoodTypeWiseSales, getItemWisePerformance } from "@/lib/server/analytics";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/reports/items?from=YYYY-MM-DD&to=YYYY-MM-DD&limit=10
// Item-wise sales quantities, revenue, cost & profit, plus best/least
// sellers and category / food-type breakdowns, over an optional date range
// (omit both to cover all-time history).
async function getImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const restaurantId = auth.session.restaurantId;

  const from = req.nextUrl.searchParams.get("from") ?? undefined;
  const to = req.nextUrl.searchParams.get("to") ?? undefined;
  const limit = Number(req.nextUrl.searchParams.get("limit")) || 10;
  const range = from || to ? { from, to } : undefined;

  const menu = await tenantDb(restaurantId).menu.all();
  const [items, sellers, categorySales, foodTypeSales] = await Promise.all([
    getItemWisePerformance(restaurantId, range),
    getBestAndLeastSellers(restaurantId, menu, range, limit),
    getCategoryWiseSales(restaurantId, range),
    getFoodTypeWiseSales(restaurantId, range),
  ]);

  return apiSuccess({
    items,
    bestSelling: sellers.bestSelling,
    leastSelling: sellers.leastSelling,
    categorySales,
    foodTypeSales,
  }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);
