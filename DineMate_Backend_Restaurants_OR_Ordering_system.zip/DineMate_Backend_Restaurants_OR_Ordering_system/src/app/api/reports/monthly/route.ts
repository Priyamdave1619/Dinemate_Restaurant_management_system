import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { getMonthlyStats, listMonthlyStats } from "@/lib/server/reports";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/reports/monthly?month=2026-07   -> single permanent monthly record
// GET /api/reports/monthly?year=2026       -> every month on record for that year
// GET /api/reports/monthly                 -> every month ever recorded
//
// Monthly records are permanent — they are never deleted, so historical
// data stays reachable indefinitely.
async function getImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const restaurantId = auth.session.restaurantId;

  const month = req.nextUrl.searchParams.get("month");
  const year = req.nextUrl.searchParams.get("year");

  if (month) {
    const stat = await getMonthlyStats(restaurantId, month);
    return apiSuccess(
      {
        month:
          stat ?? {
            restaurantId,
            monthKey: month,
            yearKey: month.slice(0, 4),
            grossSales: 0,
            discountTotal: 0,
            netSales: 0,
            taxTotal: 0,
            totalCollected: 0,
            cogsTotal: 0,
            grossProfit: 0,
            orderCount: 0,
            itemsSold: 0,
            updatedAt: new Date().toISOString(),
          },
      },
      "Operation successful"
    );
  }

  const months = await listMonthlyStats(restaurantId, year ?? undefined);
  return apiSuccess({ months }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);
