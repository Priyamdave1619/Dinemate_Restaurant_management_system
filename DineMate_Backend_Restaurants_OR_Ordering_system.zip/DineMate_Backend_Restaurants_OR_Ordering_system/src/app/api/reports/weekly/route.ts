import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { getWeeklyStats } from "@/lib/server/reports";
import { todayKeys } from "@/lib/server/time-keys";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/reports/weekly?week=2026-W30
// Weekly totals are computed on demand by aggregating the permanent daily
// stats records for that ISO week — nothing extra to store or keep in sync.
async function getImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);

  const week = req.nextUrl.searchParams.get("week") ?? todayKeys().weekKey;
  const stats = await getWeeklyStats(auth.session.restaurantId, week);
  return apiSuccess({ week: stats }, "Operation successful");
}

export const GET = withErrorHandling(getImpl);
