import { NextRequest } from "next/server";
import { requireTenant } from "@/lib/server/session";
import { getDailyStats, listDailyStats } from "@/lib/server/reports";
import { todayKeys } from "@/lib/server/time-keys";
import { apiSuccess, apiError, withErrorHandling } from "@/lib/server/api-response";

// GET /api/reports/daily?date=YYYY-MM-DD          -> single permanent daily record
// GET /api/reports/daily?from=YYYY-MM-DD&to=YYYY-MM-DD -> range of daily records
async function getImpl(req: NextRequest) {
  const auth = await requireTenant(["owner", "manager"]);
  if (!auth.ok) return apiError(auth.message, auth.status);
  const restaurantId = auth.session.restaurantId;

  const from = req.nextUrl.searchParams.get("from");
  const to = req.nextUrl.searchParams.get("to");
  const date = req.nextUrl.searchParams.get("date");

  if (from || to) {
    const days = await listDailyStats(restaurantId, from ?? undefined, to ?? undefined);
    return apiSuccess({ days }, "Operation successful");
  }

  const dateKey = date ?? todayKeys().dateKey;
  const stat = await getDailyStats(restaurantId, dateKey);
  return apiSuccess(
    {
      day:
        stat ?? {
          restaurantId,
          dateKey,
          weekKey: "",
          monthKey: dateKey.slice(0, 7),
          yearKey: dateKey.slice(0, 4),
          grossSales: 0,
          discountTotal: 0,
          netSales: 0,
          taxTotal: 0,
          totalCollected: 0,
          cogsTotal: 0,
          grossProfit: 0,
          orderCount: 0,
          itemsSold: 0,
          updatedAt: new Date().toISOString(),
        },
    },
    "Operation successful"
  );
}

export const GET = withErrorHandling(getImpl);
