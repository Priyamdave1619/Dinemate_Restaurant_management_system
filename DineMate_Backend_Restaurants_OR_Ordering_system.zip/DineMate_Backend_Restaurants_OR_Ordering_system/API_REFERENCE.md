# API Reference

**Interactive docs**: run the server and open `/swagger-ui/index.html` —
a self-hosted Swagger UI backed by the full OpenAPI 3.0 spec at
`GET /api/openapi.json`. Click "Authorize" and paste an access token to
call any endpoint live. This document is the human-readable narrative
version of the same information.

**Automated tests**: `npm test` runs 89 tests (Vitest) covering tenant
isolation, auth, refresh tokens, the pricing engine, validation schemas,
and the full order-to-bill archival flow — against a purpose-built
in-memory MongoDB-compatible fake (see `MIGRATION_NOTES.md` Phase 11 for
what it does and doesn't prove).

Base URL: your deployment's origin (e.g. `https://api.yourplatform.com`).
All responses are JSON. All requests that carry a body must send
`Content-Type: application/json` (the one exception is the logo upload
endpoint, which is `multipart/form-data`) — see `MIGRATION_NOTES.md` for
why this is enforced, not just a convention.

## Auth model

Every role logs in through the same endpoint. There's no separate "admin
login form" vs "waiter login form" — the backend figures out who you are
from the username alone (usernames are globally unique across the whole
platform):

| Role | Username is... |
|---|---|
| `super_admin` | A platform username (see `SUPER_ADMIN_USERNAME` env var) |
| `owner` | The Restaurant ID itself, e.g. `REST000021` |
| `manager` / `waiter` | Whatever their restaurant owner assigned them |

**Every protected endpoint requires `Authorization: Bearer <accessToken>`.**
`POST /api/auth/login` returns `accessToken` and `refreshToken` directly in
the JSON response body — store these and send the access token as the
Bearer header on every subsequent request. Access tokens last 15 minutes;
when a request comes back `401`, call `POST /api/auth/refresh` with
`Authorization: Bearer <refreshToken>` (or `{"refreshToken": "..."}` in the
body) to get a fresh pair, then retry the original request. If refresh also
fails, send the user back to the login screen.

A same-origin browser client can alternatively just rely on the httpOnly
cookies (`dinemate_session` / `dinemate_refresh`) this endpoint also sets —
that's a convenience fallback so a web app doesn't have to manually manage
tokens, not a separate auth system. Bearer takes priority whenever both are
present.

**Standard error shape** for every non-2xx response:
```json
{ "success": false, "message": "Human-readable message", "errors": [] }
```

**Standard success shape** for every 2xx response:
```json
{ "success": true, "message": "Human-readable message", "data": { ... }, "pagination": { ... } }
```
`pagination` is only present on endpoints that actually paginate (see each
endpoint's Notes column below); it's omitted entirely otherwise, not sent
as null.

**Roles referenced below**: `super_admin`, `owner`, `manager`, `waiter`,
or `public` (no auth required).

---

## Health

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/api/health` | public | Process + database liveness. **200** when healthy, **503** when DB is down. Safe for load balancers. |
| GET | `/api/health/db` | public | Detailed DB status: latency, Postgres version, TLS required. Never returns the connection string. |

Interactive docs: open `/swagger-ui/index.html` after starting the server (OpenAPI at `GET /api/openapi.json`).

---

## Auth

| Method | Path | Roles | Notes |
|---|---|---|---|
| POST | `/api/auth/login` | public | `{username, password}` → `{..., accessToken, refreshToken}` + sets cookies |
| POST | `/api/auth/refresh` | public (needs a valid refresh token) | Rotates the refresh token, returns a new `{accessToken, refreshToken}` |
| POST | `/api/auth/logout` | any | Revokes the refresh token server-side, clears cookies |
| GET | `/api/auth/me` | any | Current session + restaurant summary, or `{user: null}` |

## Restaurants (platform + self-service)

| Method | Path | Roles | Notes |
|---|---|---|---|
| POST | `/api/restaurants/register` | public | Self-service sign-up — creates tenant + owner login, 14-day trial |
| POST | `/api/restaurants/upload-logo` | public/owner | `multipart/form-data`, ≤300KB, returns `{logoUrl}` |
| GET | `/api/restaurants/me` | owner, manager, waiter | This restaurant's profile |
| PATCH | `/api/restaurants/me` | owner | Update name/logo/GST/contact/address |

## Super Admin

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/api/admin/dashboard` | super_admin | Platform-wide totals |
| GET | `/api/admin/restaurants` | super_admin | `?status=&search=&page=&pageSize=` |
| POST | `/api/admin/restaurants` | super_admin | Directly provision a restaurant |
| GET | `/api/admin/restaurants/[id]` | super_admin | Full detail incl. staff, login history, audit log |
| PATCH | `/api/admin/restaurants/[id]` | super_admin | `{status?, planId?, renew?, days?, ...profile fields}` |
| DELETE | `/api/admin/restaurants/[id]` | super_admin | Deletes the restaurant record (business data retained) |
| GET | `/api/admin/plans` | any authenticated | List plans (owners need this to see upgrade options) |
| POST | `/api/admin/plans` | super_admin | Create a plan |
| PATCH | `/api/admin/plans/[id]` | super_admin | Edit a plan |
| DELETE | `/api/admin/plans/[id]` | super_admin | Delete a plan (blocked if any restaurant is on it) |
| GET | `/api/admin/audit-logs` | super_admin | `?restaurantId=&kind=logins\|audit` |

## Billing (Razorpay — see `.env.example`, no-ops if unconfigured)

| Method | Path | Roles | Notes |
|---|---|---|---|
| POST | `/api/billing/checkout` | owner | `{planId}` → Razorpay order details for Checkout.js |
| POST | `/api/billing/verify` | owner | Client-side fast path right after Checkout succeeds |
| POST | `/api/billing/webhook` | public (Razorpay only, HMAC-verified) | Source of truth for payment confirmation |

## Menu

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/api/categories` | public\* / any staff | \*public needs `?restaurantId=` |
| POST | `/api/categories` | owner, manager | |
| PATCH / DELETE | `/api/categories/[id]` | owner, manager | |
| GET | `/api/menu` | public\* / any staff | |
| POST | `/api/menu` | owner, manager | Enforces plan's product limit |
| PATCH / DELETE | `/api/menu/[id]` | owner, manager | |
| GET | `/api/offers` | public\* / any staff | |
| POST | `/api/offers` | owner, manager | |
| PATCH / DELETE | `/api/offers/[id]` | owner, manager | |

## Tables

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/api/tables` | public\* / any staff | |
| POST | `/api/tables` | owner, manager | |
| PATCH | `/api/tables/[id]` | owner, manager, waiter | Waiters limited to status/waiterName/currentOrderId |
| DELETE | `/api/tables/[id]` | owner, manager | |
| GET | `/api/tables/[id]/qr` | owner, manager, waiter | `?format=png\|json`, `?regenerate=1` |
| POST | `/api/tables/[id]/qr` | owner, manager | Force-regenerate |

## Orders (customer-facing routes need no login — see below)

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/api/orders` | any staff | `?tableNumber=&active=1&includeArchived=1` |
| POST | `/api/orders` | public\* / any staff | Creates an order; enforces plan's order limit |
| GET | `/api/orders/[id]` | public | Order id itself encodes its tenant — no query param needed |
| PATCH | `/api/orders/[id]` | owner, manager, waiter | Status/discount/payment updates |
| POST | `/api/orders/[id]/items` | public | Add items to an in-progress order |
| GET | `/api/orders/[id]/kot` | public | Items not yet sent to the kitchen printer |
| POST | `/api/orders/[id]/kot` | public | Marks pending items as printed |
| GET | `/api/orders/[id]/bill` | public | First call finalizes + archives the order; later calls just read it back |

\* "public" here means unauthenticated customer requests — see
`MIGRATION_NOTES.md` / `tenant-context.ts` for how these resolve which
restaurant they belong to (`?restaurantId=` for menu-browsing routes, the
order id itself for everything order-scoped).

## Staff

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/api/users` | owner, manager | This restaurant's staff |
| POST | `/api/users` | owner, manager | Managers may only create waiters |
| PATCH | `/api/users/[id]` | owner, manager | Password reset, activate/deactivate, permissions |
| DELETE | `/api/users/[id]` | owner, manager | |

## Settings

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/api/settings` | public\* / any staff | Tax rate, currency, opening hours |
| PATCH | `/api/settings` | owner | |

## Reports & analytics

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/api/reports/daily` | owner, manager | `?date=` or `?from=&to=` |
| GET | `/api/reports/weekly` | owner, manager | `?week=2026-W30` |
| GET | `/api/reports/monthly` | owner, manager | `?month=2026-07` or `?year=2026` |
| GET | `/api/reports/yearly` | owner, manager | `?year=2026` |
| GET | `/api/reports/items` | owner, manager | Item/category/food-type performance |
| GET | `/api/analytics` | owner, manager | Dashboard summary (revenue trend, best/slow sellers, peak hours, ...) |

## Finance

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/api/finance/expenses` | owner, manager | `?month=` or `?year=` |
| POST | `/api/finance/expenses` | owner, manager | |
| PATCH / DELETE | `/api/finance/expenses/[id]` | owner, manager | |
| GET | `/api/finance/pnl` | owner, manager | `?period=monthly\|yearly&key=` |

## Notifications & activity

| Method | Path | Roles | Notes |
|---|---|---|---|
| GET | `/api/notifications` | owner, manager, waiter | `?unread=1` |
| PATCH | `/api/notifications` | owner, manager, waiter | `{markAllRead: true}` |
| PATCH | `/api/notifications/[id]` | owner, manager, waiter | Mark one read |
| GET | `/api/activity-logs` | owner, manager | This restaurant's own audit trail + login history |

## Scheduled jobs

| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/api/cron/check-subscriptions` | `Authorization: Bearer $CRON_SECRET` | Proactive expiry notifications — wire to a daily scheduler |
