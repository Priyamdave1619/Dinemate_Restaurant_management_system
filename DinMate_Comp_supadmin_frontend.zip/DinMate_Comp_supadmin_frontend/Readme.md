# Sevusal Admin — Setup & Super Admin Guide

This document covers **backend setup**, **database**, **super admin account**, and how the **admin site** talks to the API.

Base API (local): `http://localhost:3000`  
Swagger UI: `http://localhost:3000/swagger-ui/index.html`

---

## 1. Prerequisites

- Node.js 20+
- Neon PostgreSQL (or any Postgres) connection string with `sslmode=require`
- Backend folder: `backend-postgres-r2-updated`

---

## 2. Environment (`.env`)

Create / edit `.env` in the backend root:

```env
# Neon PostgreSQL (required)
DATABASE_URL=postgresql://USER:PASSWORD@HOST/neondb?sslmode=require

# JWT signing secret (required in production — use a long random string)
AUTH_SECRET=change-me-to-a-long-random-secret

# Bootstrap credentials (used on first login OR by create-superadmin script)
SUPER_ADMIN_USERNAME=Superadmin
SUPER_ADMIN_PASSWORD=StrongPass123!

# CORS — admin site origin(s), comma-separated
ALLOWED_ORIGINS=http://localhost:3001,http://localhost:3000

# Customer / QR base URL
NEXT_PUBLIC_BASE_URL=http://localhost:3000

# Optional
# CRON_SECRET=
# RAZORPAY_KEY_ID=
# RAZORPAY_KEY_SECRET=
# RAZORPAY_WEBHOOK_SECRET=
```

> **Security:** Never commit real `.env` values. Rotate passwords if this file was shared.

---

## 3. Install & create database tables

```bash
cd backend-postgres-r2-updated
npm install

# Create all Postgres tables (users, restaurants, orders, …)
npm run db:setup
```

You should see: `Done. 28 statements applied. Table "users" exists.`

---

## 4. Super Admin account

### Current credentials (this environment)

| Field        | Value              |
|-------------|--------------------|
| **Username** | `superadmin`       |
| **Password** | `StrongPass123!`   |
| **Role**     | `super_admin`      |

> Username is stored **lowercase**. Login accepts any case; the account is `superadmin`.

### Create or reset super admin (npm)

```bash
npm run create-superadmin -- --username Superadmin --password 'StrongPass123!'
```

Optional custom name:

```bash
npm run create-superadmin -- --username Superadmin --password 'StrongPass123!' --name "Platform Super Admin"
```

This **creates** the user if missing, or **resets the password** if the username already exists.

### Alternative: env bootstrap

If `SUPER_ADMIN_USERNAME` and `SUPER_ADMIN_PASSWORD` are set in `.env`, the first successful call to `POST /api/auth/login` can also create the account (only when it does not exist yet — it does **not** update an existing password). Prefer `npm run create-superadmin` when you need a known password.

---

## 5. Start the API

```bash
npm run dev
```

- API: http://localhost:3000  
- Status page: http://localhost:3000  
- Swagger: http://localhost:3000/swagger-ui/index.html  
- Health: http://localhost:3000/api/health  

---

## 6. Login API (admin site uses this)

**Endpoint**

```http
POST /api/auth/login
Content-Type: application/json
```

**Body**

```json
{
  "username": "superadmin",
  "password": "StrongPass123!"
}
```

**Example**

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"superadmin","password":"StrongPass123!"}'
```

**Success (200)** — use `data.accessToken` on later requests:

```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "id": "...",
    "username": "superadmin",
    "name": "Platform Super Admin",
    "role": "super_admin",
    "restaurantId": null,
    "accessToken": "<JWT — 15 minutes>",
    "refreshToken": "<opaque — long lived>"
  }
}
```

**Authenticated calls**

```http
Authorization: Bearer <accessToken>
```

**Refresh** (when access token expires → 401):

```http
POST /api/auth/refresh
Authorization: Bearer <refreshToken>
```

**Logout**

```http
POST /api/auth/logout
Authorization: Bearer <accessToken>
```

---

## 7. Admin site configuration

Point the admin frontend at the backend:

| Setting | Example |
|--------|---------|
| API base URL | `http://localhost:3000` |
| Login path | `POST /api/auth/login` |
| Token header | `Authorization: Bearer <accessToken>` |
| Allowed origin (backend `.env`) | `http://localhost:3001` (or your admin port) |

Add the admin origin to `ALLOWED_ORIGINS` or browser CORS will block requests.

### Who logs in where

| Role | Username | Typical UI |
|------|----------|------------|
| **Super admin** | `superadmin` | Admin / platform console (`/api/admin/*`) |
| **Owner** | Restaurant ID e.g. `REST000021` | Owner dashboard |
| **Manager / Waiter** | Staff username set by owner | Staff / waiter apps |

There is **one** login endpoint for all roles: `POST /api/auth/login`.

---

## 8. Super admin API surface

After login with `role: super_admin`:

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/admin/dashboard` | Platform totals |
| GET | `/api/admin/restaurants` | List tenants (`?status=&search=&page=`) |
| POST | `/api/admin/restaurants` | Provision restaurant + owner |
| GET | `/api/admin/restaurants/[id]` | Detail, staff, audit |
| PATCH | `/api/admin/restaurants/[id]` | Status, plan, renew, profile |
| DELETE | `/api/admin/restaurants/[id]` | Remove restaurant record |
| GET | `/api/admin/plans` | List plans |
| POST | `/api/admin/plans` | Create plan |
| PATCH | `/api/admin/plans/[id]` | Edit plan |
| DELETE | `/api/admin/plans/[id]` | Delete plan (if unused) |
| GET | `/api/admin/audit-logs` | Audit / login history |

Full interactive list: **Swagger UI** → Authorize with access token.

---

## 9. Quick checklist

```text
[ ] .env has DATABASE_URL, AUTH_SECRET, ALLOWED_ORIGINS
[ ] npm install
[ ] npm run db:setup
[ ] npm run create-superadmin -- --username Superadmin --password 'StrongPass123!'
[ ] npm run dev
[ ] POST /api/auth/login with superadmin / StrongPass123!
[ ] Admin site API URL = http://localhost:3000
[ ] Admin origin listed in ALLOWED_ORIGINS
```

---

## 10. Troubleshooting

| Problem | Fix |
|--------|-----|
| `relation "users" does not exist` | Run `npm run db:setup` |
| Login 401 / invalid credentials | Username is `superadmin`; reset with `npm run create-superadmin` |
| CORS error in admin browser | Add admin origin to `ALLOWED_ORIGINS`, restart API |
| `Expression expected` in `pg.ts` | Remove stray `}`; use fixed `src/lib/server/pg.ts` |
| 503 on `/api/health` | Check `DATABASE_URL` and Neon project status |

---

## 11. Change super admin password later

```bash
npm run create-superadmin -- --username Superadmin --password 'NewStrongPassword!'
```

Then log in again with the new password (old access tokens still expire in ~15 minutes).

---

*Credentials in section 4 match the account created during this setup. Change them before production.*
