# API Load Balancing & High Availability

The DineMate backend is a **Next.js App Router** API. Request distribution, TLS termination, rate limiting, and health-based failover belong at the **infrastructure layer**, not inside application route handlers.

## Recommended production topology

```
                    ┌─────────────────┐
  Clients ─────────►│  CDN / WAF      │  (Cloudflare / AWS CloudFront)
                    │  DDoS, TLS,     │
                    │  cache static   │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │  Load Balancer  │  (Nginx / HAProxy / ALB / Vercel Edge)
                    │  health checks  │
                    │  rate limit     │
                    └────────┬────────┘
              ┌──────────────┼──────────────┐
              ▼              ▼              ▼
         API instance    API instance   API instance
         (Next.js)       (Next.js)      (Next.js)
              │              │              │
              └──────────────┼──────────────┘
                             ▼
                    Neon PostgreSQL (pooled)
                    R2 / S3 object storage
```

## Health endpoints (already in backend)

| Path | Purpose |
|------|---------|
| `GET /api/health` | Process + DB liveness — **200** healthy, **503** DB down |
| `GET /api/health/db` | Detailed DB latency / version (no secrets) |
| `GET /api/admin/system` | Super-admin metrics (auth required) |

Configure the LB to probe `/api/health` every 5–10s. Remove unhealthy targets automatically.

## Nginx reverse-proxy example

```nginx
upstream dinemate_api {
    least_conn;
    server 10.0.1.11:3000 max_fails=3 fail_timeout=30s;
    server 10.0.1.12:3000 max_fails=3 fail_timeout=30s;
    server 10.0.1.13:3000 max_fails=3 fail_timeout=30s;
    keepalive 32;
}

limit_req_zone $binary_remote_addr zone=api_limit:10m rate=30r/s;

server {
    listen 443 ssl http2;
    server_name api.yourplatform.com;

    ssl_certificate     /etc/ssl/certs/fullchain.pem;
    ssl_certificate_key /etc/ssl/private/privkey.pem;

    # Security headers
    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options DENY always;
    add_header Referrer-Policy strict-origin-when-cross-origin always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Compression
    gzip on;
    gzip_types application/json text/plain application/javascript;

    location / {
        limit_req zone=api_limit burst=60 nodelay;

        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Connection "";

        proxy_connect_timeout 5s;
        proxy_read_timeout 60s;

        proxy_pass http://dinemate_api;
    }

    location /api/health {
        access_log off;
        proxy_pass http://dinemate_api;
    }
}
```

## Vercel / serverless

When deploying on Vercel:

- Edge network provides global anycast + automatic scaling
- Use `vercel.json` crons (already present for subscription checks)
- Set `ALLOWED_ORIGINS` to include admin panel origin
- Neon serverless driver already used — scale DB connections via pooler

## Session / JWT notes

Auth is **stateless JWT** (access 15m + rotating refresh). No sticky sessions are required for the API. Refresh tokens are stored server-side and revoked on logout.

## Rate limiting & DDoS

Prefer edge WAF (Cloudflare Rate Limiting / AWS WAF) in front of the LB. Application-level throttling can be added later with Redis if needed.

## Zero-downtime deploys

- Rolling update of upstream instances
- LB marks new instances ready only after `/api/health` returns 200
- Drain old instances (connection draining 30–60s)

## Metrics

Export:

- Request rate, latency p50/p95/p99
- Error rate (4xx/5xx)
- Upstream health status
- DB pool saturation

Hook into Prometheus + Grafana or your cloud provider’s APM.
