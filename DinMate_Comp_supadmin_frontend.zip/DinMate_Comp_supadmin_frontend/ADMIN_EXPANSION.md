# Company Admin Portal — Expansion Notes

## What was already in place

**Backend (DineMate / DineMate API)** already exposes enterprise multi-tenant APIs:

- Auth (login, refresh, logout, me) with JWT + httpOnly cookies
- Super Admin: dashboard, restaurants CRUD, plans CRUD, audit/login logs
- Tenant: menu, categories, offers, tables + QR, orders (public + staff), staff users, settings
- Billing (Razorpay checkout / verify / webhook)
- Reports (daily/weekly/monthly/yearly/items), analytics, finance/expenses/PnL
- Notifications, activity logs, subscription cron

**Admin panel** already covered:

- Super Admin login + protected shell
- Live dashboard, restaurants list/detail/provision/suspend/renew/delete
- Plans list + activate/deactivate/delete
- Audit & login logs
- Settings (session + API URL)

## What this pass added

### Backend

| Endpoint | Role | Purpose |
|----------|------|---------|
| `GET /api/admin/users` | super_admin | Platform-wide user directory (search, role, pagination) |
| `GET /api/admin/system` | super_admin | Health, memory, uptime, integration flags |

Files:

- `src/app/api/admin/users/route.ts`
- `src/app/api/admin/system/route.ts`

Copy these into the main backend tree if you develop from the original zip.

### Admin portal

| Page | Live API |
|------|----------|
| `/users` | `GET /api/admin/users` |
| `/system` | `GET /api/admin/system` (30s auto-refresh) |
| `/plans` | Full create form → `POST /api/admin/plans` |

Sidebar + header titles updated.

## Scope reality check

The request listed **every** platform resource with full CRUD, bulk ops, import/export, soft-delete, RBAC matrices, API keys, backup/restore, delivery, variants/add-ons, load balancer inside the app, etc.

That is a multi-quarter product roadmap. The current system is correctly split:

- **Tenant operations** (menu, orders, QR, staff, reports) → Restaurant owner/manager apps (not this Super Admin panel)
- **Platform operations** (tenants, plans, billing status, audit, system health) → This admin portal

Super Admin can already provision/suspend/renew any restaurant and inspect staff via restaurant detail. Deep menu/order editing for a tenant from Super Admin would mean proxy APIs that impersonate a tenant — add only if product requires it.

## Load balancer

See `docs/LOAD_BALANCING.md`. Implemented at Nginx/Cloudflare/ALB/Vercel edge — not as application code.

## How to run

```bash
# Backend
cd DineMate_Backend
cp .env.example .env   # configure DATABASE_URL, JWT secrets, SUPER_ADMIN_*
npm install && npm run dev   # :3000

# Admin
cd DineMate-admin-panel
# NEXT_PUBLIC_API_URL=http://localhost:3000
npm install && npm run dev   # :3001
```

Login with `SUPER_ADMIN_USERNAME` / `SUPER_ADMIN_PASSWORD` from backend env.
