export type UserRole = "super_admin" | "owner" | "manager" | "waiter";

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  restaurantId: string | null;
  active?: boolean;
  createdAt?: string;
}

export interface RestaurantSummary {
  id: string;
  name: string;
  status: string;
  subscriptionStatus?: string;
  subscriptionExpiresAt?: string;
  planId?: string;
}

export interface SessionUser {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  restaurantId: string | null;
}

export interface LoginResponse {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  restaurantId: string | null;
  restaurant: RestaurantSummary | null;
  accessToken: string;
  refreshToken: string;
}

export interface Restaurant {
  id: string;
  name: string;
  ownerName: string;
  email: string;
  mobile: string;
  address?: string;
  gstNumber?: string;
  status: "active" | "suspended" | "pending";
  planId: string;
  subscriptionStatus: string;
  subscriptionExpiresAt: string;
  createdAt: string;
  updatedAt?: string;
  logoUrl?: string;
  timezone?: string;
  currency?: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  durationDays: number;
  price: number;
  currency: string;
  productLimit: number;
  orderLimit: number;
  userLimit: number;
  storageLimitMb: number;
  features: string[];
  active: boolean;
  createdAt: string;
}

export interface DashboardData {
  restaurants: {
    total: number;
    active: number;
    suspended: number;
    pending: number;
    expiredSubscriptions: number;
  };
  staff: {
    managers: number;
    waiters: number;
    owners: number;
  };
  today: { orders: number; revenue: number };
  monthlyRevenue: number;
  plansInUse: Record<string, number>;
  recentRegistrations: Array<{
    id: string;
    name: string;
    ownerName: string;
    status: string;
    createdAt: string;
    planId: string;
  }>;
}

export interface AuditLogEntry {
  id: string;
  restaurantId?: string | null;
  actorUserId?: string;
  actorName?: string;
  actorRole?: string;
  action: string;
  entityType?: string;
  entityId?: string;
  details?: unknown;
  ip?: string;
  userAgent?: string;
  createdAt: string;
}

export interface LoginHistoryEntry {
  id: string;
  restaurantId?: string | null;
  userId?: string;
  username?: string;
  role?: string;
  success: boolean;
  ip?: string;
  userAgent?: string;
  createdAt: string;
}

export interface ApiSuccess<T> {
  success: true;
  message: string;
  data: T;
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
  };
}

export interface ApiError {
  success: false;
  message: string;
  errors?: unknown[];
}
