"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useAuthStore } from "@/lib/stores/auth-store";
import { updateProfile, changePassword } from "@/lib/api/auth";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { Loader2 } from "lucide-react";

export default function SettingsPage() {
  const user = useAuthStore((s) => s.user);
  const accessToken = useAuthStore((s) => s.accessToken);
  const refreshToken = useAuthStore((s) => s.refreshToken);
  const setAuth = useAuthStore((s) => s.setAuth);
  const restaurant = useAuthStore((s) => s.restaurant);
  const apiUrl = process.env.NEXT_PUBLIC_API_URL;

  const [name, setName] = useState(user?.name || "");
  const [username, setUsername] = useState(user?.username || "");
  const [profileLoading, setProfileLoading] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [pwLoading, setPwLoading] = useState(false);

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Name is required");
      return;
    }
    if (!username.trim() || username.trim().length < 3) {
      toast.error("Username must be at least 3 characters");
      return;
    }
    setProfileLoading(true);
    try {
      const body: { name?: string; username?: string } = {};
      if (name.trim() !== user?.name) body.name = name.trim();
      if (username.trim().toLowerCase() !== user?.username?.toLowerCase()) {
        body.username = username.trim();
      }
      if (!body.name && !body.username) {
        toast.message("No changes to save");
        setProfileLoading(false);
        return;
      }
      const res = await updateProfile(body);
      if (user && accessToken && refreshToken) {
        setAuth({
          user: {
            ...user,
            name: res.user.name,
            username: res.user.username,
          },
          restaurant,
          accessToken: res.accessToken || accessToken,
          refreshToken,
        });
      }
      setName(res.user.name);
      setUsername(res.user.username);
      toast.success("Profile updated");
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setProfileLoading(false);
    }
  }

  async function savePassword(e: React.FormEvent) {
    e.preventDefault();
    if (newPassword.length < 8) {
      toast.error("New password must be at least 8 characters");
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error("New passwords do not match");
      return;
    }
    setPwLoading(true);
    try {
      await changePassword({ currentPassword, newPassword });
      toast.success("Password changed successfully");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setPwLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Account</CardTitle>
          <CardDescription>Signed-in Super Admin</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Role</span>
            <Badge>{user?.role}</Badge>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Update profile</CardTitle>
          <CardDescription>Change your display name and login username</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={saveProfile} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Display name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Your name"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="login username"
                required
                minLength={3}
                autoComplete="username"
              />
              <p className="text-xs text-muted-foreground">
                Used to sign in. Letters, numbers, and . _ @ - only. Must be unique on the platform.
              </p>
            </div>
            <Button type="submit" disabled={profileLoading}>
              {profileLoading && <Loader2 className="h-4 w-4 animate-spin" />}
              Save profile
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Change password</CardTitle>
          <CardDescription>
            Use a strong password (min. 8 characters). Other devices will need to sign in again.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={savePassword} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="current">Current password</Label>
              <Input
                id="current"
                type="password"
                autoComplete="current-password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new">New password</Label>
              <Input
                id="new"
                type="password"
                autoComplete="new-password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                minLength={8}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm">Confirm new password</Label>
              <Input
                id="confirm"
                type="password"
                autoComplete="new-password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                minLength={8}
              />
            </div>
            <Button type="submit" disabled={pwLoading}>
              {pwLoading && <Loader2 className="h-4 w-4 animate-spin" />}
              Change password
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">API connection</CardTitle>
          <CardDescription>Backend endpoint this admin panel uses</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex justify-between gap-4">
            <span className="text-muted-foreground shrink-0">Base URL</span>
            <code className="rounded bg-muted px-2 py-1 text-xs break-all">{apiUrl}</code>
          </div>
          <p className="text-xs text-muted-foreground">
            Configure via <code>NEXT_PUBLIC_API_URL</code> in <code>.env.local</code>. Auth uses Bearer JWT
            with automatic refresh.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Platform</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-2">
          <p>Database: Neon PostgreSQL (managed via backend)</p>
          <p>Object storage: Cloudflare R2 (managed via backend)</p>
          <p>Payments: Razorpay (optional, backend-configured)</p>
          <p>Logging: critical auth events, admin actions, and errors only</p>
        </CardContent>
      </Card>
    </div>
  );
}
