"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { getRevenueReport } from "@/lib/api/admin";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TableLoader, CardsLoader } from "@/components/ui/loader";
import { formatCurrency, formatNumber } from "@/lib/utils/format";

export default function ReportsPage() {
  const now = new Date();
  const defaultMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const [month, setMonth] = useState(defaultMonth);

  const { data, isLoading } = useQuery({
    queryKey: ["revenue-report", month],
    queryFn: () => getRevenueReport({ month }),
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-sm text-muted-foreground">Restaurant-wise revenue for the selected month</p>
        </div>
        <input
          type="month"
          className="h-10 rounded-lg border border-input bg-background px-3 text-sm"
          value={month}
          onChange={(e) => setMonth(e.target.value)}
        />
      </div>

      {data?.totals && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: "Net sales", value: formatCurrency(data.totals.netSales) },
            { label: "Gross sales", value: formatCurrency(data.totals.grossSales) },
            { label: "Orders", value: formatNumber(data.totals.orderCount) },
            { label: "Tax", value: formatCurrency(data.totals.taxTotal) },
          ].map((s) => (
            <Card key={s.label}>
              <CardContent className="p-5">
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className="mt-1 text-2xl font-bold">{s.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">By restaurant</CardTitle>
          <CardDescription>Month {data?.month || month}</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <TableLoader rows={6} cols={6} />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-muted/40 text-left text-muted-foreground">
                    <th className="px-4 py-3 font-medium">Restaurant</th>
                    <th className="px-4 py-3 font-medium">Plan</th>
                    <th className="px-4 py-3 font-medium">Status</th>
                    <th className="px-4 py-3 font-medium text-right">Orders</th>
                    <th className="px-4 py-3 font-medium text-right">Net sales</th>
                    <th className="px-4 py-3 font-medium text-right">Gross</th>
                  </tr>
                </thead>
                <tbody>
                  {(data?.rows || []).map((r) => (
                    <tr key={r.restaurantId} className="border-b border-border/50">
                      <td className="px-4 py-3">
                        <Link href={`/restaurants/${r.restaurantId}`} className="font-medium hover:text-primary">
                          {r.name}
                        </Link>
                        <p className="text-xs text-muted-foreground">{r.restaurantId}</p>
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="outline">{r.planId}</Badge>
                      </td>
                      <td className="px-4 py-3">
                        <Badge
                          variant={
                            r.status === "active" ? "success" : r.status === "suspended" ? "destructive" : "warning"
                          }
                        >
                          {r.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-right">{formatNumber(r.orderCount)}</td>
                      <td className="px-4 py-3 text-right font-medium">{formatCurrency(r.netSales)}</td>
                      <td className="px-4 py-3 text-right text-muted-foreground">{formatCurrency(r.grossSales)}</td>
                    </tr>
                  ))}
                  {(data?.rows || []).length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-muted-foreground">
                        No restaurants found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
