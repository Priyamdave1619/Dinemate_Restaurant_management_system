"use client";

import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { listPlatformUsers, createPlatformUser } from "@/lib/api/admin";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus } from "lucide-react";
import { formatDate } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { Modal } from "@/components/ui/modal";
import { Spinner, OverlayLoader } from "@/components/ui/loader";
import { DataTable, buildPaginationMeta, type ColumnDef } from "@/components/data-table";
import { useTableState } from "@/hooks/use-table-state";
import { PasswordStrengthMeter } from "@/components/security/password-strength";
import {
  createAdminSchema,
  type CreateAdminFormValues,
  checkRateLimit,
  RATE,
  LIMITS,
} from "@/lib/security";

type PlatformUser = {
  id: string;
  username: string;
  name: string;
  role: string;
  restaurantId: string | null;
  active: boolean;
  createdAt?: string;
  lastLoginAt?: string;
};

export default function UsersPage() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const table = useTableState({ defaultSortBy: "createdAt", defaultSortDir: "desc" });

  const role = table.filters.role || "";

  const { data, isLoading } = useQuery({
    queryKey: ["platform-users", table.queryParams],
    queryFn: () =>
      listPlatformUsers({
        search: table.queryParams.search,
        role: role || undefined,
        page: table.queryParams.page,
        pageSize: table.queryParams.pageSize,
      }),
  });

  const columns = useMemo<ColumnDef<PlatformUser>[]>(
    () => [
      {
        id: "name",
        header: "User",
        sortable: true,
        accessor: (u) => u.name,
        cell: (u) => (
          <div>
            <p className="font-medium">{u.name}</p>
            <p className="text-xs text-muted-foreground">{u.username}</p>
          </div>
        ),
      },
      {
        id: "role",
        header: "Role",
        sortable: true,
        accessor: (u) => u.role,
        cell: (u) => (
          <Badge variant="secondary">{u.role === "super_admin" ? "Admin" : u.role}</Badge>
        ),
      },
      {
        id: "restaurantId",
        header: "Restaurant",
        sortable: true,
        accessor: (u) => u.restaurantId || "",
        className: "text-xs text-muted-foreground",
        cell: (u) => u.restaurantId || "—",
      },
      {
        id: "active",
        header: "Status",
        sortable: true,
        accessor: (u) => (u.active ? 1 : 0),
        cell: (u) => (
          <Badge variant={u.active ? "success" : "secondary"}>
            {u.active ? "Active" : "Inactive"}
          </Badge>
        ),
      },
      {
        id: "createdAt",
        header: "Created",
        sortable: true,
        accessor: (u) => u.createdAt || "",
        className: "text-xs text-muted-foreground",
        cell: (u) => (u.createdAt ? formatDate(u.createdAt) : "—"),
      },
    ],
    []
  );

  const users = data?.users || [];
  const meta = data?.pagination
    ? {
        page: data.pagination.page,
        pageSize: data.pagination.pageSize,
        total: data.pagination.total,
        totalPages: data.pagination.totalPages,
      }
    : buildPaginationMeta(users.length, table.page, table.pageSize);

  return (
    <div className="space-y-6">
      {data?.summary && (
        <div className="flex flex-wrap gap-3 text-sm">
          <Badge variant="secondary">Total {data.summary.total}</Badge>
          <Badge variant="outline">Admins {data.summary.byRole?.super_admin ?? 0}</Badge>
          <Badge variant="outline">Owners {data.summary.byRole?.owner ?? 0}</Badge>
          <Badge variant="outline">Managers {data.summary.byRole?.manager ?? 0}</Badge>
          <Badge variant="outline">Waiters {data.summary.byRole?.waiter ?? 0}</Badge>
        </div>
      )}

      <DataTable<PlatformUser>
        columns={columns}
        data={users}
        getRowId={(u) => u.id}
        loading={isLoading}
        pagination={meta}
        onPageChange={table.setPage}
        onPageSizeChange={table.setPageSize}
        search={table.search}
        onSearchChange={table.setSearch}
        searchPlaceholder="Search username, name…"
        sortBy={table.sortBy}
        sortDir={table.sortDir}
        onSort={table.toggleSort}
        hasActiveFilters={table.hasActiveFilters}
        onClearFilters={table.clearFilters}
        toolbarLeft={
          <select
            className="h-10 rounded-lg border border-input bg-background px-3 text-sm"
            value={role}
            onChange={(e) => table.setFilter("role", e.target.value)}
          >
            <option value="">All roles</option>
            <option value="super_admin">Super Admin / Admin</option>
            <option value="owner">Owner</option>
            <option value="manager">Manager</option>
            <option value="waiter">Waiter</option>
          </select>
        }
        toolbarRight={
          <Button onClick={() => setShowCreate(true)}>
            <Plus className="h-4 w-4" /> Create admin
          </Button>
        }
        emptyTitle="No users found"
        emptyDescription="Try a different search or role filter."
      />

      {showCreate && (
        <CreateAdminModal
          onClose={() => setShowCreate(false)}
          onCreated={() => {
            setShowCreate(false);
            qc.invalidateQueries({ queryKey: ["platform-users"] });
          }}
        />
      )}
    </div>
  );
}

function CreateAdminModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [loading, setLoading] = useState(false);
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<CreateAdminFormValues>({
    resolver: zodResolver(createAdminSchema),
    mode: "onBlur",
    defaultValues: { name: "", username: "", password: "", role: "admin" },
  });
  const password = watch("password");

  async function onSubmit(values: CreateAdminFormValues) {
    const rl = checkRateLimit("create:admin", RATE.createResource.max, RATE.createResource.windowMs);
    if (!rl.allowed) {
      toast.error(rl.message);
      return;
    }
    setLoading(true);
    try {
      await createPlatformUser(values);
      toast.success("Admin account created");
      onCreated();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title="Create admin account"
      description="Platform-level admin with access to the Company Admin Portal."
      preventClose={loading}
    >
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-3 relative" noValidate>
        <OverlayLoader show={loading} label="Creating account…" />
        <div className="space-y-1.5">
          <Label htmlFor="admin-name">Full name</Label>
          <Input
            id="admin-name"
            placeholder="Full name"
            maxLength={LIMITS.name.max}
            aria-invalid={!!errors.name}
            {...register("name")}
          />
          {errors.name && (
            <p className="text-xs text-destructive" role="alert">
              {errors.name.message}
            </p>
          )}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="admin-username">Username</Label>
          <Input
            id="admin-username"
            placeholder="Username"
            maxLength={LIMITS.username.max}
            autoComplete="off"
            aria-invalid={!!errors.username}
            {...register("username")}
          />
          {errors.username && (
            <p className="text-xs text-destructive" role="alert">
              {errors.username.message}
            </p>
          )}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="admin-password">Password</Label>
          <Input
            id="admin-password"
            placeholder="Min 12 chars, upper, lower, number, special"
            type="password"
            maxLength={LIMITS.password.max}
            autoComplete="new-password"
            aria-invalid={!!errors.password}
            {...register("password")}
          />
          <PasswordStrengthMeter password={password || ""} />
          {errors.password && (
            <p className="text-xs text-destructive" role="alert">
              {errors.password.message}
            </p>
          )}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="admin-role">Role</Label>
          <select
            id="admin-role"
            className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm"
            {...register("role")}
          >
            <option value="admin">Admin</option>
            <option value="super_admin">Super Admin</option>
          </select>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading && <Spinner />}
            {loading ? "Creating…" : "Create"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
