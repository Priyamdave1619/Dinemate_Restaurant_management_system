"use client";

import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  Store,
  Users,
  ShoppingCart,
  IndianRupee,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Ban,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";
import { getDashboard, listPlans } from "@/lib/api/admin";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CardsLoader, PageLoader } from "@/components/ui/loader";
import { formatCurrency, formatNumber, formatDate, relativeTime } from "@/lib/utils/format";
import Link from "next/link";

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.06 } },
};
const item = {
  hidden: { opacity: 0, y: 12 },
  show: { opacity: 1, y: 0 },
};

export default function DashboardPage() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["admin-dashboard"],
    queryFn: getDashboard,
  });
  const { data: plans } = useQuery({ queryKey: ["plans"], queryFn: listPlans });

  if (isLoading) {
    return <CardsLoader count={8} />;
  }

  if (error || !data) {
    return (
      <Card className="p-8 text-center">
        <p className="text-destructive">Failed to load dashboard. Is the backend running?</p>
      </Card>
    );
  }

  const stats = [
    {
      label: "Total Restaurants",
      value: data.restaurants.total,
      icon: Store,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      label: "Active",
      value: data.restaurants.active,
      icon: CheckCircle2,
      color: "text-emerald-500",
      bg: "bg-emerald-500/10",
    },
    {
      label: "Suspended",
      value: data.restaurants.suspended,
      icon: Ban,
      color: "text-red-500",
      bg: "bg-red-500/10",
    },
    {
      label: "Expired Subs",
      value: data.restaurants.expiredSubscriptions,
      icon: AlertTriangle,
      color: "text-amber-500",
      bg: "bg-amber-500/10",
    },
    {
      label: "Today's Orders",
      value: data.today.orders,
      icon: ShoppingCart,
      color: "text-blue-500",
      bg: "bg-blue-500/10",
    },
    {
      label: "Today's Revenue",
      value: formatCurrency(data.today.revenue),
      icon: IndianRupee,
      color: "text-emerald-500",
      bg: "bg-emerald-500/10",
      raw: true,
    },
    {
      label: "Monthly Revenue",
      value: formatCurrency(data.monthlyRevenue),
      icon: IndianRupee,
      color: "text-primary",
      bg: "bg-primary/10",
      raw: true,
    },
    {
      label: "Staff (Owners)",
      value: data.staff.owners,
      icon: Users,
      color: "text-sky-500",
      bg: "bg-sky-500/10",
    },
  ];

  const planChart =
    plans?.map((p) => ({
      name: p.name,
      count: data.plansInUse[p.id] || 0,
    })) || Object.entries(data.plansInUse).map(([id, count]) => ({ name: id, count }));

  return (
    <motion.div variants={container} initial="hidden" animate="show" className="space-y-6">
      <motion.div variants={item} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="overflow-hidden">
              <CardContent className="p-5">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">{s.label}</p>
                    <p className="mt-2 text-2xl font-bold tracking-tight">
                      {s.raw ? s.value : formatNumber(s.value as number)}
                    </p>
                  </div>
                  <div className={`rounded-xl p-2.5 ${s.bg}`}>
                    <Icon className={`h-5 w-5 ${s.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-3">
        <motion.div variants={item} className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Plans in use</CardTitle>
              <CardDescription>Restaurants per subscription plan</CardDescription>
            </CardHeader>
            <CardContent className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={planChart}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      borderRadius: 12,
                      border: "1px solid hsl(var(--border))",
                      background: "hsl(var(--card))",
                    }}
                  />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div variants={item}>
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="text-base">Staff breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: "Owners", value: data.staff.owners },
                { label: "Managers", value: data.staff.managers },
                { label: "Waiters", value: data.staff.waiters },
              ].map((r) => (
                <div key={r.label} className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{r.label}</span>
                  <span className="font-semibold">{formatNumber(r.value)}</span>
                </div>
              ))}
              <div className="pt-2 border-t">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Pending restaurants</span>
                  <Badge variant="warning">{data.restaurants.pending}</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div variants={item}>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base">Recent registrations</CardTitle>
              <CardDescription>Latest restaurants on the platform</CardDescription>
            </div>
            <Link href="/restaurants" className="text-sm text-primary hover:underline">
              View all
            </Link>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-left text-muted-foreground">
                    <th className="pb-3 font-medium">Restaurant</th>
                    <th className="pb-3 font-medium">Owner</th>
                    <th className="pb-3 font-medium">Plan</th>
                    <th className="pb-3 font-medium">Status</th>
                    <th className="pb-3 font-medium">Joined</th>
                  </tr>
                </thead>
                <tbody>
                  {data.recentRegistrations.map((r) => (
                    <tr key={r.id} className="border-b border-border/50 last:border-0">
                      <td className="py-3">
                        <Link href={`/restaurants/${r.id}`} className="font-medium hover:text-primary">
                          {r.name}
                        </Link>
                        <p className="text-xs text-muted-foreground">{r.id}</p>
                      </td>
                      <td className="py-3">{r.ownerName}</td>
                      <td className="py-3">
                        <Badge variant="secondary">{r.planId}</Badge>
                      </td>
                      <td className="py-3">
                        <Badge
                          variant={
                            r.status === "active"
                              ? "success"
                              : r.status === "suspended"
                                ? "destructive"
                                : "warning"
                          }
                        >
                          {r.status}
                        </Badge>
                      </td>
                      <td className="py-3 text-muted-foreground">{relativeTime(r.createdAt)}</td>
                    </tr>
                  ))}
                  {data.recentRegistrations.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-muted-foreground">
                        No restaurants yet
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}
