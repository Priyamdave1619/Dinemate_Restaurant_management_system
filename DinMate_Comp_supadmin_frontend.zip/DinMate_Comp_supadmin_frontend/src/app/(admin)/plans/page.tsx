"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listPlans, createPlan, updatePlan, deletePlan, listRestaurants, getDashboard } from "@/lib/api/admin";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { formatCurrency, formatDate } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { Check, Plus, Pencil, Search, Store } from "lucide-react";
import { motion } from "framer-motion";
import type { SubscriptionPlan } from "@/types";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { Spinner, CardsLoader, OverlayLoader, TableLoader } from "@/components/ui/loader";

type PlanForm = {
  name: string;
  durationDays: string;
  price: string;
  productLimit: string;
  orderLimit: string;
  userLimit: string;
  storageLimitMb: string;
  features: string;
  active: boolean;
};

const emptyForm = (): PlanForm => ({
  name: "",
  durationDays: "30",
  price: "0",
  productLimit: "-1",
  orderLimit: "-1",
  userLimit: "-1",
  storageLimitMb: "1024",
  features: "",
  active: true,
});

function formFromPlan(p: SubscriptionPlan): PlanForm {
  return {
    name: p.name,
    durationDays: String(p.durationDays),
    price: String(p.price),
    productLimit: String(p.productLimit),
    orderLimit: String(p.orderLimit),
    userLimit: String(p.userLimit),
    storageLimitMb: String(p.storageLimitMb),
    features: (p.features || []).join(", "),
    active: p.active,
  };
}

function formToBody(form: PlanForm) {
  return {
    name: form.name.trim(),
    durationDays: Number(form.durationDays),
    price: Number(form.price),
    productLimit: Number(form.productLimit),
    orderLimit: Number(form.orderLimit),
    userLimit: Number(form.userLimit),
    storageLimitMb: Number(form.storageLimitMb),
    currency: "INR",
    features: form.features
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean),
    active: form.active,
  };
}

export default function PlansPage() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all");
  const [modal, setModal] = useState<"create" | "edit" | null>(null);
  const [editing, setEditing] = useState<SubscriptionPlan | null>(null);
  const [viewPlanId, setViewPlanId] = useState<string | null>(null);
  const [deletePlanTarget, setDeletePlanTarget] = useState<SubscriptionPlan | null>(null);
  const [deleting, setDeleting] = useState(false);

  const { data: plans, isLoading } = useQuery({ queryKey: ["plans"], queryFn: listPlans });
  const { data: dashboard } = useQuery({ queryKey: ["admin-dashboard"], queryFn: getDashboard });

  const usage = dashboard?.plansInUse || {};

  const filtered = useMemo(() => {
    let list = plans || [];
    if (statusFilter === "active") list = list.filter((p) => p.active);
    if (statusFilter === "inactive") list = list.filter((p) => !p.active);
    const q = search.trim().toLowerCase();
    if (q) {
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.id.toLowerCase().includes(q) ||
          (p.features || []).some((f) => f.toLowerCase().includes(q))
      );
    }
    return list;
  }, [plans, search, statusFilter]);

  const toggleMut = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) => updatePlan(id, { active }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["plans"] });
      toast.success("Plan updated");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const delMut = useMutation({
    mutationFn: deletePlan,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["plans"] });
      toast.success("Plan deleted");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  if (isLoading) {
    return <CardsLoader count={4} />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-1 flex-wrap gap-2">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search plans by name, id, feature…"
              className="pl-9"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select
            className="h-10 rounded-lg border border-input bg-background px-3 text-sm"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
          >
            <option value="all">All plans</option>
            <option value="active">Active only</option>
            <option value="inactive">Inactive only</option>
          </select>
        </div>
        <Button
          onClick={() => {
            setEditing(null);
            setModal("create");
          }}
        >
          <Plus className="h-4 w-4" /> Add plan
        </Button>
      </div>

      <div className="flex flex-wrap gap-2 text-sm">
        <Badge variant="secondary">Total {(plans || []).length}</Badge>
        <Badge variant="success">Active {(plans || []).filter((p) => p.active).length}</Badge>
        <Badge variant="outline">Showing {filtered.length}</Badge>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {filtered.map((plan, i) => {
          const count = usage[plan.id] || 0;
          return (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
            >
              <Card className={`relative h-full ${!plan.active ? "opacity-70" : ""}`}>
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <CardTitle className="text-lg">{plan.name}</CardTitle>
                      <p className="text-xs text-muted-foreground mt-0.5 font-mono">{plan.id}</p>
                    </div>
                    <Badge variant={plan.active ? "success" : "secondary"}>
                      {plan.active ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  <CardDescription>
                    <span className="text-3xl font-bold text-foreground">
                      {plan.price === 0 ? "Free" : formatCurrency(plan.price, plan.currency)}
                    </span>
                    <span className="text-muted-foreground"> / {plan.durationDays} days</span>
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                      Products: {plan.productLimit < 0 ? "Unlimited" : plan.productLimit}
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                      Orders: {plan.orderLimit < 0 ? "Unlimited" : plan.orderLimit}
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                      Users: {plan.userLimit < 0 ? "Unlimited" : plan.userLimit}
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                      Storage: {plan.storageLimitMb} MB
                    </li>
                  </ul>
                  {plan.features?.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {plan.features.map((f) => (
                        <Badge key={f} variant="outline" className="text-[10px]">
                          {f}
                        </Badge>
                      ))}
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => setViewPlanId(plan.id)}
                    className="flex w-full items-center justify-between rounded-lg border bg-muted/40 px-3 py-2 text-sm hover:bg-muted transition-colors"
                  >
                    <span className="flex items-center gap-2 text-muted-foreground">
                      <Store className="h-4 w-4" />
                      Restaurants on this plan
                    </span>
                    <Badge variant="secondary">{count}</Badge>
                  </button>

                  <div className="flex flex-wrap gap-2 pt-1">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditing(plan);
                        setModal("edit");
                      }}
                    >
                      <Pencil className="h-3.5 w-3.5" /> Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => toggleMut.mutate({ id: plan.id, active: !plan.active })}
                    >
                      {plan.active ? "Deactivate" : "Activate"}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-destructive"
                      onClick={() => {
                        if (count > 0) {
                          toast.error("Plan is in use — deactivate it instead of deleting");
                          return;
                        }
                        setDeletePlanTarget(plan);
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <Card className="p-12 text-center text-muted-foreground">
          No plans match your search. Create one to get started.
        </Card>
      )}

      {(modal === "create" || modal === "edit") && (
        <PlanFormModal
          mode={modal}
          initial={editing ? formFromPlan(editing) : emptyForm()}
          planId={editing?.id}
          onClose={() => {
            setModal(null);
            setEditing(null);
          }}
          onSaved={() => {
            setModal(null);
            setEditing(null);
            qc.invalidateQueries({ queryKey: ["plans"] });
            qc.invalidateQueries({ queryKey: ["admin-dashboard"] });
          }}
        />
      )}

      {viewPlanId && (
        <RestaurantsOnPlanModal
          planId={viewPlanId}
          planName={plans?.find((p) => p.id === viewPlanId)?.name || viewPlanId}
          onClose={() => setViewPlanId(null)}
        />
      )}

      <ConfirmDialog
        open={!!deletePlanTarget}
        onClose={() => !deleting && setDeletePlanTarget(null)}
        title="Delete plan?"
        description={
          deletePlanTarget
            ? `Permanently delete "${deletePlanTarget.name}"? This cannot be undone.`
            : undefined
        }
        confirmLabel="Delete"
        variant="danger"
        loading={deleting}
        onConfirm={async () => {
          if (!deletePlanTarget) return;
          setDeleting(true);
          try {
            await deletePlan(deletePlanTarget.id);
            toast.success("Plan deleted");
            qc.invalidateQueries({ queryKey: ["plans"] });
            setDeletePlanTarget(null);
          } catch (e) {
            toast.error(getErrorMessage(e));
          } finally {
            setDeleting(false);
          }
        }}
      />
    </div>
  );
}

function PlanFormModal({
  mode,
  initial,
  planId,
  onClose,
  onSaved,
}: {
  mode: "create" | "edit";
  initial: PlanForm;
  planId?: string;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<PlanForm>(initial);
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) {
      toast.error("Name is required");
      return;
    }
    setLoading(true);
    try {
      const body = formToBody(form);
      if (mode === "create") {
        await createPlan(body);
        toast.success("Plan created");
      } else if (planId) {
        await updatePlan(planId, body);
        toast.success("Plan updated");
      }
      onSaved();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title={mode === "create" ? "Add subscription plan" : "Edit subscription plan"}
      description="Set pricing, limits, and availability for restaurant tenants"
      size="lg"
      preventClose={loading}
    >
        <form onSubmit={submit} className="space-y-3 relative">
          <OverlayLoader show={loading} label={mode === "create" ? "Creating…" : "Saving…"} />
          <div>
            <label className="text-xs text-muted-foreground">Name</label>
            <Input
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="e.g. Pro"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground">Duration (days)</label>
              <Input
                type="number"
                min={1}
                required
                value={form.durationDays}
                onChange={(e) => setForm({ ...form, durationDays: e.target.value })}
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Price (INR)</label>
              <Input
                type="number"
                min={0}
                required
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground">Product limit (−1 = ∞)</label>
              <Input
                type="number"
                value={form.productLimit}
                onChange={(e) => setForm({ ...form, productLimit: e.target.value })}
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Order limit (−1 = ∞)</label>
              <Input
                type="number"
                value={form.orderLimit}
                onChange={(e) => setForm({ ...form, orderLimit: e.target.value })}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-muted-foreground">User limit (−1 = ∞)</label>
              <Input
                type="number"
                value={form.userLimit}
                onChange={(e) => setForm({ ...form, userLimit: e.target.value })}
              />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Storage (MB)</label>
              <Input
                type="number"
                value={form.storageLimitMb}
                onChange={(e) => setForm({ ...form, storageLimitMb: e.target.value })}
              />
            </div>
          </div>
          <div>
            <label className="text-xs text-muted-foreground">Features (comma-separated)</label>
            <Input
              value={form.features}
              onChange={(e) => setForm({ ...form, features: e.target.value })}
              placeholder="QR ordering, Reports, Multi-waiter"
            />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.active}
              onChange={(e) => setForm({ ...form, active: e.target.checked })}
            />
            Active (available for new subscriptions)
          </label>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Spinner />}
              {mode === "create" ? "Create plan" : "Save changes"}
            </Button>
          </div>
        </form>
    </Modal>
  );
}

function RestaurantsOnPlanModal({
  planId,
  planName,
  onClose,
}: {
  planId: string;
  planName: string;
  onClose: () => void;
}) {
  const { data, isLoading } = useQuery({
    queryKey: ["restaurants-by-plan", planId],
    queryFn: () => listRestaurants({ planId, pageSize: 100 }),
  });

  return (
    <Modal open onClose={onClose} title={`Restaurants on ${planName}`} description={`Plan ID: ${planId}`} size="lg">
      {isLoading ? (
        <TableLoader rows={5} cols={3} />
      ) : (
        <div className="overflow-x-auto -mx-1">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-muted-foreground">
                <th className="py-2 pr-3 font-medium">Restaurant</th>
                <th className="py-2 pr-3 font-medium">Status</th>
                <th className="py-2 font-medium">Expires</th>
              </tr>
            </thead>
            <tbody>
              {(data?.restaurants || []).map((r) => (
                <tr key={r.id} className="border-b border-border/50">
                  <td className="py-2 pr-3">
                    <Link href={`/restaurants/${r.id}`} className="font-medium hover:text-primary" onClick={onClose}>
                      {r.name}
                    </Link>
                    <p className="text-xs text-muted-foreground">{r.id}</p>
                  </td>
                  <td className="py-2 pr-3">
                    <Badge variant={r.status === "active" ? "success" : "secondary"}>{r.status}</Badge>
                  </td>
                  <td className="py-2 text-xs text-muted-foreground">{formatDate(r.subscriptionExpiresAt)}</td>
                </tr>
              ))}
              {(data?.restaurants || []).length === 0 && (
                <tr>
                  <td colSpan={3} className="py-8 text-center text-muted-foreground">
                    No restaurants on this plan
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </Modal>
  );
}
