"use client";

import { useState } from "react";
import { useParams } from "next/navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import Link from "next/link";
import { getRestaurant, updateRestaurant, listPlans } from "@/lib/api/admin";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatDate, formatDateTime } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { ArrowLeft } from "lucide-react";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { PageLoader, Spinner, OverlayLoader } from "@/components/ui/loader";

type ConfirmState =
  | null
  | { type: "plan"; planId: string }
  | { type: "plan_renew"; planId: string; days: number }
  | { type: "suspend" };

export default function RestaurantDetailPage() {
  const { id } = useParams<{ id: string }>();
  const qc = useQueryClient();
  const [renewDays, setRenewDays] = useState("30");
  const [selectedPlanId, setSelectedPlanId] = useState<string>("");
  const [confirm, setConfirm] = useState<ConfirmState>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["restaurant", id],
    queryFn: () => getRestaurant(id),
    enabled: !!id,
  });

  const { data: plans } = useQuery({
    queryKey: ["plans"],
    queryFn: listPlans,
  });

  const mut = useMutation({
    mutationFn: (body: Parameters<typeof updateRestaurant>[1]) => updateRestaurant(id, body),
    onSuccess: (_data, variables) => {
      qc.invalidateQueries({ queryKey: ["restaurant", id] });
      qc.invalidateQueries({ queryKey: ["restaurants"] });
      if (variables.planId && variables.renew) toast.success("Plan updated & renewed");
      else if (variables.planId) toast.success("Plan updated");
      else if (variables.renew) toast.success("Subscription renewed");
      else if (variables.status) toast.success(`Status set to ${variables.status}`);
      else toast.success("Updated");
      setConfirm(null);
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  if (isLoading) return <PageLoader label="Loading restaurant…" />;
  if (!data) return <p className="text-destructive">Restaurant not found</p>;

  const { restaurant: r, staff, loginHistory, auditLogs } = data;
  const currentPlan = plans?.find((p) => p.id === r.planId);
  const planOptions = plans || [];

  return (
    <div className="space-y-4 sm:space-y-6 relative">
      <OverlayLoader show={mut.isPending} label="Updating…" />

      <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <Button variant="ghost" size="icon" asChild className="shrink-0">
            <Link href="/restaurants">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div className="min-w-0">
            <h2 className="text-lg sm:text-xl font-bold truncate">{r.name}</h2>
            <p className="text-xs sm:text-sm text-muted-foreground truncate">{r.id}</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Badge
            variant={r.status === "active" ? "success" : r.status === "suspended" ? "destructive" : "warning"}
          >
            {r.status}
          </Badge>
          {r.status === "active" ? (
            <Button size="sm" variant="outline" disabled={mut.isPending} onClick={() => setConfirm({ type: "suspend" })}>
              Suspend
            </Button>
          ) : (
            <Button size="sm" variant="outline" disabled={mut.isPending} onClick={() => mut.mutate({ status: "active" })}>
              Activate
            </Button>
          )}
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Subscription & plan</CardTitle>
          <CardDescription>Change plan or extend subscription for this restaurant</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2 text-sm">
            <div>
              <p className="text-muted-foreground text-xs">Current plan</p>
              <p className="font-medium">{currentPlan?.name || r.planId}</p>
            </div>
            <div>
              <p className="text-muted-foreground text-xs">Expires</p>
              <p className="font-medium">{formatDate(r.subscriptionExpiresAt)}</p>
            </div>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end">
            <div className="space-y-1 flex-1 min-w-[140px]">
              <label className="text-xs text-muted-foreground">Plan</label>
              <select
                className="h-10 w-full rounded-lg border border-input bg-background px-3 text-sm"
                value={selectedPlanId || r.planId}
                onChange={(e) => setSelectedPlanId(e.target.value)}
              >
                {planOptions.map((p) => (
                  <option key={p.id} value={p.id} disabled={!p.active && p.id !== r.planId}>
                    {p.name} {!p.active ? "(inactive)" : ""}
                  </option>
                ))}
              </select>
            </div>
            <div className="space-y-1 w-full sm:w-28">
              <label className="text-xs text-muted-foreground">Renew days</label>
              <Input value={renewDays} onChange={(e) => setRenewDays(e.target.value)} type="number" min={1} />
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                variant="outline"
                disabled={mut.isPending}
                onClick={() => {
                  const planId = selectedPlanId || r.planId;
                  if (!planId || planId === r.planId) {
                    toast.message("Select a different plan first");
                    return;
                  }
                  setConfirm({ type: "plan", planId });
                }}
              >
                Change plan
              </Button>
              <Button size="sm" variant="secondary" disabled={mut.isPending} onClick={() => mut.mutate({ renew: true, days: Math.max(1, Number(renewDays) || 30) })}>
                Renew only
              </Button>
              <Button
                size="sm"
                disabled={mut.isPending}
                onClick={() => {
                  const planId = selectedPlanId || r.planId;
                  const days = Math.max(1, Number(renewDays) || 30);
                  setConfirm({ type: "plan_renew", planId, days });
                }}
              >
                Plan + renew
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {[
              ["Owner", r.ownerName],
              ["Email", r.email],
              ["Mobile", r.mobile],
              ["Address", r.address || "—"],
              ["Created", formatDateTime(r.createdAt)],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4">
                <span className="text-muted-foreground shrink-0">{k}</span>
                <span className="text-right break-all">{v}</span>
              </div>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Staff ({staff?.length || 0})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 max-h-64 overflow-y-auto">
            {(staff || []).map((s) => (
              <div key={s.id} className="flex items-center justify-between text-sm gap-2">
                <div className="min-w-0">
                  <p className="font-medium truncate">{s.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{s.username}</p>
                </div>
                <Badge variant="secondary">{s.role}</Badge>
              </div>
            ))}
            {!staff?.length && <p className="text-sm text-muted-foreground">No staff</p>}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent logins</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 max-h-56 overflow-y-auto text-sm">
            {(loginHistory || []).slice(0, 10).map((h, i) => (
              <div key={i} className="flex justify-between gap-2 text-xs">
                <span className="truncate">{h.username || "—"}</span>
                <span className="text-muted-foreground shrink-0">{h.createdAt ? formatDateTime(h.createdAt) : "—"}</span>
              </div>
            ))}
            {!loginHistory?.length && <p className="text-muted-foreground">No logins</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Audit trail</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 max-h-56 overflow-y-auto text-sm">
            {(auditLogs || []).slice(0, 10).map((a, i) => (
              <div key={i} className="flex justify-between gap-2 text-xs">
                <span className="truncate">{a.action} · {a.actorName}</span>
                <span className="text-muted-foreground shrink-0">{a.createdAt ? formatDateTime(a.createdAt) : "—"}</span>
              </div>
            ))}
            {!auditLogs?.length && <p className="text-muted-foreground">No audit entries</p>}
          </CardContent>
        </Card>
      </div>

      <ConfirmDialog
        open={confirm?.type === "plan"}
        onClose={() => !mut.isPending && setConfirm(null)}
        title="Change plan?"
        description={confirm?.type === "plan" ? `Switch from "${r.planId}" to "${confirm.planId}"?` : undefined}
        confirmLabel="Change plan"
        variant="warning"
        loading={mut.isPending}
        onConfirm={() => {
          if (confirm?.type === "plan") mut.mutate({ planId: confirm.planId });
        }}
      />
      <ConfirmDialog
        open={confirm?.type === "plan_renew"}
        onClose={() => !mut.isPending && setConfirm(null)}
        title="Change plan & renew?"
        description={
          confirm?.type === "plan_renew"
            ? `Set plan to "${confirm.planId}" and extend subscription by ${confirm.days} days.`
            : undefined
        }
        confirmLabel="Apply"
        variant="warning"
        loading={mut.isPending}
        onConfirm={() => {
          if (confirm?.type === "plan_renew") {
            mut.mutate({ planId: confirm.planId, renew: true, days: confirm.days });
          }
        }}
      />
      <ConfirmDialog
        open={confirm?.type === "suspend"}
        onClose={() => !mut.isPending && setConfirm(null)}
        title="Suspend restaurant?"
        description={`Staff of "${r.name}" will not be able to log in until activated again.`}
        confirmLabel="Suspend"
        variant="danger"
        loading={mut.isPending}
        onConfirm={() => mut.mutate({ status: "suspended" })}
      />
    </div>
  );
}
