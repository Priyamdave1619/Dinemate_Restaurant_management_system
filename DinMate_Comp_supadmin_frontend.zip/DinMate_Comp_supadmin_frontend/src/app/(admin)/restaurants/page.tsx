"use client";

import { useEffect, useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import {
  listRestaurants,
  updateRestaurant,
  deleteRestaurant,
  createRestaurant,
  listPlans,
} from "@/lib/api/admin";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils/format";
import { getErrorMessage } from "@/lib/api/client";
import type { Restaurant } from "@/types";
import { Modal } from "@/components/ui/modal";
import { ConfirmDialog } from "@/components/ui/confirm-dialog";
import { Spinner, OverlayLoader } from "@/components/ui/loader";
import { DataTable, buildPaginationMeta, type ColumnDef } from "@/components/data-table";
import { useTableState } from "@/hooks/use-table-state";
import { PasswordStrengthMeter } from "@/components/security/password-strength";
import {
  createRestaurantSchema,
  type CreateRestaurantFormValues,
  checkRateLimit,
  RATE,
  LIMITS,
} from "@/lib/security";

export default function RestaurantsPage() {
  const qc = useQueryClient();
  const searchParams = useSearchParams();
  const table = useTableState({ defaultSortBy: "name", defaultSortDir: "asc" });

  const [showCreate, setShowCreate] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Restaurant | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [planChange, setPlanChange] = useState<{
    id: string;
    name: string;
    planId: string;
    from: string;
  } | null>(null);
  const [planChanging, setPlanChanging] = useState(false);

  useEffect(() => {
    const fromUrl = searchParams.get("planId") || "";
    if (fromUrl) table.setFilter("planId", fromUrl);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const status = table.filters.status || "";
  const planId = table.filters.planId || "";

  const { data: plans } = useQuery({ queryKey: ["plans"], queryFn: listPlans });

  const { data, isLoading } = useQuery({
    queryKey: ["restaurants", table.queryParams],
    queryFn: () =>
      listRestaurants({
        search: table.queryParams.search,
        status: status || undefined,
        planId: planId || undefined,
        page: table.queryParams.page,
        pageSize: table.queryParams.pageSize,
        sortBy: table.queryParams.sortBy,
        sortDir: table.queryParams.sortDir,
      }),
  });

  const patchMut = useMutation({
    mutationFn: ({ id, body }: { id: string; body: Parameters<typeof updateRestaurant>[1] }) =>
      updateRestaurant(id, body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["restaurants"] });
      toast.success("Restaurant updated");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const columns = useMemo<ColumnDef<Restaurant>[]>(
    () => [
      {
        id: "name",
        header: "Restaurant",
        sortable: true,
        accessor: (r) => r.name,
        cell: (r) => (
          <div>
            <Link href={`/restaurants/${r.id}`} className="font-medium hover:text-primary">
              {r.name}
            </Link>
            <p className="text-xs text-muted-foreground">{r.id}</p>
          </div>
        ),
      },
      {
        id: "ownerName",
        header: "Owner",
        sortable: true,
        accessor: (r) => r.ownerName,
        cell: (r) => (
          <div>
            <p>{r.ownerName}</p>
            <p className="text-xs text-muted-foreground">{r.email}</p>
          </div>
        ),
      },
      {
        id: "planId",
        header: "Plan",
        sortable: true,
        accessor: (r) => r.planId,
        cell: (r) => (
          <select
            className="h-8 max-w-[140px] rounded-md border border-input bg-background px-2 text-xs"
            value={r.planId}
            onChange={(e) => {
              const next = e.target.value;
              if (next === r.planId) return;
              setPlanChange({ id: r.id, name: r.name, planId: next, from: r.planId });
            }}
          >
            {(plans || []).map((pl) => (
              <option key={pl.id} value={pl.id} disabled={!pl.active && pl.id !== r.planId}>
                {pl.name}
              </option>
            ))}
            {!(plans || []).some((pl) => pl.id === r.planId) && (
              <option value={r.planId}>{r.planId}</option>
            )}
          </select>
        ),
      },
      {
        id: "status",
        header: "Status",
        sortable: true,
        accessor: (r) => r.status,
        cell: (r) => (
          <Badge
            variant={
              r.status === "active" ? "success" : r.status === "suspended" ? "destructive" : "warning"
            }
          >
            {r.status}
          </Badge>
        ),
      },
      {
        id: "subscriptionExpiresAt",
        header: "Expires",
        sortable: true,
        accessor: (r) => r.subscriptionExpiresAt,
        className: "text-muted-foreground text-xs",
        cell: (r) => formatDate(r.subscriptionExpiresAt),
      },
      {
        id: "actions",
        header: "Actions",
        cell: (r) => (
          <div className="flex flex-wrap gap-1">
            {r.status === "active" ? (
              <Button
                size="sm"
                variant="outline"
                onClick={() => patchMut.mutate({ id: r.id, body: { status: "suspended" } })}
              >
                Suspend
              </Button>
            ) : (
              <Button
                size="sm"
                variant="outline"
                onClick={() => patchMut.mutate({ id: r.id, body: { status: "active" } })}
              >
                Activate
              </Button>
            )}
            <Button
              size="sm"
              variant="secondary"
              onClick={() => patchMut.mutate({ id: r.id, body: { renew: true, days: 30 } })}
            >
              Renew 30d
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="text-destructive"
              onClick={() => setDeleteTarget(r)}
            >
              Delete
            </Button>
          </div>
        ),
      },
    ],
    [plans, patchMut]
  );

  const restaurants = data?.restaurants || [];
  const meta = data?.pagination
    ? {
        page: data.pagination.page,
        pageSize: data.pagination.pageSize,
        total: data.pagination.total,
        totalPages: data.pagination.totalPages,
      }
    : buildPaginationMeta(restaurants.length, table.page, table.pageSize);

  return (
    <div className="space-y-6">
      {data?.summary && (
        <div className="flex flex-wrap gap-3 text-sm">
          <Badge variant="secondary">Total {data.summary.total}</Badge>
          <Badge variant="success">Active {data.summary.active}</Badge>
          <Badge variant="destructive">Suspended {data.summary.suspended}</Badge>
          <Badge variant="warning">Pending {data.summary.pending}</Badge>
        </div>
      )}

      <DataTable<Restaurant>
        columns={columns}
        data={restaurants}
        getRowId={(r) => r.id}
        loading={isLoading}
        pagination={meta}
        onPageChange={table.setPage}
        onPageSizeChange={table.setPageSize}
        search={table.search}
        onSearchChange={table.setSearch}
        searchPlaceholder="Search name, id, email…"
        sortBy={table.sortBy}
        sortDir={table.sortDir}
        onSort={table.toggleSort}
        hasActiveFilters={table.hasActiveFilters}
        onClearFilters={table.clearFilters}
        toolbarLeft={
          <>
            <select
              className="h-10 rounded-lg border border-input bg-background px-3 text-sm"
              value={status}
              onChange={(e) => table.setFilter("status", e.target.value)}
            >
              <option value="">All status</option>
              <option value="active">Active</option>
              <option value="suspended">Suspended</option>
              <option value="pending">Pending</option>
            </select>
            <select
              className="h-10 rounded-lg border border-input bg-background px-3 text-sm max-w-[180px]"
              value={planId}
              onChange={(e) => table.setFilter("planId", e.target.value)}
            >
              <option value="">All plans</option>
              {(plans || []).map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </>
        }
        toolbarRight={
          <Button onClick={() => setShowCreate(true)}>
            <Plus className="h-4 w-4" /> Provision restaurant
          </Button>
        }
        emptyTitle="No restaurants found"
        emptyDescription="Try adjusting search or filters, or provision a new restaurant."
      />

      {showCreate && (
        <CreateRestaurantModal
          onClose={() => setShowCreate(false)}
          onCreated={() => {
            setShowCreate(false);
            qc.invalidateQueries({ queryKey: ["restaurants"] });
          }}
        />
      )}

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => !deleting && setDeleteTarget(null)}
        title="Delete restaurant?"
        description={
          deleteTarget
            ? `This will permanently remove "${deleteTarget.name}" (${deleteTarget.id}) from the platform. Business data may be retained for audit.`
            : undefined
        }
        confirmLabel="Delete"
        variant="danger"
        loading={deleting}
        onConfirm={async () => {
          if (!deleteTarget) return;
          setDeleting(true);
          try {
            await deleteRestaurant(deleteTarget.id);
            toast.success("Restaurant deleted");
            qc.invalidateQueries({ queryKey: ["restaurants"] });
            setDeleteTarget(null);
          } catch (e) {
            toast.error(getErrorMessage(e));
          } finally {
            setDeleting(false);
          }
        }}
      />

      <ConfirmDialog
        open={!!planChange}
        onClose={() => !planChanging && setPlanChange(null)}
        title="Change plan?"
        description={
          planChange
            ? `Change plan for "${planChange.name}" from ${planChange.from} to ${planChange.planId}?`
            : undefined
        }
        confirmLabel="Change plan"
        variant="warning"
        loading={planChanging}
        onConfirm={async () => {
          if (!planChange) return;
          setPlanChanging(true);
          try {
            await updateRestaurant(planChange.id, { planId: planChange.planId });
            toast.success("Plan updated");
            qc.invalidateQueries({ queryKey: ["restaurants"] });
            setPlanChange(null);
          } catch (e) {
            toast.error(getErrorMessage(e));
          } finally {
            setPlanChanging(false);
          }
        }}
      />
    </div>
  );
}

function CreateRestaurantModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [loading, setLoading] = useState(false);
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<CreateRestaurantFormValues>({
    resolver: zodResolver(createRestaurantSchema),
    mode: "onBlur",
    defaultValues: {
      name: "",
      ownerName: "",
      email: "",
      mobile: "",
      password: "",
      address: "",
    },
  });
  const password = watch("password");

  async function onSubmit(values: CreateRestaurantFormValues) {
    const rl = checkRateLimit(
      "create:restaurant",
      RATE.createResource.max,
      RATE.createResource.windowMs
    );
    if (!rl.allowed) {
      toast.error(rl.message);
      return;
    }
    setLoading(true);
    try {
      await createRestaurant({
        name: values.name,
        ownerName: values.ownerName,
        email: values.email,
        mobile: values.mobile,
        password: values.password,
        address: values.address || undefined,
      });
      toast.success("Restaurant provisioned");
      onCreated();
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal
      open
      onClose={onClose}
      title="Provision restaurant"
      description="Create a new restaurant tenant and owner login"
      size="lg"
      preventClose={loading}
    >
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-3 relative" noValidate>
        <OverlayLoader show={loading} label="Creating restaurant…" />
        <div className="space-y-1.5">
          <Label htmlFor="rest-name">Restaurant name</Label>
          <Input
            id="rest-name"
            maxLength={LIMITS.restaurantName.max}
            disabled={loading}
            aria-invalid={!!errors.name}
            {...register("name")}
          />
          {errors.name && (
            <p className="text-xs text-destructive" role="alert">
              {errors.name.message}
            </p>
          )}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="rest-owner">Owner name</Label>
          <Input
            id="rest-owner"
            maxLength={LIMITS.ownerName.max}
            disabled={loading}
            aria-invalid={!!errors.ownerName}
            {...register("ownerName")}
          />
          {errors.ownerName && (
            <p className="text-xs text-destructive" role="alert">
              {errors.ownerName.message}
            </p>
          )}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="rest-email">Email</Label>
          <Input
            id="rest-email"
            type="email"
            maxLength={LIMITS.email.max}
            disabled={loading}
            aria-invalid={!!errors.email}
            {...register("email")}
          />
          {errors.email && (
            <p className="text-xs text-destructive" role="alert">
              {errors.email.message}
            </p>
          )}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="rest-mobile">Mobile</Label>
          <Input
            id="rest-mobile"
            inputMode="numeric"
            maxLength={LIMITS.mobile.max + 3}
            disabled={loading}
            aria-invalid={!!errors.mobile}
            {...register("mobile")}
          />
          {errors.mobile && (
            <p className="text-xs text-destructive" role="alert">
              {errors.mobile.message}
            </p>
          )}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="rest-password">Owner password</Label>
          <Input
            id="rest-password"
            type="password"
            maxLength={LIMITS.password.max}
            autoComplete="new-password"
            disabled={loading}
            aria-invalid={!!errors.password}
            {...register("password")}
          />
          <PasswordStrengthMeter password={password || ""} />
          {errors.password && (
            <p className="text-xs text-destructive" role="alert">
              {errors.password.message}
            </p>
          )}
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="rest-address">Address (optional)</Label>
          <Input
            id="rest-address"
            maxLength={LIMITS.address.max}
            disabled={loading}
            {...register("address")}
          />
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="outline" onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading && <Spinner />}
            Create
          </Button>
        </div>
      </form>
    </Modal>
  );
}
