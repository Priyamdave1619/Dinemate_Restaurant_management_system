"use client";

import { useQuery } from "@tanstack/react-query";
import { getSystemStatus } from "@/lib/api/admin";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PageLoader, Spinner } from "@/components/ui/loader";
import { Activity, Database, Server, HardDrive } from "lucide-react";
import { formatDateTime } from "@/lib/utils/format";

function formatUptime(sec: number) {
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

export default function SystemPage() {
  const { data, isLoading, error, refetch, isFetching } = useQuery({
    queryKey: ["system-status"],
    queryFn: getSystemStatus,
    refetchInterval: 30_000,
  });

  if (isLoading) {
    return <PageLoader label="Checking system health…" />;
  }

  if (error || !data) {
    return (
      <Card className="p-8 text-center">
        <p className="text-destructive">Failed to load system status. Is the backend running?</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Badge variant={data.status === "healthy" ? "success" : "destructive"}>
            {data.status}
          </Badge>
          <span className="text-xs text-muted-foreground">
            Checked {formatDateTime(data.checkedAt)} · {data.responseTimeMs}ms
          </span>
        </div>
        <button
          onClick={() => refetch()}
          className="text-sm text-primary hover:underline disabled:opacity-50"
          disabled={isFetching}
        >
          {isFetching ? "Refreshing…" : "Refresh"}
        </button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-5 flex items-start gap-3">
            <div className="rounded-xl bg-emerald-500/10 p-2.5">
              <Database className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Database</p>
              <p className="text-lg font-semibold">
                {data.database.connected ? "Connected" : "Down"}
              </p>
              <p className="text-xs text-muted-foreground">{data.database.latencyMs} ms</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 flex items-start gap-3">
            <div className="rounded-xl bg-blue-500/10 p-2.5">
              <Server className="h-5 w-5 text-blue-500" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Uptime</p>
              <p className="text-lg font-semibold">{formatUptime(data.process.uptimeSec)}</p>
              <p className="text-xs text-muted-foreground">{data.process.nodeVersion}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 flex items-start gap-3">
            <div className="rounded-xl bg-primary/10 p-2.5">
              <HardDrive className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Memory (heap)</p>
              <p className="text-lg font-semibold">
                {data.process.memory.heapUsedMb} / {data.process.memory.heapTotalMb} MB
              </p>
              <p className="text-xs text-muted-foreground">RSS {data.process.memory.rssMb} MB</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 flex items-start gap-3">
            <div className="rounded-xl bg-amber-500/10 p-2.5">
              <Activity className="h-5 w-5 text-amber-500" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Platform</p>
              <p className="text-lg font-semibold">{data.platform.restaurants} restaurants</p>
              <p className="text-xs text-muted-foreground">
                {data.platform.users} users · {data.platform.plans} plans
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Integration status</CardTitle>
          <CardDescription>Configured environment capabilities</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2 text-sm">
          {[
            ["Environment", data.env.nodeEnv],
            ["Razorpay", data.env.hasRazorpay ? "Configured" : "Not set"],
            ["Cron secret", data.env.hasCronSecret ? "Configured" : "Not set"],
            ["Object storage (S3/R2)", data.env.hasS3 ? "Configured" : "Not set"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between border-b border-border/40 pb-2">
              <span className="text-muted-foreground">{k}</span>
              <span className="font-medium">{v}</span>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
