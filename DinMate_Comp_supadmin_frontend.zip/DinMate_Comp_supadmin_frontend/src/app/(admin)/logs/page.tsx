"use client";

import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { listAuditLogs } from "@/lib/api/admin";
import { Badge } from "@/components/ui/badge";
import {
  DataTable,
  clientProcessRows,
  type ColumnDef,
} from "@/components/data-table";
import { useTableState } from "@/hooks/use-table-state";
import { formatDateTime } from "@/lib/utils/format";
import type { AuditLogEntry, LoginHistoryEntry } from "@/types";

export default function LogsPage() {
  const [kind, setKind] = useState<"audit" | "logins">("audit");
  const table = useTableState({ defaultSortBy: "createdAt", defaultSortDir: "desc" });

  const { data, isLoading } = useQuery({
    queryKey: ["audit-logs", kind, table.queryParams],
    queryFn: () =>
      listAuditLogs({
        kind,
        search: table.queryParams.search,
        page: table.queryParams.page,
        pageSize: table.queryParams.pageSize,
        sortBy: table.queryParams.sortBy,
        sortDir: table.queryParams.sortDir,
      }),
  });

  const auditAll: AuditLogEntry[] = data?.logs || [];
  const loginAll: LoginHistoryEntry[] = data?.logins || [];

  const auditColumns = useMemo<ColumnDef<AuditLogEntry>[]>(
    () => [
      {
        id: "createdAt",
        header: "Time",
        sortable: true,
        accessor: (r) => r.createdAt,
        className: "text-xs text-muted-foreground whitespace-nowrap",
        cell: (r) => formatDateTime(r.createdAt),
      },
      {
        id: "actor",
        header: "Actor",
        sortable: true,
        accessor: (r) => r.actorName || "",
        cell: (r) => (
          <div>
            <p className="font-medium">{r.actorName || "—"}</p>
            <p className="text-xs text-muted-foreground">{r.actorRole || ""}</p>
          </div>
        ),
      },
      {
        id: "action",
        header: "Action",
        sortable: true,
        accessor: (r) => r.action,
        cell: (r) => <Badge variant="outline">{r.action}</Badge>,
      },
      {
        id: "entity",
        header: "Entity",
        sortable: true,
        accessor: (r) => `${r.entityType || ""} ${r.entityId || ""}`,
        className: "text-xs",
        cell: (r) => (
          <span>
            {r.entityType || ""} {r.entityId || ""}
          </span>
        ),
      },
      {
        id: "restaurantId",
        header: "Restaurant",
        sortable: true,
        accessor: (r) => r.restaurantId || "",
        className: "text-xs text-muted-foreground",
        cell: (r) => r.restaurantId || "—",
      },
    ],
    []
  );

  const loginColumns = useMemo<ColumnDef<LoginHistoryEntry>[]>(
    () => [
      {
        id: "createdAt",
        header: "Time",
        sortable: true,
        accessor: (r) => r.createdAt,
        className: "text-xs text-muted-foreground whitespace-nowrap",
        cell: (r) => formatDateTime(r.createdAt),
      },
      {
        id: "username",
        header: "User",
        sortable: true,
        accessor: (r) => r.username || "",
        cell: (r) => r.username || "—",
      },
      {
        id: "role",
        header: "Role",
        sortable: true,
        accessor: (r) => r.role || "",
        cell: (r) => <Badge variant="secondary">{r.role || ""}</Badge>,
      },
      {
        id: "success",
        header: "Result",
        sortable: true,
        accessor: (r) => (r.success ? 1 : 0),
        cell: (r) => (
          <Badge variant={r.success ? "success" : "destructive"}>
            {r.success ? "Success" : "Failed"}
          </Badge>
        ),
      },
      {
        id: "ip",
        header: "IP",
        sortable: true,
        accessor: (r) => r.ip || "",
        className: "text-xs text-muted-foreground",
        cell: (r) => r.ip || "—",
      },
    ],
    []
  );

  // Prefer server pagination when present; otherwise client-side process
  const serverMeta = data?.pagination;
  const auditProcessed = clientProcessRows(auditAll, {
    search: serverMeta ? undefined : table.debouncedSearch,
    searchKeys: [
      (r) => r.actorName || "",
      (r) => r.actorRole || "",
      (r) => r.action,
      (r) => r.entityType || "",
      (r) => r.entityId || "",
      (r) => r.restaurantId || "",
    ],
    sortBy: serverMeta ? undefined : table.sortBy,
    sortDir: table.sortDir,
    columns: auditColumns,
    page: table.page,
    pageSize: table.pageSize,
  });
  const loginProcessed = clientProcessRows(loginAll, {
    search: serverMeta ? undefined : table.debouncedSearch,
    searchKeys: [
      (r) => r.username || "",
      (r) => r.role || "",
      (r) => r.ip || "",
      (r) => (r.success ? "success" : "failed"),
    ],
    sortBy: serverMeta ? undefined : table.sortBy,
    sortDir: table.sortDir,
    columns: loginColumns,
    page: table.page,
    pageSize: table.pageSize,
  });

  const isAudit = kind === "audit";
  const rows = isAudit
    ? serverMeta
      ? auditAll
      : auditProcessed.rows
    : serverMeta
      ? loginAll
      : loginProcessed.rows;
  const meta = serverMeta
    ? {
        page: serverMeta.page,
        pageSize: serverMeta.pageSize,
        total: serverMeta.total,
        totalPages: serverMeta.totalPages,
      }
    : isAudit
      ? auditProcessed.meta
      : loginProcessed.meta;

  return (
    <div className="space-y-6">
      <div className="flex gap-2">
        <button
          type="button"
          onClick={() => {
            setKind("audit");
            table.setPage(1);
          }}
          className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
            kind === "audit" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
          }`}
        >
          Audit logs
        </button>
        <button
          type="button"
          onClick={() => {
            setKind("logins");
            table.setPage(1);
          }}
          className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
            kind === "logins" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
          }`}
        >
          Login history
        </button>
      </div>

      {isAudit ? (
        <DataTable<AuditLogEntry>
          columns={auditColumns}
          data={rows as AuditLogEntry[]}
          getRowId={(r) => r.id}
          loading={isLoading}
          pagination={meta}
          onPageChange={table.setPage}
          onPageSizeChange={table.setPageSize}
          search={table.search}
          onSearchChange={table.setSearch}
          searchPlaceholder="Search actor, action, entity, restaurant…"
          sortBy={table.sortBy}
          sortDir={table.sortDir}
          onSort={table.toggleSort}
          emptyTitle="No audit logs found"
          emptyDescription="No matching platform audit events."
        />
      ) : (
        <DataTable<LoginHistoryEntry>
          columns={loginColumns}
          data={rows as LoginHistoryEntry[]}
          getRowId={(r) => r.id}
          loading={isLoading}
          pagination={meta}
          onPageChange={table.setPage}
          onPageSizeChange={table.setPageSize}
          search={table.search}
          onSearchChange={table.setSearch}
          searchPlaceholder="Search user, role, IP…"
          sortBy={table.sortBy}
          sortDir={table.sortDir}
          onSort={table.toggleSort}
          emptyTitle="No login history found"
          emptyDescription="No matching login attempts."
        />
      )}
    </div>
  );
}
