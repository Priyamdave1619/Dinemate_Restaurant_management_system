"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import {
  Bell,
  AlertTriangle,
  Info,
  CheckCircle2,
  ShieldAlert,
  Store,
  CreditCard,
  Activity,
  CheckCheck,
  Filter,
} from "lucide-react";
import { fetchPlatformNotifications, type AppNotification, type NotificationKind } from "@/lib/api/notifications";
import { useNotificationStore } from "@/lib/stores/notification-store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { PageLoader } from "@/components/ui/loader";
import { formatDateTime, relativeTime } from "@/lib/utils/format";
import { cn } from "@/lib/utils/cn";

const KIND_FILTERS: { id: "all" | NotificationKind; label: string }[] = [
  { id: "all", label: "All" },
  { id: "subscription", label: "Subscriptions" },
  { id: "restaurant", label: "Restaurants" },
  { id: "system", label: "System" },
  { id: "security", label: "Security" },
  { id: "registration", label: "Registrations" },
];

function severityIcon(severity: AppNotification["severity"]) {
  switch (severity) {
    case "critical":
      return AlertTriangle;
    case "warning":
      return ShieldAlert;
    case "success":
      return CheckCircle2;
    default:
      return Info;
  }
}

function severityStyles(severity: AppNotification["severity"]) {
  switch (severity) {
    case "critical":
      return "bg-destructive/10 text-destructive";
    case "warning":
      return "bg-amber-500/10 text-amber-600 dark:text-amber-400";
    case "success":
      return "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400";
    default:
      return "bg-primary/10 text-primary";
  }
}

function kindIcon(kind: NotificationKind) {
  switch (kind) {
    case "subscription":
      return CreditCard;
    case "restaurant":
    case "registration":
      return Store;
    case "system":
      return Activity;
    case "security":
      return ShieldAlert;
    default:
      return Bell;
  }
}

export default function NotificationsPage() {
  const [filter, setFilter] = useState<"all" | NotificationKind>("all");
  const [showUnreadOnly, setShowUnreadOnly] = useState(false);
  const readIds = useNotificationStore((s) => s.readIds);
  const markRead = useNotificationStore((s) => s.markRead);
  const markAllRead = useNotificationStore((s) => s.markAllRead);
  const isRead = useNotificationStore((s) => s.isRead);

  const { data, isLoading, isFetching, refetch } = useQuery({
    queryKey: ["platform-notifications"],
    queryFn: fetchPlatformNotifications,
    refetchInterval: 60_000,
  });

  const notifications = data || [];

  const filtered = useMemo(() => {
    return notifications.filter((n) => {
      if (filter !== "all" && n.kind !== filter) return false;
      if (showUnreadOnly && isRead(n.id)) return false;
      return true;
    });
  }, [notifications, filter, showUnreadOnly, isRead, readIds]);

  const unreadCount = useMemo(
    () => notifications.filter((n) => !isRead(n.id)).length,
    [notifications, isRead, readIds]
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-xl font-semibold tracking-tight flex items-center gap-2">
            <Bell className="h-5 w-5 text-primary" />
            Notifications
            {unreadCount > 0 && (
              <Badge variant="destructive" className="ml-1">
                {unreadCount} new
              </Badge>
            )}
          </h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Platform alerts from subscriptions, restaurants, system health, and security activity
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowUnreadOnly((v) => !v)}
          >
            <Filter className="h-3.5 w-3.5" />
            {showUnreadOnly ? "Show all" : "Unread only"}
          </Button>
          <Button
            variant="outline"
            size="sm"
            disabled={unreadCount === 0}
            onClick={() => markAllRead(notifications.map((n) => n.id))}
          >
            <CheckCheck className="h-3.5 w-3.5" />
            Mark all read
          </Button>
          <Button variant="secondary" size="sm" onClick={() => void refetch()} disabled={isFetching}>
            Refresh
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {KIND_FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setFilter(f.id)}
            className={cn(
              "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
              filter === f.id
                ? "border-primary bg-primary/10 text-primary"
                : "border-border text-muted-foreground hover:bg-muted"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <PageLoader label="Loading notifications…" />
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center gap-2 py-16 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-muted">
              <Bell className="h-6 w-6 text-muted-foreground" />
            </div>
            <p className="font-medium">No notifications</p>
            <p className="text-sm text-muted-foreground max-w-sm">
              {showUnreadOnly
                ? "You're all caught up — no unread items in this filter."
                : "When restaurants expire, get suspended, or system health changes, alerts will appear here."}
            </p>
          </CardContent>
        </Card>
      ) : (
        <ul className="space-y-2">
          {filtered.map((n, i) => {
            const SevIcon = severityIcon(n.severity);
            const KindIcon = kindIcon(n.kind);
            const read = isRead(n.id);
            const body = (
              <motion.li
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.03, 0.3) }}
              >
                <div
                  className={cn(
                    "group flex gap-3 rounded-xl border bg-card p-4 transition-colors hover:bg-muted/40",
                    !read && "border-primary/25 bg-primary/[0.03]"
                  )}
                >
                  <div
                    className={cn(
                      "mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
                      severityStyles(n.severity)
                    )}
                  >
                    <SevIcon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className={cn("font-medium", !read && "text-foreground")}>{n.title}</p>
                      {!read && (
                        <span className="h-1.5 w-1.5 rounded-full bg-primary" aria-label="Unread" />
                      )}
                      <Badge variant="secondary" className="text-[10px] gap-1">
                        <KindIcon className="h-3 w-3" />
                        {n.kind}
                      </Badge>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{n.message}</p>
                    <p className="mt-2 text-xs text-muted-foreground" title={formatDateTime(n.createdAt)}>
                      {relativeTime(n.createdAt)}
                    </p>
                  </div>
                </div>
              </motion.li>
            );

            if (n.href) {
              return (
                <Link
                  key={n.id}
                  href={n.href}
                  onClick={() => markRead(n.id)}
                  className="block"
                >
                  {body}
                </Link>
              );
            }

            return (
              <button
                key={n.id}
                type="button"
                className="block w-full text-left"
                onClick={() => markRead(n.id)}
              >
                {body}
              </button>
            );
          })}
        </ul>
      )}
    </div>
  );
}
