"use client";

import { Suspense, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { Loader2, Eye, EyeOff } from "lucide-react";
import { Captcha, type CaptchaHandle } from "@/components/security/captcha";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Logo } from "@/components/brand/logo";
import { login } from "@/lib/api/auth";
import { useAuthStore } from "@/lib/stores/auth-store";
import { getErrorMessage } from "@/lib/api/client";
import {
  loginSchema,
  type LoginFormValues,
  checkRateLimit,
  RATE,
  securityLog,
} from "@/lib/security";
import { LIMITS } from "@/lib/security/limits";

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const setAuth = useAuthStore((s) => s.setAuth);
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const captchaRef = useRef<CaptchaHandle>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    mode: "onBlur",
    defaultValues: { username: "", password: "" },
  });

  async function onSubmit(values: LoginFormValues) {
    if (!captchaRef.current?.validate()) {
      toast.error("Please complete the security check correctly");
      return;
    }

    const rl = checkRateLimit(`login:${values.username}`, RATE.login.max, RATE.login.windowMs);
    if (!rl.allowed) {
      toast.error(rl.message);
      captchaRef.current?.refresh();
      return;
    }

    setLoading(true);
    try {
      const res = await login(values.username, values.password);
      if (res.role !== "super_admin") {
        securityLog("login_role_denied", { role: res.role });
        toast.error("Only Super Admin can access this panel");
        captchaRef.current?.refresh();
        return;
      }
      setAuth({
        user: {
          id: res.id,
          username: res.username,
          name: res.name,
          role: res.role,
          restaurantId: res.restaurantId,
        },
        restaurant: res.restaurant,
        accessToken: res.accessToken,
        refreshToken: res.refreshToken,
      });
      toast.success(`Welcome back, ${res.name}`);
      router.replace("/dashboard");
    } catch (e) {
      toast.error(getErrorMessage(e));
      captchaRef.current?.refresh();
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background p-4">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background" />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-md"
      >
        <div className="glass-card rounded-2xl p-8 shadow-xl">
          <div className="mb-8 flex flex-col items-center text-center">
            <Logo variant="full" className="mb-4" priority />
            <h1 className="text-2xl font-bold tracking-tight">Admin</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Sign in to the platform control panel
            </p>
            {params.get("error") === "unauthorized" && (
              <p className="mt-2 text-xs text-destructive" role="alert">
                Super Admin access required
              </p>
            )}
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4" noValidate>
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                placeholder="superadmin"
                autoComplete="username"
                maxLength={LIMITS.username.max}
                aria-invalid={!!errors.username}
                aria-describedby={errors.username ? "username-error" : undefined}
                {...register("username")}
              />
              {errors.username && (
                <p id="username-error" className="text-xs text-destructive" role="alert">
                  {errors.username.message}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={show ? "text" : "password"}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  maxLength={LIMITS.password.max}
                  aria-invalid={!!errors.password}
                  aria-describedby={errors.password ? "password-error" : undefined}
                  {...register("password")}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
                  onClick={() => setShow(!show)}
                  aria-label={show ? "Hide password" : "Show password"}
                >
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.password && (
                <p id="password-error" className="text-xs text-destructive" role="alert">
                  {errors.password.message}
                </p>
              )}
            </div>
            <Captcha ref={captchaRef} />
            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              Sign in
            </Button>
          </form>
        </div>
        <p className="mt-6 text-center text-xs text-muted-foreground">
          Multi-tenant Restaurant Management Platform
        </p>
      </motion.div>
    </div>
  );
}

function LoginFallback() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<LoginFallback />}>
      <LoginForm />
    </Suspense>
  );
}
