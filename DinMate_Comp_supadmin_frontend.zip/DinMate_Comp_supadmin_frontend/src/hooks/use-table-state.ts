"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useDebouncedValue } from "./use-debounced-value";
import {
  DEFAULT_PAGE_SIZE,
  PAGE_SIZE_OPTIONS,
  type PageSizeOption,
  type SortDir,
} from "@/components/data-table/types";

const STORAGE_KEY = "dinemate-admin-page-size";

function readStoredPageSize(): PageSizeOption {
  if (typeof window === "undefined") return DEFAULT_PAGE_SIZE;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const n = Number(raw);
    if (PAGE_SIZE_OPTIONS.includes(n as PageSizeOption)) return n as PageSizeOption;
  } catch {
    /* ignore */
  }
  return DEFAULT_PAGE_SIZE;
}

export type TableStateOptions = {
  /** localStorage is shared app-wide for page size */
  defaultPageSize?: PageSizeOption;
  defaultSortBy?: string;
  defaultSortDir?: SortDir;
  searchDebounceMs?: number;
};

export function useTableState(options: TableStateOptions = {}) {
  const {
    defaultPageSize,
    defaultSortBy = "",
    defaultSortDir = "desc",
    searchDebounceMs = 400,
  } = options;

  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search, searchDebounceMs);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSizeState] = useState<PageSizeOption>(
    defaultPageSize ?? DEFAULT_PAGE_SIZE
  );
  const [sortBy, setSortBy] = useState(defaultSortBy);
  const [sortDir, setSortDir] = useState<SortDir>(defaultSortDir);
  const [filters, setFilters] = useState<Record<string, string>>({});

  // Hydrate page size from localStorage once
  useEffect(() => {
    if (defaultPageSize) return;
    setPageSizeState(readStoredPageSize());
  }, [defaultPageSize]);

  const setPageSize = useCallback((size: number) => {
    const next = (PAGE_SIZE_OPTIONS.includes(size as PageSizeOption)
      ? size
      : DEFAULT_PAGE_SIZE) as PageSizeOption;
    setPageSizeState(next);
    setPage(1);
    try {
      localStorage.setItem(STORAGE_KEY, String(next));
    } catch {
      /* ignore */
    }
  }, []);

  const setSearchAndReset = useCallback((value: string) => {
    setSearch(value);
    setPage(1);
  }, []);

  const setFilter = useCallback((key: string, value: string) => {
    setFilters((prev) => {
      const next = { ...prev };
      if (!value) delete next[key];
      else next[key] = value;
      return next;
    });
    setPage(1);
  }, []);

  const clearFilters = useCallback(() => {
    setFilters({});
    setSearch("");
    setPage(1);
  }, []);

  const toggleSort = useCallback(
    (columnId: string) => {
      if (sortBy === columnId) {
        setSortDir((d) => (d === "asc" ? "desc" : "asc"));
      } else {
        setSortBy(columnId);
        setSortDir("asc");
      }
      setPage(1);
    },
    [sortBy]
  );

  const hasActiveFilters = useMemo(
    () => Boolean(search) || Object.keys(filters).length > 0,
    [search, filters]
  );

  /** Params to send to list APIs */
  const queryParams = useMemo(
    () => ({
      search: debouncedSearch || undefined,
      page,
      pageSize,
      sortBy: sortBy || undefined,
      sortDir: sortBy ? sortDir : undefined,
      ...Object.fromEntries(
        Object.entries(filters).map(([k, v]) => [k, v || undefined])
      ),
    }),
    [debouncedSearch, page, pageSize, sortBy, sortDir, filters]
  );

  return {
    search,
    setSearch: setSearchAndReset,
    debouncedSearch,
    page,
    setPage,
    pageSize,
    setPageSize,
    sortBy,
    sortDir,
    toggleSort,
    filters,
    setFilter,
    clearFilters,
    hasActiveFilters,
    queryParams,
  };
}

export type TableState = ReturnType<typeof useTableState>;
