"use client";

import { motion, AnimatePresence } from "framer-motion";
import { AlertTriangle, Trash2, Info, Loader2 } from "lucide-react";
import { Button } from "./button";

type Variant = "danger" | "warning" | "info";

type ConfirmDialogProps = {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void | Promise<void>;
  title: string;
  description?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: Variant;
  loading?: boolean;
};

const icons = {
  danger: Trash2,
  warning: AlertTriangle,
  info: Info,
};

const iconBg = {
  danger: "bg-destructive/10 text-destructive",
  warning: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
  info: "bg-primary/10 text-primary",
};

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  description,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  variant = "danger",
  loading,
}: ConfirmDialogProps) {
  const Icon = icons[variant];

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center p-4 isolate height-[100dvh]">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            style={{ transform: "translateZ(0)", WebkitBackfaceVisibility: "hidden", backfaceVisibility: "hidden" }}
            className="fixed inset-0 bg-black/55 dark:bg-black/70 backdrop-blur-[3px] will-change-[opacity]"
            onClick={() => !loading && onClose()}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 8 }}
            transition={{ type: "spring", damping: 24, stiffness: 320 }}
            style={{ WebkitBackfaceVisibility: "hidden", backfaceVisibility: "hidden" }}
            className="relative w-full max-w-sm rounded-2xl bg-card text-card-foreground p-6 shadow-2xl shadow-black/20 dark:shadow-black/50 ring-1 ring-black/5 dark:ring-white/10 border-0 outline-none will-change-transform transform-gpu"
            role="alertdialog"
          >
            <div className={`mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl ${iconBg[variant]}`}>
              <Icon className="h-6 w-6" />
            </div>
            <h2 className="text-center text-lg font-semibold">{title}</h2>
            {description && (
              <p className="mt-2 text-center text-sm text-muted-foreground">{description}</p>
            )}
            <div className="mt-6 flex gap-3">
              <Button variant="outline" className="flex-1" disabled={loading} onClick={onClose}>
                {cancelLabel}
              </Button>
              <Button
                variant={variant === "danger" ? "destructive" : "default"}
                className="flex-1"
                disabled={loading}
                onClick={() => void onConfirm()}
              >
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                {confirmLabel}
              </Button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}