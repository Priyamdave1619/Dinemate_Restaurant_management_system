"use client";

import { cn } from "@/lib/utils/cn";
import { Loader2 } from "lucide-react";
import { Skeleton } from "./skeleton";

/** Inline spinner for buttons / small areas */
export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={cn("h-4 w-4 animate-spin", className)} />;
}

/** Full-area centered loader (cards, pages) */
export function PageLoader({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex min-h-[240px] flex-col items-center justify-center gap-3 text-muted-foreground">
      <div className="relative">
        <div className="h-10 w-10 rounded-full border-2 border-primary/20" />
        <div className="absolute inset-0 h-10 w-10 animate-spin rounded-full border-2 border-transparent border-t-primary" />
      </div>
      <p className="text-sm">{label}</p>
    </div>
  );
}

/** Overlay on top of a relative parent while saving */
export function OverlayLoader({ show, label = "Saving…" }: { show: boolean; label?: string }) {
  if (!show) return null;
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center rounded-[inherit] bg-background/70 backdrop-blur-[2px]">
      <div className="flex items-center gap-2 rounded-full border bg-card px-4 py-2 shadow-lg text-sm">
        <Spinner className="text-primary" />
        {label}
      </div>
    </div>
  );
}

/** Table skeleton rows */
export function TableLoader({ rows = 6, cols = 5 }: { rows?: number; cols?: number }) {
  return (
    <div className="space-y-2 p-4">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex gap-3">
          {Array.from({ length: cols }).map((_, j) => (
            <Skeleton key={j} className="h-9 flex-1" />
          ))}
        </div>
      ))}
    </div>
  );
}

/** Card grid skeleton */
export function CardsLoader({ count = 4 }: { count?: number }) {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {Array.from({ length: count }).map((_, i) => (
        <Skeleton key={i} className="h-32 rounded-xl" />
      ))}
    </div>
  );
}
