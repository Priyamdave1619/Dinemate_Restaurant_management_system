"use client";

import { ArrowDown, ArrowUp, ArrowUpDown, Inbox, Search, X } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TableLoader } from "@/components/ui/loader";
import { TablePagination } from "./pagination";
import type { ColumnDef, PaginationMeta, SortDir } from "./types";

export type DataTableProps<T> = {
  columns: ColumnDef<T>[];
  data: T[];
  getRowId: (row: T) => string;
  loading?: boolean;
  /** Server pagination meta; if omitted, footer is hidden */
  pagination?: PaginationMeta | null;
  onPageChange?: (page: number) => void;
  onPageSizeChange?: (size: number) => void;
  /** Search */
  search?: string;
  onSearchChange?: (value: string) => void;
  searchPlaceholder?: string;
  /** Sorting */
  sortBy?: string;
  sortDir?: SortDir;
  onSort?: (columnId: string) => void;
  /** Extra toolbar (filters, actions) */
  toolbarLeft?: React.ReactNode;
  toolbarRight?: React.ReactNode;
  /** Clear filters */
  hasActiveFilters?: boolean;
  onClearFilters?: () => void;
  emptyTitle?: string;
  emptyDescription?: string;
  className?: string;
  /** Sticky header */
  stickyHeader?: boolean;
};

export function DataTable<T>({
  columns,
  data,
  getRowId,
  loading,
  pagination,
  onPageChange,
  onPageSizeChange,
  search,
  onSearchChange,
  searchPlaceholder = "Search…",
  sortBy,
  sortDir,
  onSort,
  toolbarLeft,
  toolbarRight,
  hasActiveFilters,
  onClearFilters,
  emptyTitle = "No records found",
  emptyDescription = "Try adjusting search or filters.",
  className,
  stickyHeader = true,
}: DataTableProps<T>) {
  const showToolbar =
    onSearchChange != null || toolbarLeft != null || toolbarRight != null || hasActiveFilters;

  return (
    <div className={cn("space-y-3", className)}>
      {showToolbar && (
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-1 flex-col gap-2 sm:flex-row sm:items-center sm:flex-wrap">
            {onSearchChange != null && (
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                <Input
                  value={search ?? ""}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder={searchPlaceholder}
                  className="pl-9 pr-9"
                  aria-label="Search table"
                />
                {search ? (
                  <button
                    type="button"
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 rounded-md p-0.5 text-muted-foreground hover:text-foreground"
                    onClick={() => onSearchChange("")}
                    aria-label="Clear search"
                  >
                    <X className="h-4 w-4" />
                  </button>
                ) : null}
              </div>
            )}
            {toolbarLeft}
            {hasActiveFilters && onClearFilters && (
              <Button type="button" variant="ghost" size="sm" onClick={onClearFilters}>
                <X className="h-3.5 w-3.5" />
                Clear filters
              </Button>
            )}
          </div>
          {toolbarRight && <div className="flex shrink-0 items-center gap-2">{toolbarRight}</div>}
        </div>
      )}

      <div className="rounded-xl border bg-card overflow-hidden shadow-sm">
        {loading ? (
          <TableLoader rows={8} cols={Math.min(columns.length, 6)} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead
                className={cn(
                  "bg-muted/50 text-left text-muted-foreground",
                  stickyHeader && "sticky top-0 z-10 backdrop-blur-sm"
                )}
              >
                <tr className="border-b">
                  {columns.map((col) => {
                    const active = sortBy === col.id;
                    const canSort = Boolean(col.sortable && onSort);
                    return (
                      <th
                        key={col.id}
                        className={cn(
                          "px-4 py-3 font-medium whitespace-nowrap",
                          col.headerClassName,
                          canSort && "cursor-pointer select-none hover:text-foreground"
                        )}
                        onClick={canSort ? () => onSort!(col.id) : undefined}
                        aria-sort={
                          active ? (sortDir === "asc" ? "ascending" : "descending") : undefined
                        }
                      >
                        <span className="inline-flex items-center gap-1.5">
                          {col.header}
                          {canSort && (
                            <span className="text-muted-foreground/80">
                              {active ? (
                                sortDir === "asc" ? (
                                  <ArrowUp className="h-3.5 w-3.5 text-primary" />
                                ) : (
                                  <ArrowDown className="h-3.5 w-3.5 text-primary" />
                                )
                              ) : (
                                <ArrowUpDown className="h-3.5 w-3.5 opacity-50" />
                              )}
                            </span>
                          )}
                        </span>
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                {data.length === 0 ? (
                  <tr>
                    <td colSpan={columns.length} className="px-4 py-16 text-center">
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Inbox className="h-10 w-10 opacity-40" />
                        <p className="font-medium text-foreground">{emptyTitle}</p>
                        <p className="text-sm">{emptyDescription}</p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  data.map((row) => (
                    <tr
                      key={getRowId(row)}
                      className="border-b border-border/50 transition-colors hover:bg-muted/30"
                    >
                      {columns.map((col) => (
                        <td key={col.id} className={cn("px-4 py-3", col.className)}>
                          {col.cell(row)}
                        </td>
                      ))}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {pagination && onPageChange && onPageSizeChange && (
        <TablePagination
          meta={pagination}
          onPageChange={onPageChange}
          onPageSizeChange={onPageSizeChange}
        />
      )}
    </div>
  );
}

/** Build pagination meta when the API omits it (client-side slice). */
export function buildPaginationMeta(
  total: number,
  page: number,
  pageSize: number
): PaginationMeta {
  const totalPages = Math.max(1, Math.ceil(total / pageSize) || 1);
  return {
    page: Math.min(page, totalPages),
    pageSize,
    total,
    totalPages,
  };
}

/** Client-side filter + sort + page (when API has no server pagination). */
export function clientProcessRows<T>(
  rows: T[],
  opts: {
    search?: string;
    searchKeys?: ((row: T) => string)[];
    sortBy?: string;
    sortDir?: SortDir;
    columns?: ColumnDef<T>[];
    page: number;
    pageSize: number;
  }
): { rows: T[]; meta: PaginationMeta } {
  let filtered = rows;

  if (opts.search?.trim() && opts.searchKeys?.length) {
    const q = opts.search.trim().toLowerCase();
    filtered = filtered.filter((row) =>
      opts.searchKeys!.some((fn) => String(fn(row) ?? "").toLowerCase().includes(q))
    );
  }

  if (opts.sortBy && opts.columns) {
    const col = opts.columns.find((c) => c.id === opts.sortBy);
    if (col?.accessor) {
      const dir = opts.sortDir === "asc" ? 1 : -1;
      filtered = [...filtered].sort((a, b) => {
        const av = col.accessor!(a);
        const bv = col.accessor!(b);
        if (av == null && bv == null) return 0;
        if (av == null) return 1;
        if (bv == null) return -1;
        if (typeof av === "number" && typeof bv === "number") return (av - bv) * dir;
        return String(av).localeCompare(String(bv), undefined, { sensitivity: "base" }) * dir;
      });
    }
  }

  const total = filtered.length;
  const meta = buildPaginationMeta(total, opts.page, opts.pageSize);
  const start = (meta.page - 1) * opts.pageSize;
  const pageRows = filtered.slice(start, start + opts.pageSize);

  return { rows: pageRows, meta };
}
