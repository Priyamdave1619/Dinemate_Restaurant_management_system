"use client";

import Image from "next/image";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils/cn";

type LogoProps = {
  /** full = login size; compact = sidebar expanded; icon = sidebar collapsed / header */
  variant?: "full" | "compact" | "icon";
  className?: string;
  priority?: boolean;
};

/**
 * Theme-aware DineMate logo.
 * - Light mode → logo-light.png
 * - Dark mode  → logo-dark.png
 */
export function Logo({ variant = "full", className, priority }: LogoProps) {
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  const isDark = mounted && resolvedTheme === "dark";
  const src = isDark ? "/logos/logo-dark.png" : "/logos/logo-light.png";

  if (variant === "icon") {
    return (
      <div
        className={cn(
          "relative flex h-11 w-11 items-center justify-center overflow-hidden rounded-xl",
          className
        )}
      >
        <Image
          src={src}
          alt="DineMate"
          width={64}
          height={64}
          className="h-full w-full object-cover object-center"
          priority={priority}
        />
      </div>
    );
  }

  if (variant === "compact") {
    return (
      <div className={cn("relative flex w-full items-center justify-center overflow-hidden", className)}>
        <Image
          src={src}
          alt="DineMate"
          width={220}
          height={100}
          className="h-16 w-auto max-w-full object-contain"
          priority={priority}
        />
      </div>
    );
  }

  return (
    <div className={cn("relative mx-auto", className)}>
      <Image
        src={src}
        alt="DineMate"
        width={320}
        height={180}
        className="h-auto w-full max-w-[280px] object-contain"
        priority={priority}
      />
    </div>
  );
}
