"use client";

import {
  useCallback,
  useEffect,
  useId,
  useImperativeHandle,
  useRef,
  useState,
  forwardRef,
} from "react";
import { RefreshCw, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

/** Ambiguous chars omitted (0/O, 1/I/l) for stronger human readability */
const CHARSET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function randomCode(length = 6): string {
  const arr = new Uint32Array(length);
  if (typeof crypto !== "undefined" && crypto.getRandomValues) {
    crypto.getRandomValues(arr);
  } else {
    for (let i = 0; i < length; i++) arr[i] = Math.floor(Math.random() * 0xffffffff);
  }
  return Array.from(arr, (n) => CHARSET[n % CHARSET.length]!).join("");
}

function drawCaptcha(
  canvas: HTMLCanvasElement,
  code: string,
  isDark: boolean
) {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const w = canvas.width;
  const h = canvas.height;

  // Background
  const bg = isDark ? "#0f172a" : "#f1f5f9";
  const fg = isDark ? "#e2e8f0" : "#0f172a";
  const accent = isDark ? "#38bdf8" : "#0369a1";
  const noise = isDark ? "rgba(148,163,184,0.35)" : "rgba(100,116,139,0.35)";

  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  // Soft gradient wash
  const grad = ctx.createLinearGradient(0, 0, w, h);
  grad.addColorStop(0, isDark ? "rgba(56,189,248,0.08)" : "rgba(3,105,161,0.06)");
  grad.addColorStop(1, isDark ? "rgba(167,139,250,0.08)" : "rgba(124,58,237,0.05)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Noise dots
  for (let i = 0; i < 48; i++) {
    ctx.fillStyle = noise;
    ctx.beginPath();
    ctx.arc(Math.random() * w, Math.random() * h, Math.random() * 1.8 + 0.4, 0, Math.PI * 2);
    ctx.fill();
  }

  // Interference lines
  for (let i = 0; i < 4; i++) {
    ctx.strokeStyle = isDark
      ? `rgba(56,189,248,${0.15 + Math.random() * 0.2})`
      : `rgba(3,105,161,${0.12 + Math.random() * 0.18})`;
    ctx.lineWidth = 1 + Math.random() * 1.5;
    ctx.beginPath();
    ctx.moveTo(Math.random() * w, Math.random() * h);
    ctx.bezierCurveTo(
      Math.random() * w,
      Math.random() * h,
      Math.random() * w,
      Math.random() * h,
      Math.random() * w,
      Math.random() * h
    );
    ctx.stroke();
  }

  // Characters
  const step = w / (code.length + 1);
  for (let i = 0; i < code.length; i++) {
    const ch = code[i]!;
    const x = step * (i + 1);
    const y = h / 2 + (Math.random() * 10 - 5);
    const angle = (Math.random() - 0.5) * 0.55;
    const size = 22 + Math.floor(Math.random() * 6);

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle);
    ctx.font = `700 ${size}px ui-monospace, SFMono-Regular, Menlo, monospace`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillStyle = i % 2 === 0 ? fg : accent;
    ctx.shadowColor = isDark ? "rgba(0,0,0,0.5)" : "rgba(0,0,0,0.15)";
    ctx.shadowBlur = 2;
    ctx.fillText(ch, 0, 0);
    ctx.restore();
  }

  // Light scratch lines over text
  for (let i = 0; i < 2; i++) {
    ctx.strokeStyle = isDark ? "rgba(226,232,240,0.2)" : "rgba(15,23,42,0.15)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, Math.random() * h);
    ctx.lineTo(w, Math.random() * h);
    ctx.stroke();
  }
}

export type CaptchaHandle = {
  /** Returns true if the user input matches the current code (case-insensitive). */
  validate: () => boolean;
  /** Generate a new challenge and clear the input. */
  refresh: () => void;
  /** Clear validation error state. */
  clearError: () => void;
};

type CaptchaProps = {
  className?: string;
  /** Called when the user types (optional external control). */
  onChange?: (value: string) => void;
};

/**
 * Modern canvas CAPTCHA — distorted code + noise, theme-aware, refreshable.
 * Client-side only; backend rate limits remain the real security boundary.
 */
export const Captcha = forwardRef<CaptchaHandle, CaptchaProps>(function Captcha(
  { className, onChange },
  ref
) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [code, setCode] = useState(() => randomCode(6));
  const [value, setValue] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [isDark, setIsDark] = useState(false);
  const inputId = useId();

  // Track dark mode via class on <html> (next-themes)
  useEffect(() => {
    const root = document.documentElement;
    const sync = () => setIsDark(root.classList.contains("dark"));
    sync();
    const obs = new MutationObserver(sync);
    obs.observe(root, { attributes: true, attributeFilter: ["class"] });
    return () => obs.disconnect();
  }, []);

  const paint = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    drawCaptcha(canvas, code, isDark);
  }, [code, isDark]);

  useEffect(() => {
    paint();
  }, [paint]);

  const refresh = useCallback(() => {
    setCode(randomCode(6));
    setValue("");
    setError(null);
    onChange?.("");
  }, [onChange]);

  useImperativeHandle(
    ref,
    () => ({
      validate: () => {
        const ok = value.trim().toUpperCase() === code.toUpperCase();
        if (!ok) {
          setError("CAPTCHA does not match. Try again.");
          // Auto-refresh on failure to prevent brute-force guessing
          setTimeout(() => refresh(), 350);
        } else {
          setError(null);
        }
        return ok;
      },
      refresh,
      clearError: () => setError(null),
    }),
    [value, code, refresh]
  );

  return (
    <div className={cn("space-y-2", className)}>
      <Label htmlFor={inputId} className="flex items-center gap-1.5">
        <ShieldCheck className="h-3.5 w-3.5 text-primary" />
        Security check
      </Label>

      <div className="flex items-stretch gap-2">
        <div className="relative flex-1 overflow-hidden rounded-xl border border-border/70 bg-muted/40 shadow-inner">
          <canvas
            ref={canvasRef}
            width={220}
            height={64}
            className="h-14 w-full select-none"
            aria-hidden
          />
          <div className="pointer-events-none absolute inset-0 rounded-xl ring-1 ring-inset ring-black/5 dark:ring-white/10" />
        </div>
        <Button
          type="button"
          variant="outline"
          size="icon"
          className="h-14 w-11 shrink-0 rounded-xl"
          onClick={refresh}
          aria-label="Refresh CAPTCHA"
          title="New code"
        >
          <RefreshCw className="h-4 w-4" />
        </Button>
      </div>

      <Input
        id={inputId}
        value={value}
        onChange={(e) => {
          const next = e.target.value.replace(/\s/g, "").slice(0, 8);
          setValue(next);
          setError(null);
          onChange?.(next);
        }}
        placeholder="Enter the code above"
        autoComplete="off"
        autoCapitalize="characters"
        spellCheck={false}
        inputMode="text"
        maxLength={8}
        aria-invalid={!!error}
        aria-describedby={error ? `${inputId}-error` : undefined}
        className={cn(
          "font-mono tracking-[0.2em] uppercase placeholder:tracking-normal placeholder:normal-case",
          error && "border-destructive focus-visible:ring-destructive"
        )}
      />

      {error && (
        <p id={`${inputId}-error`} className="text-xs text-destructive" role="alert">
          {error}
        </p>
      )}
      <p className="text-[11px] text-muted-foreground">
        Case-insensitive · letters & numbers · refresh if unclear
      </p>
    </div>
  );
});

Captcha.displayName = "Captcha";
