"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard,
  Store,
  CreditCard,
  ScrollText,
  Settings,
  Bell,
  ChevronLeft,
  ChevronRight,
  Users,
  Activity,
  BarChart3,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/brand/logo";
import { useShell } from "./app-shell";

const nav = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/restaurants", label: "Restaurants", icon: Store },
  { href: "/plans", label: "Plans", icon: CreditCard },
  { href: "/users", label: "Users", icon: Users },
  { href: "/reports", label: "Reports", icon: BarChart3 },
  { href: "/logs", label: "Audit Logs", icon: ScrollText },
  { href: "/notifications", label: "Notifications", icon: Bell },
  { href: "/system", label: "System", icon: Activity },
  { href: "/settings", label: "Settings", icon: Settings },
];

function NavLinks({ collapsed, onNavigate }: { collapsed: boolean; onNavigate?: () => void }) {
  const pathname = usePathname();

  return (
    <nav className="flex-1 space-y-1 p-3 overflow-y-auto">
      {nav.map((item) => {
        const active = pathname === item.href || pathname.startsWith(item.href + "/");
        const Icon = item.icon;
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            title={collapsed ? item.label : undefined}
            className={cn(
              "relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
              collapsed && "justify-center px-2",
              active
                ? "bg-sidebar-accent text-primary"
                : "text-muted-foreground hover:bg-accent hover:text-foreground"
            )}
          >
            {active && (
              <motion.div
                layoutId="sidebar-active"
                className="absolute inset-0 rounded-lg bg-primary/10"
                transition={{ type: "spring", bounce: 0.2, duration: 0.4 }}
              />
            )}
            <Icon className="relative z-10 h-5 w-5 shrink-0" />
            {!collapsed && <span className="relative z-10 truncate">{item.label}</span>}
          </Link>
        );
      })}
    </nav>
  );
}

export function Sidebar() {
  const { mobileNavOpen, setMobileNavOpen, sidebarCollapsed, setSidebarCollapsed } = useShell();

  return (
    <>
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-0 z-40 hidden h-screen flex-col border-r border-sidebar-border bg-sidebar transition-[width] duration-300 ease-in-out lg:flex",
          sidebarCollapsed ? "w-[72px]" : "w-64"
        )}
      >
        {/* Logo + toggle under it */}
        <div className="border-b border-sidebar-border">
          <div
            className={cn(
              "flex items-center justify-center px-3 py-3",
              sidebarCollapsed ? "h-16 px-2" : "min-h-[88px]"
            )}
          >
            {sidebarCollapsed ? (
              <Logo variant="icon" />
            ) : (
              <Logo variant="compact" />
            )}
          </div>
          <div className={cn("px-3 pb-3", sidebarCollapsed && "px-2")}>
            <Button
              variant="outline"
              size="sm"
              className={cn(
                "w-full border-sidebar-border bg-transparent hover:bg-accent",
                sidebarCollapsed && "px-0"
              )}
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              title={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
              {sidebarCollapsed ? (
                <ChevronRight className="h-4 w-4" />
              ) : (
                <>
                  <ChevronLeft className="h-4 w-4" />
                  <span>Collapse</span>
                </>
              )}
            </Button>
          </div>
        </div>

        <NavLinks collapsed={sidebarCollapsed} />
      </aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileNavOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
              onClick={() => setMobileNavOpen(false)}
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: "spring", damping: 28, stiffness: 320 }}
              className="fixed left-0 top-0 z-50 flex h-screen w-[min(280px,85vw)] flex-col border-r border-sidebar-border bg-sidebar lg:hidden"
            >
              <div className="flex min-h-[72px] items-center justify-between gap-2 border-b border-sidebar-border px-3 py-2">
                <Logo variant="compact" className="min-w-0 flex-1" />
                <Button variant="ghost" size="icon" className="shrink-0" onClick={() => setMobileNavOpen(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
              <NavLinks collapsed={false} onNavigate={() => setMobileNavOpen(false)} />
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
