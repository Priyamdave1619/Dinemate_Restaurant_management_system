"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import {
  Search,
  Store,
  Users,
  CreditCard,
  LayoutDashboard,
  Activity,
  ScrollText,
  BarChart3,
  Settings,
  Bell,
  Loader2,
  ArrowRight,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { useDebouncedValue } from "@/hooks/use-debounced-value";
import { listRestaurants, listPlatformUsers, listPlans } from "@/lib/api/admin";
import { cn } from "@/lib/utils/cn";
import { validateSearch } from "@/lib/security/validators";

type ResultItem = {
  id: string;
  group: string;
  title: string;
  subtitle?: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
};

const QUICK_LINKS: ResultItem[] = [
  { id: "nav-dashboard", group: "Pages", title: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { id: "nav-restaurants", group: "Pages", title: "Restaurants", href: "/restaurants", icon: Store },
  { id: "nav-plans", group: "Pages", title: "Subscription plans", href: "/plans", icon: CreditCard },
  { id: "nav-users", group: "Pages", title: "Platform users", href: "/users", icon: Users },
  { id: "nav-reports", group: "Pages", title: "Revenue reports", href: "/reports", icon: BarChart3 },
  { id: "nav-logs", group: "Pages", title: "Audit & login logs", href: "/logs", icon: ScrollText },
  { id: "nav-system", group: "Pages", title: "System health", href: "/system", icon: Activity },
  { id: "nav-notifications", group: "Pages", title: "Notifications", href: "/notifications", icon: Bell },
  { id: "nav-settings", group: "Pages", title: "Settings", href: "/settings", icon: Settings },
];

export function GlobalSearch({ className }: { className?: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const debounced = useDebouncedValue(query.trim(), 300);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const safeQuery = useMemo(() => {
    const r = validateSearch(debounced);
    return r.ok ? r.value : "";
  }, [debounced]);

  const enabled = safeQuery.length >= 2;

  const { data, isFetching } = useQuery({
    queryKey: ["global-search", safeQuery],
    enabled,
    staleTime: 15_000,
    queryFn: async () => {
      const [restaurants, users, plans] = await Promise.all([
        listRestaurants({ search: safeQuery, page: 1, pageSize: 6 }),
        listPlatformUsers({ search: safeQuery, page: 1, pageSize: 6 }),
        listPlans(),
      ]);
      return { restaurants, users, plans };
    },
  });

  const results = useMemo<ResultItem[]>(() => {
    const q = safeQuery.toLowerCase();
    const items: ResultItem[] = [];

    // Static pages always filtered by query (or all when empty & open)
    const pages = (q
      ? QUICK_LINKS.filter(
          (p) =>
            p.title.toLowerCase().includes(q) ||
            p.href.toLowerCase().includes(q) ||
            p.group.toLowerCase().includes(q)
        )
      : QUICK_LINKS
    ).slice(0, 6);
    items.push(...pages);

    if (data?.restaurants?.restaurants) {
      for (const r of data.restaurants.restaurants) {
        items.push({
          id: `rest-${r.id}`,
          group: "Restaurants",
          title: r.name,
          subtitle: `${r.ownerName} · ${r.status} · ${r.email}`,
          href: `/restaurants/${r.id}`,
          icon: Store,
        });
      }
    }

    if (data?.users?.users) {
      for (const u of data.users.users) {
        items.push({
          id: `user-${u.id}`,
          group: "Users",
          title: u.name,
          subtitle: `${u.username} · ${u.role}${u.restaurantId ? ` · ${u.restaurantId}` : ""}`,
          href: u.restaurantId ? `/restaurants/${u.restaurantId}` : "/users",
          icon: Users,
        });
      }
    }

    if (data?.plans && q) {
      for (const p of data.plans) {
        if (
          p.name.toLowerCase().includes(q) ||
          String(p.price).includes(q) ||
          p.id.toLowerCase().includes(q)
        ) {
          items.push({
            id: `plan-${p.id}`,
            group: "Plans",
            title: p.name,
            subtitle: `₹${p.price} · ${p.durationDays} days · ${p.active ? "active" : "inactive"}`,
            href: "/plans",
            icon: CreditCard,
          });
        }
      }
    }

    return items;
  }, [safeQuery, data]);

  useEffect(() => {
    setActiveIndex(0);
  }, [results.length, safeQuery]);

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!containerRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  // Ctrl/Cmd + K
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen(true);
        inputRef.current?.focus();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function go(item: ResultItem) {
    setOpen(false);
    setQuery("");
    router.push(item.href);
  }

  function onKeyDown(e: React.KeyboardEvent) {
    if (!open && (e.key === "ArrowDown" || e.key === "Enter")) {
      setOpen(true);
      return;
    }
    if (e.key === "Escape") {
      setOpen(false);
      return;
    }
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => Math.min(i + 1, Math.max(results.length - 1, 0)));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter" && results[activeIndex]) {
      e.preventDefault();
      go(results[activeIndex]!);
    }
  }

  const groups = useMemo(() => {
    const map = new Map<string, ResultItem[]>();
    for (const r of results) {
      const list = map.get(r.group) || [];
      list.push(r);
      map.set(r.group, list);
    }
    return Array.from(map.entries());
  }, [results]);

  return (
    <div ref={containerRef} className={cn("relative w-full max-w-xs", className)}>
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      <Input
        ref={inputRef}
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={onKeyDown}
        placeholder="Search restaurants, users, plans…"
        className="pl-9 pr-12 h-9 bg-muted/50 border-0"
        aria-autocomplete="list"
        aria-expanded={open}
        role="combobox"
      />
      <kbd className="pointer-events-none absolute right-2 top-1/2 hidden -translate-y-1/2 select-none rounded border bg-background px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground sm:inline-block">
        ⌘K
      </kbd>

      {open && (
        <div
          className="absolute left-0 right-0 top-[calc(100%+6px)] z-50 max-h-[min(420px,70vh)] overflow-y-auto rounded-xl border bg-card shadow-xl ring-1 ring-black/5 dark:ring-white/10"
          role="listbox"
        >
          {enabled && isFetching && (
            <div className="flex items-center gap-2 px-3 py-3 text-xs text-muted-foreground">
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              Searching platform…
            </div>
          )}

          {!enabled && (
            <p className="px-3 py-2 text-xs text-muted-foreground border-b border-border/50">
              Type at least 2 characters, or pick a page below
            </p>
          )}

          {enabled && !isFetching && results.length === 0 && (
            <p className="px-3 py-6 text-center text-sm text-muted-foreground">
              No matches for “{safeQuery}”
            </p>
          )}

          {groups.map(([group, items]) => (
            <div key={group} className="py-1.5">
              <p className="px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                {group}
              </p>
              {items.map((item) => {
                const globalIndex = results.indexOf(item);
                const Icon = item.icon;
                const active = globalIndex === activeIndex;
                return (
                  <button
                    key={item.id}
                    type="button"
                    role="option"
                    aria-selected={active}
                    className={cn(
                      "flex w-full items-center gap-3 px-3 py-2 text-left text-sm transition-colors",
                      active ? "bg-primary/10 text-foreground" : "hover:bg-muted/80"
                    )}
                    onMouseEnter={() => setActiveIndex(globalIndex)}
                    onClick={() => go(item)}
                  >
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted">
                      <Icon className="h-4 w-4 text-muted-foreground" />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-medium">{item.title}</span>
                      {item.subtitle && (
                        <span className="block truncate text-xs text-muted-foreground">
                          {item.subtitle}
                        </span>
                      )}
                    </span>
                    <ArrowRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground opacity-50" />
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
