"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import { motion, AnimatePresence } from "framer-motion";
import { Moon, Sun, Bell, User, LogOut, Settings, ChevronDown, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuthStore } from "@/lib/stores/auth-store";
import { logout as apiLogout } from "@/lib/api/auth";
import { toast } from "sonner";
import { useShell } from "./app-shell";
import { GlobalSearch } from "./global-search";
import { useQuery } from "@tanstack/react-query";
import { fetchPlatformNotifications } from "@/lib/api/notifications";
import { useNotificationStore } from "@/lib/stores/notification-store";


const titles: Record<string, string> = {
  "/dashboard": "Dashboard",
  "/restaurants": "Restaurants",
  "/plans": "Subscription Plans",
  "/users": "Platform Users",
  "/reports": "Revenue Reports",
  "/logs": "Audit & Login Logs",
  "/system": "System Health",
  "/notifications": "Notifications",
  "/settings": "Settings",
};


function NotificationBadge() {
  const readIds = useNotificationStore((s) => s.readIds);
  const { data } = useQuery({
    queryKey: ["platform-notifications"],
    queryFn: fetchPlatformNotifications,
    staleTime: 30_000,
    refetchInterval: 60_000,
  });
  const unread = (data || []).filter((n) => !readIds.includes(n.id)).length;
  if (unread <= 0) return null;
  return (
    <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
      {unread > 9 ? "9+" : unread}
    </span>
  );
}

export function Header() {
  const { theme, setTheme } = useTheme();
  const pathname = usePathname();
  const router = useRouter();
  const user = useAuthStore((s) => s.user);
  const clearAuth = useAuthStore((s) => s.clearAuth);
  const refreshToken = useAuthStore((s) => s.refreshToken);

  const { setMobileNavOpen } = useShell();
  const [menuOpen, setMenuOpen] = useState(false);
  const [logoutOpen, setLogoutOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const title =
    Object.entries(titles).find(([k]) => pathname === k || pathname.startsWith(k + "/"))?.[1] ||
    "Admin";

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  async function confirmLogout() {
    setLoggingOut(true);
    try {
      await apiLogout(refreshToken || undefined);
    } catch {
      /* ignore */
    }
    clearAuth();
    toast.success("Logged out");
    setLogoutOpen(false);
    router.push("/login");
  }

  return (
    <>
      <header className="sticky top-0 z-30 flex h-14 sm:h-16 items-center gap-2 sm:gap-4 border-b bg-background/80 backdrop-blur-xl px-3 sm:px-6">
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden shrink-0"
          onClick={() => setMobileNavOpen(true)}
          aria-label="Open menu"
        >
          <Menu className="h-5 w-5" />
        </Button>
        <div className="flex-1 min-w-0">
          <h1 className="text-base sm:text-lg font-semibold tracking-tight truncate">{title}</h1>
        </div>
        <div className="hidden sm:block relative max-w-[200px] md:max-w-xs w-full">
          <GlobalSearch />
        </div>
        <Link href="/notifications" className="relative">
          <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
            <Bell className="h-4 w-4" />
            <NotificationBadge />
          </Button>
        </Link>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        >
          <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
          <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
        </Button>

        <div className="relative" ref={menuRef}>
          <button
            type="button"
            onClick={() => setMenuOpen((o) => !o)}
            className="flex items-center gap-2 rounded-xl border border-border/60 bg-muted/40 px-2.5 py-1.5 text-sm hover:bg-muted transition-colors"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/15 text-primary">
              <User className="h-4 w-4" />
            </div>
            <div className="hidden sm:block text-left leading-tight">
              <p className="font-medium max-w-[120px] truncate">{user?.name || "Admin"}</p>
              <p className="text-[10px] text-muted-foreground truncate">{user?.username}</p>
            </div>
            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
          </button>

          <AnimatePresence>
            {menuOpen && (
              <motion.div
                initial={{ opacity: 0, y: 6, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 6, scale: 0.98 }}
                transition={{ duration: 0.15 }}
                className="absolute right-0 mt-2 w-56 rounded-xl border bg-card p-1.5 shadow-xl z-50"
              >
                <div className="px-3 py-2 border-b border-border/50 mb-1">
                  <p className="text-sm font-medium truncate">{user?.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{user?.username}</p>
                </div>
                <Link
                  href="/settings"
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-muted transition-colors"
                >
                  <Settings className="h-4 w-4" />
                  Profile & settings
                </Link>
                <button
                  type="button"
                  onClick={() => {
                    setMenuOpen(false);
                    setLogoutOpen(true);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-destructive hover:bg-destructive/10 transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                  Log out
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </header>

      <AnimatePresence>
        {logoutOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => !loggingOut && setLogoutOpen(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 8 }}
              transition={{ type: "spring", damping: 24, stiffness: 320 }}
              className="relative w-full max-w-sm rounded-2xl border bg-card p-6 shadow-2xl"
            >
              <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-destructive/10 text-destructive">
                <LogOut className="h-6 w-6" />
              </div>
              <h2 className="text-center text-lg font-semibold">Sign out?</h2>
              <p className="mt-2 text-center text-sm text-muted-foreground">
                You will need to sign in again to access the DineMate admin portal.
              </p>
              <div className="mt-6 flex gap-3">
                <Button
                  variant="outline"
                  className="flex-1"
                  disabled={loggingOut}
                  onClick={() => setLogoutOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  className="flex-1"
                  disabled={loggingOut}
                  onClick={confirmLogout}
                >
                  {loggingOut ? "Signing out…" : "Log out"}
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
