"use client";

import { createContext, useContext, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Sidebar } from "./sidebar";
import { Header } from "./header";
import { useAuthStore } from "@/lib/stores/auth-store";
import { cn } from "@/lib/utils/cn";

type ShellCtx = {
  mobileNavOpen: boolean;
  setMobileNavOpen: (v: boolean) => void;
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (v: boolean) => void;
};

const ShellContext = createContext<ShellCtx | null>(null);

export function useShell() {
  const ctx = useContext(ShellContext);
  if (!ctx) throw new Error("useShell must be used within AppShell");
  return ctx;
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const isSuperAdmin = useAuthStore((s) => s.isSuperAdmin);
  const [ready, setReady] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  useEffect(() => {
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    if (!isAuthenticated()) {
      router.replace("/login");
      return;
    }
    if (!isSuperAdmin()) {
      router.replace("/login?error=unauthorized");
    }
  }, [ready, isAuthenticated, isSuperAdmin, router]);

  // Close mobile nav on resize to desktop
  useEffect(() => {
    function onResize() {
      if (window.innerWidth >= 1024) setMobileNavOpen(false);
    }
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  if (!ready) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  return (
    <ShellContext.Provider
      value={{ mobileNavOpen, setMobileNavOpen, sidebarCollapsed, setSidebarCollapsed }}
    >
      <div className="min-h-screen bg-background">
        <Sidebar />
        <div
          className={cn(
            "transition-all duration-300 min-h-screen",
            // mobile: full width; desktop: offset by sidebar
            "pl-0",
            sidebarCollapsed ? "lg:pl-[72px]" : "lg:pl-64"
          )}
        >
          <Header />
          <main className="p-4 sm:p-5 lg:p-6 animate-fade-in max-w-[1600px]">{children}</main>
        </div>
      </div>
    </ShellContext.Provider>
  );
}
