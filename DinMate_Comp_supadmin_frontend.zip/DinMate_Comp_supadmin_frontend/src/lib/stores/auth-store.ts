"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { SessionUser, RestaurantSummary } from "@/types";

interface AuthState {
  user: SessionUser | null;
  restaurant: RestaurantSummary | null;
  accessToken: string | null;
  refreshToken: string | null;
  setAuth: (payload: {
    user: SessionUser;
    restaurant: RestaurantSummary | null;
    accessToken: string;
    refreshToken: string;
  }) => void;
  setTokens: (accessToken: string, refreshToken: string) => void;
  clearAuth: () => void;
  isAuthenticated: () => boolean;
  isSuperAdmin: () => boolean;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      restaurant: null,
      accessToken: null,
      refreshToken: null,
      setAuth: ({ user, restaurant, accessToken, refreshToken }) =>
        set({ user, restaurant, accessToken, refreshToken }),
      setTokens: (accessToken, refreshToken) => set({ accessToken, refreshToken }),
      clearAuth: () =>
        set({ user: null, restaurant: null, accessToken: null, refreshToken: null }),
      isAuthenticated: () => !!get().accessToken && !!get().user,
      isSuperAdmin: () => get().user?.role === "super_admin",
    }),
    {
      name: "dinemate-admin-auth",
      partialize: (s) => ({
        user: s.user,
        restaurant: s.restaurant,
        accessToken: s.accessToken,
        refreshToken: s.refreshToken,
      }),
    }
  )
);
