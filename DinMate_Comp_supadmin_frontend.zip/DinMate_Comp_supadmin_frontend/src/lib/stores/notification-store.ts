"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

interface NotificationState {
  /** IDs the user has marked as read */
  readIds: string[];
  markRead: (id: string) => void;
  markAllRead: (ids: string[]) => void;
  isRead: (id: string) => boolean;
  clearRead: () => void;
}

export const useNotificationStore = create<NotificationState>()(
  persist(
    (set, get) => ({
      readIds: [],
      markRead: (id) => {
        const cur = get().readIds;
        if (cur.includes(id)) return;
        set({ readIds: [...cur, id].slice(-500) });
      },
      markAllRead: (ids) => {
        const setIds = new Set([...get().readIds, ...ids]);
        set({ readIds: Array.from(setIds).slice(-500) });
      },
      isRead: (id) => get().readIds.includes(id),
      clearRead: () => set({ readIds: [] }),
    }),
    { name: "dinemate-admin-notifications" }
  )
);
