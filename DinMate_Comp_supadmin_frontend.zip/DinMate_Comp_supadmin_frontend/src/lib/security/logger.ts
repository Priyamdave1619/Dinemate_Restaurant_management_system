/**
 * Dev-only security event logger. Never surfaces details to end users.
 */

const isDev = process.env.NODE_ENV === "development";

export function securityLog(
  event: string,
  detail?: Record<string, unknown>
): void {
  if (!isDev) return;
  try {
    // Avoid logging raw secrets or full payloads
    const safe = detail
      ? Object.fromEntries(
          Object.entries(detail).map(([k, v]) => {
            if (/password|token|secret|key/i.test(k)) return [k, "[redacted]"];
            if (typeof v === "string" && v.length > 120) return [k, v.slice(0, 120) + "…"];
            return [k, v];
          })
        )
      : undefined;
    // eslint-disable-next-line no-console
    console.warn(`[security] ${event}`, safe ?? "");
  } catch {
    /* ignore */
  }
}

/** User-facing error helper — never leaks internals */
export function safeErrorMessage(error: unknown, fallback = "Something went wrong"): string {
  if (typeof error === "string" && error.length < 200 && !/stack|at\s+\w+|Error:/i.test(error)) {
    return error;
  }
  if (error && typeof error === "object" && "message" in error) {
    const msg = String((error as { message: unknown }).message || "");
    // Strip paths, SQL, stack fragments
    if (
      msg &&
      msg.length < 180 &&
      !/ECONN|ENOENT|postgres|sql|stack|node_modules|\/home\//i.test(msg)
    ) {
      return msg;
    }
  }
  return fallback;
}
