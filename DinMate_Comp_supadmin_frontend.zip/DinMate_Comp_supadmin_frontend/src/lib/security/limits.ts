/** Strict field length limits used across the admin portal */

export const LIMITS = {
  username: { min: 3, max: 30 },
  password: { min: 12, max: 128 },
  name: { min: 1, max: 100 },
  restaurantName: { min: 2, max: 100 },
  ownerName: { min: 2, max: 100 },
  email: { min: 5, max: 254 },
  mobile: { min: 10, max: 15 },
  address: { max: 300 },
  gstNumber: { min: 15, max: 15 },
  description: { max: 1000 },
  notes: { max: 500 },
  search: { max: 100 },
  coupon: { max: 30 },
  category: { max: 60 },
  productName: { max: 150 },
  tableNumber: { max: 20 },
  planName: { max: 80 },
  url: { max: 2048 },
  uuid: { min: 36, max: 36 },
  filename: { max: 120 },
  fileSizeBytes: 5 * 1024 * 1024, // 5 MB default upload cap
} as const;

export const ALLOWED_UPLOAD_MIME = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
  "application/pdf",
] as const;

export const ALLOWED_UPLOAD_EXT = [".jpg", ".jpeg", ".png", ".webp", ".gif", ".pdf"] as const;
