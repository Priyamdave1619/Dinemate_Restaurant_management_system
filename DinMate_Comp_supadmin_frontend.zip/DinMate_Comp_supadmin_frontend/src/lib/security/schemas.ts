import { z } from "zod";
import { LIMITS } from "./limits";
import {
  validateEmail,
  validateMobile,
  validateName,
  validatePassword,
  validateRestaurantName,
  validateUsername,
  validateGstNumber,
} from "./validators";
import { normalizeText } from "./sanitize";

/** Zod refinements that call our security validators */

export const usernameSchema = z
  .string()
  .transform((v) => normalizeText(v, { collapseSpaces: true }))
  .superRefine((val, ctx) => {
    const r = validateUsername(val);
    if (!r.ok) ctx.addIssue({ code: z.ZodIssueCode.custom, message: r.error });
  });

export const passwordSchema = z.string().superRefine((val, ctx) => {
  const r = validatePassword(val, { requireStrong: true });
  if (!r.ok) ctx.addIssue({ code: z.ZodIssueCode.custom, message: r.error });
});

/** Login password — length only (existing accounts may predate strong rules) */
export const loginPasswordSchema = z
  .string()
  .min(1, "Password is required")
  .max(LIMITS.password.max, "Password is too long");

export const emailSchema = z.string().superRefine((val, ctx) => {
  const r = validateEmail(val);
  if (!r.ok) ctx.addIssue({ code: z.ZodIssueCode.custom, message: r.error });
});

export const mobileSchema = z.string().superRefine((val, ctx) => {
  const r = validateMobile(val);
  if (!r.ok) ctx.addIssue({ code: z.ZodIssueCode.custom, message: r.error });
});

export const personNameSchema = (label = "Name") =>
  z.string().superRefine((val, ctx) => {
    const r = validateName(val, label);
    if (!r.ok) ctx.addIssue({ code: z.ZodIssueCode.custom, message: r.error });
  });

export const restaurantNameSchema = z.string().superRefine((val, ctx) => {
  const r = validateRestaurantName(val);
  if (!r.ok) ctx.addIssue({ code: z.ZodIssueCode.custom, message: r.error });
});

export const optionalAddressSchema = z
  .string()
  .max(LIMITS.address.max, `Address must be at most ${LIMITS.address.max} characters`)
  .transform((v) => normalizeText(v, { collapseSpaces: true, maxLength: LIMITS.address.max }))
  .optional()
  .or(z.literal(""));

export const optionalGstSchema = z.string().superRefine((val, ctx) => {
  if (!val || !String(val).trim()) return;
  const r = validateGstNumber(val);
  if (!r.ok) ctx.addIssue({ code: z.ZodIssueCode.custom, message: r.error });
});

export const loginSchema = z.object({
  username: usernameSchema,
  password: loginPasswordSchema,
});

export const createAdminSchema = z.object({
  name: personNameSchema("Full name"),
  username: usernameSchema,
  password: passwordSchema,
  role: z.enum(["admin", "super_admin"]),
});

export const createRestaurantSchema = z.object({
  name: restaurantNameSchema,
  ownerName: personNameSchema("Owner name"),
  email: emailSchema,
  mobile: mobileSchema,
  password: passwordSchema,
  address: optionalAddressSchema,
});

export const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, "Current password is required").max(LIMITS.password.max),
    newPassword: passwordSchema,
    confirmPassword: z.string().min(1, "Confirm your new password"),
  })
  .superRefine((data, ctx) => {
    if (data.newPassword !== data.confirmPassword) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Passwords do not match",
        path: ["confirmPassword"],
      });
    }
    if (data.currentPassword === data.newPassword) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "New password must be different from current password",
        path: ["newPassword"],
      });
    }
  });

export type LoginFormValues = z.infer<typeof loginSchema>;
export type CreateAdminFormValues = z.infer<typeof createAdminSchema>;
export type CreateRestaurantFormValues = z.infer<typeof createRestaurantSchema>;
