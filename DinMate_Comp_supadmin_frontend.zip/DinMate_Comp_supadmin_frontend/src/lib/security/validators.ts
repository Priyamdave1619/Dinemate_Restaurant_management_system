import { LIMITS, ALLOWED_UPLOAD_EXT, ALLOWED_UPLOAD_MIME } from "./limits";
import { normalizeEmail, normalizePhone, normalizeText, sanitizeFilename } from "./sanitize";
import { assertSafeInput } from "./threats";
import { securityLog } from "./logger";

/** Common weak passwords (subset) */
const COMMON_PASSWORDS = new Set(
  [
    "password",
    "password123",
    "password1234",
    "12345678",
    "123456789012",
    "qwertyuiop",
    "admin1234567",
    "letmein12345",
    "welcome12345",
    "changeme1234",
    "dinemate1234",
    "superadmin12",
  ].map((s) => s.toLowerCase())
);

const EMAIL_RE =
  /^[a-z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/i;

const DISPOSABLE_EMAIL_DOMAINS = new Set([
  "mailinator.com",
  "guerrillamail.com",
  "10minutemail.com",
  "tempmail.com",
  "throwaway.email",
  "yopmail.com",
  "trashmail.com",
]);

const GSTIN_RE = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
const UUID_RE =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export type FieldResult = { ok: true; value: string } | { ok: false; error: string };

function fail(error: string): FieldResult {
  return { ok: false, error };
}

function pass(value: string): FieldResult {
  return { ok: true, value };
}

function threatCheck(value: string, label: string): string | null {
  return assertSafeInput(value, label);
}

export function validateUsername(raw: unknown): FieldResult {
  const value = normalizeText(raw, { collapseSpaces: true });
  if (!value) return fail("Username is required");
  if (value.length < LIMITS.username.min) return fail(`Username must be at least ${LIMITS.username.min} characters`);
  if (value.length > LIMITS.username.max) return fail(`Username must be at most ${LIMITS.username.max} characters`);
  if (!/^[a-zA-Z0-9._-]+$/.test(value)) {
    return fail("Username may only contain letters, numbers, dot, underscore, hyphen");
  }
  const t = threatCheck(value, "Username");
  if (t) return fail(t);
  return pass(value.toLowerCase());
}

export function validatePassword(
  raw: unknown,
  opts: { username?: string; requireStrong?: boolean } = {}
): FieldResult {
  const value = typeof raw === "string" ? raw : String(raw ?? "");
  // Do not normalize password beyond length checks (preserve special chars)
  if (!value) return fail("Password is required");
  if (value.length < LIMITS.password.min) {
    return fail(`Password must be at least ${LIMITS.password.min} characters`);
  }
  if (value.length > LIMITS.password.max) {
    return fail(`Password must be at most ${LIMITS.password.max} characters`);
  }

  const requireStrong = opts.requireStrong !== false;
  if (requireStrong) {
    if (!/[A-Z]/.test(value)) return fail("Password must include an uppercase letter");
    if (!/[a-z]/.test(value)) return fail("Password must include a lowercase letter");
    if (!/[0-9]/.test(value)) return fail("Password must include a number");
    if (!/[^A-Za-z0-9]/.test(value)) return fail("Password must include a special character");
  }

  if (COMMON_PASSWORDS.has(value.toLowerCase())) {
    securityLog("common_password_rejected");
    return fail("This password is too common");
  }

  // Sequential / repeated
  if (/(.)\1{3,}/.test(value)) return fail("Password has too many repeated characters");
  if (/012345|123456|234567|345678|456789|abcdef|qwerty/i.test(value)) {
    return fail("Password contains sequential characters");
  }

  if (opts.username) {
    const u = opts.username.toLowerCase();
    if (u.length >= 3 && value.toLowerCase().includes(u)) {
      return fail("Password must not contain your username");
    }
  }

  return pass(value);
}

export function passwordStrength(raw: string): {
  score: 0 | 1 | 2 | 3 | 4;
  label: "Very weak" | "Weak" | "Fair" | "Strong" | "Very strong";
} {
  let score = 0;
  if (raw.length >= 12) score++;
  if (raw.length >= 16) score++;
  if (/[A-Z]/.test(raw) && /[a-z]/.test(raw)) score++;
  if (/[0-9]/.test(raw)) score++;
  if (/[^A-Za-z0-9]/.test(raw)) score++;
  const clamped = Math.min(4, score) as 0 | 1 | 2 | 3 | 4;
  const labels = ["Very weak", "Weak", "Fair", "Strong", "Very strong"] as const;
  return { score: clamped, label: labels[clamped]! };
}

export function validateEmail(raw: unknown): FieldResult {
  const value = normalizeEmail(String(raw ?? ""));
  if (!value) return fail("Email is required");
  if (value.length > LIMITS.email.max) return fail("Email is too long");
  if ((value.match(/@/g) || []).length !== 1) return fail("Invalid email format");
  if (/\s/.test(value)) return fail("Email cannot contain spaces");
  if (!EMAIL_RE.test(value)) return fail("Invalid email format");
  const domain = value.split("@")[1]?.toLowerCase() || "";
  if (DISPOSABLE_EMAIL_DOMAINS.has(domain)) {
    securityLog("disposable_email_rejected", { domain });
    return fail("Temporary email addresses are not allowed");
  }
  const t = threatCheck(value, "Email");
  if (t) return fail(t);
  return pass(value);
}

/** India-first mobile: 10 digits, optional +91 */
export function validateMobile(raw: unknown, opts: { indiaOnly?: boolean } = {}): FieldResult {
  const value = normalizePhone(String(raw ?? ""));
  if (!value) return fail("Mobile number is required");
  if (!/^\+?\d+$/.test(value)) return fail("Mobile number may only contain digits");
  const digits = value.replace(/\D/g, "");
  if (opts.indiaOnly !== false) {
    // 10-digit Indian mobile or 91 + 10
    if (digits.length === 10 && /^[6-9]/.test(digits)) return pass(digits);
    if (digits.length === 12 && digits.startsWith("91") && /^91[6-9]/.test(digits)) {
      return pass(digits.slice(2));
    }
    return fail("Enter a valid 10-digit Indian mobile number");
  }
  if (digits.length < LIMITS.mobile.min || digits.length > LIMITS.mobile.max) {
    return fail(`Mobile must be ${LIMITS.mobile.min}–${LIMITS.mobile.max} digits`);
  }
  return pass(value.startsWith("+") ? value : digits);
}

export function validateName(raw: unknown, label = "Name", max = LIMITS.name.max): FieldResult {
  const value = normalizeText(raw, { collapseSpaces: true, maxLength: max });
  if (!value) return fail(`${label} is required`);
  if (value.length < 2) return fail(`${label} is too short`);
  if (value.length > max) return fail(`${label} must be at most ${max} characters`);
  // Letters, spaces, common punctuation for Indian names
  if (!/^[\p{L}\p{M}\s.'’-]+$/u.test(value)) {
    return fail(`${label} contains invalid characters`);
  }
  const t = threatCheck(value, label);
  if (t) return fail(t);
  return pass(value);
}

export function validateRestaurantName(raw: unknown): FieldResult {
  const value = normalizeText(raw, { collapseSpaces: true, maxLength: LIMITS.restaurantName.max });
  if (!value) return fail("Restaurant name is required");
  if (value.length < LIMITS.restaurantName.min) return fail("Restaurant name is too short");
  if (value.length > LIMITS.restaurantName.max) return fail("Restaurant name is too long");
  if (!/^[\p{L}\p{M}0-9\s.'&\-()]+$/u.test(value)) {
    return fail("Restaurant name contains invalid characters");
  }
  const t = threatCheck(value, "Restaurant name");
  if (t) return fail(t);
  return pass(value);
}

export function validateSearch(raw: unknown): FieldResult {
  const value = normalizeText(raw, { collapseSpaces: true, maxLength: LIMITS.search.max });
  if (value.length > LIMITS.search.max) return fail("Search query is too long");
  const t = threatCheck(value, "Search");
  if (t) return fail(t);
  return pass(value);
}

export function validateGstNumber(raw: unknown): FieldResult {
  const value = normalizeText(raw, { collapseSpaces: true }).toUpperCase();
  if (!value) return pass(""); // optional
  if (!GSTIN_RE.test(value)) return fail("Invalid GSTIN format");
  return pass(value);
}

export function validateUuid(raw: unknown): FieldResult {
  const value = normalizeText(raw);
  if (!value) return fail("ID is required");
  if (!UUID_RE.test(value)) return fail("Invalid ID format");
  return pass(value.toLowerCase());
}

export function validatePositiveNumber(
  raw: unknown,
  opts: { min?: number; max?: number; integer?: boolean; label?: string } = {}
): { ok: true; value: number } | { ok: false; error: string } {
  const label = opts.label || "Value";
  if (raw === "" || raw == null) return { ok: false, error: `${label} is required` };
  const n = typeof raw === "number" ? raw : Number(String(raw).trim());
  if (!Number.isFinite(n) || Number.isNaN(n)) return { ok: false, error: `${label} must be a valid number` };
  if (opts.integer && !Number.isInteger(n)) return { ok: false, error: `${label} must be a whole number` };
  if (n < (opts.min ?? 0)) return { ok: false, error: `${label} must be at least ${opts.min ?? 0}` };
  if (opts.max != null && n > opts.max) return { ok: false, error: `${label} is too large` };
  return { ok: true, value: n };
}

export function validatePercent(raw: unknown): { ok: true; value: number } | { ok: false; error: string } {
  return validatePositiveNumber(raw, { min: 0, max: 100, label: "Percentage" });
}

export function validateUploadFile(file: File): { ok: true } | { ok: false; error: string } {
  if (!file) return { ok: false, error: "No file selected" };
  if (file.size <= 0) return { ok: false, error: "File is empty" };
  if (file.size > LIMITS.fileSizeBytes) {
    return { ok: false, error: `File must be under ${Math.round(LIMITS.fileSizeBytes / 1024 / 1024)} MB` };
  }
  const name = sanitizeFilename(file.name);
  const lower = name.toLowerCase();
  if (lower.includes("\0")) return { ok: false, error: "Invalid filename" };
  // Double extension / executables
  if (/\.(exe|sh|bat|cmd|js|mjs|cjs|php|asp|aspx|jsp|html|htm|svg)$/i.test(lower)) {
    securityLog("upload_rejected_extension", { name: lower });
    return { ok: false, error: "File type not allowed" };
  }
  const ext = ALLOWED_UPLOAD_EXT.find((e) => lower.endsWith(e));
  if (!ext) return { ok: false, error: "File extension not allowed" };
  if (file.type && !(ALLOWED_UPLOAD_MIME as readonly string[]).includes(file.type)) {
    // Some browsers omit type — soft warn but still check extension
    if (file.type !== "" && file.type !== "application/octet-stream") {
      securityLog("upload_mime_mismatch", { type: file.type, name: lower });
      return { ok: false, error: "File type not allowed" };
    }
  }
  return { ok: true };
}
