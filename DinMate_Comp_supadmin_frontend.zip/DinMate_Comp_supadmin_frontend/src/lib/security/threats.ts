/**
 * Client-side threat pattern detection.
 * Backend must still validate — this rejects obvious attack payloads early.
 */

import { securityLog } from "./logger";

export type ThreatKind =
  | "sql_injection"
  | "command_injection"
  | "path_traversal"
  | "xss"
  | "prototype_pollution";

const SQL_PATTERNS: RegExp[] = [
  /(\b)(SELECT|INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER|CREATE|EXEC|EXECUTE|UNION|MERGE)\b/i,
  /(\b)(OR|AND)\s+['"]?\d+['"]?\s*=\s*['"]?\d+/i,
  /(--|#|\/\*|\*\/)/,
  /(\b)(INFORMATION_SCHEMA|sysobjects|xp_cmdshell|WAITFOR\s+DELAY)\b/i,
  /;\s*(SELECT|DROP|DELETE|UPDATE|INSERT)\b/i,
];

const CMD_PATTERNS: RegExp[] = [
  /[;&|`$]/,
  /\b(curl|wget|bash|sh|cmd|powershell|nc|ncat|python|perl|ruby)\b/i,
  /\$\([^)]+\)/,
  /`[^`]+`/,
];

const PATH_PATTERNS: RegExp[] = [
  /\.\.(\/|\\)/,
  /(%2e){2}/i,
  /%2f/i,
  /%5c/i,
  /(^|\/|\\)\.\.(\/|\\|$)/,
];

const XSS_PATTERNS: RegExp[] = [
  /<\s*script\b/i,
  /<\s*iframe\b/i,
  /<\s*object\b/i,
  /<\s*embed\b/i,
  /<\s*svg\b/i,
  /javascript\s*:/i,
  /on\w+\s*=/i,
  /<\s*img[^>]+onerror/i,
];

const PROTO_POLLUTION: RegExp[] = [/\b__proto__\b/, /\bconstructor\b\s*\[/, /\bprototype\b\s*\[/];

export function detectThreats(raw: string): ThreatKind[] {
  if (!raw || typeof raw !== "string") return [];
  const found = new Set<ThreatKind>();
  const sample = raw.length > 2000 ? raw.slice(0, 2000) : raw;

  for (const re of SQL_PATTERNS) {
    if (re.test(sample)) {
      found.add("sql_injection");
      break;
    }
  }
  for (const re of CMD_PATTERNS) {
    if (re.test(sample)) {
      found.add("command_injection");
      break;
    }
  }
  for (const re of PATH_PATTERNS) {
    if (re.test(sample)) {
      found.add("path_traversal");
      break;
    }
  }
  for (const re of XSS_PATTERNS) {
    if (re.test(sample)) {
      found.add("xss");
      break;
    }
  }
  for (const re of PROTO_POLLUTION) {
    if (re.test(sample)) {
      found.add("prototype_pollution");
      break;
    }
  }

  if (found.size > 0) {
    securityLog("threat_detected", { kinds: Array.from(found), length: raw.length });
  }
  return Array.from(found);
}

export function assertSafeInput(value: string, fieldLabel = "Input"): string | null {
  const threats = detectThreats(value);
  if (threats.length === 0) return null;
  return `${fieldLabel} contains disallowed content`;
}
