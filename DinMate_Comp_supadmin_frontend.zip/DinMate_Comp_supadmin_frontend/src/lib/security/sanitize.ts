/**
 * Input sanitization & normalization — OWASP-aligned frontend layer.
 * Never treat this as a substitute for backend validation.
 */

/** Strip control chars & zero-width / invisible Unicode */
const INVISIBLE_RE =
  /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F\u200B-\u200F\u202A-\u202E\u2060\uFEFF]/g;

/** Dangerous HTML / script patterns for display-safe text */
const HTML_TAG_RE = /<\/?[a-z][\s\S]*>/gi;
const SCRIPTISH_RE =
  /javascript\s*:|data\s*:|vbscript\s*:|on\w+\s*=|<script|<iframe|<object|<embed|<svg[\s>]/gi;

/**
 * Normalize free-text input before validation or submit.
 * - Unicode NFC
 * - Remove invisible chars
 * - Trim
 * - Collapse internal whitespace (optional)
 */
export function normalizeText(
  value: unknown,
  opts: { collapseSpaces?: boolean; maxLength?: number } = {}
): string {
  if (value == null) return "";
  let s = String(value).normalize("NFC").replace(INVISIBLE_RE, "");
  s = s.trim();
  if (opts.collapseSpaces) {
    s = s.replace(/\s+/g, " ");
  }
  if (opts.maxLength != null && s.length > opts.maxLength) {
    s = s.slice(0, opts.maxLength);
  }
  return s;
}

/** Escape HTML entities for safe text insertion (never use dangerouslySetInnerHTML). */
export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * Strip HTML tags and event-handler / protocol injections from user content
 * that will only be shown as plain text.
 */
export function stripHtml(value: string): string {
  return normalizeText(value)
    .replace(HTML_TAG_RE, "")
    .replace(SCRIPTISH_RE, "")
    .replace(/[<>]/g, "");
}

/** Sanitize a filename for uploads (no path segments, no hidden names). */
export function sanitizeFilename(name: string, maxLen = 120): string {
  let base = normalizeText(name).replace(/\\/g, "/").split("/").pop() || "file";
  base = base.replace(/^\.+/, ""); // no leading dots
  base = base.replace(/[^\w.\- ()[\]]+/g, "_");
  base = base.replace(/\.{2,}/g, ".");
  if (!base || base === "." || base === "..") base = "file";
  return base.slice(0, maxLen);
}

/** Lowercase + trim email for consistent identity checks */
export function normalizeEmail(value: string): string {
  return normalizeText(value).toLowerCase();
}

/** Keep only digits (and optional leading + for intl phone) */
export function normalizePhone(value: string): string {
  const s = normalizeText(value);
  if (s.startsWith("+")) {
    return "+" + s.slice(1).replace(/\D/g, "");
  }
  return s.replace(/\D/g, "");
}
