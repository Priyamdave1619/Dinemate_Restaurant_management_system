/**
 * Client-side action rate limiting (UX + spam reduction).
 * Not a security boundary — backend must enforce real limits.
 */

import { securityLog } from "./logger";

type Bucket = { timestamps: number[] };

const store = new Map<string, Bucket>();

export type RateLimitResult =
  | { allowed: true }
  | { allowed: false; retryAfterMs: number; message: string };

/**
 * Sliding-window limiter.
 * @param key unique action key e.g. "login:user"
 * @param max max attempts in window
 * @param windowMs window length
 */
export function checkRateLimit(
  key: string,
  max: number,
  windowMs: number
): RateLimitResult {
  const now = Date.now();
  let bucket = store.get(key);
  if (!bucket) {
    bucket = { timestamps: [] };
    store.set(key, bucket);
  }
  bucket.timestamps = bucket.timestamps.filter((t) => now - t < windowMs);
  if (bucket.timestamps.length >= max) {
    const oldest = bucket.timestamps[0]!;
    const retryAfterMs = Math.max(0, windowMs - (now - oldest));
    securityLog("rate_limited", { key, max, windowMs, retryAfterMs });
    return {
      allowed: false,
      retryAfterMs,
      message: `Too many attempts. Try again in ${Math.ceil(retryAfterMs / 1000)}s`,
    };
  }
  bucket.timestamps.push(now);
  return { allowed: true };
}

export function clearRateLimit(key: string): void {
  store.delete(key);
}

/** Presets for common actions */
export const RATE = {
  login: { max: 5, windowMs: 60_000 },
  createResource: { max: 10, windowMs: 60_000 },
  search: { max: 30, windowMs: 10_000 },
} as const;
