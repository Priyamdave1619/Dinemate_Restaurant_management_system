import { api } from "./client";
import type { ApiSuccess, LoginResponse, SessionUser, RestaurantSummary } from "@/types";

export async function login(username: string, password: string) {
  const { data } = await api.post<ApiSuccess<LoginResponse>>("/api/auth/login", {
    username,
    password,
  });
  return data.data;
}

export async function logout(refreshToken?: string) {
  await api.post("/api/auth/logout", refreshToken ? { refreshToken } : undefined);
}

export async function getMe() {
  const { data } = await api.get<
    ApiSuccess<{ user: SessionUser | null; restaurant: RestaurantSummary | null }>
  >("/api/auth/me");
  return data.data;
}

export async function updateProfile(body: { name?: string; username?: string }) {
  const { data } = await api.patch<
    ApiSuccess<{ user: SessionUser; accessToken: string }>
  >("/api/auth/profile", body);
  return data.data;
}

export async function changePassword(body: { currentPassword: string; newPassword: string }) {
  const { data } = await api.post<ApiSuccess<{ ok: boolean }>>("/api/auth/change-password", body);
  return data.data;
}
