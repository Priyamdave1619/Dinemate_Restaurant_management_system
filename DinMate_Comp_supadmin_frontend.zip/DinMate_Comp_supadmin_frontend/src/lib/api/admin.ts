import { api } from "./client";
import type {
  ApiSuccess,
  DashboardData,
  Restaurant,
  SubscriptionPlan,
  AuditLogEntry,
  LoginHistoryEntry,
} from "@/types";

export async function getDashboard() {
  const { data } = await api.get<ApiSuccess<DashboardData>>("/api/admin/dashboard");
  return data.data;
}

export async function listRestaurants(params?: {
  status?: string;
  search?: string;
  planId?: string;
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortDir?: "asc" | "desc";
}) {
  const { data } = await api.get<
    ApiSuccess<{ restaurants: Restaurant[]; summary: Record<string, number> }>
  >("/api/admin/restaurants", { params });
  return { ...data.data, pagination: data.pagination };
}

export async function getRestaurant(id: string) {
  const { data } = await api.get<
    ApiSuccess<{
      restaurant: Restaurant;
      staff: Array<{ id: string; username: string; name: string; role: string; active: boolean }>;
      loginHistory: LoginHistoryEntry[];
      auditLogs: AuditLogEntry[];
    }>
  >(`/api/admin/restaurants/${id}`);
  return data.data;
}

export async function createRestaurant(body: {
  name: string;
  ownerName: string;
  email: string;
  mobile: string;
  password: string;
  address?: string;
  gstNumber?: string;
  planId?: string;
}) {
  const { data } = await api.post<ApiSuccess<{ restaurant: Restaurant }>>(
    "/api/admin/restaurants",
    body
  );
  return data.data;
}

export async function updateRestaurant(
  id: string,
  body: Partial<{
    status: string;
    planId: string;
    renew: boolean;
    days: number;
    name: string;
    ownerName: string;
    email: string;
    mobile: string;
    address: string;
    gstNumber: string;
  }>
) {
  const { data } = await api.patch<ApiSuccess<{ restaurant: Restaurant }>>(
    `/api/admin/restaurants/${id}`,
    body
  );
  return data.data;
}

export async function deleteRestaurant(id: string) {
  await api.delete(`/api/admin/restaurants/${id}`);
}

export async function listPlans() {
  const { data } = await api.get<ApiSuccess<{ plans: SubscriptionPlan[] }>>("/api/admin/plans");
  return data.data.plans;
}

export async function createPlan(body: Partial<SubscriptionPlan> & { name: string; durationDays: number; price: number }) {
  const { data } = await api.post<ApiSuccess<{ plan: SubscriptionPlan }>>("/api/admin/plans", body);
  return data.data.plan;
}

export async function updatePlan(id: string, body: Partial<SubscriptionPlan>) {
  const { data } = await api.patch<ApiSuccess<{ plan: SubscriptionPlan }>>(
    `/api/admin/plans/${id}`,
    body
  );
  return data.data.plan;
}

export async function deletePlan(id: string) {
  await api.delete(`/api/admin/plans/${id}`);
}

export async function listAuditLogs(params?: {
  restaurantId?: string;
  kind?: "audit" | "logins";
  search?: string;
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortDir?: "asc" | "desc";
}) {
  const { data } = await api.get<
    ApiSuccess<{ logs?: AuditLogEntry[]; logins?: LoginHistoryEntry[] }>
  >("/api/admin/audit-logs", { params });
  return { ...data.data, pagination: data.pagination };
}

export async function listPlatformUsers(params?: {
  role?: string;
  restaurantId?: string;
  search?: string;
  active?: string;
  page?: number;
  pageSize?: number;
}) {
  const { data } = await api.get<
    ApiSuccess<{
      users: Array<{
        id: string;
        username: string;
        name: string;
        role: string;
        restaurantId: string | null;
        active: boolean;
        createdAt?: string;
        lastLoginAt?: string;
      }>;
      summary: { total: number; byRole: Record<string, number> };
    }>
  >("/api/admin/users", { params });
  return { ...data.data, pagination: data.pagination };
}

export async function getSystemStatus() {
  const { data } = await api.get<
    ApiSuccess<{
      status: string;
      checkedAt: string;
      responseTimeMs: number;
      database: { connected: boolean; latencyMs: number };
      process: {
        nodeVersion: string;
        uptimeSec: number;
        memory: { rssMb: number; heapUsedMb: number; heapTotalMb: number };
      };
      platform: { restaurants: number; users: number; plans: number };
      env: {
        nodeEnv: string;
        hasRazorpay: boolean;
        hasCronSecret: boolean;
        hasS3: boolean;
      };
    }>
  >("/api/admin/system");
  return data.data;
}


export async function createPlatformUser(body: {
  name: string;
  username: string;
  password: string;
  role?: "super_admin" | "admin";
}) {
  const { data } = await api.post<ApiSuccess<{ user: { id: string; username: string; name: string; role: string } }>>(
    "/api/admin/users",
    body
  );
  return data.data;
}

export async function getRevenueReport(params?: { month?: string }) {
  const { data } = await api.get<
    ApiSuccess<{
      month: string;
      rows: Array<{
        restaurantId: string;
        name: string;
        ownerName: string;
        status: string;
        planId: string;
        netSales: number;
        grossSales: number;
        orderCount: number;
        taxTotal: number;
      }>;
      totals: { netSales: number; grossSales: number; orderCount: number; taxTotal: number };
    }>
  >("/api/admin/reports/revenue", { params });
  return data.data;
}
