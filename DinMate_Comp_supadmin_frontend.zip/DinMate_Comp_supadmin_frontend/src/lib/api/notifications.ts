import { getDashboard, getSystemStatus, listAuditLogs, listRestaurants } from "./admin";

export type NotificationKind =
  | "subscription"
  | "restaurant"
  | "system"
  | "security"
  | "registration"
  | "info";

export type AppNotification = {
  id: string;
  kind: NotificationKind;
  title: string;
  message: string;
  href?: string;
  createdAt: string;
  severity: "info" | "warning" | "critical" | "success";
};

/**
 * Build platform notifications from existing admin APIs.
 * No dedicated notifications endpoint required on the backend.
 */
export async function fetchPlatformNotifications(): Promise<AppNotification[]> {
  const items: AppNotification[] = [];
  const now = new Date().toISOString();

  const [dash, system, audits, suspended] = await Promise.allSettled([
    getDashboard(),
    getSystemStatus(),
    listAuditLogs({ kind: "audit", page: 1, pageSize: 15, sortBy: "createdAt", sortDir: "desc" }),
    listRestaurants({ status: "suspended", page: 1, pageSize: 10 }),
  ]);

  if (dash.status === "fulfilled") {
    const d = dash.value;
    if (d.restaurants.expiredSubscriptions > 0) {
      items.push({
        id: `sub-expired-${d.restaurants.expiredSubscriptions}`,
        kind: "subscription",
        title: "Expired subscriptions",
        message: `${d.restaurants.expiredSubscriptions} restaurant(s) have expired subscriptions and need renewal.`,
        href: "/restaurants?status=expired",
        createdAt: now,
        severity: "critical",
      });
    }
    if (d.restaurants.suspended > 0) {
      items.push({
        id: `rest-suspended-count-${d.restaurants.suspended}`,
        kind: "restaurant",
        title: "Suspended restaurants",
        message: `${d.restaurants.suspended} restaurant(s) are currently suspended.`,
        href: "/restaurants?status=suspended",
        createdAt: now,
        severity: "warning",
      });
    }
    if (d.restaurants.pending > 0) {
      items.push({
        id: `rest-pending-${d.restaurants.pending}`,
        kind: "restaurant",
        title: "Pending restaurants",
        message: `${d.restaurants.pending} restaurant(s) are awaiting activation.`,
        href: "/restaurants?status=pending",
        createdAt: now,
        severity: "info",
      });
    }
    for (const r of d.recentRegistrations.slice(0, 8)) {
      items.push({
        id: `reg-${r.id}`,
        kind: "registration",
        title: "New restaurant registered",
        message: `${r.name} (owner: ${r.ownerName}) · status ${r.status}`,
        href: `/restaurants/${r.id}`,
        createdAt: r.createdAt,
        severity: "success",
      });
    }
  }

  if (system.status === "fulfilled") {
    const s = system.value;
    if (!s.database.connected || (s.status !== "ok" && s.status !== "healthy")) {
      items.push({
        id: `sys-db-${s.checkedAt}`,
        kind: "system",
        title: "Database connectivity issue",
        message: s.database.connected
          ? `System status: ${s.status}. DB latency ${s.database.latencyMs}ms.`
          : "Database is not connected. Platform APIs may fail.",
        href: "/system",
        createdAt: s.checkedAt,
        severity: "critical",
      });
    } else if (s.database.latencyMs > 500) {
      items.push({
        id: `sys-latency-${s.checkedAt}`,
        kind: "system",
        title: "High database latency",
        message: `DB responded in ${s.database.latencyMs}ms. Check Neon pool / network.`,
        href: "/system",
        createdAt: s.checkedAt,
        severity: "warning",
      });
    }
    if (s.process.memory.heapUsedMb > 400) {
      items.push({
        id: `sys-mem-${s.checkedAt}`,
        kind: "system",
        title: "Elevated memory usage",
        message: `Heap used ${s.process.memory.heapUsedMb} MB / ${s.process.memory.heapTotalMb} MB.`,
        href: "/system",
        createdAt: s.checkedAt,
        severity: "warning",
      });
    }
    if (!s.env.hasRazorpay) {
      items.push({
        id: "sys-razorpay-missing",
        kind: "system",
        title: "Razorpay not configured",
        message: "Billing checkout may be unavailable until Razorpay keys are set.",
        href: "/system",
        createdAt: s.checkedAt,
        severity: "info",
      });
    }
  }

  if (suspended.status === "fulfilled") {
    for (const r of (suspended.value.restaurants || []).slice(0, 8)) {
      items.push({
        id: `suspended-${r.id}`,
        kind: "restaurant",
        title: `${r.name} is suspended`,
        message: `Owner ${r.ownerName} · ${r.email}`,
        href: `/restaurants/${r.id}`,
        createdAt: r.updatedAt || r.createdAt,
        severity: "warning",
      });
    }
  }

  if (audits.status === "fulfilled") {
    const logs = audits.value.logs || [];
    for (const log of logs.slice(0, 12)) {
      const action = log.action || "activity";
      const isSecurity = /login|logout|password|auth|fail/i.test(action);
      items.push({
        id: `audit-${log.id}`,
        kind: isSecurity ? "security" : "info",
        title: action.replace(/[._]/g, " "),
        message: [log.actorName, log.actorRole, log.entityType, log.entityId]
          .filter(Boolean)
          .join(" · ") || "Platform activity",
        href: "/logs",
        createdAt: log.createdAt,
        severity: isSecurity ? "warning" : "info",
      });
    }
  }

  // Newest first
  items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  // Dedupe by id
  const seen = new Set<string>();
  return items.filter((n) => {
    if (seen.has(n.id)) return false;
    seen.add(n.id);
    return true;
  });
}
