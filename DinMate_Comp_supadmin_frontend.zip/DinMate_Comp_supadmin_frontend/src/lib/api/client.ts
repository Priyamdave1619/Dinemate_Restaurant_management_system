import axios, { type AxiosError, type InternalAxiosRequestConfig } from "axios";
import { useAuthStore } from "@/lib/stores/auth-store";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000";

export const api = axios.create({
  baseURL: API_URL,
  headers: { "Content-Type": "application/json" },
  timeout: 30000,
});

let refreshing: Promise<string | null> | null = null;

async function refreshAccessToken(): Promise<string | null> {
  const { refreshToken, setTokens, clearAuth } = useAuthStore.getState();
  if (!refreshToken) {
    clearAuth();
    return null;
  }
  try {
    const res = await axios.post(`${API_URL}/api/auth/refresh`, null, {
      headers: { Authorization: `Bearer ${refreshToken}` },
    });
    const data = res.data?.data;
    if (data?.accessToken && data?.refreshToken) {
      setTokens(data.accessToken, data.refreshToken);
      return data.accessToken as string;
    }
    clearAuth();
    return null;
  } catch {
    clearAuth();
    return null;
  }
}

api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = useAuthStore.getState().accessToken;
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  async (error: AxiosError) => {
    const original = error.config as InternalAxiosRequestConfig & { _retry?: boolean };
    if (error.response?.status === 401 && original && !original._retry) {
      original._retry = true;
      if (!refreshing) {
        refreshing = refreshAccessToken().finally(() => {
          refreshing = null;
        });
      }
      const newToken = await refreshing;
      if (newToken) {
        original.headers.Authorization = `Bearer ${newToken}`;
        return api(original);
      }
      if (typeof window !== "undefined" && !window.location.pathname.startsWith("/login")) {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  }
);

export function getErrorMessage(error: unknown): string {
  // Never surface stack traces, SQL, paths, or internal codes to the UI
  const sanitize = (msg: string) => {
    if (!msg || msg.length > 200) return "Something went wrong";
    if (/ECONN|ENOENT|postgres|sql|stack|node_modules|\/home\/|at\s+\w+\s+\(/i.test(msg)) {
      return "Something went wrong";
    }
    return msg;
  };

  if (axios.isAxiosError(error)) {
    const status = error.response?.status;
    if (status === 401) return "Invalid credentials or session expired";
    if (status === 403) return "You do not have permission to perform this action";
    if (status === 429) return "Too many requests. Please wait and try again";
    if (status && status >= 500) return "Server error. Please try again later";
    const data = error.response?.data as { message?: string } | undefined;
    if (data?.message) return sanitize(String(data.message));
    return "Something went wrong";
  }
  if (error instanceof Error) return sanitize(error.message);
  return "Something went wrong";
}
