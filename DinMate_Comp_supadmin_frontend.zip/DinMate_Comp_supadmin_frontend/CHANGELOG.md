# Super Admin portal updates

## New pages
- `/users` — platform users list with search & role filter
- `/system` — live system health

## Enhanced
- `/plans` — create, edit, activate/deactivate, search, filter, restaurants-on-plan modal
- `/restaurants` — filter by plan (`?planId=`), search, status
- `/restaurants/[id]` — change plan, custom renew days, suspend/activate

## API client
- listPlatformUsers, getSystemStatus, listRestaurants(+planId)
