"use client";
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { SessionUser, RestaurantSummary } from "@/types";

const ALLOWED_ROLES = new Set(["owner", "manager", "waiter", "staff"]);

function isSafeToken(t: unknown): t is string {
  return typeof t === "string" && t.length >= 20 && t.length < 4096 && !/\s/.test(t);
}

function sanitizeUser(u: unknown): SessionUser | null {
  if (!u || typeof u !== "object") return null;
  const o = u as Record<string, unknown>;
  const role = String(o.role || "");
  if (!ALLOWED_ROLES.has(role)) return null;
  const id = String(o.id || "").slice(0, 64);
  const username = String(o.username || "").slice(0, 64);
  const name = String(o.name || "").slice(0, 120);
  if (!id || !username) return null;
  return {
    id,
    username,
    name,
    role: role as SessionUser["role"],
    restaurantId: o.restaurantId != null ? String(o.restaurantId).slice(0, 64) : null,
  };
}

interface AuthState {
  user: SessionUser | null;
  restaurant: RestaurantSummary | null;
  accessToken: string | null;
  refreshToken: string | null;
  setAuth: (p: {
    user: SessionUser;
    restaurant: RestaurantSummary | null;
    accessToken: string;
    refreshToken: string;
  }) => void;
  setTokens: (a: string, r: string) => void;
  clearAuth: () => void;
  isAuthenticated: () => boolean;
  canManage: () => boolean;
  isOwner: () => boolean;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      restaurant: null,
      accessToken: null,
      refreshToken: null,
      setAuth: (p) => {
        const user = sanitizeUser(p.user);
        if (!user || !isSafeToken(p.accessToken) || !isSafeToken(p.refreshToken)) {
          set({ user: null, restaurant: null, accessToken: null, refreshToken: null });
          return;
        }
        set({
          user,
          restaurant: p.restaurant,
          accessToken: p.accessToken,
          refreshToken: p.refreshToken,
        });
      },
      setTokens: (accessToken, refreshToken) => {
        if (!isSafeToken(accessToken) || !isSafeToken(refreshToken)) {
          get().clearAuth();
          return;
        }
        set({ accessToken, refreshToken });
      },
      clearAuth: () =>
        set({ user: null, restaurant: null, accessToken: null, refreshToken: null }),
      isAuthenticated: () => {
        const s = get();
        return isSafeToken(s.accessToken) && !!sanitizeUser(s.user);
      },
      canManage: () => ["owner", "manager"].includes(get().user?.role || ""),
      isOwner: () => get().user?.role === "owner",
    }),
    {
      name: "dinemate-restaurant-auth",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        user: s.user,
        restaurant: s.restaurant,
        accessToken: s.accessToken,
        refreshToken: s.refreshToken,
      }),
      // Re-validate on rehydrate
      onRehydrateStorage: () => (state) => {
        if (!state) return;
        if (!isSafeToken(state.accessToken) || !sanitizeUser(state.user)) {
          state.clearAuth();
        }
      },
    }
  )
);
