export type QrStyleConfig = {
  fgColor: string;
  bgColor: string;
  accentColor: string;
  cardBg: string;
  textColor: string;
  borderRadius: number;
  qrSize: number;
  qrMargin: number;
  showLogo: boolean;
  showRestaurantName: boolean;
  showTableLabel: boolean;
  showAddress: boolean;
  showWelcome: boolean;
  welcomeMessage: string;
  frameStyle: "none" | "simple" | "double" | "dashed";
  errorCorrectionLevel: "L" | "M" | "Q" | "H";
};

export const defaultQrStyle: QrStyleConfig = {
  fgColor: "#1C1B1A",
  bgColor: "#FFFDFB",
  accentColor: "#F97316",
  cardBg: "#FFFFFF",
  textColor: "#1C1B1A",
  borderRadius: 20,
  qrSize: 240,
  qrMargin: 2,
  showLogo: true,
  showRestaurantName: true,
  showTableLabel: true,
  showAddress: false,
  showWelcome: true,
  welcomeMessage: "Scan to order",
  frameStyle: "simple",
  errorCorrectionLevel: "M",
};

const KEY = "dinemate-qr-style";

export function loadQrStyle(): QrStyleConfig {
  if (typeof window === "undefined") return defaultQrStyle;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultQrStyle;
    return { ...defaultQrStyle, ...JSON.parse(raw) };
  } catch {
    return defaultQrStyle;
  }
}

export function saveQrStyle(style: QrStyleConfig) {
  try {
    localStorage.setItem(KEY, JSON.stringify(style));
  } catch {
    /* ignore */
  }
}
