import axios, { type AxiosError, type InternalAxiosRequestConfig } from "axios";
import { useAuthStore } from "@/lib/stores/auth-store";

const API_URL = (process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000").replace(/\/$/, "");

/** Max response / request awareness */
const DEFAULT_TIMEOUT_MS = 30_000;
const MAX_JSON_BODY_HINT = 1_000_000; // 1MB soft client check

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },
  timeout: DEFAULT_TIMEOUT_MS,
  // Do not send cookies cross-origin by default
  withCredentials: false,
  maxContentLength: 5_000_000,
  maxBodyLength: 5_000_000,
  validateStatus: (s) => s >= 200 && s < 300,
});

let refreshing: Promise<string | null> | null = null;

function isSafeToken(t: unknown): t is string {
  return typeof t === "string" && t.length >= 20 && t.length < 4096 && !/\s/.test(t);
}

async function refreshAccessToken(): Promise<string | null> {
  const { refreshToken, setTokens, clearAuth } = useAuthStore.getState();
  if (!isSafeToken(refreshToken)) {
    clearAuth();
    return null;
  }
  try {
    const res = await axios.post(
      `${API_URL}/api/auth/refresh`,
      null,
      {
        headers: { Authorization: `Bearer ${refreshToken}`, Accept: "application/json" },
        timeout: 15_000,
      }
    );
    const d = res.data?.data;
    if (isSafeToken(d?.accessToken) && isSafeToken(d?.refreshToken)) {
      setTokens(d.accessToken, d.refreshToken);
      return d.accessToken;
    }
    clearAuth();
    return null;
  } catch {
    clearAuth();
    return null;
  }
}

api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = useAuthStore.getState().accessToken;
  if (isSafeToken(token)) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  // Strip accidental Authorization override from callers if empty
  if (config.headers.Authorization === "Bearer null" || config.headers.Authorization === "Bearer undefined") {
    delete config.headers.Authorization;
  }
  // FormData must not send a fixed Content-Type — browser/axios must set
  // multipart/form-data WITH boundary. A bare header breaks server parsing.
  if (typeof FormData !== "undefined" && config.data instanceof FormData) {
    const h = config.headers as { delete?: (k: string) => void } & Record<string, unknown>;
    if (typeof h.delete === "function") {
      h.delete("Content-Type");
      h.delete("content-type");
    } else {
      delete h["Content-Type"];
      delete h["content-type"];
    }
  }
  // Soft size guard for JSON bodies
  if (config.data && typeof config.data === "object" && !(config.data instanceof FormData)) {
    try {
      const size = JSON.stringify(config.data).length;
      if (size > MAX_JSON_BODY_HINT) {
        return Promise.reject(new Error("Request payload is too large"));
      }
    } catch {
      /* ignore */
    }
  }
  return config;
});

api.interceptors.response.use(
  (r) => r,
  async (error: AxiosError) => {
    const original = error.config as InternalAxiosRequestConfig & { _retry?: boolean };
    if (error.response?.status === 401 && original && !original._retry) {
      original._retry = true;
      if (!refreshing) {
        refreshing = refreshAccessToken().finally(() => {
          refreshing = null;
        });
      }
      const t = await refreshing;
      if (t) {
        original.headers.Authorization = `Bearer ${t}`;
        return api(original);
      }
      if (typeof window !== "undefined") {
        const path = window.location.pathname;
        if (!path.startsWith("/login")) {
          window.location.replace("/login");
        }
      }
    }
    return Promise.reject(error);
  }
);

/**
 * User-facing error messages only — never leak stack traces, SQL, paths, or internal codes.
 */
export function getErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    const status = error.response?.status;
    const data = error.response?.data as
      | { message?: string; error?: string; errors?: Array<{ message?: string; path?: string }> }
      | undefined;

    // Prefer structured API message if it looks safe (no stack-like content)
    const raw = data?.message || data?.error || data?.errors?.[0]?.message;
    if (typeof raw === "string" && raw.length > 0 && raw.length < 300) {
      if (!/at\s+\w+\s+\(|Exception|ECONNREFUSED|ENOENT|\/Users\/|\/home\/|node_modules/i.test(raw)) {
        return raw;
      }
    }

    if (status === 400) return "Invalid request. Please check your input.";
    if (status === 401) return "Session expired. Please sign in again.";
    if (status === 403) return "You do not have permission to perform this action.";
    if (status === 404) return "The requested resource was not found.";
    if (status === 409) return "Conflict — this resource already exists or was modified.";
    if (status === 413) return "Upload is too large.";
    if (status === 422) return "Validation failed. Please check your input.";
    if (status === 429) return "Too many requests. Please wait a moment and try again.";
    if (status && status >= 500) return "Server error. Please try again later.";
    if (error.code === "ECONNABORTED") return "Request timed out. Please try again.";
    if (error.code === "ERR_NETWORK") return "Network error — check your connection.";
    return "Request failed. Please try again.";
  }
  if (error instanceof Error) {
    // Never surface raw Error.stack
    const msg = error.message || "Something went wrong";
    if (/payload is too large/i.test(msg)) return msg;
    if (msg.length < 200 && !/at\s+\w+/.test(msg)) return msg;
  }
  return "Something went wrong";
}

export { API_URL };
