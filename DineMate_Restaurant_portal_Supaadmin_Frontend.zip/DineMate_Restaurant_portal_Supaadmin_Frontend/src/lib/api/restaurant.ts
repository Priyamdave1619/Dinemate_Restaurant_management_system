import { api } from "./client";
import type {
  ApiSuccess, MenuCategory, MenuItem, RestaurantTable, Order, StaffUser,
  Expense, Offer, AppNotification, RestaurantSettings, RestaurantSummary,
  Plan, DailyStat, ActivityLog, CheckoutPayload, Pagination,
} from "@/types";

export async function getAnalytics() {
  const { data } = await api.get<ApiSuccess<Record<string, unknown>>>("/api/analytics");
  return data.data;
}

export async function getDailyReport(params?: { date?: string; from?: string; to?: string }) {
  const { data } = await api.get<ApiSuccess<{ day?: DailyStat; days?: DailyStat[] }>>("/api/reports/daily", { params });
  return data.data;
}

export async function getWeeklyReport(params?: { week?: string }) {
  const { data } = await api.get<ApiSuccess<{ week: DailyStat }>>("/api/reports/weekly", { params });
  return data.data;
}

export async function getMonthlyReport(params?: { month?: string; year?: string }) {
  const { data } = await api.get<ApiSuccess<{ month?: DailyStat; months?: DailyStat[] }>>("/api/reports/monthly", { params });
  return data.data;
}

export async function getYearlyReport(params?: { year?: string }) {
  const { data } = await api.get<ApiSuccess<{ year: DailyStat; availableYears: string[] }>>("/api/reports/yearly", { params });
  return data.data;
}

export async function getItemsReport(params?: { from?: string; to?: string; limit?: number }) {
  const { data } = await api.get<ApiSuccess<{
    items: unknown[]; bestSelling: unknown[]; leastSelling: unknown[];
    categorySales: unknown[]; foodTypeSales: unknown[];
  }>>("/api/reports/items", { params });
  return data.data;
}

export async function listCategories() {
  const { data } = await api.get<ApiSuccess<{ categories: MenuCategory[] }>>("/api/categories");
  return data.data.categories ?? [];
}

export async function createCategory(body: { name: string; icon?: string }) {
  const { data } = await api.post<ApiSuccess<{ category: MenuCategory }>>("/api/categories", body);
  return data.data.category;
}

export async function updateCategory(id: string, body: Partial<{ name: string; icon: string }>) {
  const { data } = await api.patch<ApiSuccess<unknown>>(`/api/categories/${id}`, body);
  return data.data;
}

export async function deleteCategory(id: string) {
  await api.delete(`/api/categories/${id}`);
}

export async function listMenu() {
  const { data } = await api.get<ApiSuccess<{ items?: MenuItem[]; menu?: MenuItem[] }>>("/api/menu");
  return data.data.items ?? data.data.menu ?? [];
}

export async function createMenuItem(body: Partial<MenuItem>) {
  const { data } = await api.post<ApiSuccess<{ item: MenuItem }>>("/api/menu", body);
  return data.data.item;
}

export async function updateMenuItem(id: string, body: Partial<MenuItem>) {
  const { data } = await api.patch<ApiSuccess<{ item?: MenuItem; items?: MenuItem[] }>>(`/api/menu/${id}`, body);
  return data.data;
}

export async function deleteMenuItem(id: string) {
  await api.delete(`/api/menu/${id}`);
}

export async function listTables() {
  const { data } = await api.get<ApiSuccess<{ tables: RestaurantTable[] }>>("/api/tables");
  return data.data.tables ?? [];
}

export async function createTable(body: { number: number; capacity?: number }) {
  const { data } = await api.post<ApiSuccess<{ table: RestaurantTable }>>("/api/tables", body);
  return data.data.table;
}

export async function updateTable(id: string, body: Partial<RestaurantTable>) {
  const { data } = await api.patch<ApiSuccess<{ tables: RestaurantTable[] }>>(`/api/tables/${id}`, body);
  return data.data.tables;
}

export async function deleteTable(id: string) {
  await api.delete(`/api/tables/${id}`);
}

export async function getTableQr(id: string, regenerate?: boolean) {
  const { data } = await api.get<ApiSuccess<{ qrPath: string; targetUrl: string; encryptedUrl?: string; plainUrl?: string }>>(
    `/api/tables/${id}/qr`,
    { params: { format: "json", ...(regenerate ? { regenerate: "1" } : {}) } }
  );
  return data.data;
}

export async function regenerateTableQr(id: string) {
  const { data } = await api.post<ApiSuccess<{ qrPath: string; targetUrl: string; encryptedUrl?: string; plainUrl?: string }>>(`/api/tables/${id}/qr`);
  return data.data;
}

export async function listOrders(params?: {
  active?: string; includeArchived?: string; tableNumber?: string;
  search?: string; page?: number; pageSize?: number;
}) {
  const { data } = await api.get<ApiSuccess<{ orders: Order[] }>>("/api/orders", { params });
  return { orders: data.data.orders ?? [], pagination: data.pagination as Pagination | undefined };
}

export async function getOrder(id: string) {
  const { data } = await api.get<ApiSuccess<{ order: Order }>>(`/api/orders/${id}`);
  return data.data.order;
}

export async function updateOrder(id: string, body: Partial<Order> & { paymentMethod?: string }) {
  const { data } = await api.patch<ApiSuccess<{ order: Order }>>(`/api/orders/${id}`, body);
  return data.data.order;
}

export async function getOrderBill(id: string) {
  const { data } = await api.get<ApiSuccess<{ order: Order; settings: RestaurantSettings }>>(`/api/orders/${id}/bill`);
  return data.data;
}

export async function getOrderKot(id: string) {
  const { data } = await api.get<ApiSuccess<{ order: Order; itemsToPrint: Order["items"] }>>(`/api/orders/${id}/kot`);
  return data.data;
}

export async function markKotPrinted(id: string) {
  const { data } = await api.post<ApiSuccess<{ order: Order }>>(`/api/orders/${id}/kot`);
  return data.data.order;
}

export async function addOrderItems(
  id: string,
  items: Array<{ itemId: string; name: string; quantity?: number; price?: number; note?: string; variant?: string }>
) {
  const { data } = await api.post<ApiSuccess<{ order: Order }>>(`/api/orders/${id}/items`, { items });
  return data.data.order;
}

export async function listStaff() {
  const { data } = await api.get<ApiSuccess<{ users: StaffUser[] }>>("/api/users");
  return data.data.users ?? [];
}

export async function createStaff(body: {
  username: string; name: string; password: string; role: string; permissions?: string[];
}) {
  const { data } = await api.post<ApiSuccess<{ user: StaffUser }>>("/api/users", body);
  return data.data.user;
}

export async function updateStaff(
  id: string,
  body: Partial<{ name: string; active: boolean; password: string; role: string; permissions: string[] }>
) {
  const { data } = await api.patch<ApiSuccess<{ users: StaffUser[] }>>(`/api/users/${id}`, body);
  return data.data.users;
}

export async function deleteStaff(id: string) {
  await api.delete(`/api/users/${id}`);
}

export async function listExpenses(params?: { month?: string; year?: string }) {
  const { data } = await api.get<ApiSuccess<{ expenses: Expense[] }>>("/api/finance/expenses", { params });
  return data.data.expenses ?? [];
}

export async function createExpense(body: {
  date: string; category: string; description?: string; amount: number;
}) {
  const { data } = await api.post<ApiSuccess<{ expense: Expense }>>("/api/finance/expenses", body);
  return data.data.expense;
}

export async function updateExpense(
  id: string,
  body: Partial<{ date: string; category: string; description: string; amount: number }>
) {
  const { data } = await api.patch<ApiSuccess<{ expenses: Expense[] }>>(`/api/finance/expenses/${id}`, body);
  return data.data.expenses;
}

export async function deleteExpense(id: string) {
  await api.delete(`/api/finance/expenses/${id}`);
}

export async function getPnl(params?: { period?: string; key?: string }) {
  const { data } = await api.get<ApiSuccess<{ period: string; pnl: Record<string, unknown> }>>("/api/finance/pnl", { params });
  return data.data;
}

export async function listOffers() {
  const { data } = await api.get<ApiSuccess<{ offers: Offer[] }>>("/api/offers");
  return data.data.offers ?? [];
}

export async function createOffer(body: Partial<Offer>) {
  const { data } = await api.post<ApiSuccess<{ offer: Offer }>>("/api/offers", body);
  return data.data.offer;
}

export async function updateOffer(id: string, body: Partial<Offer>) {
  const { data } = await api.patch<ApiSuccess<{ offer?: Offer; offers?: Offer[] }>>(`/api/offers/${id}`, body);
  return data.data;
}

export async function deleteOffer(id: string) {
  await api.delete(`/api/offers/${id}`);
}

export async function getSettings() {
  const { data } = await api.get<ApiSuccess<{ settings: RestaurantSettings } | RestaurantSettings>>("/api/settings");
  const d = data.data as { settings?: RestaurantSettings };
  return d.settings ?? (data.data as RestaurantSettings);
}

export async function updateSettings(body: Partial<RestaurantSettings>) {
  const { data } = await api.patch<ApiSuccess<unknown>>("/api/settings", body);
  return data.data;
}

export async function getRestaurantMe() {
  const { data } = await api.get<ApiSuccess<{ restaurant: RestaurantSummary }>>("/api/restaurants/me");
  return data.data.restaurant;
}

export async function updateRestaurantMe(body: Partial<RestaurantSummary>) {
  const { data } = await api.patch<ApiSuccess<{ restaurant: RestaurantSummary }>>("/api/restaurants/me", body);
  return data.data.restaurant;
}

export async function uploadLogo(file: File) {
  const form = new FormData();
  form.append("file", file);
  const { data } = await api.post<ApiSuccess<{ logoUrl: string }>>("/api/restaurants/upload-logo", form, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data.data.logoUrl;
}

export async function listNotifications(params?: { unread?: string }) {
  const { data } = await api.get<ApiSuccess<{ notifications: AppNotification[] }>>("/api/notifications", { params });
  return data.data.notifications ?? [];
}

export async function markAllNotificationsRead() {
  await api.patch("/api/notifications", { markAllRead: true });
}

export async function markNotificationRead(id: string) {
  await api.patch(`/api/notifications/${id}`, { read: true });
}

export async function listActivityLogs(params?: { page?: number; pageSize?: number }) {
  const { data } = await api.get<ApiSuccess<{ logs?: ActivityLog[]; activityLogs?: ActivityLog[] }>>("/api/activity-logs", { params });
  return data.data.logs ?? data.data.activityLogs ?? [];
}

export async function listPlans() {
  const { data } = await api.get<ApiSuccess<{ plans: Plan[] }>>("/api/admin/plans");
  return data.data.plans ?? [];
}

export async function createCheckout(planId: string) {
  const { data } = await api.post<ApiSuccess<{ checkout: CheckoutPayload }>>("/api/billing/checkout", { planId });
  return data.data.checkout;
}

export async function verifyPayment(body: {
  razorpayOrderId: string; razorpayPaymentId: string; razorpaySignature: string; planId: string;
}) {
  const { data } = await api.post<ApiSuccess<{ ok: boolean }>>("/api/billing/verify", body);
  return data.data;
}

// ---------------------------------------------------------------------------
// Bulk Menu Import
// ---------------------------------------------------------------------------

export type MenuImportStatus =
  | "uploaded"
  | "processing"
  | "review_required"
  | "ready"
  | "importing"
  | "completed"
  | "partially_completed"
  | "failed";

export interface ExtractedMenuItem {
  id: string;
  name: string;
  description?: string;
  price: number;
  categoryName?: string;
  categoryId?: string;
  foodType?: string;
  jainAvailable?: boolean | "needs_review";
  variants?: { label: string; price: number }[];
  addOns?: { label: string; price: number }[];
  tags?: string[];
  confidence: { name: number; price: number; category: number; foodType: number; overall: number };
  status: string;
  duplicateOfId?: string;
  errorMessage?: string;
  sourceFile?: string;
}

export interface MenuImportSession {
  id: string;
  restaurantId: string;
  status: MenuImportStatus;
  totalFiles: number;
  totalItems: number;
  processedItems: number;
  successfulItems: number;
  failedItems: number;
  duplicateItems: number;
  needsReviewItems: number;
  files: Array<{ name: string; size: number; mimeType: string; status: string; error?: string }>;
  items: ExtractedMenuItem[];
  categoriesDetected: string[];
  createdAt: string;
  completedAt?: string;
  processingTimeMs?: number;
}

export async function uploadMenuImport(files: File[]) {
  const form = new FormData();
  files.forEach((f) => form.append("files", f));
  // Do NOT set Content-Type manually — boundary must be set by the runtime
  const { data } = await api.post<ApiSuccess<{ session: MenuImportSession }>>(
    "/api/menu-import/upload",
    form,
    {
      timeout: 120_000,
      maxBodyLength: 55 * 1024 * 1024,
      maxContentLength: 55 * 1024 * 1024,
    }
  );
  return data.data.session;
}

export async function processMenuImport(id: string) {
  const { data } = await api.post<ApiSuccess<{ session: MenuImportSession }>>(
    `/api/menu-import/${id}/process`,
    null,
    { timeout: 180_000 }
  );
  return data.data.session;
}

export async function getMenuImport(id: string) {
  const { data } = await api.get<ApiSuccess<{ session: MenuImportSession }>>(`/api/menu-import/${id}`);
  return data.data.session;
}

export async function getMenuImportPreview(id: string, filter?: string) {
  const { data } = await api.get<
    ApiSuccess<{ session: MenuImportSession; summary: Record<string, number> }>
  >(`/api/menu-import/${id}/preview`, { params: filter ? { filter } : undefined });
  return data.data;
}

export async function updateMenuImportItem(sessionId: string, itemId: string, patch: Partial<ExtractedMenuItem>) {
  const { data } = await api.patch<ApiSuccess<{ session: MenuImportSession }>>(
    `/api/menu-import/${sessionId}/items/${itemId}`,
    patch
  );
  return data.data.session;
}

export async function bulkUpdateMenuImport(
  sessionId: string,
  itemIds: string[],
  patch: Record<string, unknown>
) {
  const { data } = await api.post<ApiSuccess<{ session: MenuImportSession }>>(
    `/api/menu-import/${sessionId}/bulk`,
    { itemIds, patch }
  );
  return data.data.session;
}

export async function commitMenuImport(
  id: string,
  opts?: { skipDuplicates?: boolean; approveAllReady?: boolean }
) {
  const { data } = await api.post<
    ApiSuccess<{
      session: MenuImportSession;
      createdCategories: number;
      createdItems: number;
      skipped: number;
      failed: number;
    }>
  >(`/api/menu-import/${id}/commit`, opts || {});
  return data.data;
}

export async function listMenuImportHistory() {
  const { data } = await api.get<ApiSuccess<{ history: MenuImportSession[] }>>("/api/menu-import/history");
  return data.data.history ?? [];
}


export async function deleteMenuImportItem(sessionId: string, itemId: string) {
  const { data } = await api.delete<ApiSuccess<{ session: MenuImportSession }>>(
    `/api/menu-import/${sessionId}/items/${itemId}`
  );
  return data.data.session;
}

export async function deleteMenuImportItems(sessionId: string, itemIds: string[]) {
  const { data } = await api.post<ApiSuccess<{ session: MenuImportSession }>>(
    `/api/menu-import/${sessionId}/bulk`,
    { itemIds, action: "delete" }
  );
  return data.data.session;
}

export async function deleteMenuImport(id: string, opts?: { deleteItems?: boolean }) {
  const params = opts?.deleteItems === false ? { deleteItems: "0" } : { deleteItems: "1" };
  const { data } = await api.delete<ApiSuccess<{ deletedSession: boolean; deletedMenuItems: number }>>(
    `/api/menu-import/${id}`,
    { params }
  );
  return data.data;
}

export async function getAiExtractionStatus(opts?: { probe?: boolean }) {
  const { data } = await api.get<
    ApiSuccess<{
      aiExtractionAvailable: boolean;
      provider: string | null;
      model: string | null;
      source: string;
      connection?: {
        ok: boolean;
        message: string;
        latencyMs?: number;
        model?: string;
      };
    }>
  >("/api/settings/ai-status", {
    params: opts?.probe ? { probe: "1" } : undefined,
    timeout: opts?.probe ? 30_000 : undefined,
  });
  return data.data;
}
