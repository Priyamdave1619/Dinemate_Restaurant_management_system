import { api } from "./client";
import type { ApiSuccess, LoginResponse } from "@/types";

export async function login(username: string, password: string) {
  // Credentials only in memory for this request — never logged
  const { data } = await api.post<ApiSuccess<LoginResponse>>("/api/auth/login", {
    username: String(username).trim().slice(0, 64),
    password: String(password).slice(0, 128),
  });
  if (!data?.data?.accessToken || !data?.data?.refreshToken) {
    throw new Error("Invalid authentication response");
  }
  return data.data;
}

export async function logout(refreshToken?: string) {
  try {
    await api.post("/api/auth/logout", refreshToken ? { refreshToken } : {});
  } catch {
    /* best-effort */
  }
}

export async function changePassword(currentPassword: string, newPassword: string) {
  const { data } = await api.post<ApiSuccess<unknown>>("/api/auth/change-password", {
    currentPassword: String(currentPassword).slice(0, 128),
    newPassword: String(newPassword).slice(0, 128),
  });
  return data.data;
}
