/**
 * Platform-admin API helpers.
 * Restaurant portal does not use these in production UI; stubs exist so
 * accidental imports (e.g. mixed super-admin components) still typecheck/build.
 */
import { api } from "./client";

export interface AdminRestaurantSummary {
  id: string;
  name: string;
  ownerName: string;
  email: string;
  status: string;
  createdAt: string;
  updatedAt?: string;
}

export async function listRestaurants(params?: {
  page?: number;
  limit?: number;
  pageSize?: number;
  search?: string;
  status?: string;
}): Promise<{ restaurants: AdminRestaurantSummary[]; items: AdminRestaurantSummary[]; total: number }> {
  try {
    const { data } = await api.get("/api/admin/restaurants", { params });
    const payload = data?.data ?? data ?? {};
    const restaurants: AdminRestaurantSummary[] = payload.restaurants ?? payload.items ?? [];
    return { restaurants, items: restaurants, total: payload.total ?? restaurants.length };
  } catch {
    return { restaurants: [], items: [], total: 0 };
  }
}

/** Platform dashboard summary — used by the (unused-in-portal) notifications helper. */
export async function getDashboard(): Promise<{
  restaurants: { expiredSubscriptions: number; suspended: number; pending: number };
  recentRegistrations: Array<{ id: string; name: string; ownerName: string; status: string; createdAt: string }>;
}> {
  try {
    const { data } = await api.get("/api/admin/dashboard");
    const d = data?.data ?? data ?? {};
    return {
      restaurants: {
        expiredSubscriptions: d.restaurants?.expiredSubscriptions ?? 0,
        suspended: d.restaurants?.suspended ?? 0,
        pending: d.restaurants?.pending ?? 0,
      },
      recentRegistrations: d.recentRegistrations ?? [],
    };
  } catch {
    return { restaurants: { expiredSubscriptions: 0, suspended: 0, pending: 0 }, recentRegistrations: [] };
  }
}

/** Platform system health — used by the (unused-in-portal) notifications helper. */
export async function getSystemStatus(): Promise<{
  status: string;
  checkedAt: string;
  database: { connected: boolean; latencyMs: number };
  process: { memory: { heapUsedMb: number; heapTotalMb: number } };
  env: { hasRazorpay: boolean };
}> {
  try {
    const { data } = await api.get("/api/admin/system");
    const s = data?.data ?? data ?? {};
    return {
      status: s.status ?? "unknown",
      checkedAt: s.checkedAt ?? new Date().toISOString(),
      database: { connected: s.database?.connected ?? false, latencyMs: s.database?.latencyMs ?? 0 },
      process: {
        memory: {
          heapUsedMb: s.process?.memory?.heapUsedMb ?? 0,
          heapTotalMb: s.process?.memory?.heapTotalMb ?? 0,
        },
      },
      env: { hasRazorpay: s.env?.hasRazorpay ?? false },
    };
  } catch {
    return {
      status: "unknown",
      checkedAt: new Date().toISOString(),
      database: { connected: false, latencyMs: 0 },
      process: { memory: { heapUsedMb: 0, heapTotalMb: 0 } },
      env: { hasRazorpay: false },
    };
  }
}

/** Platform audit/login logs — used by the (unused-in-portal) notifications helper. */
export async function listAuditLogs(params?: {
  kind?: string;
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortDir?: "asc" | "desc";
}): Promise<{
  logs: Array<{
    id: string;
    action: string;
    actorName?: string;
    actorRole?: string;
    entityType?: string;
    entityId?: string;
    createdAt: string;
  }>;
}> {
  try {
    const { data } = await api.get("/api/admin/logs", { params });
    const payload = data?.data ?? data ?? {};
    return { logs: payload.logs ?? [] };
  } catch {
    return { logs: [] };
  }
}

export async function listPlatformUsers(params?: {
  page?: number;
  limit?: number;
  search?: string;
}) {
  try {
    const { data } = await api.get("/api/admin/users", { params });
    return data?.data ?? data ?? { items: [], total: 0 };
  } catch {
    return { items: [], total: 0 };
  }
}

export async function listPlans(params?: { search?: string }) {
  try {
    const { data } = await api.get("/api/admin/plans", { params });
    return data?.data ?? data ?? [];
  } catch {
    return [];
  }
}
