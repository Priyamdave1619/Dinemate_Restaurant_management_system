/**
 * Client-side rate limiting (UX + basic abuse resistance).
 * Real enforcement MUST exist on the backend.
 */

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();

export function checkRateLimit(
  key: string,
  limit: number,
  windowMs: number
): { allowed: boolean; retryAfterMs: number } {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || now >= b.resetAt) {
    b = { count: 0, resetAt: now + windowMs };
    buckets.set(key, b);
  }
  if (b.count >= limit) {
    return { allowed: false, retryAfterMs: Math.max(0, b.resetAt - now) };
  }
  b.count += 1;
  return { allowed: true, retryAfterMs: 0 };
}

export function resetRateLimit(key: string) {
  buckets.delete(key);
}

/** Login: max 5 attempts per 60s per username fingerprint */
export function checkLoginRateLimit(username: string) {
  const key = `login:${username.trim().toLowerCase().slice(0, 64)}`;
  return checkRateLimit(key, 5, 60_000);
}
