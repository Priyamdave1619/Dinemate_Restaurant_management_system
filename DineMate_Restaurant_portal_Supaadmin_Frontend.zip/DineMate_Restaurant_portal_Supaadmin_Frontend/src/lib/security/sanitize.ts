/**
 * Input sanitization utilities — defense in depth against XSS / injection.
 * Frontend sanitization does NOT replace backend validation.
 */

const CONTROL_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
const HTML_TAG = /<\/?[^>]+(>|$)/g;
const SCRIPTISH =
  /javascript\s*:|data\s*:|vbscript\s*:|on\w+\s*=|<script|<iframe|<object|<embed|<link|<meta|<svg/gi;

/** Strip control characters and normalize whitespace edges */
export function stripControlChars(input: string): string {
  return input.replace(CONTROL_CHARS, "");
}

/** Normalize Unicode (NFC) and remove zero-width / invisible chars */
export function normalizeUnicode(input: string): string {
  return input
    .normalize("NFC")
    .replace(/[\u200B-\u200D\uFEFF\u2060\u180E]/g, "");
}

/** Escape HTML entities — safe for textContent-style display */
export function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;")
    .replace(/\//g, "&#x2F;");
}

/** Remove HTML tags and dangerous protocol handlers */
export function stripHtml(input: string): string {
  return stripControlChars(normalizeUnicode(input))
    .replace(HTML_TAG, "")
    .replace(SCRIPTISH, "");
}

/** Trim + strip HTML + collapse internal whitespace for plain text fields */
export function sanitizeText(input: unknown, maxLen = 500): string {
  if (input == null) return "";
  let s = String(input);
  s = stripHtml(s);
  s = s.trim().replace(/\s+/g, " ");
  if (s.length > maxLen) s = s.slice(0, maxLen);
  return s;
}

/** Multiline text (descriptions, notes) — preserve newlines, strip HTML */
export function sanitizeMultiline(input: unknown, maxLen = 2000): string {
  if (input == null) return "";
  let s = String(input);
  s = stripControlChars(normalizeUnicode(s))
    .replace(HTML_TAG, "")
    .replace(SCRIPTISH, "");
  s = s.replace(/[ \t]+\n/g, "\n").trim();
  if (s.length > maxLen) s = s.slice(0, maxLen);
  return s;
}

/** Identifiers: usernames, restaurant IDs, codes */
export function sanitizeIdentifier(input: unknown, maxLen = 64): string {
  if (input == null) return "";
  let s = String(input);
  s = stripControlChars(normalizeUnicode(s)).trim();
  s = s.replace(/[^\w.@+\-]/g, "");
  if (s.length > maxLen) s = s.slice(0, maxLen);
  return s;
}

/** Safe filename for uploads */
export function sanitizeFilename(name: string): string {
  const base = name.split(/[/\\]/).pop() || "file";
  return base
    .replace(/\0/g, "")
    .replace(/[^\w.\- ()]/g, "_")
    .replace(/^\.+/, "")
    .replace(/\.{2,}/g, ".")
    .slice(0, 180);
}

/**
 * Detect common injection patterns (XSS, SQLi, command, path traversal).
 * Used for client-side early reject before API submission.
 */
export function looksMalicious(input: string): boolean {
  if (!input) return false;
  const patterns = [
    /(<script|<\/script)/i,
    /<iframe/i,
    /<object/i,
    /<embed/i,
    /<svg[\s>]/i,
    /javascript\s*:/i,
    /vbscript\s*:/i,
    /data\s*:\s*text\/html/i,
    /on\w+\s*=\s*["']/i,
    /(\$\{|`)/,
    /(\bunion\b.+\bselect\b)/i,
    /(\bselect\b.+\bfrom\b)/i,
    /(\binsert\b.+\binto\b)/i,
    /(\bupdate\b.+\bset\b)/i,
    /(\bdelete\b.+\bfrom\b)/i,
    /(\bdrop\b.+\b(table|database|schema)\b)/i,
    /(\bexec\b|\bexecute\b|\bxp_)/i,
    /(\bwaitfor\b\s+delay)/i,
    /information_schema/i,
    /(\bor\b\s+1\s*=\s*1)/i,
    /(\band\b\s+1\s*=\s*1)/i,
    /(--|\/\*|\*\/)/,
    /[;&|`$\\]/,
    /\b(cmd|powershell|bash|sh|wget|curl)\b/i,
    /\.\.\//,
    /\.\.\\/,
    /%2e%2e/i,
    /%2f/i,
    /%00/,
  ];
  return patterns.some((p) => p.test(input));
}

/** Log security events in development only */
export function logSecurityEvent(
  type: string,
  detail?: Record<string, unknown>
): void {
  if (process.env.NODE_ENV === "development") {
    // eslint-disable-next-line no-console
    console.warn(`[security] ${type}`, detail || {});
  }
}

/** Deep sanitize plain string values in a shallow object (form payloads) */
export function sanitizeObject<T extends Record<string, unknown>>(
  obj: T,
  opts?: { multilineKeys?: string[]; maxLen?: number }
): T {
  const multiline = new Set(
    opts?.multilineKeys || ["description", "address", "note", "message"]
  );
  const max = opts?.maxLen ?? 500;
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (typeof v === "string") {
      if (looksMalicious(v)) {
        logSecurityEvent("malicious_payload_rejected", { key: k });
      }
      out[k] = multiline.has(k)
        ? sanitizeMultiline(v, max * 4)
        : sanitizeText(v, max);
    } else {
      out[k] = v;
    }
  }
  return out as T;
}

/** Allowed image MIME types for logo / product uploads */
export const ALLOWED_IMAGE_MIMES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
] as const;

export const ALLOWED_IMAGE_EXTS = [".jpg", ".jpeg", ".png", ".webp", ".gif"] as const;

export const MAX_UPLOAD_BYTES = 5 * 1024 * 1024; // 5 MB

/** Client-side file validation before upload */
export function validateUploadFile(file: File): { ok: true } | { ok: false; error: string } {
  if (!file || !(file instanceof File)) {
    return { ok: false, error: "No file selected" };
  }
  if (file.size <= 0) {
    return { ok: false, error: "File is empty" };
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    return { ok: false, error: "File must be 5 MB or smaller" };
  }
  const name = file.name.toLowerCase();
  if (name.includes("..") || name.startsWith(".")) {
    return { ok: false, error: "Invalid filename" };
  }
  if (/\.(exe|sh|bat|cmd|js|php|asp|aspx|jsp|html|htm|svg)(\.|$)/i.test(name)) {
    logSecurityEvent("upload_rejected_extension", { name: file.name });
    return { ok: false, error: "This file type is not allowed" };
  }
  const ext = name.includes(".") ? `.${name.split(".").pop()}` : "";
  if (!ALLOWED_IMAGE_EXTS.includes(ext as (typeof ALLOWED_IMAGE_EXTS)[number])) {
    return { ok: false, error: "Only JPEG, PNG, WebP, or GIF images are allowed" };
  }
  if (
    file.type &&
    !ALLOWED_IMAGE_MIMES.includes(file.type as (typeof ALLOWED_IMAGE_MIMES)[number])
  ) {
    return { ok: false, error: "Invalid image type" };
  }
  return { ok: true };
}
