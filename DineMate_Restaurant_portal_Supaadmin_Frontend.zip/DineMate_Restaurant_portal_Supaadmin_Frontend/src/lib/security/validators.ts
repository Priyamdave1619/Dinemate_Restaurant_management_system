/**
 * Shared frontend validators — pure functions used outside Zod forms
 * (search bars, quick filters, ad-hoc inputs).
 */
import {
  looksMalicious,
  sanitizeText,
  sanitizeIdentifier,
  logSecurityEvent,
} from "./sanitize";

/** Max length for global / table search inputs */
export const SEARCH_MAX_LEN = 120;

/**
 * Validate + sanitize a search query string.
 * Returns cleaned value or null if rejected (malicious / empty after trim).
 */
export function validateSearch(
  raw: unknown,
  maxLen: number = SEARCH_MAX_LEN
): string | null {
  if (raw == null) return null;
  const s = sanitizeText(String(raw), maxLen);
  if (!s) return null;
  if (looksMalicious(s)) {
    logSecurityEvent("search_rejected_malicious", { sample: s.slice(0, 40) });
    return null;
  }
  return s;
}

/** Boolean: is this search string safe to send to the API? */
export function isValidSearch(raw: unknown, maxLen: number = SEARCH_MAX_LEN): boolean {
  return validateSearch(raw, maxLen) != null;
}

/** Validate a generic short identifier (codes, usernames, ids) */
export function validateIdentifier(
  raw: unknown,
  maxLen = 64
): string | null {
  if (raw == null) return null;
  const s = sanitizeIdentifier(raw, maxLen);
  if (!s || s.length < 1) return null;
  if (looksMalicious(s)) {
    logSecurityEvent("identifier_rejected_malicious");
    return null;
  }
  return s;
}

/** Simple email shape check (full RFC lives in Zod schemas) */
export function isValidEmail(raw: unknown): boolean {
  if (typeof raw !== "string") return false;
  const s = raw.trim().toLowerCase();
  if (s.length < 5 || s.length > 254) return false;
  if (looksMalicious(s)) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
}

/** Phone digits with optional leading + */
export function isValidPhone(raw: unknown): boolean {
  if (typeof raw !== "string") return false;
  const s = raw.replace(/[\s\-()]/g, "");
  return /^\+?[0-9]{8,15}$/.test(s);
}

/** Positive money amount (up to 2 decimal places) */
export function isValidCurrency(raw: unknown): boolean {
  if (raw == null || raw === "") return false;
  const n = typeof raw === "number" ? raw : Number(String(raw).replace(/,/g, ""));
  if (!Number.isFinite(n) || n < 0) return false;
  return /^\d+(\.\d{1,2})?$/.test(String(n));
}

/** UUID v4 loose check */
export function isValidUuid(raw: unknown): boolean {
  if (typeof raw !== "string") return false;
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
    raw.trim()
  );
}

/** Reject empty / whitespace-only after sanitize */
export function isNonEmpty(raw: unknown, maxLen = 500): boolean {
  return sanitizeText(raw, maxLen).length > 0;
}

export interface PasswordStrengthResult {
  /** 0 (empty) to 4 (strong) */
  score: 0 | 1 | 2 | 3 | 4;
  label: "" | "Weak" | "Fair" | "Good" | "Strong";
  /** Unmet requirements, in priority order — empty when score is 4 */
  feedback: string[];
}

const COMMON_PASSWORDS = new Set([
  "password", "12345678", "123456789", "qwerty123", "letmein123",
  "password123", "admin123", "welcome123", "restaurant123",
]);

/**
 * Score a password's strength (0-4) with actionable feedback.
 * Pure heuristic — mirrors server-side rules loosely, final validation
 * always happens server-side too.
 */
export function passwordStrength(raw: unknown): PasswordStrengthResult {
  const pw = typeof raw === "string" ? raw : "";
  if (!pw) return { score: 0, label: "", feedback: [] };

  const feedback: string[] = [];
  let score = 0;

  if (pw.length >= 12) score++;
  else feedback.push("Use at least 12 characters");

  if (pw.length >= 16) score++;

  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++;
  else feedback.push("Mix uppercase and lowercase letters");

  if (/[0-9]/.test(pw)) score++;
  else feedback.push("Add a number");

  if (/[^A-Za-z0-9]/.test(pw)) score++;
  else feedback.push("Add a symbol");

  if (COMMON_PASSWORDS.has(pw.toLowerCase())) {
    score = Math.min(score, 1) as PasswordStrengthResult["score"];
    feedback.unshift("This password is too common");
  }

  const clamped = Math.min(4, score) as PasswordStrengthResult["score"];
  const labels: PasswordStrengthResult["label"][] = ["", "Weak", "Fair", "Good", "Strong"];

  return { score: clamped, label: labels[clamped], feedback };
}
