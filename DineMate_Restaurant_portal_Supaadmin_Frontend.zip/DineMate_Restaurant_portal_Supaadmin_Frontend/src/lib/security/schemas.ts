/**
 * Zod schemas for every form / API payload used by the restaurant portal.
 * Strict: unknown keys stripped via .strict() where appropriate.
 */
import { z } from "zod";
import { sanitizeText, sanitizeMultiline, sanitizeIdentifier, looksMalicious } from "./sanitize";

const noMalice = (msg = "Invalid characters detected") =>
  z.string().refine((v) => !looksMalicious(v), { message: msg });

/** Shared helpers */
export const requiredTrimmed = (label: string, min = 1, max = 200) =>
  z
    .string({ required_error: `${label} is required` })
    .transform((s) => sanitizeText(s, max))
    .pipe(
      z
        .string()
        .min(min, `${label} is required`)
        .max(max, `${label} must be at most ${max} characters`)
    )
    .refine((v) => !looksMalicious(v), { message: "Invalid characters detected" });

export const optionalTrimmed = (max = 500) =>
  z
    .string()
    .optional()
    .transform((s) => (s == null ? undefined : sanitizeText(s, max)))
    .pipe(z.string().max(max).optional());

export const emailSchema = z
  .string()
  .transform((s) => s.trim().toLowerCase())
  .pipe(
    z
      .string()
      .min(1, "Email is required")
      .max(254, "Email is too long")
      .email("Enter a valid email address")
  );

export const phoneSchema = z
  .string()
  .transform((s) => s.replace(/[\s\-()]/g, "").trim())
  .pipe(
    z
      .string()
      .min(8, "Enter a valid phone number")
      .max(15, "Phone number is too long")
      .regex(/^\+?[0-9]{8,15}$/, "Enter a valid phone number")
  );

export const optionalPhone = z
  .string()
  .optional()
  .transform((s) => (s ? s.replace(/[\s\-()]/g, "").trim() : undefined))
  .pipe(
    z
      .string()
      .regex(/^\+?[0-9]{8,15}$/, "Enter a valid phone number")
      .optional()
      .or(z.literal("").transform(() => undefined))
  );

const COMMON_PASSWORDS = new Set([
  "password","password123","password123!","123456789012","qwertyuiop12",
  "admin123456!","welcome1234!","letmein12345","changeme123!","dinemate123!",
]);

/** Enterprise password policy — OWASP-aligned (min 12, complexity, anti-sequence) */
export const passwordSchema = z
  .string({ required_error: "Password is required" })
  .min(12, "Password must be at least 12 characters")
  .max(128, "Password is too long")
  .regex(/[a-z]/, "Include at least one lowercase letter")
  .regex(/[A-Z]/, "Include at least one uppercase letter")
  .regex(/[0-9]/, "Include at least one number")
  .regex(/[^A-Za-z0-9]/, "Include at least one special character")
  .refine((v) => !/(.)\1{2,}/.test(v), {
    message: "Avoid repeated characters (e.g. aaa)",
  })
  .refine(
    (v) => !/(012|123|234|345|456|567|678|789|890|abc|bcd|cde)/i.test(v),
    { message: "Avoid sequential characters" }
  )
  .refine((v) => !COMMON_PASSWORDS.has(v.toLowerCase()), {
    message: "This password is too common",
  });

/** Login — username may be Restaurant ID or staff username */
export const loginSchema = z
  .object({
    username: z
      .string({ required_error: "Username is required" })
      .transform((s) => sanitizeIdentifier(s, 64))
      .pipe(
        z
          .string()
          .min(2, "Username is required")
          .max(64, "Username is too long")
          .regex(/^[a-zA-Z0-9._@+-]+$/, "Invalid username format")
      ),
    password: z
      .string({ required_error: "Password is required" })
      .min(1, "Password is required")
      .max(128, "Password is too long"),
  })
  .strict();

export type LoginInput = z.infer<typeof loginSchema>;

/** Change password */
export const changePasswordSchema = z
  .object({
    current: z.string().min(1, "Current password is required").max(128),
    next: passwordSchema,
    confirm: z.string().min(1, "Confirm your new password"),
  })
  .strict()
  .refine((d) => d.next === d.confirm, {
    message: "Passwords do not match",
    path: ["confirm"],
  })
  .refine((d) => d.current !== d.next, {
    message: "New password must differ from current password",
    path: ["next"],
  });

/** Staff create */
export const staffCreateSchema = z
  .object({
    username: z
      .string()
      .transform((s) => sanitizeIdentifier(s, 32))
      .pipe(
        z
          .string()
          .min(3, "Username must be at least 3 characters")
          .max(32, "Username is too long")
          .regex(/^[a-zA-Z0-9._-]+$/, "Only letters, numbers, dots, underscores, hyphens")
      ),
    name: requiredTrimmed("Name", 2, 80),
    password: passwordSchema,
    role: z.enum(["waiter", "manager"], {
      errorMap: () => ({ message: "Select a valid role" }),
    }),
  })
  .strict();

/** Menu category */
export const categorySchema = z
  .object({
    name: requiredTrimmed("Category name", 1, 60),
    icon: z
      .string()
      .max(8, "Icon is too long")
      .optional()
      .transform((s) => (s ? sanitizeText(s, 8) : undefined)),
    scheduleEnabled: z.boolean().default(false),
    availableFrom: z
      .string()
      .optional()
      .transform((s) => (s && s.trim() ? s.trim() : undefined)),
    availableTo: z
      .string()
      .optional()
      .transform((s) => (s && s.trim() ? s.trim() : undefined)),
  })
  .strict()
  .superRefine((data, ctx) => {
    if (data.scheduleEnabled) {
      const re = /^([01]\d|2[0-3]):([0-5]\d)$/;
      if (!data.availableFrom || !re.test(data.availableFrom)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Start time is required (HH:mm)",
          path: ["availableFrom"],
        });
      }
      if (!data.availableTo || !re.test(data.availableTo)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "End time is required (HH:mm)",
          path: ["availableTo"],
        });
      }
    }
  });

/** Menu item */
export const menuItemSchema = z
  .object({
    name: requiredTrimmed("Item name", 1, 120),
    price: z.coerce
      .number({ invalid_type_error: "Price must be a number" })
      .finite()
      .positive("Price must be greater than 0")
      .max(999999, "Price is too large"),
    costPrice: z.preprocess(
      (v) => (v === "" || v === null || v === undefined ? undefined : v),
      z.coerce.number().finite().min(0).max(999999).optional()
    ),
    categoryId: z.string().min(1, "Select a category").max(64),
    description: z
      .string()
      .optional()
      .transform((s) => (s ? sanitizeMultiline(s, 1000) : undefined)),
    foodType: z.enum(["veg", "non-veg", "egg", "other"]).default("veg"),
    prepTimeMinutes: z.preprocess(
      (v) => (v === "" || v === null || v === undefined ? undefined : v),
      z.coerce.number().int().min(0).max(600).optional()
    ),
    available: z.boolean().default(true),
    scheduleEnabled: z.boolean().default(false),
    availableFrom: z
      .string()
      .optional()
      .transform((s) => (s && s.trim() ? s.trim() : undefined)),
    availableTo: z
      .string()
      .optional()
      .transform((s) => (s && s.trim() ? s.trim() : undefined)),
  })
  .strict()
  .superRefine((data, ctx) => {
    if (data.scheduleEnabled) {
      const re = /^([01]\d|2[0-3]):([0-5]\d)$/;
      if (!data.availableFrom || !re.test(data.availableFrom)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Start time is required (HH:mm)",
          path: ["availableFrom"],
        });
      }
      if (!data.availableTo || !re.test(data.availableTo)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "End time is required (HH:mm)",
          path: ["availableTo"],
        });
      }
    }
  });

export const expenseSchema = z
  .object({
    date: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date")
      .refine((d) => !Number.isNaN(Date.parse(d)), "Invalid date"),
    category: z.enum([
      "supplies",
      "rent",
      "utilities",
      "salaries",
      "marketing",
      "maintenance",
      "other",
    ]),
    description: requiredTrimmed("Description", 1, 200),
    amount: z.coerce
      .number({ invalid_type_error: "Amount must be a number" })
      .finite()
      .positive("Amount must be greater than 0")
      .max(10_000_000, "Amount is too large"),
  })
  .strict();

/** Restaurant profile */
export const profileSchema = z
  .object({
    name: requiredTrimmed("Restaurant name", 2, 120),
    ownerName: requiredTrimmed("Owner name", 2, 80),
    email: emailSchema,
    mobile: phoneSchema,
    address: z
      .string()
      .transform((s) => sanitizeMultiline(s, 500))
      .pipe(z.string().max(500, "Address is too long")),
    gstNumber: z
      .string()
      .transform((s) => s.trim().toUpperCase())
      .pipe(
        z
          .string()
          .max(20)
          .regex(/^$|^[0-9A-Z]{10,20}$/, "Invalid GST number")
      )
      .optional()
      .or(z.literal("")),
  })
  .strict();

/** Table create/update */
export const tableSchema = z
  .object({
    number: z.coerce
      .number({ invalid_type_error: "Table number is required" })
      .int("Must be a whole number")
      .positive("Must be greater than 0")
      .max(9999),
    capacity: z.coerce
      .number()
      .int()
      .min(1, "Capacity must be at least 1")
      .max(100, "Capacity is too large"),
    status: z
      .enum(["available", "occupied", "reserved", "cleaning"])
      .optional(),
  })
  .strict();

/** Settings (tax etc.) */
export const settingsSchema = z
  .object({
    taxRatePercent: z.coerce
      .number()
      .finite()
      .min(0, "Tax cannot be negative")
      .max(100, "Tax cannot exceed 100%"),
    restaurantName: requiredTrimmed("Restaurant name", 2, 120).optional(),
    address: optionalTrimmed(500),
    phone: optionalTrimmed(20),
    foodLicence: optionalTrimmed(64),
    gstin: z
      .string()
      .optional()
      .transform((s) => (s ? s.trim().toUpperCase() : undefined)),
  })
  .strict();


/** Offer create */
export const offerSchema = z
  .object({
    name: requiredTrimmed("Offer name", 1, 120),
    type: z.enum(["percent", "fixed", "bogo", "flat"], {
      errorMap: () => ({ message: "Select a valid offer type" }),
    }).or(z.string().min(1).max(32)),
    discountPercent: z.preprocess(
      (v) => (v === "" || v === null || v === undefined ? undefined : v),
      z.coerce.number().min(0).max(100).optional()
    ),
    discountAmount: z.preprocess(
      (v) => (v === "" || v === null || v === undefined ? undefined : v),
      z.coerce.number().min(0).max(1_000_000).optional()
    ),
    buyQty: z.preprocess(
      (v) => (v === "" || v === null || v === undefined ? undefined : v),
      z.coerce.number().int().min(1).max(100).optional()
    ),
    getQty: z.preprocess(
      (v) => (v === "" || v === null || v === undefined ? undefined : v),
      z.coerce.number().int().min(1).max(100).optional()
    ),
    minOrderAmount: z.preprocess(
      (v) => (v === "" || v === null || v === undefined ? undefined : v),
      z.coerce.number().min(0).max(1_000_000).optional()
    ),
    active: z.boolean().optional(),
  })
  .strict();

/** File upload constraints */
export const LOGO_CONSTRAINTS = {
  maxBytes: 300 * 1024,
  allowedMime: ["image/png", "image/jpeg", "image/jpg", "image/webp"] as const,
  allowedExt: [".png", ".jpg", ".jpeg", ".webp"] as const,
};

export function validateImageFile(file: File): { ok: true } | { ok: false; error: string } {
  if (!file) return { ok: false, error: "No file selected" };
  if (file.size <= 0) return { ok: false, error: "File is empty" };
  if (file.size > LOGO_CONSTRAINTS.maxBytes) {
    return { ok: false, error: `File must be ≤ ${Math.round(LOGO_CONSTRAINTS.maxBytes / 1024)}KB` };
  }
  const mime = (file.type || "").toLowerCase();
  if (!(LOGO_CONSTRAINTS.allowedMime as readonly string[]).includes(mime)) {
    return { ok: false, error: "Only PNG, JPG, or WebP images are allowed" };
  }
  const name = file.name.toLowerCase();
  // Reject double extensions / executables
  if (/\.(exe|js|html|htm|svg|php|sh|bat|cmd|dll|msi)(\.|$)/i.test(name)) {
    return { ok: false, error: "File type not allowed" };
  }
  const hasExt = LOGO_CONSTRAINTS.allowedExt.some((ext) => name.endsWith(ext));
  if (!hasExt) {
    return { ok: false, error: "Invalid file extension" };
  }
  return { ok: true };
}

/** Safe ID for path params */
export const idParamSchema = z
  .string()
  .min(1)
  .max(64)
  .regex(/^[a-zA-Z0-9_-]+$/, "Invalid id");
