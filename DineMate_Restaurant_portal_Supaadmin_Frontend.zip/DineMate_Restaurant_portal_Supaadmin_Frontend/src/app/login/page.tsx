"use client";
import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { Loader2, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { BrandLogo } from "@/components/branding";
import { login } from "@/lib/api/auth";
import { useAuthStore } from "@/lib/stores/auth-store";
import { getErrorMessage } from "@/lib/api/client";
import { loginSchema, type LoginInput } from "@/lib/security/schemas";
import { checkLoginRateLimit } from "@/lib/security/rate-limit";
import { sanitizeIdentifier } from "@/lib/security/sanitize";
import { PasswordStrength } from "@/components/shared/password-strength";

export default function LoginPage() {
  const router = useRouter();
  const setAuth = useAuthStore((s) => s.setAuth);
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const submitting = useRef(false);

  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
    watch,
  } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    mode: "onChange",
    defaultValues: { username: "", password: "" },
  });

  const passwordValue = watch("password");

  async function onSubmit(values: LoginInput) {
    if (submitting.current) return;
    submitting.current = true;

    const username = sanitizeIdentifier(values.username, 64);
    const rate = checkLoginRateLimit(username);
    if (!rate.allowed) {
      const secs = Math.ceil(rate.retryAfterMs / 1000);
      toast.error(`Too many login attempts. Try again in ${secs}s.`);
      submitting.current = false;
      return;
    }

    setLoading(true);
    try {
      const res = await login(username, values.password);
      if (res.role === "super_admin") {
        toast.error("Use the Platform Admin panel for super admin");
        return;
      }
      if (!res.restaurantId) {
        toast.error("Account is not linked to a restaurant");
        return;
      }
      if (!res.accessToken || !res.refreshToken) {
        toast.error("Authentication failed");
        return;
      }
      setAuth({
        user: {
          id: String(res.id),
          username: String(res.username),
          name: String(res.name || res.username),
          role: res.role,
          restaurantId: res.restaurantId,
        },
        restaurant: res.restaurant,
        accessToken: res.accessToken,
        refreshToken: res.refreshToken,
      });
      toast.success(`Welcome, ${String(res.name || res.username).slice(0, 80)}`);
      router.replace("/dashboard");
    } catch (e) {
      toast.error(getErrorMessage(e));
    } finally {
      setLoading(false);
      submitting.current = false;
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-background p-4 safe-top safe-bottom">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/15 via-background to-background" />
      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full max-w-md"
      >
        <div className="glass-card rounded-2xl p-6 shadow-floating sm:p-8">
          <div className="mb-8 flex flex-col items-center text-center">
            {/* Company logo — gold in light mode, blue in dark mode */}
            <div className="mb-2 flex min-h-[120px] w-full items-center justify-center">
              <BrandLogo
                variant="login"
                size="xl"
                companyName="DineMate"
              />
            </div>
            <h1 className="mt-2 text-xl font-semibold tracking-tight text-foreground">
              Restaurant Portal
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Sign in to manage your restaurant
            </p>
            <p className="mt-2 text-xs text-muted-foreground">
              Owners: use Restaurant ID as username
            </p>
          </div>
          <form
            onSubmit={handleSubmit(onSubmit)}
            className="space-y-4"
            autoComplete="on"
            noValidate
          >
            <div className="space-y-2">
              <Label htmlFor="username">Username / Restaurant ID</Label>
              <Input
                id="username"
                placeholder="REST000021 or waiter username"
                autoComplete="username"
                autoCapitalize="off"
                autoCorrect="off"
                spellCheck={false}
                maxLength={64}
                aria-invalid={!!errors.username}
                aria-describedby={errors.username ? "username-err" : undefined}
                {...register("username")}
              />
              {errors.username && (
                <p id="username-err" className="text-xs text-destructive animate-fade-in" role="alert">
                  {errors.username.message}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={show ? "text" : "password"}
                  placeholder="••••••••"
                  autoComplete="current-password"
                  maxLength={128}
                  className="pr-10"
                  aria-invalid={!!errors.password}
                  aria-describedby={errors.password ? "password-err" : undefined}
                  {...register("password")}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-0.5 text-muted-foreground transition-colors hover:text-foreground"
                  onClick={() => setShow(!show)}
                  aria-label={show ? "Hide password" : "Show password"}
                  tabIndex={-1}
                >
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.password && (
                <p id="password-err" className="text-xs text-destructive animate-fade-in" role="alert">
                  {errors.password.message}
                </p>
              )}
              <PasswordStrength password={passwordValue || ""} />
            </div>
            <Button
              type="submit"
              className="w-full"
              disabled={loading || !isValid}
            >
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              Sign in
            </Button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}
