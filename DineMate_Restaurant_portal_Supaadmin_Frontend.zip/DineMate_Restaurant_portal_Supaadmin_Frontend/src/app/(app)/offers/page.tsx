"use client";

import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  listOffers,
  createOffer,
  updateOffer,
  deleteOffer,
  listMenu,
  listCategories,
} from "@/lib/api/restaurant";
import type { Offer, OfferType, MenuItem, MenuCategory } from "@/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { PageLoader, StatCardSkeleton } from "@/components/shared/loaders";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { useAuthStore } from "@/lib/stores/auth-store";
import {
  Plus,
  Tag,
  Percent,
  Copy,
  Pencil,
  Trash2,
  Clock,
  Calendar,
  Sparkles,
  Ticket,
} from "lucide-react";

const OFFER_TYPES: { value: OfferType; label: string; hint: string }[] = [
  { value: "percent", label: "Percentage", hint: "e.g. 20% off" },
  { value: "flat", label: "Flat amount", hint: "e.g. ₹200 off" },
  { value: "bogo", label: "Buy X Get Y", hint: "BOGO / free units" },
  { value: "category", label: "Category discount", hint: "Whole category" },
  { value: "item", label: "Item-specific", hint: "Selected products" },
  { value: "happy_hour", label: "Happy hour", hint: "Time-slot promo" },
  { value: "coupon", label: "Coupon code", hint: "Requires code" },
  { value: "combo", label: "Combo", hint: "Bundle-style" },
];

const DAYS = [
  { v: 0, l: "Sun" },
  { v: 1, l: "Mon" },
  { v: 2, l: "Tue" },
  { v: 3, l: "Wed" },
  { v: 4, l: "Thu" },
  { v: 5, l: "Fri" },
  { v: 6, l: "Sat" },
];

type FormState = {
  name: string;
  description: string;
  type: OfferType;
  discountPercent: string;
  discountAmount: string;
  maxDiscountAmount: string;
  minOrderAmount: string;
  buyQty: string;
  getQty: string;
  itemIds: string[];
  categoryIds: string[];
  excludeItemIds: string[];
  startsAt: string;
  endsAt: string;
  daysOfWeek: number[];
  timeFrom: string;
  timeTo: string;
  usageLimit: string;
  perCustomerLimit: string;
  couponCode: string;
  autoApply: boolean;
  stackable: boolean;
  priority: string;
  active: boolean;
};

const emptyForm = (): FormState => ({
  name: "",
  description: "",
  type: "percent",
  discountPercent: "10",
  discountAmount: "",
  maxDiscountAmount: "",
  minOrderAmount: "",
  buyQty: "2",
  getQty: "1",
  itemIds: [],
  categoryIds: [],
  excludeItemIds: [],
  startsAt: "",
  endsAt: "",
  daysOfWeek: [],
  timeFrom: "",
  timeTo: "",
  usageLimit: "",
  perCustomerLimit: "",
  couponCode: "",
  autoApply: true,
  stackable: true,
  priority: "0",
  active: true,
});

function statusVariant(status?: string) {
  switch (status) {
    case "active":
      return "success" as const;
    case "scheduled":
      return "warning" as const;
    case "expired":
    case "exhausted":
      return "secondary" as const;
    default:
      return "secondary" as const;
  }
}

function summarizeOffer(o: Offer): string {
  if (o.type === "bogo") return `Buy ${o.buyQty ?? "?"} get ${o.getQty ?? "?"}`;
  if (o.discountPercent != null) return `${o.discountPercent}% off`;
  if (o.discountAmount != null) return `₹${o.discountAmount} off`;
  return o.type;
}

export default function OffersPage() {
  const qc = useQueryClient();
  const canManage = useAuthStore((s) => s.canManage());
  const { data: offers, isLoading } = useQuery({
    queryKey: ["offers"],
    queryFn: listOffers,
  });
  const { data: menu } = useQuery({ queryKey: ["menu"], queryFn: listMenu });
  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: listCategories,
  });

  const [show, setShow] = useState(false);
  const [editing, setEditing] = useState<Offer | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [productSearch, setProductSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "active" | "scheduled" | "expired">("all");

  const stats = useMemo(() => {
    const list = offers || [];
    return {
      total: list.length,
      active: list.filter((o) => o.status === "active" || (o.active && o.live)).length,
      scheduled: list.filter((o) => o.status === "scheduled").length,
      expired: list.filter((o) => o.status === "expired" || o.status === "exhausted").length,
      coupons: list.filter((o) => !!o.couponCode).length,
    };
  }, [offers]);

  const filtered = useMemo(() => {
    const list = offers || [];
    if (filter === "all") return list;
    return list.filter((o) => {
      if (filter === "active") return o.status === "active" || o.live;
      if (filter === "scheduled") return o.status === "scheduled";
      if (filter === "expired") return o.status === "expired" || o.status === "exhausted";
      return true;
    });
  }, [offers, filter]);

  const _menuById = useMemo(() => {
    const m = new Map<string, MenuItem>();
    (menu || []).forEach((i) => m.set(i.id, i));
    return m;
  }, [menu]);

  const filteredProducts = useMemo(() => {
    const q = productSearch.trim().toLowerCase();
    let items = menu || [];
    if (q) {
      items = items.filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          i.description?.toLowerCase().includes(q)
      );
    }
    return items.slice(0, 40);
  }, [menu, productSearch]);

  function openCreate() {
    setEditing(null);
    setForm(emptyForm());
    setProductSearch("");
    setShow(true);
  }

  function openEdit(o: Offer) {
    setEditing(o);
    setForm({
      name: o.name,
      description: o.description || "",
      type: (o.type as OfferType) || "percent",
      discountPercent: o.discountPercent != null ? String(o.discountPercent) : "",
      discountAmount: o.discountAmount != null ? String(o.discountAmount) : "",
      maxDiscountAmount: o.maxDiscountAmount != null ? String(o.maxDiscountAmount) : "",
      minOrderAmount: o.minOrderAmount != null ? String(o.minOrderAmount) : "",
      buyQty: o.buyQty != null ? String(o.buyQty) : "2",
      getQty: o.getQty != null ? String(o.getQty) : "1",
      itemIds: o.itemIds || (o.itemId ? [o.itemId] : []),
      categoryIds: o.categoryIds || (o.categoryId ? [o.categoryId] : []),
      excludeItemIds: o.excludeItemIds || [],
      startsAt: o.startsAt ? o.startsAt.slice(0, 16) : "",
      endsAt: o.endsAt ? o.endsAt.slice(0, 16) : "",
      daysOfWeek: o.daysOfWeek || [],
      timeFrom: o.timeFrom || "",
      timeTo: o.timeTo || "",
      usageLimit: o.usageLimit != null ? String(o.usageLimit) : "",
      perCustomerLimit: o.perCustomerLimit != null ? String(o.perCustomerLimit) : "",
      couponCode: o.couponCode || "",
      autoApply: o.autoApply !== false,
      stackable: o.stackable !== false,
      priority: String(o.priority ?? 0),
      active: o.active,
    });
    setShow(true);
  }

  function openDuplicate(o: Offer) {
    openEdit(o);
    setEditing(null);
    setForm((f) => ({
      ...f,
      name: `${o.name} (copy)`,
      couponCode: o.couponCode ? `${o.couponCode}-COPY` : "",
    }));
  }

  function buildBody() {
    const body: Record<string, unknown> = {
      name: form.name.trim(),
      description: form.description.trim() || undefined,
      type: form.type,
      active: form.active,
      autoApply: form.autoApply,
      stackable: form.stackable,
      priority: Number(form.priority) || 0,
      itemIds: form.itemIds.length ? form.itemIds : undefined,
      categoryIds: form.categoryIds.length ? form.categoryIds : undefined,
      excludeItemIds: form.excludeItemIds.length ? form.excludeItemIds : undefined,
      startsAt: form.startsAt ? new Date(form.startsAt).toISOString() : undefined,
      endsAt: form.endsAt ? new Date(form.endsAt).toISOString() : undefined,
      daysOfWeek: form.daysOfWeek.length ? form.daysOfWeek : undefined,
      timeFrom: form.timeFrom || undefined,
      timeTo: form.timeTo || undefined,
      couponCode: form.couponCode.trim().toUpperCase() || undefined,
    };
    if (form.discountPercent !== "") body.discountPercent = Number(form.discountPercent);
    if (form.discountAmount !== "") body.discountAmount = Number(form.discountAmount);
    if (form.maxDiscountAmount !== "") body.maxDiscountAmount = Number(form.maxDiscountAmount);
    if (form.minOrderAmount !== "") body.minOrderAmount = Number(form.minOrderAmount);
    if (form.usageLimit !== "") body.usageLimit = Number(form.usageLimit);
    if (form.perCustomerLimit !== "") body.perCustomerLimit = Number(form.perCustomerLimit);
    if (form.type === "bogo") {
      body.buyQty = Number(form.buyQty) || 1;
      body.getQty = Number(form.getQty) || 1;
    }
    return body;
  }

  const saveMut = useMutation({
    mutationFn: async () => {
      if (!form.name.trim()) throw new Error("Offer name is required");
      const body = buildBody();
      if (editing) return updateOffer(editing.id, body);
      return createOffer(body);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["offers"] });
      setShow(false);
      toast.success(editing ? "Offer updated" : "Offer created");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const toggleMut = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) =>
      updateOffer(id, { active }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["offers"] });
      toast.success("Status updated");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const delMut = useMutation({
    mutationFn: deleteOffer,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["offers"] });
      setDeleteId(null);
      toast.success("Offer deleted");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  function toggleDay(d: number) {
    setForm((f) => ({
      ...f,
      daysOfWeek: f.daysOfWeek.includes(d)
        ? f.daysOfWeek.filter((x) => x !== d)
        : [...f.daysOfWeek, d].sort(),
    }));
  }

  function toggleItem(id: string) {
    setForm((f) => ({
      ...f,
      itemIds: f.itemIds.includes(id)
        ? f.itemIds.filter((x) => x !== id)
        : [...f.itemIds, id],
    }));
  }

  function toggleCategory(id: string) {
    setForm((f) => ({
      ...f,
      categoryIds: f.categoryIds.includes(id)
        ? f.categoryIds.filter((x) => x !== id)
        : [...f.categoryIds, id],
    }));
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <PageHeader title="Offers & discounts" description="Promotions, coupons, and happy hours" />
        <StatCardSkeleton count={5} />
        <PageLoader label="Loading offers…" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Offers & discounts"
        description="Percentage, flat, BOGO, happy hour, and coupon promotions"
        actions={
          canManage ? (
            <Button size="sm" onClick={openCreate}>
              <Plus className="h-4 w-4" /> Create offer
            </Button>
          ) : undefined
        }
      />

      {/* Stats */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {[
          { label: "Total offers", value: stats.total, icon: Tag },
          { label: "Live now", value: stats.active, icon: Sparkles },
          { label: "Scheduled", value: stats.scheduled, icon: Calendar },
          { label: "Expired", value: stats.expired, icon: Clock },
          { label: "Coupons", value: stats.coupons, icon: Ticket },
        ].map((s) => (
          <Card key={s.label} className="card-interactive">
            <CardContent className="flex items-center gap-3 py-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <s.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-semibold tabular-nums">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-2">
        {(["all", "active", "scheduled", "expired"] as const).map((f) => (
          <Button
            key={f}
            size="sm"
            variant={filter === f ? "default" : "outline"}
            onClick={() => setFilter(f)}
            className="capitalize"
          >
            {f}
          </Button>
        ))}
      </div>

      {!filtered.length ? (
        <EmptyState
          icon={Tag}
          title="No offers yet"
          description="Create percentage, flat, BOGO, or coupon promotions for your guests"
          action={
            canManage ? (
              <Button size="sm" onClick={openCreate}>
                <Plus className="h-4 w-4" /> Create offer
              </Button>
            ) : undefined
          }
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((o) => (
            <Card key={o.id} className="card-interactive flex flex-col">
              <CardHeader className="flex flex-row items-start justify-between gap-2 space-y-0 pb-2">
                <div className="min-w-0 space-y-1">
                  <CardTitle className="truncate text-base">{o.name}</CardTitle>
                  <CardDescription className="capitalize">{o.type.replace("_", " ")}</CardDescription>
                </div>
                <Badge variant={statusVariant(o.status || (o.active ? "active" : "inactive"))}>
                  {o.status || (o.active ? "active" : "off")}
                </Badge>
              </CardHeader>
              <CardContent className="flex flex-1 flex-col gap-3 text-sm">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className="font-medium">
                    <Percent className="mr-1 h-3 w-3" />
                    {summarizeOffer(o)}
                  </Badge>
                  {o.couponCode && (
                    <Badge variant="secondary" className="font-mono text-xs">
                      {o.couponCode}
                    </Badge>
                  )}
                  {o.minOrderAmount != null && (
                    <Badge variant="outline">Min ₹{o.minOrderAmount}</Badge>
                  )}
                </div>
                {o.description && (
                  <p className="line-clamp-2 text-xs text-muted-foreground">{o.description}</p>
                )}
                <div className="mt-auto space-y-1 text-xs text-muted-foreground">
                  {(o.timeFrom || o.startsAt) && (
                    <p className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {o.timeFrom && o.timeTo
                        ? `${o.timeFrom}–${o.timeTo}`
                        : o.startsAt
                          ? `From ${new Date(o.startsAt).toLocaleString()}`
                          : null}
                      {o.endsAt ? ` → ${new Date(o.endsAt).toLocaleDateString()}` : null}
                    </p>
                  )}
                  {o.autoApply === false && <p>Manual coupon only</p>}
                  {o.stackable === false && <p>Non-stackable</p>}
                </div>
                {canManage && (
                  <div className="flex flex-wrap gap-1 border-t border-border/50 pt-3">
                    <Button size="sm" variant="outline" onClick={() => openEdit(o)}>
                      <Pencil className="h-3.5 w-3.5" /> Edit
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => openDuplicate(o)}>
                      <Copy className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => toggleMut.mutate({ id: o.id, active: !o.active })}
                    >
                      {o.active ? "Disable" : "Enable"}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-destructive"
                      onClick={() => setDeleteId(o.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Create / Edit dialog */}
      <Dialog open={show} onOpenChange={setShow}>
        <DialogContent className="max-h-[92vh] max-w-2xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit offer" : "Create offer"}</DialogTitle>
            <DialogDescription>
              Configure discount type, schedule, products, and coupon rules
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Offer name *</Label>
              <Input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. Lunch 20% Off"
              />
            </div>

            <div className="space-y-1.5 sm:col-span-2">
              <Label>Type</Label>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {OFFER_TYPES.map((t) => (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => setForm({ ...form, type: t.value })}
                    className={`rounded-lg border px-2 py-2 text-left text-xs transition-colors ${
                      form.type === t.value
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border hover:bg-muted/50"
                    }`}
                  >
                    <div className="font-medium">{t.label}</div>
                    <div className="text-muted-foreground">{t.hint}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5 sm:col-span-2">
              <Label>Description</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={2}
              />
            </div>

            {form.type !== "bogo" && (
              <>
                <div className="space-y-1.5">
                  <Label>Discount %</Label>
                  <Input
                    type="number"
                    min={0}
                    max={100}
                    value={form.discountPercent}
                    onChange={(e) => setForm({ ...form, discountPercent: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Flat amount (₹)</Label>
                  <Input
                    type="number"
                    min={0}
                    value={form.discountAmount}
                    onChange={(e) => setForm({ ...form, discountAmount: e.target.value })}
                  />
                </div>
              </>
            )}

            {form.type === "bogo" && (
              <>
                <div className="space-y-1.5">
                  <Label>Buy qty</Label>
                  <Input
                    type="number"
                    min={1}
                    value={form.buyQty}
                    onChange={(e) => setForm({ ...form, buyQty: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>Get qty (free)</Label>
                  <Input
                    type="number"
                    min={1}
                    value={form.getQty}
                    onChange={(e) => setForm({ ...form, getQty: e.target.value })}
                  />
                </div>
              </>
            )}

            <div className="space-y-1.5">
              <Label>Max discount (₹)</Label>
              <Input
                type="number"
                min={0}
                value={form.maxDiscountAmount}
                onChange={(e) => setForm({ ...form, maxDiscountAmount: e.target.value })}
                placeholder="Optional cap"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Min order (₹)</Label>
              <Input
                type="number"
                min={0}
                value={form.minOrderAmount}
                onChange={(e) => setForm({ ...form, minOrderAmount: e.target.value })}
              />
            </div>

            {/* Categories */}
            <div className="space-y-2 sm:col-span-2">
              <Label>Applicable categories</Label>
              <div className="flex flex-wrap gap-2">
                {(categories || []).map((c: MenuCategory) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => toggleCategory(c.id)}
                    className={`rounded-full border px-3 py-1 text-xs transition-colors ${
                      form.categoryIds.includes(c.id)
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border hover:bg-muted"
                    }`}
                  >
                    {c.icon} {c.name}
                  </button>
                ))}
                {!categories?.length && (
                  <span className="text-xs text-muted-foreground">No categories</span>
                )}
              </div>
            </div>

            {/* Products multi-select */}
            <div className="space-y-2 sm:col-span-2">
              <Label>Applicable products</Label>
              <Input
                placeholder="Search menu items…"
                value={productSearch}
                onChange={(e) => setProductSearch(e.target.value)}
              />
              <div className="max-h-40 space-y-1 overflow-y-auto rounded-lg border p-2">
                {filteredProducts.map((item) => (
                  <label
                    key={item.id}
                    className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-muted/60"
                  >
                    <input
                      type="checkbox"
                      className="h-4 w-4"
                      checked={form.itemIds.includes(item.id)}
                      onChange={() => toggleItem(item.id)}
                    />
                    <span className="flex-1 truncate">{item.name}</span>
                    <span className="text-xs text-muted-foreground">₹{item.price}</span>
                  </label>
                ))}
                {!filteredProducts.length && (
                  <p className="p-2 text-xs text-muted-foreground">No products found</p>
                )}
              </div>
              {form.itemIds.length > 0 && (
                <p className="text-xs text-muted-foreground">
                  {form.itemIds.length} selected
                  {" · "}
                  <button
                    type="button"
                    className="text-primary underline"
                    onClick={() => setForm({ ...form, itemIds: [] })}
                  >
                    Clear
                  </button>
                </p>
              )}
            </div>

            {/* Schedule */}
            <div className="space-y-1.5">
              <Label>Starts at</Label>
              <Input
                type="datetime-local"
                value={form.startsAt}
                onChange={(e) => setForm({ ...form, startsAt: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Ends at</Label>
              <Input
                type="datetime-local"
                value={form.endsAt}
                onChange={(e) => setForm({ ...form, endsAt: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Daily from (happy hour)</Label>
              <Input
                type="time"
                value={form.timeFrom}
                onChange={(e) => setForm({ ...form, timeFrom: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Daily until</Label>
              <Input
                type="time"
                value={form.timeTo}
                onChange={(e) => setForm({ ...form, timeTo: e.target.value })}
              />
            </div>

            <div className="space-y-2 sm:col-span-2">
              <Label>Days of week</Label>
              <div className="flex flex-wrap gap-1">
                {DAYS.map((d) => (
                  <button
                    key={d.v}
                    type="button"
                    onClick={() => toggleDay(d.v)}
                    className={`h-9 w-10 rounded-md border text-xs font-medium ${
                      form.daysOfWeek.includes(d.v)
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border"
                    }`}
                  >
                    {d.l}
                  </button>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">Leave empty for every day</p>
            </div>

            <div className="space-y-1.5">
              <Label>Coupon code</Label>
              <Input
                value={form.couponCode}
                onChange={(e) =>
                  setForm({ ...form, couponCode: e.target.value.toUpperCase() })
                }
                placeholder="LUNCH20"
                className="font-mono uppercase"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Priority</Label>
              <Input
                type="number"
                min={0}
                value={form.priority}
                onChange={(e) => setForm({ ...form, priority: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Usage limit</Label>
              <Input
                type="number"
                min={1}
                value={form.usageLimit}
                onChange={(e) => setForm({ ...form, usageLimit: e.target.value })}
                placeholder="Unlimited"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Per customer limit</Label>
              <Input
                type="number"
                min={1}
                value={form.perCustomerLimit}
                onChange={(e) => setForm({ ...form, perCustomerLimit: e.target.value })}
              />
            </div>

            <div className="flex flex-wrap gap-4 sm:col-span-2">
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  className="h-4 w-4"
                  checked={form.autoApply}
                  onChange={(e) => setForm({ ...form, autoApply: e.target.checked })}
                />
                Auto-apply (no code needed)
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  className="h-4 w-4"
                  checked={form.stackable}
                  onChange={(e) => setForm({ ...form, stackable: e.target.checked })}
                />
                Stackable with other offers
              </label>
              <label className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  className="h-4 w-4"
                  checked={form.active}
                  onChange={(e) => setForm({ ...form, active: e.target.checked })}
                />
                Active
              </label>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShow(false)}>
              Cancel
            </Button>
            <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>
              {saveMut.isPending ? "Saving…" : editing ? "Update offer" : "Create offer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteId}
        onOpenChange={(o) => !o && setDeleteId(null)}
        title="Delete offer?"
        description="This promotion will be removed permanently."
        confirmLabel="Delete"
        variant="destructive"
        onConfirm={() => deleteId && delMut.mutate(deleteId)}
        loading={delMut.isPending}
      />
    </div>
  );
}
