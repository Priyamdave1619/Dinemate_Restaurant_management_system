"use client";

import { useCallback, useState } from "react";
import { useRouter } from "next/navigation";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  uploadMenuImport,
  processMenuImport,
  getMenuImportPreview,
  updateMenuImportItem,
  bulkUpdateMenuImport,
  deleteMenuImportItem,
  deleteMenuImportItems,
  deleteMenuImport,
  commitMenuImport,
  listMenuImportHistory,
  getAiExtractionStatus,
  type MenuImportSession,
  type ExtractedMenuItem,
} from "@/lib/api/restaurant";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import {
  Upload,
  FileImage,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ArrowLeft,
  ArrowRight,
  RefreshCw,
  Trash2,
} from "lucide-react";
import { formatCurrency } from "@/lib/utils/format";
import Link from "next/link";

type Step = "upload" | "processing" | "review" | "result";

const ACCEPTED =
  "image/jpeg,image/png,image/webp,application/pdf,text/csv,application/json,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,.jpg,.jpeg,.png,.webp,.pdf,.csv,.json,.xlsx";

export default function BulkMenuImportPage() {
  const router = useRouter();
  const qc = useQueryClient();
  const [step, setStep] = useState<Step>("upload");
  const [files, setFiles] = useState<File[]>([]);
  const [session, setSession] = useState<MenuImportSession | null>(null);
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [dragOver, setDragOver] = useState(false);

  const historyQ = useQuery({
    queryKey: ["menu-import-history"],
    queryFn: listMenuImportHistory,
  });

  const aiStatusQ = useQuery({
    queryKey: ["ai-extraction-status"],
    queryFn: () => getAiExtractionStatus({ probe: true }),
    staleTime: 60_000,
  });

  const uploadMut = useMutation({
    mutationFn: uploadMenuImport,
    onSuccess: (s) => {
      setSession(s);
      setStep("processing");
      processMut.mutate(s.id);
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const processMut = useMutation({
    mutationFn: processMenuImport,
    onSuccess: (s) => {
      setSession(s);
      setStep("review");
      if (s.totalItems > 0) {
        toast.success(`Extracted ${s.totalItems} items`);
      } else {
        const detail =
          s.files?.find((f) => f.error)?.error ||
          "No items found — use a clear full-page menu photo (JPG/PNG)";
        toast.error(detail.slice(0, 220));
      }
    },
    onError: (e) => {
      toast.error(getErrorMessage(e));
      setStep("upload");
    },
  });

  const commitMut = useMutation({
    mutationFn: (id: string) => commitMenuImport(id, { approveAllReady: true, skipDuplicates: true }),
    onSuccess: (res) => {
      setSession(res.session);
      setStep("result");
      qc.invalidateQueries({ queryKey: ["menu"] });
      qc.invalidateQueries({ queryKey: ["categories"] });
      qc.invalidateQueries({ queryKey: ["menu-import-history"] });
      toast.success(`Imported ${res.createdItems} items`);
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const list = Array.from(e.dataTransfer.files);
    setFiles((prev) => [...prev, ...list].slice(0, 100));
  }, []);

  const onFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = Array.from(e.target.files || []);
    setFiles((prev) => [...prev, ...list].slice(0, 100));
  };

  const removeFile = (idx: number) => setFiles((f) => f.filter((_, i) => i !== idx));

  const startUpload = () => {
    if (files.length === 0) {
      toast.error("Add at least one file");
      return;
    }
    uploadMut.mutate(files);
  };

  const items = session?.items || [];
  const filtered =
    filter === "all"
      ? items
      : filter === "needs_review"
        ? items.filter((i) => i.status === "needs_review")
        : filter === "duplicate"
          ? items.filter((i) => i.status === "duplicate")
          : filter === "error"
            ? items.filter((i) => i.status === "error")
            : items.filter((i) => i.status === "extracted" || i.status === "approved");

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });
  };

  const selectAllFiltered = () => {
    setSelected(new Set(filtered.map((i) => i.id)));
  };

  const applyBulkFoodType = async (foodType: string) => {
    if (!session || selected.size === 0) return;
    try {
      const s = await bulkUpdateMenuImport(session.id, [...selected], { foodType, status: "approved" });
      setSession(s);
      toast.success("Updated selected items");
    } catch (e) {
      toast.error(getErrorMessage(e));
    }
  };

  const deleteSelected = async () => {
    if (!session || selected.size === 0) return;
    if (!confirm(`Delete ${selected.size} selected item(s)?`)) return;
    try {
      const s = await deleteMenuImportItems(session.id, [...selected]);
      setSession(s);
      setSelected(new Set());
      toast.success("Deleted selected items");
    } catch (e) {
      toast.error(getErrorMessage(e));
    }
  };

  const deleteOne = async (itemId: string) => {
    if (!session) return;
    try {
      const s = await deleteMenuImportItem(session.id, itemId);
      setSession(s);
      setSelected((prev) => {
        const n = new Set(prev);
        n.delete(itemId);
        return n;
      });
      toast.success("Item deleted");
    } catch (e) {
      toast.error(getErrorMessage(e));
    }
  };

  const confidenceBadge = (c: number) => {
    if (c >= 0.85) return <Badge className="bg-green-100 text-green-800">High</Badge>;
    if (c >= 0.6) return <Badge className="bg-yellow-100 text-yellow-800">Medium</Badge>;
    return <Badge className="bg-red-100 text-red-800">Review</Badge>;
  };

  return (
    <div className="space-y-6">
      <PageHeader
        title="Bulk Menu Import"
        description="Upload menu images, PDFs, CSV or JSON — AI-assisted extraction with human review before import."
        actions={
          <Button variant="outline" asChild>
            <Link href="/menu">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to Menu
            </Link>
          </Button>
        }
      />

      {/* Steps indicator */}
      <div className="flex gap-2 text-sm">
        {(["upload", "processing", "review", "result"] as Step[]).map((s, i) => (
          <div
            key={s}
            className={`flex items-center gap-1 rounded-full px-3 py-1 ${
              step === s ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
            }`}
          >
            <span className="font-medium">{i + 1}. {s.replace("_", " ")}</span>
          </div>
        ))}
      </div>

      {step === "upload" && (
        <Card>
          <CardHeader>
            <CardTitle>Upload Your Restaurant Menu</CardTitle>
            {aiStatusQ.data && (
              <div className="space-y-1 text-sm text-muted-foreground">
                <p>
                  {aiStatusQ.data.connection?.ok ? (
                    <>
                      AI image extraction:{" "}
                      <Badge className="bg-green-100 text-green-800">Groq connected</Badge>
                      {aiStatusQ.data.model ? (
                        <span className="ml-2 text-xs">({aiStatusQ.data.model})</span>
                      ) : null}
                      {aiStatusQ.data.connection.latencyMs != null ? (
                        <span className="ml-2 text-xs">{aiStatusQ.data.connection.latencyMs}ms</span>
                      ) : null}
                    </>
                  ) : aiStatusQ.data.aiExtractionAvailable ? (
                    <>
                      AI image extraction:{" "}
                      <Badge className="bg-amber-100 text-amber-800">Key set, not verified</Badge>
                      <span className="ml-2 text-xs">
                        {aiStatusQ.data.connection?.message || "Could not reach Groq"}
                      </span>
                    </>
                  ) : (
                    <>
                      AI image extraction:{" "}
                      <Badge className="bg-amber-100 text-amber-800">Not configured</Badge>
                      <span className="ml-2 text-xs">
                        CSV/JSON still work. Set GROQ_API_KEY on the backend.
                      </span>
                    </>
                  )}
                </p>
              </div>
            )}
          </CardHeader>
          <CardContent className="space-y-4">
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={onDrop}
              className={`flex flex-col items-center justify-center rounded-xl border-2 border-dashed p-12 transition ${
                dragOver ? "border-primary bg-primary/5" : "border-muted-foreground/30"
              }`}
            >
              <Upload className="mb-3 h-10 w-10 text-muted-foreground" />
              <p className="mb-1 text-lg font-medium">Drag & drop files here or Browse</p>
              <p className="mb-4 text-sm text-muted-foreground">
                JPG · PNG · WebP · PDF · CSV · XLSX · JSON — up to 100 files
              </p>
              <label>
                <input type="file" multiple accept={ACCEPTED} className="hidden" onChange={onFileInput} />
                <Button type="button" variant="secondary" asChild>
                  <span>Browse Files</span>
                </Button>
              </label>
            </div>

            {files.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium">{files.length} file(s) selected</p>
                <ul className="max-h-48 space-y-1 overflow-y-auto text-sm">
                  {files.map((f, i) => (
                    <li key={`${f.name}-${i}`} className="flex items-center justify-between rounded border px-3 py-2">
                      <span className="flex items-center gap-2 truncate">
                        <FileImage className="h-4 w-4 shrink-0" />
                        {f.name}
                        <span className="text-muted-foreground">({(f.size / 1024).toFixed(1)} KB)</span>
                      </span>
                      <Button size="sm" variant="ghost" onClick={() => removeFile(i)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </li>
                  ))}
                </ul>
                <Button onClick={startUpload} disabled={uploadMut.isPending}>
                  {uploadMut.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Uploading…
                    </>
                  ) : (
                    <>
                      Upload & Extract <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            )}

            {historyQ.data && historyQ.data.length > 0 && (
              <div className="mt-6">
                <h3 className="mb-2 font-medium">Recent imports</h3>
                <ul className="space-y-2 text-sm">
                  {historyQ.data.slice(0, 10).map((h) => (
                    <li
                      key={h.id}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-lg border px-3 py-2.5"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="font-medium">
                          {new Date(h.createdAt).toLocaleString()} — {h.totalItems} items
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {h.successfulItems ?? 0} imported
                          {h.needsReviewItems ? ` · ${h.needsReviewItems} review` : ""}
                          {h.failedItems ? ` · ${h.failedItems} failed` : ""}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{h.status}</Badge>
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          className="h-8 text-destructive hover:bg-destructive/10 hover:text-destructive"
                          title={
                            h.status === "completed"
                              ? "Delete import and remove menu items created by it"
                              : "Delete this import session"
                          }
                          onClick={async () => {
                            const cascade = h.status === "completed";
                            const msg = cascade
                              ? `Delete this import and remove the menu items it created (${h.successfulItems || h.totalItems} items)? This cannot be undone.`
                              : "Delete this import session from history?";
                            if (!confirm(msg)) return;
                            try {
                              const res = await deleteMenuImport(h.id, { deleteItems: cascade });
                              toast.success(
                                res?.deletedMenuItems
                                  ? `Deleted import and ${res.deletedMenuItems} menu item(s)`
                                  : "Import deleted"
                              );
                              historyQ.refetch();
                              qc.invalidateQueries({ queryKey: ["menu"] });
                            } catch (e) {
                              toast.error(getErrorMessage(e));
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {step === "processing" && (
        <Card>
          <CardContent className="flex flex-col items-center gap-4 py-16">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
            <p className="text-lg font-medium">Processing menu…</p>
            <p className="text-sm text-muted-foreground">
              Validating files → OCR / AI extraction → category detection → duplicate check
            </p>
            {session && (
              <p className="text-sm">
                {session.files.filter((f) => f.status === "done").length} / {session.totalFiles} files
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {step === "review" && session && (
        <div className="space-y-4">
          {session.files.some((f) => f.status === "error") && (
            <Card className="border-red-200 bg-red-50">
              <CardContent className="space-y-1 pt-4 text-sm text-red-800">
                <p className="font-medium">Extraction issues</p>
                {session.files
                  .filter((f) => f.error)
                  .map((f) => (
                    <p key={f.name}>
                      <strong>{f.name}:</strong> {f.error}
                    </p>
                  ))}
                <p className="pt-1 text-xs text-red-700">
                  Tips: use a sharp full-page photo, avoid heavy glare, prefer JPG/PNG (not PDF), one
                  page per image.
                </p>
              </CardContent>
            </Card>
          )}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardContent className="pt-4">
                <p className="text-2xl font-bold">{session.totalItems}</p>
                <p className="text-sm text-muted-foreground">Items found</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <p className="text-2xl font-bold">{session.categoriesDetected.length}</p>
                <p className="text-sm text-muted-foreground">Categories</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <p className="text-2xl font-bold text-amber-600">{session.needsReviewItems}</p>
                <p className="text-sm text-muted-foreground">Needs review</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <p className="text-2xl font-bold text-orange-600">{session.duplicateItems}</p>
                <p className="text-sm text-muted-foreground">Possible duplicates</p>
              </CardContent>
            </Card>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="w-40"
            >
              <option value="all">All</option>
              <option value="valid">Valid</option>
              <option value="needs_review">Needs Review</option>
              <option value="duplicate">Duplicates</option>
              <option value="error">Errors</option>
            </Select>
            <Button size="sm" variant="outline" onClick={selectAllFiltered}>
              Select visible
            </Button>
            <Button size="sm" variant="outline" onClick={() => applyBulkFoodType("veg")} disabled={selected.size === 0}>
              Set Veg
            </Button>
            <Button size="sm" variant="outline" onClick={() => applyBulkFoodType("non-veg")} disabled={selected.size === 0}>
              Set Non-Veg
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="text-red-600"
              onClick={deleteSelected}
              disabled={selected.size === 0}
            >
              <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete selected
            </Button>
            <div className="flex-1" />
            <Button
              onClick={() => commitMut.mutate(session.id)}
              disabled={commitMut.isPending || session.totalItems === 0}
            >
              {commitMut.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Importing…
                </>
              ) : (
                <>
                  <CheckCircle2 className="mr-2 h-4 w-4" /> Confirm & Import
                </>
              )}
            </Button>
          </div>

          <div className="overflow-x-auto rounded-lg border">
            <table className="w-full text-sm">
              <thead className="bg-muted/50">
                <tr>
                  <th className="p-2 text-left">Sel</th>
                  <th className="p-2 text-left">Name</th>
                  <th className="p-2 text-left">Category</th>
                  <th className="p-2 text-left">Type</th>
                  <th className="p-2 text-right">Price</th>
                  <th className="p-2 text-left">Status</th>
                  <th className="p-2 text-left">Confidence</th>
                  <th className="p-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((it) => (
                  <tr key={it.id} className="border-t">
                    <td className="p-2">
                      <input
                        type="checkbox"
                        checked={selected.has(it.id)}
                        onChange={() => toggleSelect(it.id)}
                      />
                    </td>
                    <td className="p-2">
                      <Input
                        className="h-8 min-w-[140px]"
                        defaultValue={it.name}
                        onBlur={async (e) => {
                          if (e.target.value !== it.name && session) {
                            const s = await updateMenuImportItem(session.id, it.id, {
                              name: e.target.value,
                              status: "approved",
                            });
                            setSession(s);
                          }
                        }}
                      />
                      {it.errorMessage && (
                        <p className="mt-0.5 text-xs text-red-600">{it.errorMessage}</p>
                      )}
                    </td>
                    <td className="p-2">
                      <Input
                        className="h-8 min-w-[100px]"
                        defaultValue={it.categoryName || ""}
                        onBlur={async (e) => {
                          if (e.target.value !== it.categoryName && session) {
                            const s = await updateMenuImportItem(session.id, it.id, {
                              categoryName: e.target.value,
                            });
                            setSession(s);
                          }
                        }}
                      />
                    </td>
                    <td className="p-2">{it.foodType || "—"}</td>
                    <td className="p-2 text-right">
                      <Input
                        className="h-8 w-24 text-right"
                        type="number"
                        defaultValue={it.price || ""}
                        onBlur={async (e) => {
                          const p = parseFloat(e.target.value);
                          if (!Number.isNaN(p) && p !== it.price && session) {
                            const s = await updateMenuImportItem(session.id, it.id, {
                              price: p,
                              status: p > 0 ? "approved" : "needs_review",
                            });
                            setSession(s);
                          }
                        }}
                      />
                    </td>
                    <td className="p-2">
                      {it.status === "duplicate" && (
                        <span className="flex items-center gap-1 text-orange-600">
                          <AlertTriangle className="h-3 w-3" /> Duplicate
                        </span>
                      )}
                      {it.status === "needs_review" && (
                        <span className="flex items-center gap-1 text-amber-600">
                          <AlertTriangle className="h-3 w-3" /> Review
                        </span>
                      )}
                      {it.status === "error" && (
                        <span className="flex items-center gap-1 text-red-600">
                          <XCircle className="h-3 w-3" /> Error
                        </span>
                      )}
                      {(it.status === "extracted" || it.status === "approved") && (
                        <span className="flex items-center gap-1 text-green-600">
                          <CheckCircle2 className="h-3 w-3" /> Ready
                        </span>
                      )}
                    </td>
                    <td className="p-2">{confidenceBadge(it.confidence?.overall ?? 0)}</td>
                    <td className="p-2 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <select
                          className="h-8 rounded border bg-background px-1 text-xs"
                          value={it.foodType || "other"}
                          onChange={async (e) => {
                            if (!session) return;
                            try {
                              const s = await updateMenuImportItem(session.id, it.id, {
                                foodType: e.target.value as "veg" | "non-veg" | "egg" | "vegan" | "other",
                                status: "approved",
                              });
                              setSession(s);
                            } catch (err) {
                              toast.error(getErrorMessage(err));
                            }
                          }}
                        >
                          <option value="veg">Veg</option>
                          <option value="non-veg">Non-Veg</option>
                          <option value="egg">Egg</option>
                          <option value="vegan">Vegan</option>
                          <option value="other">Other</option>
                        </select>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-red-600"
                          title="Delete item"
                          onClick={() => deleteOne(it.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <p className="p-6 text-center text-muted-foreground">No items match this filter</p>
            )}
          </div>
        </div>
      )}

      {step === "result" && session && (
        <Card>
          <CardContent className="space-y-4 py-10 text-center">
            <CheckCircle2 className="mx-auto h-16 w-16 text-green-600" />
            <h2 className="text-2xl font-bold">Menu Import Completed</h2>
            <div className="mx-auto grid max-w-md gap-2 text-left text-sm">
              <p>
                Successfully imported: <strong>{session.successfulItems}</strong>
              </p>
              <p>
                Skipped / duplicates: <strong>{session.duplicateItems}</strong>
              </p>
              <p>
                Failed: <strong>{session.failedItems}</strong>
              </p>
              {session.processingTimeMs != null && (
                <p>
                  Processing time: <strong>{(session.processingTimeMs / 1000).toFixed(1)}s</strong>
                </p>
              )}
            </div>
            <div className="flex justify-center gap-3">
              <Button asChild>
                <Link href="/menu">View Menu</Link>
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setStep("upload");
                  setFiles([]);
                  setSession(null);
                  setSelected(new Set());
                }}
              >
                <RefreshCw className="mr-2 h-4 w-4" /> Import Another
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
