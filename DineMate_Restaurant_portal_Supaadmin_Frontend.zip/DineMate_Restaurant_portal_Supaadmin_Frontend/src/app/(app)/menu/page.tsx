"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  listMenu,
  listCategories,
  createMenuItem,
  updateMenuItem,
  deleteMenuItem,
  createCategory,
  updateCategory,
  deleteCategory,
} from "@/lib/api/restaurant";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { Plus, Pencil, Trash2, Search, FolderOpen, Loader2, Upload } from "lucide-react";
import Link from "next/link";
import { TableSkeleton } from "@/components/shared/loaders";
import { menuItemSchema, categorySchema } from "@/lib/security/schemas";
import { PageHeader } from "@/components/shared/page-header";
import { TablePagination } from "@/components/data-table/pagination";
import { DEFAULT_PAGE_SIZE, PAGE_SIZE_OPTIONS } from "@/components/data-table/types";
import { EmptyState } from "@/components/shared/empty-state";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import type { MenuItem, MenuCategory } from "@/types";
import { useAuthStore } from "@/lib/stores/auth-store";

const emptyItemForm = {
  name: "",
  price: "",
  costPrice: "",
  categoryId: "",
  description: "",
  foodType: "veg",
  prepTimeMinutes: "",
  available: true,
  scheduleEnabled: false,
  availableFrom: "11:00",
  availableTo: "15:00",
  jainAvailable: false,
  jainOnly: false,
  enableSpiceLevel: false,
  enableCookingRequest: true,
  addOnsText: "",
  variantsText: "",
  tagsText: "",
};

export default function MenuPage() {
  const qc = useQueryClient();
  const canManage = useAuthStore((s) => s.canManage());
  const { data: items, isLoading } = useQuery({ queryKey: ["menu"], queryFn: listMenu });
  const { data: categories, isLoading: catLoading } = useQuery({
    queryKey: ["categories"],
    queryFn: listCategories,
  });

  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(DEFAULT_PAGE_SIZE);
  const [showItemForm, setShowItemForm] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [itemForm, setItemForm] = useState(emptyItemForm);
  const [deleteItemId, setDeleteItemId] = useState<string | null>(null);

  // Category CRUD state
  const [showCatForm, setShowCatForm] = useState(false);
  const [editingCat, setEditingCat] = useState<MenuCategory | null>(null);
  const [catForm, setCatForm] = useState({
    name: "",
    icon: "",
    scheduleEnabled: false,
    availableFrom: "11:00",
    availableTo: "15:00",
  });
  const [deleteCatId, setDeleteCatId] = useState<string | null>(null);

  const filtered = (items || []).filter((item) => {
    if (catFilter && item.categoryId !== catFilter) return false;
    if (search && !item.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize) || 1);
  const safePage = Math.min(page, totalPages);
  const pagedItems = filtered.slice((safePage - 1) * pageSize, safePage * pageSize);
  const catMap = Object.fromEntries((categories || []).map((c) => [c.id, c.name]));
  const itemCountByCat = (categories || []).reduce<Record<string, number>>((acc, c) => {
    acc[c.id] = (items || []).filter((i) => i.categoryId === c.id).length;
    return acc;
  }, {});

  /* ── Menu item mutations ─────────────────────────────────────── */
  const saveItemMut = useMutation({
    mutationFn: async () => {
      const parsed = menuItemSchema.safeParse({
        name: itemForm.name,
        price: itemForm.price,
        costPrice: itemForm.costPrice || undefined,
        categoryId: itemForm.categoryId || categories?.[0]?.id || "",
        description: itemForm.description || undefined,
        available: itemForm.available,
        foodType: itemForm.foodType,
        prepTimeMinutes: itemForm.prepTimeMinutes || undefined,
        scheduleEnabled: itemForm.scheduleEnabled,
        availableFrom: itemForm.scheduleEnabled ? itemForm.availableFrom : undefined,
        availableTo: itemForm.scheduleEnabled ? itemForm.availableTo : undefined,
      });
      if (!parsed.success) {
        throw new Error(parsed.error.errors[0]?.message || "Invalid menu item");
      }
      const parsePairs = (text: string, asAddOn: boolean) =>
        text
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean)
          .map((pair, i) => {
            const [label, priceStr] = pair.split(":").map((x) => x.trim());
            const priceDelta = Number(priceStr || 0) || 0;
            const slug = (label || "x").toLowerCase().replace(/\s+/g, "-");
            if (asAddOn) {
              return {
                id: `ao-${i + 1}-${slug}`,
                label: label || `Option ${i + 1}`,
                priceDelta,
                available: true,
              };
            }
            return {
              id: `v-${i + 1}-${slug}`,
              label: label || `Variant ${i + 1}`,
              priceDelta,
            };
          });

      const body = {
        ...parsed.data,
        isVeg: parsed.data.foodType === "veg",
        jainAvailable: itemForm.jainAvailable,
        jainOnly: itemForm.jainOnly,
        enableSpiceLevel: itemForm.enableSpiceLevel,
        spiceOptions: itemForm.enableSpiceLevel
          ? ["mild", "medium", "spicy", "extra_spicy"]
          : undefined,
        enableCookingRequest: itemForm.enableCookingRequest,
        maxCookingRequestLength: 250,
        addOns: itemForm.addOnsText.trim()
          ? parsePairs(itemForm.addOnsText, true)
          : [],
        variants: itemForm.variantsText.trim()
          ? parsePairs(itemForm.variantsText, false)
          : [],
        tags: itemForm.tagsText
          .split(",")
          .map((s) => s.trim().toLowerCase().replace(/\s+/g, "_"))
          .filter(Boolean),
      };
      if (editingItem) return updateMenuItem(editingItem.id, body);
      return createMenuItem(body);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["menu"] });
      setShowItemForm(false);
      setEditingItem(null);
      setItemForm(emptyItemForm);
      toast.success(editingItem ? "Item updated" : "Item added");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const toggleMut = useMutation({
    mutationFn: ({ id, available }: { id: string; available: boolean }) =>
      updateMenuItem(id, { available }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["menu"] }),
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const delItemMut = useMutation({
    mutationFn: deleteMenuItem,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["menu"] });
      setDeleteItemId(null);
      toast.success("Item deleted");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  /* ── Category mutations ──────────────────────────────────────── */
  const saveCatMut = useMutation({
    mutationFn: async () => {
      const parsed = categorySchema.safeParse({
        name: catForm.name,
        icon: catForm.icon || undefined,
        scheduleEnabled: catForm.scheduleEnabled,
        availableFrom: catForm.scheduleEnabled ? catForm.availableFrom : undefined,
        availableTo: catForm.scheduleEnabled ? catForm.availableTo : undefined,
      });
      if (!parsed.success) {
        throw new Error(parsed.error.errors[0]?.message || "Invalid category");
      }
      if (editingCat) return updateCategory(editingCat.id, parsed.data);
      return createCategory(parsed.data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["categories"] });
      setShowCatForm(false);
      setEditingCat(null);
      setCatForm({
      name: "",
      icon: "",
      scheduleEnabled: false,
      availableFrom: "11:00",
      availableTo: "15:00",
    });
      toast.success(editingCat ? "Category updated" : "Category created");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const delCatMut = useMutation({
    mutationFn: deleteCategory,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["categories"] });
      qc.invalidateQueries({ queryKey: ["menu"] });
      setDeleteCatId(null);
      toast.success("Category deleted");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  function openEditItem(item: MenuItem) {
    setEditingItem(item);
    setItemForm({
      name: item.name,
      price: String(item.price),
      costPrice: item.costPrice != null ? String(item.costPrice) : "",
      categoryId: item.categoryId,
      description: item.description || "",
      foodType: item.foodType || "veg",
      prepTimeMinutes:
        item.prepTimeMinutes != null ? String(item.prepTimeMinutes) : "",
      available: item.available,
      scheduleEnabled: !!item.scheduleEnabled,
      availableFrom: item.availableFrom || "11:00",
      availableTo: item.availableTo || "15:00",
      jainAvailable: !!item.jainAvailable,
      jainOnly: !!item.jainOnly,
      enableSpiceLevel: !!item.enableSpiceLevel,
      enableCookingRequest: item.enableCookingRequest !== false,
      addOnsText: (item.addOns || [])
        .map((a) => `${a.label}:${a.priceDelta || 0}`)
        .join(", "),
      variantsText: (item.variants || [])
        .map((v) => `${v.label}:${v.priceDelta || 0}`)
        .join(", "),
      tagsText: (item.tags || []).join(", "),
    });
    setShowItemForm(true);
  }

  function openCreateCat() {
    setEditingCat(null);
    setCatForm({
      name: "",
      icon: "",
      scheduleEnabled: false,
      availableFrom: "11:00",
      availableTo: "15:00",
    });
    setShowCatForm(true);
  }

  function openEditCat(cat: MenuCategory) {
    setEditingCat(cat);
    setCatForm({
      name: cat.name,
      icon: cat.icon || "",
      scheduleEnabled: !!cat.scheduleEnabled,
      availableFrom: cat.availableFrom || "11:00",
      availableTo: cat.availableTo || "15:00",
    });
    setShowCatForm(true);
  }

  return (
    <div className="space-y-4">
      <PageHeader
        title="Menu"
        description={`${items?.length ?? 0} products · ${categories?.length ?? 0} categories`}
        actions={
          canManage ? (
            <div className="flex gap-2">
              <Button size="sm" variant="outline" asChild>
                <Link href="/menu/bulk-import">
                  <Upload className="h-4 w-4" /> Bulk Import
                </Link>
              </Button>
              <Button size="sm" variant="outline" onClick={openCreateCat}>
                <FolderOpen className="h-4 w-4" /> Category
              </Button>
              <Button
                size="sm"
                onClick={() => {
                  setEditingItem(null);
                  setItemForm(emptyItemForm);
                  setShowItemForm(true);
                }}
              >
                <Plus className="h-4 w-4" /> Add item
              </Button>
            </div>
          ) : undefined
        }
      />

      <Tabs defaultValue="items">
        <TabsList>
          <TabsTrigger value="items">Products</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
        </TabsList>

        {/* ── Categories tab ─────────────────────────────────────── */}
        <TabsContent value="categories" className="space-y-4">
          {canManage && (
            <div className="flex justify-end">
              <Button size="sm" onClick={openCreateCat}>
                <Plus className="h-4 w-4" /> New category
              </Button>
            </div>
          )}

          {catLoading ? (
            <TableSkeleton rows={4} cols={4} />
          ) : !categories?.length ? (
            <EmptyState
              icon={FolderOpen}
              title="No categories"
              description="Create categories to organize your menu items"
              action={
                canManage ? (
                  <Button size="sm" onClick={openCreateCat}>
                    <Plus className="h-4 w-4" /> Create category
                  </Button>
                ) : undefined
              }
            />
          ) : (
            <Card>
              <CardContent className="p-0">
                <div className="table-scroll table-sticky">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-muted/40 text-left text-muted-foreground">
                        <th className="px-4 py-3 font-medium">Name</th>
                        <th className="px-4 py-3 font-medium">Icon</th>
                        <th className="px-4 py-3 font-medium">Items</th>
                        <th className="px-4 py-3 font-medium">Schedule</th>
                        <th className="px-4 py-3 font-medium">ID</th>
                        {canManage && (
                          <th className="px-4 py-3 font-medium">Actions</th>
                        )}
                      </tr>
                    </thead>
                    <tbody>
                      {(categories || []).map((c) => (
                        <tr key={c.id} className="border-b border-border/50">
                          <td className="px-4 py-3 font-medium">{c.name}</td>
                          <td className="px-4 py-3 text-lg">{c.icon || "—"}</td>
                          <td className="px-4 py-3">
                            <Badge variant="secondary">
                              {itemCountByCat[c.id] ?? 0}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">
                            {c.scheduleEnabled && c.availableFrom && c.availableTo
                              ? `${c.availableFrom}–${c.availableTo}`
                              : "All day"}
                          </td>
                          <td className="px-4 py-3 font-mono text-xs text-muted-foreground">
                            {c.id}
                          </td>
                          {canManage && (
                            <td className="px-4 py-3">
                              <div className="flex gap-1">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => openEditCat(c)}
                                >
                                  <Pencil className="h-3.5 w-3.5" /> Edit
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="text-destructive"
                                  onClick={() => setDeleteCatId(c.id)}
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ── Products tab ───────────────────────────────────────── */}
        <TabsContent value="items" className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <div className="relative min-w-[180px] max-w-xs flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search menu…"
                className="h-9 pl-9"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
              />
            </div>
            <Select
              className="h-9 w-40"
              value={catFilter}
              onChange={(e) => {
                setCatFilter(e.target.value);
                setPage(1);
              }}
            >
              <option value="">All categories</option>
              {(categories || []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </Select>
            <Select
              className="h-9 w-36"
              value={String(pageSize)}
              onChange={(e) => {
                setPageSize(Number(e.target.value) as typeof pageSize);
                setPage(1);
              }}
              aria-label="Rows per page"
            >
              {PAGE_SIZE_OPTIONS.map((n) => (
                <option key={n} value={n}>
                  {n} / page
                </option>
              ))}
            </Select>
          </div>

          <Card>
            <CardContent className="p-0">
              {isLoading ? (
                <TableSkeleton rows={5} cols={6} />
              ) : filtered.length === 0 ? (
                <EmptyState
                  title="No menu items"
                  description="Add products under a category to build your menu"
                />
              ) : (
                <div className="table-scroll table-sticky">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-muted/40 text-left text-muted-foreground">
                        <th className="px-4 py-3 font-medium">Item</th>
                        <th className="px-4 py-3 font-medium">Category</th>
                        <th className="px-4 py-3 font-medium">Price</th>
                        <th className="px-4 py-3 font-medium">Type</th>
                        <th className="px-4 py-3 font-medium">Status</th>
                        <th className="px-4 py-3 font-medium">Schedule</th>
                        <th className="px-4 py-3 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pagedItems.map((item) => (
                        <tr key={item.id} className="border-b border-border/50">
                          <td className="px-4 py-3">
                            <p className="font-medium">{item.name}</p>
                            <p className="line-clamp-1 text-xs text-muted-foreground">
                              {item.description}
                            </p>
                          </td>
                          <td className="px-4 py-3 text-muted-foreground">
                            {catMap[item.categoryId] || item.categoryId}
                          </td>
                          <td className="px-4 py-3 font-semibold">
                            {formatCurrency(item.price)}
                          </td>
                          <td className="px-4 py-3">
                            <Badge
                              variant="outline"
                              className="text-[10px] capitalize"
                            >
                              {item.foodType || (item.isVeg ? "veg" : "—")}
                            </Badge>
                          </td>
                          <td className="px-4 py-3">
                            <Badge
                              variant={item.available ? "success" : "secondary"}
                            >
                              {item.available ? "Available" : "Hidden"}
                            </Badge>
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground">
                            {item.scheduleEnabled && item.availableFrom && item.availableTo
                              ? `${item.availableFrom}–${item.availableTo}`
                              : "All day"}
                          </td>
                          <td className="px-4 py-3">
                            {canManage && (
                              <div className="flex gap-1">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() =>
                                    toggleMut.mutate({
                                      id: item.id,
                                      available: !item.available,
                                    })
                                  }
                                >
                                  {item.available ? "Hide" : "Show"}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => openEditItem(item)}
                                >
                                  <Pencil className="h-3.5 w-3.5" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="text-destructive"
                                  onClick={() => setDeleteItemId(item.id)}
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              {filtered.length > 0 && (
                <div className="border-t bg-muted/20 px-3">
                  <TablePagination
                    meta={{
                      page: safePage,
                      pageSize,
                      total: filtered.length,
                      totalPages,
                    }}
                    onPageChange={(p) => setPage(p)}
                    onPageSizeChange={(size) => {
                      setPageSize(size as typeof pageSize);
                      setPage(1);
                    }}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Category create / edit dialog */}
      <Dialog open={showCatForm} onOpenChange={setShowCatForm}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingCat ? "Edit category" : "New category"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label>Name</Label>
              <Input
                placeholder="e.g. Starters, Main Course, Beverages"
                value={catForm.name}
                onChange={(e) => setCatForm({ ...catForm, name: e.target.value })}
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label>Icon (optional emoji)</Label>
              <Input
                placeholder="e.g. 🥗 🍕 🥤"
                value={catForm.icon}
                onChange={(e) => setCatForm({ ...catForm, icon: e.target.value })}
                maxLength={8}
              />
            </div>
            <div className="rounded-lg border border-border/60 bg-muted/30 p-3 space-y-3">
              <label className="flex items-center gap-2 text-sm font-medium cursor-pointer">
                <input
                  type="checkbox"
                  className="h-4 w-4 rounded border-input"
                  checked={catForm.scheduleEnabled}
                  onChange={(e) =>
                    setCatForm({ ...catForm, scheduleEnabled: e.target.checked })
                  }
                />
                Limit category to time window (e.g. Lunch 11:00–15:00)
              </label>
              {catForm.scheduleEnabled && (
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label>Available from</Label>
                    <Input
                      type="time"
                      value={catForm.availableFrom}
                      onChange={(e) =>
                        setCatForm({ ...catForm, availableFrom: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Available until</Label>
                    <Input
                      type="time"
                      value={catForm.availableTo}
                      onChange={(e) =>
                        setCatForm({ ...catForm, availableTo: e.target.value })
                      }
                    />
                  </div>
                  <p className="sm:col-span-2 text-xs text-muted-foreground">
                    All items in this category can only be ordered during this window (unless an item has its own tighter schedule). Overnight windows are supported.
                  </p>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCatForm(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => saveCatMut.mutate()}
              disabled={!catForm.name.trim() || saveCatMut.isPending}
            >
              {saveCatMut.isPending && (
                <Loader2 className="h-4 w-4 animate-spin" />
              )}
              {editingCat ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Menu item create / edit dialog */}
      <Dialog open={showItemForm} onOpenChange={setShowItemForm}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? "Edit item" : "Add menu item"}
            </DialogTitle>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Name</Label>
              <Input
                value={itemForm.name}
                onChange={(e) =>
                  setItemForm({ ...itemForm, name: e.target.value })
                }
              />
            </div>
            <div className="space-y-1.5">
              <Label>Price</Label>
              <Input
                type="number"
                value={itemForm.price}
                onChange={(e) =>
                  setItemForm({ ...itemForm, price: e.target.value })
                }
              />
            </div>
            <div className="space-y-1.5">
              <Label>Cost price</Label>
              <Input
                type="number"
                value={itemForm.costPrice}
                onChange={(e) =>
                  setItemForm({ ...itemForm, costPrice: e.target.value })
                }
              />
            </div>
            <div className="space-y-1.5">
              <Label>Category</Label>
              <Select
                value={itemForm.categoryId}
                onChange={(e) =>
                  setItemForm({ ...itemForm, categoryId: e.target.value })
                }
              >
                <option value="">Select</option>
                {(categories || []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.icon ? `${c.icon} ` : ""}
                    {c.name}
                  </option>
                ))}
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Food type</Label>
              <Select
                value={itemForm.foodType}
                onChange={(e) =>
                  setItemForm({ ...itemForm, foodType: e.target.value })
                }
              >
                <option value="veg">Veg</option>
                <option value="non-veg">Non-veg</option>
                <option value="egg">Egg</option>
                <option value="other">Other</option>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Prep time (min)</Label>
              <Input
                type="number"
                value={itemForm.prepTimeMinutes}
                onChange={(e) =>
                  setItemForm({ ...itemForm, prepTimeMinutes: e.target.value })
                }
              />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Description</Label>
              <Textarea
                value={itemForm.description}
                onChange={(e) =>
                  setItemForm({ ...itemForm, description: e.target.value })
                }
              />
            </div>
            <div className="sm:col-span-2 rounded-lg border border-border/60 bg-muted/30 p-3 space-y-3">
              <p className="text-sm font-semibold">Customization (customer app)</p>
              <div className="grid gap-2 sm:grid-cols-2">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-input"
                    checked={itemForm.jainAvailable}
                    onChange={(e) =>
                      setItemForm({ ...itemForm, jainAvailable: e.target.checked })
                    }
                  />
                  Jain available
                </label>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-input"
                    checked={itemForm.jainOnly}
                    onChange={(e) =>
                      setItemForm({ ...itemForm, jainOnly: e.target.checked })
                    }
                  />
                  Jain only
                </label>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-input"
                    checked={itemForm.enableSpiceLevel}
                    onChange={(e) =>
                      setItemForm({ ...itemForm, enableSpiceLevel: e.target.checked })
                    }
                  />
                  Spice level picker
                </label>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input
                    type="checkbox"
                    className="h-4 w-4 rounded border-input"
                    checked={itemForm.enableCookingRequest}
                    onChange={(e) =>
                      setItemForm({
                        ...itemForm,
                        enableCookingRequest: e.target.checked,
                      })
                    }
                  />
                  Cooking request
                </label>
              </div>
              <div className="space-y-1.5">
                <Label>Variants (label:priceDelta, comma-separated)</Label>
                <Input
                  value={itemForm.variantsText}
                  onChange={(e) =>
                    setItemForm({ ...itemForm, variantsText: e.target.value })
                  }
                  placeholder="Half:0, Full:50"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Add-ons (label:price, comma-separated)</Label>
                <Input
                  value={itemForm.addOnsText}
                  onChange={(e) =>
                    setItemForm({ ...itemForm, addOnsText: e.target.value })
                  }
                  placeholder="Extra Cheese:40, Extra Paneer:60"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Tags (comma-separated)</Label>
                <Input
                  value={itemForm.tagsText}
                  onChange={(e) =>
                    setItemForm({ ...itemForm, tagsText: e.target.value })
                  }
                  placeholder="bestseller, spicy, recommended"
                />
              </div>
            </div>

            <div className="sm:col-span-2 rounded-lg border border-border/60 bg-muted/30 p-3 space-y-3">
              <label className="flex items-center gap-2 text-sm font-medium cursor-pointer">
                <input
                  type="checkbox"
                  className="h-4 w-4 rounded border-input"
                  checked={itemForm.scheduleEnabled}
                  onChange={(e) =>
                    setItemForm({ ...itemForm, scheduleEnabled: e.target.checked })
                  }
                />
                Limit to time window (e.g. Thali 11:00–15:00)
              </label>
              {itemForm.scheduleEnabled && (
                <div className="grid gap-3 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label>Available from</Label>
                    <Input
                      type="time"
                      value={itemForm.availableFrom}
                      onChange={(e) =>
                        setItemForm({ ...itemForm, availableFrom: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Available until</Label>
                    <Input
                      type="time"
                      value={itemForm.availableTo}
                      onChange={(e) =>
                        setItemForm({ ...itemForm, availableTo: e.target.value })
                      }
                    />
                  </div>
                  <p className="sm:col-span-2 text-xs text-muted-foreground">
                    Outside this window, customers cannot order this item. Overnight windows (e.g. 22:00–02:00) are supported.
                  </p>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowItemForm(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => saveItemMut.mutate()}
              disabled={
                !itemForm.name || !itemForm.price || saveItemMut.isPending
              }
            >
              {saveItemMut.isPending && (
                <Loader2 className="h-4 w-4 animate-spin" />
              )}
              {editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteItemId}
        onOpenChange={(o) => !o && setDeleteItemId(null)}
        title="Delete menu item?"
        description="This removes the item from your menu permanently."
        confirmLabel="Delete"
        variant="destructive"
        loading={delItemMut.isPending}
        onConfirm={() => deleteItemId && delItemMut.mutate(deleteItemId)}
      />

      <ConfirmDialog
        open={!!deleteCatId}
        onOpenChange={(o) => !o && setDeleteCatId(null)}
        title="Delete category?"
        description="Items in this category may become uncategorized. This cannot be undone."
        confirmLabel="Delete category"
        variant="destructive"
        loading={delCatMut.isPending}
        onConfirm={() => deleteCatId && delCatMut.mutate(deleteCatId)}
      />
    </div>
  );
}
