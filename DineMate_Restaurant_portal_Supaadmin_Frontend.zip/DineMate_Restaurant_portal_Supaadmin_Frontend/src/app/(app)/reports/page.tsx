"use client";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  getDailyReport, getMonthlyReport, getWeeklyReport, getYearlyReport, getItemsReport,
} from "@/lib/api/restaurant";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PageHeader } from "@/components/shared/page-header";
import { formatCurrency, formatNumber } from "@/lib/utils/format";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar,
} from "recharts";

function StatGrid({ data }: { data: Record<string, number | string | undefined> }) {
  const fields = [
    ["Net sales", data.netSales],
    ["Gross sales", data.grossSales],
    ["Tax", data.taxTotal],
    ["Discounts", data.discountTotal],
    ["Orders", data.orderCount],
    ["Items sold", data.itemsSold],
    ["COGS", data.cogsTotal],
    ["Gross profit", data.grossProfit],
  ];
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {fields.map(([label, val]) => (
        <Card key={String(label)} className="card-interactive">
          <CardContent className="flex min-h-[88px] flex-col justify-center gap-2 py-5">
            <p className="text-xs font-medium text-muted-foreground leading-none">{label}</p>
            <p className="text-xl font-bold tracking-tight leading-none">
              {typeof val === "number"
                ? label === "Orders" || label === "Items sold"
                  ? formatNumber(val)
                  : formatCurrency(val)
                : "—"}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export default function ReportsPage() {
  const today = new Date().toISOString().slice(0, 10);
  const [date, setDate] = useState(today);
  const [month, setMonth] = useState(today.slice(0, 7));
  const [year, setYear] = useState(today.slice(0, 4));

  const { data: daily, isLoading: dLoad } = useQuery({
    queryKey: ["report-daily", date],
    queryFn: () => getDailyReport({ date }),
  });
  const { data: monthly, isLoading: mLoad } = useQuery({
    queryKey: ["report-monthly", month],
    queryFn: () => getMonthlyReport({ month }),
  });
  const { data: yearly } = useQuery({
    queryKey: ["report-yearly", year],
    queryFn: () => getYearlyReport({ year }),
  });
  const { data: items } = useQuery({
    queryKey: ["report-items"],
    queryFn: () => getItemsReport({ limit: 10 }),
  });
  const { data: range } = useQuery({
    queryKey: ["report-range"],
    queryFn: async () => {
      const to = new Date();
      const from = new Date();
      from.setDate(from.getDate() - 29);
      return getDailyReport({ from: from.toISOString().slice(0, 10), to: to.toISOString().slice(0, 10) });
    },
  });

  const chartDays = (range?.days || []).map((d) => ({
    date: d.dateKey?.slice(5),
    revenue: d.netSales || 0,
    orders: d.orderCount || 0,
  }));

  const bestSelling = (items?.bestSelling || []) as Array<{ name?: string; quantity?: number; revenue?: number }>;

  return (
    <div className="space-y-6">
      <PageHeader title="Reports & analytics" description="Sales, items, and period performance" />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">30-day revenue</CardTitle>
          <CardDescription>Net sales trend</CardDescription>
        </CardHeader>
        <CardContent className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartDays}>
              <defs>
                <linearGradient id="rGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(221 65% 32%)" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="hsl(221 65% 32%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: 12, background: "hsl(var(--card))" }} formatter={(v: number) => formatCurrency(v)} />
              <Area type="monotone" dataKey="revenue" stroke="hsl(221 65% 32%)" fill="url(#rGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Tabs defaultValue="daily">
        <TabsList>
          <TabsTrigger value="daily">Daily</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
          <TabsTrigger value="yearly">Yearly</TabsTrigger>
          <TabsTrigger value="items">Items</TabsTrigger>
        </TabsList>
        <TabsContent value="daily" className="space-y-4">
          <Input type="date" className="w-44" value={date} onChange={(e) => setDate(e.target.value)} />
          {dLoad ? <Skeleton className="h-32" /> : <StatGrid data={(daily?.day || {}) as Record<string, number>} />}
        </TabsContent>
        <TabsContent value="monthly" className="space-y-4">
          <Input type="month" className="w-44" value={month} onChange={(e) => setMonth(e.target.value)} />
          {mLoad ? <Skeleton className="h-32" /> : <StatGrid data={(monthly?.month || {}) as Record<string, number>} />}
        </TabsContent>
        <TabsContent value="yearly" className="space-y-4">
          <Input type="number" className="w-32" value={year} onChange={(e) => setYear(e.target.value)} />
          <StatGrid data={(yearly?.year || {}) as Record<string, number>} />
        </TabsContent>
        <TabsContent value="items" className="space-y-4">
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {bestSelling.map((item, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <p className="font-medium text-sm">{item.name || `Item ${i + 1}`}</p>
                  <p className="text-xs text-muted-foreground">
                    {item.quantity != null ? `${item.quantity} sold` : ""}
                    {item.revenue != null ? ` · ${formatCurrency(item.revenue)}` : ""}
                  </p>
                </CardContent>
              </Card>
            ))}
            {!bestSelling.length && <p className="text-sm text-muted-foreground col-span-full py-8 text-center">No item sales data yet</p>}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
