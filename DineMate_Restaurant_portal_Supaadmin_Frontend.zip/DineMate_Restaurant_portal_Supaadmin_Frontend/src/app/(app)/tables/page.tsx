"use client";
import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  listTables, createTable, updateTable, deleteTable, getTableQr, regenerateTableQr,
} from "@/lib/api/restaurant";
import { PageLoader } from "@/components/shared/loaders";
import { tableSchema, idParamSchema } from "@/lib/security/schemas";
import { API_URL, getErrorMessage } from "@/lib/api/client";
import { useAuthStore } from "@/lib/stores/auth-store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { QrPreviewCard, useQrDataUrl } from "@/components/qr/qr-preview-card";
import {
  defaultQrStyle, loadQrStyle, saveQrStyle, type QrStyleConfig,
} from "@/lib/qr-style";
import { toast } from "sonner";
import {
  Plus, QrCode, Download, Copy, Loader2, Armchair, Palette, Printer, Settings2, RefreshCw,
} from "lucide-react";
import { motion } from "framer-motion";

type QrModal = {
  tableId: string;
  tableNumber: number;
  url: string;
};

export default function TablesPage() {
  const qc = useQueryClient();
  const restaurant = useAuthStore((s) => s.restaurant);
  const { data: tables, isLoading } = useQuery({ queryKey: ["tables"], queryFn: listTables });
  const [number, setNumber] = useState("");
  const [capacity, setCapacity] = useState("4");
  const [qr, setQr] = useState<QrModal | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [qrBusy, setQrBusy] = useState(false);
  const [qrRefresh, setQrRefresh] = useState(0);
  const [style, setStyle] = useState<QrStyleConfig>(defaultQrStyle);
  const [styleReady, setStyleReady] = useState(false);

  useEffect(() => {
    setStyle(loadQrStyle());
    setStyleReady(true);
  }, []);

  function patchStyle(partial: Partial<QrStyleConfig>) {
    setStyle((s) => {
      const next = { ...s, ...partial };
      saveQrStyle(next);
      return next;
    });
  }

  const { dataUrl, error: qrError } = useQrDataUrl(qr?.url, style, qr?.tableId, qrRefresh > 0);

  const logoSrc = restaurant?.logoUrl
    ? restaurant.logoUrl.startsWith("http")
      ? restaurant.logoUrl
      : `${API_URL}${restaurant.logoUrl}`
    : null;

  const createMut = useMutation({
    mutationFn: async () => {
      const parsed = tableSchema.safeParse({ number, capacity: capacity || "4" });
      if (!parsed.success) throw new Error(parsed.error.errors[0]?.message || "Invalid table");
      return createTable(parsed.data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tables"] });
      setNumber("");
      toast.success("Table added");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const statusMut = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      updateTable(id, { status } as never),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["tables"] }),
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const delMut = useMutation({
    mutationFn: deleteTable,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tables"] });
      setDeleteId(null);
      toast.success("Deleted");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  async function openQr(tableId: string, tableNumber: number) {
    setQrBusy(true);
    try {
      const d = await getTableQr(tableId);
      setQr({ tableId, tableNumber, url: d.targetUrl });
    } catch (e) {
      toast.error(getErrorMessage(e));
    } finally {
      setQrBusy(false);
    }
  }

  async function regenerateQr() {
    if (!qr?.tableId) return;
    setQrBusy(true);
    try {
      // Prefer POST regenerate endpoint; fall back to GET ?regenerate=1
      let d;
      try {
        d = await regenerateTableQr(qr.tableId);
      } catch {
        d = await getTableQr(qr.tableId, true);
      }
      setQr({
        tableId: qr.tableId,
        tableNumber: qr.tableNumber,
        url: d.targetUrl || d.encryptedUrl || d.plainUrl || qr.url,
      });
      setQrRefresh((n) => n + 1);
      toast.success("QR regenerated with encrypted link");
    } catch (e) {
      toast.error(getErrorMessage(e));
    } finally {
      setQrBusy(false);
    }
  }

  function downloadPng() {
    if (!dataUrl || !qr) {
      toast.error("QR not ready");
      return;
    }
    // High-res branded card (2x for retina)
    const scale = 3;
    const w = 420;
    const h = 560;
    const canvas = document.createElement("canvas");
    canvas.width = w * scale;
    canvas.height = h * scale;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(scale, scale);

    // Card background
    ctx.fillStyle = style.cardBg || "#ffffff";
    roundRect(ctx, 0, 0, w, h, style.borderRadius || 24);
    ctx.fill();

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      let y = 40;
      ctx.textAlign = "center";
      ctx.textBaseline = "top";

      // Logo placeholder spacing if shown
      if (style.showLogo && logoSrc) {
        // logo drawn async below — reserve space
        y += 8;
      }

      const drawTextBlock = () => {
        if (style.showRestaurantName && restaurant?.name) {
          ctx.fillStyle = style.textColor || "#111";
          ctx.font = "700 18px system-ui, -apple-system, sans-serif";
          ctx.fillText(restaurant.name, w / 2, y);
          y += 28;
        }
        if (style.showTableLabel) {
          ctx.fillStyle = style.accentColor || "#1d4ed8";
          ctx.font = "800 36px system-ui, -apple-system, sans-serif";
          ctx.fillText(`Table ${qr.tableNumber}`, w / 2, y);
          y += 48;
        }

        // QR frame
        const qrBox = Math.min(style.qrSize || 240, 280);
        const pad = 16;
        const qx = (w - qrBox) / 2;
        ctx.fillStyle = style.bgColor || "#ffffff";
        roundRect(ctx, qx - pad, y - pad, qrBox + pad * 2, qrBox + pad * 2, 16);
        ctx.fill();
        // subtle border
        ctx.strokeStyle = "rgba(0,0,0,0.08)";
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.drawImage(img, qx, y, qrBox, qrBox);
        y += qrBox + pad + 20;

        if (style.showAddress && restaurant?.address) {
          ctx.fillStyle = style.textColor || "#111";
          ctx.globalAlpha = 0.65;
          ctx.font = "500 12px system-ui, sans-serif";
          const lines = wrapText(ctx, restaurant.address, w - 64);
          for (const line of lines.slice(0, 3)) {
            ctx.fillText(line, w / 2, y);
            y += 16;
          }
          ctx.globalAlpha = 1;
          y += 8;
        }

        if (style.showWelcome && style.welcomeMessage) {
          ctx.fillStyle = style.textColor || "#111";
          ctx.globalAlpha = 0.75;
          ctx.font = "600 14px system-ui, sans-serif";
          ctx.fillText(style.welcomeMessage, w / 2, y);
          ctx.globalAlpha = 1;
        }

        const a = document.createElement("a");
        a.href = canvas.toDataURL("image/png");
        a.download = `table-${qr.tableNumber}-qr.png`;
        a.click();
        toast.success("Card PNG downloaded");
      };

      if (style.showLogo && logoSrc) {
        const logo = new Image();
        logo.crossOrigin = "anonymous";
        logo.onload = () => {
          const s = 56;
          ctx.save();
          roundRect(ctx, (w - s) / 2, y, s, s, 12);
          ctx.clip();
          ctx.drawImage(logo, (w - s) / 2, y, s, s);
          ctx.restore();
          y += s + 16;
          drawTextBlock();
        };
        logo.onerror = () => drawTextBlock();
        logo.src = logoSrc;
      } else {
        drawTextBlock();
      }
    };
    img.onerror = () => toast.error("Could not render QR image");
    img.src = dataUrl;
  }

  function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
    const words = text.split(/\s+/);
    const lines: string[] = [];
    let line = "";
    for (const word of words) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width > maxWidth && line) {
        lines.push(line);
        line = word;
      } else {
        line = test;
      }
    }
    if (line) lines.push(line);
    return lines;
  }

  function downloadRawPng() {
    if (!dataUrl || !qr) return;
    const a = document.createElement("a");
    a.href = dataUrl;
    a.download = `table-${qr.tableNumber}-qr-raw.png`;
    a.click();
  }

  function printCard() {
    const node = document.getElementById("qr-print-root");
    if (!node) {
      toast.error("Nothing to print");
      return;
    }
    const win = window.open("", "_blank", "width=520,height=720");
    if (!win) {
      toast.error("Pop-up blocked — allow pop-ups for this site");
      return;
    }
    const tableNum = Number(qr?.tableNumber) || "";
    const doc = win.document;
    doc.open();
    doc.write(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>QR Table ${tableNum}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    @page {
      size: 105mm 148mm; /* A6 — ideal table-tent card */
      margin: 8mm;
    }
    html, body {
      width: 100%;
      height: 100%;
      background: #fff;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    body {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
    }
    #qr-print-root {
      width: 100%;
      display: flex;
      justify-content: center;
    }
    .qr-table-card {
      width: 88mm !important;
      max-width: 88mm !important;
      padding: 10mm 8mm !important;
      border-radius: 6mm !important;
      box-shadow: none !important;
    }
    .qr-card-name { font-size: 14pt !important; }
    .qr-card-table { font-size: 22pt !important; margin-bottom: 6mm !important; }
    .qr-card-frame { padding: 3mm !important; }
    .qr-card-img {
      width: 52mm !important;
      height: 52mm !important;
      max-width: 52mm !important;
      max-height: 52mm !important;
    }
    .qr-card-logo {
      width: 14mm !important;
      height: 14mm !important;
    }
    .qr-card-welcome { font-size: 11pt !important; margin-top: 5mm !important; }
    .qr-card-address { font-size: 9pt !important; }
    @media print {
      body { min-height: auto; }
      .qr-table-card { break-inside: avoid; }
    }
  </style>
</head>
<body></body>
</html>`);
    doc.close();
    const body = doc.body;
    if (!body) {
      toast.error("Could not prepare print window");
      win.close();
      return;
    }
    body.appendChild(node.cloneNode(true));
    const imgs = Array.from(body.querySelectorAll("img"));
    const ready = imgs.length
      ? Promise.all(
          imgs.map(
            (img) =>
              img.complete
                ? Promise.resolve()
                : new Promise<void>((res) => {
                    img.onload = () => res();
                    img.onerror = () => res();
                  })
          )
        )
      : Promise.resolve();
    ready.then(() => {
      setTimeout(() => {
        win.focus();
        win.print();
      }, 200);
    });
  }

  function copyUrl() {
    if (!qr?.url) return;
    navigator.clipboard.writeText(qr.url).then(
      () => toast.success("Link copied"),
      () => toast.error("Could not copy")
    );
  }

  return (
    <div className="space-y-4">
      <PageHeader
        title="Tables & QR"
        description="Manage floor tables and customize print-ready QR codes"
      />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Add table</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Input
            placeholder="Table number"
            type="number"
            className="w-32"
            value={number}
            onChange={(e) => setNumber(e.target.value)}
          />
          <Input
            placeholder="Capacity"
            type="number"
            className="w-28"
            value={capacity}
            onChange={(e) => setCapacity(e.target.value)}
          />
          <Button
            size="sm"
            onClick={() => createMut.mutate()}
            disabled={!number || createMut.isPending}
          >
            {createMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Add
          </Button>
        </CardContent>
      </Card>

      {isLoading ? (
        <PageLoader label="Loading tables…" />
      ) : !tables?.length ? (
        <EmptyState
          icon={Armchair}
          title="No tables yet"
          description="Add your first table to generate QR codes for customers"
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {(tables || []).map((t, i) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
            >
              <Card className="group transition-shadow hover:shadow-md">
                <CardContent className="space-y-3 p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-2xl font-bold">T{t.number}</p>
                      <p className="text-xs text-muted-foreground">Seats {t.capacity}</p>
                    </div>
                    <Badge
                      variant={
                        t.status === "available"
                          ? "success"
                          : t.status === "occupied"
                            ? "warning"
                            : "secondary"
                      }
                    >
                      {t.status}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => statusMut.mutate({ id: t.id, status: "available" })}
                    >
                      Free
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => statusMut.mutate({ id: t.id, status: "occupied" })}
                    >
                      Occupy
                    </Button>
                    <Button
                      size="sm"
                      variant="secondary"
                      disabled={qrBusy}
                      onClick={() => openQr(t.id, t.number)}
                    >
                      <QrCode className="h-3.5 w-3.5" /> QR
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-destructive"
                      onClick={() => setDeleteId(t.id)}
                    >
                      Del
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Premium QR modal */}
      <Dialog open={!!qr} onOpenChange={(o) => { if (!o) { setQr(null); setQrRefresh(0); } }}>
        <DialogContent className="max-h-[92vh] max-w-3xl gap-0 overflow-hidden p-0">
          <DialogHeader className="border-b px-5 py-4">
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="h-5 w-5 text-primary" />
              QR — Table {qr?.tableNumber}
            </DialogTitle>
          </DialogHeader>

          <div className="grid max-h-[calc(92vh-4rem)] gap-0 overflow-y-auto lg:grid-cols-[1fr_280px]">
            {/* Live preview */}
            <div className="flex flex-col items-center justify-center bg-muted/30 p-6">
              {styleReady && (
                <div id="qr-print-root" className="w-full">
                  <QrPreviewCard
                    dataUrl={dataUrl}
                    tableNumber={qr?.tableNumber ?? 0}
                    restaurantName={restaurant?.name}
                    address={restaurant?.address}
                    logoSrc={logoSrc}
                    style={style}
                    error={qrError}
                  />
                </div>
              )}

              <div className="mt-5 flex flex-wrap justify-center gap-2">
                <Button
                  size="sm"
                  variant="default"
                  onClick={() => void regenerateQr()}
                  disabled={qrBusy || !qr?.tableId}
                >
                  {qrBusy ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <RefreshCw className="h-3.5 w-3.5" />
                  )}
                  Regenerate QR
                </Button>
                <Button size="sm" onClick={downloadPng} disabled={!dataUrl}>
                  <Download className="h-3.5 w-3.5" /> Card PNG
                </Button>
                <Button size="sm" variant="outline" onClick={downloadRawPng} disabled={!dataUrl}>
                  <Download className="h-3.5 w-3.5" /> QR only
                </Button>
                <Button size="sm" variant="outline" onClick={printCard}>
                  <Printer className="h-3.5 w-3.5" /> Print
                </Button>
                <Button size="sm" variant="outline" onClick={copyUrl}>
                  <Copy className="h-3.5 w-3.5" /> Copy link
                </Button>
              </div>

              <p className="mt-3 max-w-xs break-all text-center font-mono text-[10px] text-muted-foreground">
                {qr?.url}
              </p>
            </div>

            {/* Customization */}
            <div className="border-t border-border/60 bg-card p-4 lg:border-l lg:border-t-0">
              <div className="mb-3 flex items-center gap-2 text-sm font-semibold">
                <Palette className="h-4 w-4 text-primary" /> Customize
              </div>
              <Tabs defaultValue="colors">
                <TabsList className="mb-3 w-full">
                  <TabsTrigger value="colors" className="flex-1 text-xs">
                    Colors
                  </TabsTrigger>
                  <TabsTrigger value="layout" className="flex-1 text-xs">
                    Layout
                  </TabsTrigger>
                  <TabsTrigger value="content" className="flex-1 text-xs">
                    Content
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="colors" className="space-y-3">
                  <ColorField
                    label="QR dark"
                    value={style.fgColor}
                    onChange={(v) => patchStyle({ fgColor: v })}
                  />
                  <ColorField
                    label="QR light"
                    value={style.bgColor}
                    onChange={(v) => patchStyle({ bgColor: v })}
                  />
                  <ColorField
                    label="Accent"
                    value={style.accentColor}
                    onChange={(v) => patchStyle({ accentColor: v })}
                  />
                  <ColorField
                    label="Card background"
                    value={style.cardBg}
                    onChange={(v) => patchStyle({ cardBg: v })}
                  />
                  <ColorField
                    label="Text"
                    value={style.textColor}
                    onChange={(v) => patchStyle({ textColor: v })}
                  />
                </TabsContent>

                <TabsContent value="layout" className="space-y-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs">QR size ({style.qrSize}px)</Label>
                    <input
                      type="range"
                      min={140}
                      max={280}
                      value={style.qrSize}
                      onChange={(e) => patchStyle({ qrSize: Number(e.target.value) })}
                      className="w-full"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Corner radius ({style.borderRadius}px)</Label>
                    <input
                      type="range"
                      min={0}
                      max={32}
                      value={style.borderRadius}
                      onChange={(e) =>
                        patchStyle({ borderRadius: Number(e.target.value) })
                      }
                      className="w-full"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Frame style</Label>
                    <Select
                      value={style.frameStyle}
                      onChange={(e) =>
                        patchStyle({
                          frameStyle: e.target.value as QrStyleConfig["frameStyle"],
                        })
                      }
                    >
                      <option value="none">None</option>
                      <option value="simple">Simple</option>
                      <option value="double">Double ring</option>
                      <option value="dashed">Dashed</option>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">Error correction</Label>
                    <Select
                      value={style.errorCorrectionLevel}
                      onChange={(e) =>
                        patchStyle({
                          errorCorrectionLevel: e.target
                            .value as QrStyleConfig["errorCorrectionLevel"],
                        })
                      }
                    >
                      <option value="L">L — Low</option>
                      <option value="M">M — Medium</option>
                      <option value="Q">Q — Quartile</option>
                      <option value="H">H — High</option>
                    </Select>
                  </div>
                </TabsContent>

                <TabsContent value="content" className="space-y-3">
                  <ToggleRow
                    label="Restaurant name"
                    checked={style.showRestaurantName}
                    onChange={(v) => patchStyle({ showRestaurantName: v })}
                  />
                  <ToggleRow
                    label="Table number"
                    checked={style.showTableLabel}
                    onChange={(v) => patchStyle({ showTableLabel: v })}
                  />
                  <ToggleRow
                    label="Logo"
                    checked={style.showLogo}
                    onChange={(v) => patchStyle({ showLogo: v })}
                  />
                  <ToggleRow
                    label="Welcome message"
                    checked={style.showWelcome}
                    onChange={(v) => patchStyle({ showWelcome: v })}
                  />
                  <ToggleRow
                    label="Address"
                    checked={style.showAddress}
                    onChange={(v) => patchStyle({ showAddress: v })}
                  />
                  {style.showWelcome && (
                    <div className="space-y-1.5">
                      <Label className="text-xs">Welcome text</Label>
                      <Input
                        value={style.welcomeMessage}
                        onChange={(e) => patchStyle({ welcomeMessage: e.target.value })}
                      />
                    </div>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      setStyle(defaultQrStyle);
                      saveQrStyle(defaultQrStyle);
                      toast.success("Style reset");
                    }}
                  >
                    <Settings2 className="h-3.5 w-3.5" /> Reset defaults
                  </Button>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!deleteId}
        onOpenChange={(o) => !o && setDeleteId(null)}
        title="Delete table?"
        description="This removes the table and its QR association."
        confirmLabel="Delete"
        variant="destructive"
        loading={delMut.isPending}
        onConfirm={() => deleteId && delMut.mutate(deleteId)}
      />
    </div>
  );
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <Label className="text-xs">{label}</Label>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-8 w-10 cursor-pointer rounded border-0 bg-transparent"
        />
        <Input
          className="h-8 w-[88px] font-mono text-xs"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <Label className="text-xs">{label}</Label>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}
