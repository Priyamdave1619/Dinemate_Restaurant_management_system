"use client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getSettings, updateSettings } from "@/lib/api/restaurant";
import { useAuthStore } from "@/lib/stores/auth-store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { PageHeader } from "@/components/shared/page-header";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { settingsSchema } from "@/lib/security/schemas";
import { sanitizeText, sanitizeMultiline } from "@/lib/security/sanitize";
import { Loader2 } from "lucide-react";

export default function SettingsPage() {
  const user = useAuthStore((s) => s.user);
  const restaurant = useAuthStore((s) => s.restaurant);
  const qc = useQueryClient();
  const canEdit = user?.role === "owner";
  const { data: settings, isLoading } = useQuery({ queryKey: ["settings"], queryFn: getSettings });
  const [form, setForm] = useState({
    taxRatePercent: "5",
    restaurantName: "",
    currency: "INR",
    openingTime: "",
    closingTime: "",
    billPrefix: "",
    address: "",
    phone: "",
    foodLicence: "",
    gstin: "",
    baseUrl: "",
  });

  useEffect(() => {
    if (settings) {
      setForm({
        taxRatePercent: String(settings.taxRatePercent ?? 5),
        restaurantName: settings.restaurantName || "",
        currency: settings.currency || "INR",
        openingTime: settings.openingTime || "",
        closingTime: settings.closingTime || "",
        billPrefix: settings.billPrefix || "",
        address: settings.address || "",
        phone: settings.phone || "",
        foodLicence: settings.foodLicence || "",
        gstin: settings.gstin || "",
        baseUrl: settings.baseUrl || "",
      });
    }
  }, [settings]);

  const saveMut = useMutation({
    mutationFn: async () => {
      const parsed = settingsSchema.safeParse({
        taxRatePercent: form.taxRatePercent,
        restaurantName: form.restaurantName,
        address: form.address,
        phone: form.phone,
        foodLicence: form.foodLicence,
        gstin: form.gstin,
      });
      if (!parsed.success) {
        throw new Error(parsed.error.errors[0]?.message || "Invalid settings");
      }
      return updateSettings({
        ...form,
        ...parsed.data,
        taxRatePercent: Number(form.taxRatePercent),
      });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["settings"] });
      toast.success("Settings saved");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  if (isLoading) return <Skeleton className="h-48 w-full" />;

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <PageHeader title="Settings" description="Tax, branding, and operational preferences" />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Restaurant</CardTitle>
          <CardDescription>{restaurant?.id}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Status</span>
            <Badge variant="success">{restaurant?.status}</Badge>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Plan</span>
            <span>{restaurant?.planId}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Subscription</span>
            <span>{restaurant?.subscriptionStatus}</span>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Operational settings</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Display name</Label>
            <Input
              value={form.restaurantName}
              disabled={!canEdit}
              onChange={(e) => setForm({ ...form, restaurantName: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Tax rate %</Label>
            <Input
              type="number"
              value={form.taxRatePercent}
              disabled={!canEdit}
              onChange={(e) => setForm({ ...form, taxRatePercent: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Currency</Label>
            <Input
              value={form.currency}
              disabled={!canEdit}
              onChange={(e) => setForm({ ...form, currency: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Opening time</Label>
            <Input
              type="time"
              value={form.openingTime}
              disabled={!canEdit}
              onChange={(e) => setForm({ ...form, openingTime: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Closing time</Label>
            <Input
              type="time"
              value={form.closingTime}
              disabled={!canEdit}
              onChange={(e) => setForm({ ...form, closingTime: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Bill prefix</Label>
            <Input
              value={form.billPrefix}
              disabled={!canEdit}
              onChange={(e) => setForm({ ...form, billPrefix: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>GSTIN</Label>
            <Input
              value={form.gstin}
              disabled={!canEdit}
              onChange={(e) => setForm({ ...form, gstin: e.target.value })}
            />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Address</Label>
            <Input
              value={form.address}
              disabled={!canEdit}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              placeholder="Street, area, city"
            />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Phone (shown on bills)</Label>
            <Input
              type="tel"
              value={form.phone}
              disabled={!canEdit}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="e.g. +91 98765 43210"
            />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Food licence / FSSAI (shown on bills)</Label>
            <Input
              value={form.foodLicence}
              disabled={!canEdit}
              onChange={(e) => setForm({ ...form, foodLicence: e.target.value })}
              placeholder="e.g. 10012021000123"
            />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Customer app base URL</Label>
            <Input
              value={form.baseUrl}
              disabled={!canEdit}
              placeholder="https://order.yourdomain.com"
              onChange={(e) => setForm({ ...form, baseUrl: e.target.value })}
            />
          </div>
          {canEdit && (
            <div className="sm:col-span-2">
              <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>
                {saveMut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                Save changes
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
