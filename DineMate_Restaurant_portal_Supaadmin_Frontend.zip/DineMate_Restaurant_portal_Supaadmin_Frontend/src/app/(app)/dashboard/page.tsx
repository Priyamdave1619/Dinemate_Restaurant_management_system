"use client";
import { useQuery } from "@tanstack/react-query";
import {
  ShoppingCart, IndianRupee, Armchair, Users, TrendingUp, UtensilsCrossed,
  CheckCircle2, XCircle, Clock, Package,
} from "lucide-react";
import {
  getAnalytics, listOrders, listTables, listStaff, listMenu, listCategories, getDailyReport,
} from "@/lib/api/restaurant";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { StatCard } from "@/components/shared/stat-card";
import { StatCardSkeleton, ChartSkeleton } from "@/components/shared/loaders";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatNumber, relativeTime } from "@/lib/utils/format";
import { useAuthStore } from "@/lib/stores/auth-store";
import Link from "next/link";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar,
} from "recharts";
import { useMemo } from "react";

export default function DashboardPage() {
  const restaurant = useAuthStore((s) => s.restaurant);
  const { data: analytics, isLoading: aLoad } = useQuery({ queryKey: ["analytics"], queryFn: getAnalytics });
  const { data: ordersData } = useQuery({
    queryKey: ["orders-active"],
    queryFn: () => listOrders({ active: "1" }),
    refetchInterval: 15000,
  });
  const { data: tables } = useQuery({ queryKey: ["tables"], queryFn: listTables });
  const { data: staff } = useQuery({ queryKey: ["staff"], queryFn: listStaff });
  const { data: menu } = useQuery({ queryKey: ["menu"], queryFn: listMenu });
  const { data: categories } = useQuery({ queryKey: ["categories"], queryFn: listCategories });
  const { data: dailyRange } = useQuery({
    queryKey: ["daily-range"],
    queryFn: async () => {
      const to = new Date();
      const from = new Date();
      from.setDate(from.getDate() - 13);
      return getDailyReport({
        from: from.toISOString().slice(0, 10),
        to: to.toISOString().slice(0, 10),
      });
    },
  });

  const activeOrders = ordersData?.orders?.length ?? 0;
  const occupied = tables?.filter((t) => t.status === "occupied").length ?? 0;
  const available = tables?.filter((t) => t.status === "available").length ?? 0;

  const a = (analytics || {}) as Record<string, unknown>;
  const todayObj =
    a.today && typeof a.today === "object" ? (a.today as Record<string, unknown>) : ({} as Record<string, unknown>);
  const todayRevenue =
    Number(a.todayRevenue ?? todayObj["revenue"] ?? a.revenueToday ?? 0) || 0;
  const todayOrders =
    Number(a.todayOrders ?? todayObj["orders"] ?? 0) || activeOrders;
  const pending = ordersData?.orders?.filter((o) => ["pending", "confirmed"].includes(o.status)).length ?? 0;
  const preparing = ordersData?.orders?.filter((o) => o.status === "preparing").length ?? 0;
  const ready = ordersData?.orders?.filter((o) => o.status === "ready").length ?? 0;

  const chartData = useMemo(() => {
    const days = dailyRange?.days ?? [];
    if (days.length) {
      return days.map((d) => ({
        date: d.dateKey?.slice(5) || "",
        revenue: d.netSales || d.totalCollected || 0,
        orders: d.orderCount || 0,
      }));
    }
    return Array.from({ length: 7 }).map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return { date: d.toISOString().slice(5, 10), revenue: 0, orders: 0 };
    });
  }, [dailyRange]);

  const topItems = useMemo(() => {
    const best = (a.bestSelling || a.topItems || a.topSellingItems || []) as Array<{
      name?: string; quantity?: number; revenue?: number;
    }>;
    return best.slice(0, 5);
  }, [a]);

  const expiresAt = restaurant?.subscriptionExpiresAt
    ? new Date(restaurant.subscriptionExpiresAt)
    : null;
  const daysLeft = expiresAt
    ? Math.ceil((expiresAt.getTime() - Date.now()) / 86400000)
    : null;

  const stats = [
    { label: "Today's revenue", value: formatCurrency(todayRevenue), icon: IndianRupee, color: "text-emerald-500", bg: "bg-emerald-500/10", raw: true },
    { label: "Orders today", value: todayOrders, icon: ShoppingCart, color: "text-orange-500", bg: "bg-orange-500/10" },
    { label: "Active orders", value: activeOrders, icon: Clock, color: "text-blue-500", bg: "bg-blue-500/10" },
    { label: "Tables occupied", value: `${occupied}/${tables?.length ?? 0}`, icon: Armchair, color: "text-violet-500", bg: "bg-violet-500/10", raw: true },
    { label: "Menu items", value: menu?.length ?? 0, icon: UtensilsCrossed, color: "text-pink-500", bg: "bg-pink-500/10" },
    { label: "Categories", value: categories?.length ?? 0, icon: Package, color: "text-cyan-500", bg: "bg-cyan-500/10" },
    { label: "Staff", value: staff?.length ?? 0, icon: Users, color: "text-amber-500", bg: "bg-amber-500/10" },
    { label: "Available tables", value: available, icon: CheckCircle2, color: "text-green-500", bg: "bg-green-500/10" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="text-xl font-bold">{restaurant?.name || "Dashboard"}</h2>
          <div className="flex flex-wrap items-center gap-x-1.5 gap-y-1 text-sm text-muted-foreground">
            <span>
              Plan: <span className="font-medium text-foreground">{restaurant?.planId || "—"}</span>
            </span>
            <span>·</span>
            <span className="inline-flex items-center gap-1">
              Status:{" "}
              <Badge variant={restaurant?.status === "active" ? "success" : "warning"} className="text-[10px]">
                {restaurant?.status || "—"}
              </Badge>
            </span>
            {daysLeft != null && (
              <>
                <span>·</span>
                <span>
                  Sub:{" "}
                  <span className={daysLeft <= 5 ? "font-medium text-amber-600" : ""}>
                    {daysLeft < 0 ? "Expired" : `${daysLeft}d left`}
                  </span>
                </span>
              </>
            )}
          </div>
        </div>
        <div className="flex gap-2 text-xs">
          <Badge variant="secondary">{pending} pending</Badge>
          <Badge variant="secondary">{preparing} preparing</Badge>
          <Badge variant="secondary">{ready} ready</Badge>
        </div>
      </div>

      {aLoad && !analytics ? (
        <StatCardSkeleton count={8} />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((s, i) => (
            <StatCard
              key={s.label}
              label={s.label}
              value={s.raw ? s.value : formatNumber(s.value as number)}
              icon={s.icon}
              color={s.color}
              bg={s.bg}
              index={i}
            />
          ))}
        </div>
      )}

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Revenue trend</CardTitle>
            <CardDescription>Last 14 days net sales</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            {aLoad ? (
              <ChartSkeleton />
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(221 65% 32%)" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="hsl(221 65% 32%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis dataKey="date" tick={{ fontSize: 11 }} className="text-muted-foreground" />
                  <YAxis tick={{ fontSize: 11 }} className="text-muted-foreground" />
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }}
                    formatter={(v: number) => [formatCurrency(v), "Revenue"]}
                  />
                  <Area type="monotone" dataKey="revenue" stroke="hsl(221 65% 32%)" fill="url(#revGrad)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Orders volume</CardTitle>
            <CardDescription>Daily order count</CardDescription>
          </CardHeader>
          <CardContent className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }}
                />
                <Bar dataKey="orders" fill="hsl(221 65% 32%)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-base">Live orders</CardTitle>
              <CardDescription>Active billing queue</CardDescription>
            </div>
            <Link href="/orders" className="text-sm text-primary hover:underline">
              View all
            </Link>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {(ordersData?.orders || []).slice(0, 6).map((o) => (
                <div
                  key={o.id}
                  className="flex items-center justify-between rounded-lg border border-border/50 px-3 py-2.5 text-sm transition-colors hover:bg-muted/30"
                >
                  <div>
                    <p className="font-medium">Table {o.tableNumber}</p>
                    <p className="text-xs text-muted-foreground">
                      {o.items?.length} items · {relativeTime(o.placedAt)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{formatCurrency(o.total)}</p>
                    <Badge variant="secondary" className="text-[10px]">
                      {o.status}
                    </Badge>
                  </div>
                </div>
              ))}
              {!ordersData?.orders?.length && (
                <p className="py-8 text-center text-sm text-muted-foreground">No active orders</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Floor status</CardTitle>
            <CardDescription>Tables overview</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-2 sm:grid-cols-5">
              {(tables || []).map((t) => (
                <div
                  key={t.id}
                  className={`rounded-lg border p-3 text-center text-sm transition-colors ${
                    t.status === "occupied"
                      ? "border-orange-500/40 bg-orange-500/10"
                      : t.status === "cleaning"
                        ? "border-amber-500/40 bg-amber-500/10"
                        : t.status === "reserved"
                          ? "border-blue-500/40 bg-blue-500/10"
                          : "border-emerald-500/30 bg-emerald-500/5"
                  }`}
                >
                  <p className="font-bold">T{t.number}</p>
                  <p className="text-[10px] capitalize text-muted-foreground">{t.status}</p>
                </div>
              ))}
              {!tables?.length && (
                <p className="col-span-full py-8 text-center text-sm text-muted-foreground">
                  No tables configured
                </p>
              )}
            </div>
            <div className="mt-3 flex flex-wrap gap-3 text-xs text-muted-foreground">
              <span>{available} available</span>
              <span>{occupied} occupied</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {topItems.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" /> Top selling items
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
              {topItems.map((item, i) => (
                <div key={i} className="rounded-lg border border-border/50 px-3 py-2.5">
                  <p className="truncate text-sm font-medium">{item.name || `Item ${i + 1}`}</p>
                  <p className="text-xs text-muted-foreground">
                    {item.quantity != null ? `${item.quantity} sold` : ""}
                    {item.revenue != null ? ` · ${formatCurrency(item.revenue)}` : ""}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
