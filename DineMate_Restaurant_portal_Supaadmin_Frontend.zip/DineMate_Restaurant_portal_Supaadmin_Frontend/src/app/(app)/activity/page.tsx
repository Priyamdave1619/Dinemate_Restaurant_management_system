"use client";
import { useQuery } from "@tanstack/react-query";
import { listActivityLogs } from "@/lib/api/restaurant";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { relativeTime, formatDateTime } from "@/lib/utils/format";
import { Activity } from "lucide-react";

export default function ActivityPage() {
  const { data: logs, isLoading } = useQuery({
    queryKey: ["activity-logs"],
    queryFn: () => listActivityLogs(),
  });

  return (
    <div className="space-y-4">
      <PageHeader title="Activity log" description="Audit trail for this restaurant" />
      {isLoading ? (
        <Skeleton className="h-40" />
      ) : !logs?.length ? (
        <EmptyState icon={Activity} title="No activity yet" />
      ) : (
        <Card>
          <CardContent className="divide-y p-0">
            {logs.map((log, i) => (
              <div key={log.id || i} className="flex items-start justify-between gap-4 px-4 py-3 text-sm">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="outline" className="text-[10px]">{log.action}</Badge>
                    {log.entityType && <span className="text-xs text-muted-foreground">{log.entityType}</span>}
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {log.actorName || "System"}
                    {log.actorRole ? ` (${log.actorRole})` : ""}
                    {log.entityId ? ` · ${log.entityId}` : ""}
                  </p>
                </div>
                <div className="shrink-0 text-right text-xs text-muted-foreground">
                  <p>{relativeTime(log.createdAt)}</p>
                  <p className="opacity-70">{formatDateTime(log.createdAt)}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
