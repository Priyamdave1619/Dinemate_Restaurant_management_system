"use client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listPlans, createCheckout, verifyPayment, getRestaurantMe } from "@/lib/api/restaurant";
import { useAuthStore } from "@/lib/stores/auth-store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatDate } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { Check, CreditCard, Loader2, Sparkles } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { useEffect, useState } from "react";

declare global {
  interface Window {
    Razorpay?: new (options: Record<string, unknown>) => { open: () => void };
  }
}

function loadRazorpay(): Promise<boolean> {
  return new Promise((resolve) => {
    if (window.Razorpay) {
      resolve(true);
      return;
    }
    const s = document.createElement("script");
    s.src = "https://checkout.razorpay.com/v1/checkout.js";
    s.onload = () => resolve(true);
    s.onerror = () => resolve(false);
    document.body.appendChild(s);
  });
}

export default function SubscriptionPage() {
  const restaurant = useAuthStore((s) => s.restaurant);
  const setAuth = useAuthStore((s) => s.setAuth);
  const user = useAuthStore((s) => s.user);
  const accessToken = useAuthStore((s) => s.accessToken);
  const refreshToken = useAuthStore((s) => s.refreshToken);
  const qc = useQueryClient();
  const [paying, setPaying] = useState<string | null>(null);

  const { data: plans, isLoading } = useQuery({ queryKey: ["plans"], queryFn: listPlans });
  const { data: me } = useQuery({
    queryKey: ["restaurant-me"],
    queryFn: getRestaurantMe,
  });

  const r = me || restaurant;
  const expiresAt = r?.subscriptionExpiresAt ? new Date(r.subscriptionExpiresAt) : null;
  const daysLeft = expiresAt ? Math.ceil((expiresAt.getTime() - Date.now()) / 86400000) : null;
  const currentPlanId = r?.planId;

  async function handleUpgrade(planId: string) {
    setPaying(planId);
    try {
      const checkout = await createCheckout(planId);
      const ok = await loadRazorpay();
      if (!ok || !window.Razorpay) {
        toast.error("Payment gateway unavailable. Configure Razorpay on the backend.");
        return;
      }
      const rzp = new window.Razorpay({
        key: checkout.keyId,
        amount: checkout.amount,
        currency: checkout.currency || "INR",
        order_id: checkout.orderId,
        name: r?.name || "Restaurant",
        description: `Plan upgrade`,
        handler: async (response: {
          razorpay_order_id: string;
          razorpay_payment_id: string;
          razorpay_signature: string;
        }) => {
          try {
            await verifyPayment({
              razorpayOrderId: response.razorpay_order_id,
              razorpayPaymentId: response.razorpay_payment_id,
              razorpaySignature: response.razorpay_signature,
              planId,
            });
            toast.success("Payment successful — plan updated");
            const updated = await getRestaurantMe();
            if (user && accessToken && refreshToken) {
              setAuth({ user, restaurant: updated, accessToken, refreshToken });
            }
            qc.invalidateQueries({ queryKey: ["restaurant-me"] });
            qc.invalidateQueries({ queryKey: ["plans"] });
          } catch (e) {
            toast.error(getErrorMessage(e));
          }
        },
      });
      rzp.open();
    } catch (e) {
      toast.error(getErrorMessage(e));
    } finally {
      setPaying(null);
    }
  }

  const activePlans = (plans || []).filter((p) => p.active);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Subscription"
        description="Manage your plan, renew, or upgrade"
      />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Current subscription</CardTitle>
          <CardDescription>Restaurant ID: {r?.id}</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <p className="text-xs text-muted-foreground">Plan</p>
            <p className="mt-1 font-semibold">{currentPlanId || "—"}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Status</p>
            <Badge
              variant={r?.subscriptionStatus === "active" ? "success" : "warning"}
              className="mt-1"
            >
              {r?.subscriptionStatus || r?.status || "—"}
            </Badge>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Expires</p>
            <p className="mt-1 font-semibold">
              {expiresAt ? formatDate(expiresAt.toISOString()) : "—"}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Remaining</p>
            <p className={`mt-1 font-semibold ${daysLeft != null && daysLeft <= 5 ? "text-amber-600" : ""}`}>
              {daysLeft == null ? "—" : daysLeft < 0 ? "Expired" : `${daysLeft} days`}
            </p>
          </div>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {activePlans.map((plan) => {
            const isCurrent = plan.id === currentPlanId;
            return (
              <Card
                key={plan.id}
                className={isCurrent ? "border-primary shadow-md shadow-primary/10" : ""}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-lg">{plan.name}</CardTitle>
                    {isCurrent && <Badge>Current</Badge>}
                  </div>
                  <div className="mt-2">
                    <span className="text-3xl font-bold">{formatCurrency(plan.price)}</span>
                    <span className="text-sm text-muted-foreground"> / {plan.durationDays}d</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-emerald-500" /> {plan.productLimit} products
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-emerald-500" /> {plan.orderLimit} orders
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-emerald-500" /> {plan.userLimit} staff users
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-emerald-500" /> {plan.storageLimitMb} MB storage
                    </li>
                    {(plan.features || []).map((f) => (
                      <li key={f} className="flex items-center gap-2">
                        <Sparkles className="h-4 w-4 text-primary" /> {f}
                      </li>
                    ))}
                  </ul>
                  <Button
                    className="w-full"
                    variant={isCurrent ? "outline" : "default"}
                    disabled={paying === plan.id}
                    onClick={() => handleUpgrade(plan.id)}
                  >
                    {paying === plan.id ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <CreditCard className="h-4 w-4" />
                    )}
                    {isCurrent ? "Renew" : "Upgrade"}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
          {!activePlans.length && (
            <p className="col-span-full py-12 text-center text-muted-foreground">
              No plans available. Contact platform admin.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
