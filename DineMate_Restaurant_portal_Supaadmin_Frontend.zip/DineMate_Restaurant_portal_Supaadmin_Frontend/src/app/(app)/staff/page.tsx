"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listStaff, createStaff, updateStaff, deleteStaff } from "@/lib/api/restaurant";
import type { StaffUser } from "@/types";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { useAuthStore } from "@/lib/stores/auth-store";
import { Plus } from "lucide-react";
import { staffCreateSchema } from "@/lib/security/schemas";
import { DataTable, SortableHeader } from "@/components/data-table";
import { useDataTableState, useClientTable } from "@/hooks/use-data-table";
import { PageHeader } from "@/components/shared/page-header";

export default function StaffPage() {
  const qc = useQueryClient();
  const role = useAuthStore((s) => s.user?.role);
  const { data: users, isLoading } = useQuery({
    queryKey: ["staff"],
    queryFn: listStaff,
  });
  const [show, setShow] = useState(false);
  const [form, setForm] = useState({
    username: "",
    name: "",
    password: "",
    role: "waiter",
  });
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const tableState = useDataTableState();
  const table = useClientTable(users, {
    state: tableState,
    searchKeys: ["name", "username", "role"],
    filterFn: (u: StaffUser) => {
      if (roleFilter !== "all" && u.role !== roleFilter) return false;
      if (statusFilter === "active" && !u.active) return false;
      if (statusFilter === "inactive" && u.active) return false;
      return true;
    },
  });

  const createMut = useMutation({
    mutationFn: async () => {
      const parsed = staffCreateSchema.safeParse(form);
      if (!parsed.success) {
        throw new Error(parsed.error.errors[0]?.message || "Invalid input");
      }
      return createStaff(parsed.data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["staff"] });
      setShow(false);
      setForm({ username: "", name: "", password: "", role: "waiter" });
      toast.success("Staff created");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const toggleMut = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) =>
      updateStaff(id, { active }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["staff"] }),
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const delMut = useMutation({
    mutationFn: deleteStaff,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["staff"] });
      toast.success("Removed");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const hasFilters =
    !!tableState.search || roleFilter !== "all" || statusFilter !== "all";

  return (
    <div className="space-y-4">
      <PageHeader
        title="Staff"
        description="Manage waiters and managers"
        actions={
          <Button size="sm" onClick={() => setShow(true)}>
            <Plus className="h-4 w-4" /> Add staff
          </Button>
        }
      />

      {show && (
        <Card>
          <CardContent className="grid gap-3 p-4 sm:grid-cols-2">
            <Input
              placeholder="Name"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
            <Input
              placeholder="Username"
              value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })}
            />
            <Input
              type="password"
              placeholder="Password"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
            <select
              className="h-10 rounded-md border border-input bg-background px-3 text-sm"
              value={form.role}
              onChange={(e) => setForm({ ...form, role: e.target.value })}
            >
              <option value="waiter">Waiter</option>
              {role === "owner" && <option value="manager">Manager</option>}
            </select>
            <div className="flex gap-2 sm:col-span-2">
              <Button
                size="sm"
                onClick={() => createMut.mutate()}
                disabled={!form.username || !form.password || !form.name}
              >
                Create
              </Button>
              <Button size="sm" variant="outline" onClick={() => setShow(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <DataTable
        search={tableState.search}
        onSearchChange={tableState.setSearch}
        searchPlaceholder="Search name, username, role…"
        hasActiveFilters={hasFilters}
        onClearFilters={() => {
          tableState.resetFilters();
          setRoleFilter("all");
          setStatusFilter("all");
        }}
        toolbarExtra={
          <>
            <select
              className="h-9 rounded-md border border-input bg-background px-2 text-sm"
              value={roleFilter}
              onChange={(e) => {
                setRoleFilter(e.target.value);
                tableState.setPage(1);
              }}
            >
              <option value="all">All roles</option>
              <option value="manager">Manager</option>
              <option value="waiter">Waiter</option>
              <option value="owner">Owner</option>
            </select>
            <select
              className="h-9 rounded-md border border-input bg-background px-2 text-sm"
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                tableState.setPage(1);
              }}
            >
              <option value="all">All status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </>
        }
        page={table.page}
        pageSize={table.pageSize}
        total={table.total}
        totalPages={table.totalPages}
        from={table.from}
        to={table.to}
        onPageChange={tableState.setPage}
        onPageSizeChange={tableState.setPageSize}
        loading={isLoading}
        skeletonCols={5}
        emptyTitle="No staff found"
        emptyDescription="Add staff or adjust your search filters"
      >
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-muted/40 text-left">
              <th className="px-4 py-3">
                <SortableHeader
                  label="Name"
                  column="name"
                  sortBy={tableState.sortBy}
                  sortDir={tableState.sortDir}
                  onSort={tableState.toggleSort}
                />
              </th>
              <th className="px-4 py-3">
                <SortableHeader
                  label="Username"
                  column="username"
                  sortBy={tableState.sortBy}
                  sortDir={tableState.sortDir}
                  onSort={tableState.toggleSort}
                />
              </th>
              <th className="px-4 py-3">
                <SortableHeader
                  label="Role"
                  column="role"
                  sortBy={tableState.sortBy}
                  sortDir={tableState.sortDir}
                  onSort={tableState.toggleSort}
                />
              </th>
              <th className="px-4 py-3 font-medium text-muted-foreground">Status</th>
              <th className="px-4 py-3 font-medium text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {table.rows.map((u) => (
              <tr key={u.id} className="border-b border-border/50 hover:bg-muted/30">
                <td className="px-4 py-3 font-medium">{u.name}</td>
                <td className="px-4 py-3 text-muted-foreground">{u.username}</td>
                <td className="px-4 py-3">
                  <Badge variant="outline">{u.role}</Badge>
                </td>
                <td className="px-4 py-3">
                  <Badge variant={u.active ? "success" : "secondary"}>
                    {u.active ? "Active" : "Off"}
                  </Badge>
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1">
                    {u.role !== "owner" && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            toggleMut.mutate({ id: u.id, active: !u.active })
                          }
                        >
                          {u.active ? "Deactivate" : "Activate"}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-destructive"
                          onClick={() => {
                            if (confirm("Delete this staff member?")) delMut.mutate(u.id);
                          }}
                        >
                          Delete
                        </Button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </DataTable>
    </div>
  );
}
