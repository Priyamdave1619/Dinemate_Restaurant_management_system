"use client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getRestaurantMe, updateRestaurantMe, uploadLogo, getSettings,
} from "@/lib/api/restaurant";
import { changePassword } from "@/lib/api/auth";
import { useAuthStore } from "@/lib/stores/auth-store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { PageHeader } from "@/components/shared/page-header";
import { toast } from "sonner";
import { getErrorMessage, API_URL } from "@/lib/api/client";
import { useEffect, useState } from "react";
import { Loader2, Upload } from "lucide-react";
import { PageLoader } from "@/components/shared/loaders";
import { profileSchema, changePasswordSchema, validateImageFile } from "@/lib/security/schemas";
import { formatDate } from "@/lib/utils/format";

export default function ProfilePage() {
  const user = useAuthStore((s) => s.user);
  const restaurant = useAuthStore((s) => s.restaurant);
  const setAuth = useAuthStore((s) => s.setAuth);
  const accessToken = useAuthStore((s) => s.accessToken);
  const refreshToken = useAuthStore((s) => s.refreshToken);
  const qc = useQueryClient();
  const canEdit = user?.role === "owner";

  const { data: me, isLoading } = useQuery({ queryKey: ["restaurant-me"], queryFn: getRestaurantMe });
  const r = me || restaurant;

  const [form, setForm] = useState({
    name: "",
    ownerName: "",
    email: "",
    mobile: "",
    address: "",
    gstNumber: "",
  });
  const [pwd, setPwd] = useState({ current: "", next: "", confirm: "" });
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (r) {
      setForm({
        name: r.name || "",
        ownerName: r.ownerName || "",
        email: r.email || "",
        mobile: r.mobile || "",
        address: r.address || "",
        gstNumber: r.gstNumber || "",
      });
    }
  }, [r]);

  const saveMut = useMutation({
    mutationFn: async () => {
      const parsed = profileSchema.safeParse(form);
      if (!parsed.success) throw new Error(parsed.error.errors[0]?.message || "Invalid profile");
      return updateRestaurantMe(parsed.data);
    },
    onSuccess: (updated) => {
      qc.invalidateQueries({ queryKey: ["restaurant-me"] });
      if (user && accessToken && refreshToken) {
        setAuth({ user, restaurant: updated, accessToken, refreshToken });
      }
      toast.success("Profile updated");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const pwdMut = useMutation({
    mutationFn: async () => {
      const parsed = changePasswordSchema.safeParse(pwd);
      if (!parsed.success) throw new Error(parsed.error.errors[0]?.message || "Invalid password");
      return changePassword(parsed.data.current, parsed.data.next);
    },
    onSuccess: () => {
      setPwd({ current: "", next: "", confirm: "" });
      toast.success("Password changed");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  async function onLogo(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const check = validateImageFile(file);
    if (!check.ok) {
      toast.error(check.error);
      return;
    }
    setUploading(true);
    try {
      const logoUrl = await uploadLogo(file);
      const updated = await updateRestaurantMe({ logoUrl } as never);
      qc.invalidateQueries({ queryKey: ["restaurant-me"] });
      if (user && accessToken && refreshToken) {
        setAuth({ user, restaurant: { ...updated, logoUrl }, accessToken, refreshToken });
      }
      toast.success("Logo uploaded");
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setUploading(false);
    }
  }

  if (isLoading) return <PageLoader label="Loading profile…" />;

  const logoSrc = r?.logoUrl
    ? r.logoUrl.startsWith("http")
      ? r.logoUrl
      : `${API_URL}${r.logoUrl}`
    : null;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader title="Restaurant profile" description="Manage identity, contact, and security" />

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Identity</CardTitle>
          <CardDescription>Restaurant ID: {r?.id}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="flex h-20 w-20 items-center justify-center overflow-hidden rounded-2xl border bg-muted">
              {logoSrc ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={logoSrc} alt="Logo" className="h-full w-full object-cover" />
              ) : (
                <span className="text-2xl font-bold text-muted-foreground">
                  {(r?.name || "R").slice(0, 1)}
                </span>
              )}
            </div>
            {canEdit && (
              <div>
                <Label htmlFor="logo" className="cursor-pointer">
                  <div className="inline-flex items-center gap-2 rounded-lg border px-3 py-2 text-sm hover:bg-accent">
                    {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                    Upload logo
                  </div>
                </Label>
                <input id="logo" type="file" accept="image/*" className="hidden" onChange={onLogo} />
                <p className="mt-1 text-xs text-muted-foreground">PNG/JPG ≤ 300KB</p>
              </div>
            )}
            <div className="ml-auto space-y-1 text-right text-sm">
              <Badge variant={r?.status === "active" ? "success" : "warning"}>{r?.status}</Badge>
              <p className="text-xs text-muted-foreground">Plan: {r?.planId}</p>
              {r?.subscriptionExpiresAt && (
                <p className="text-xs text-muted-foreground">
                  Sub until {formatDate(r.subscriptionExpiresAt)}
                </p>
              )}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Restaurant name</Label>
              <Input
                value={form.name}
                disabled={!canEdit}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Owner name</Label>
              <Input
                value={form.ownerName}
                disabled={!canEdit}
                onChange={(e) => setForm({ ...form, ownerName: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Email</Label>
              <Input
                type="email"
                value={form.email}
                disabled={!canEdit}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Mobile</Label>
              <Input
                value={form.mobile}
                disabled={!canEdit}
                onChange={(e) => setForm({ ...form, mobile: e.target.value })}
              />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label>Address</Label>
              <Textarea
                value={form.address}
                disabled={!canEdit}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label>GST number</Label>
              <Input
                value={form.gstNumber}
                disabled={!canEdit}
                onChange={(e) => setForm({ ...form, gstNumber: e.target.value })}
              />
            </div>
          </div>

          {canEdit && (
            <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>
              {saveMut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              Save profile
            </Button>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Change password</CardTitle>
          <CardDescription>Update your login password</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 max-w-md">
          <div className="space-y-1.5">
            <Label>Current password</Label>
            <Input
              type="password"
              value={pwd.current}
              onChange={(e) => setPwd({ ...pwd, current: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>New password</Label>
            <Input
              type="password"
              value={pwd.next}
              onChange={(e) => setPwd({ ...pwd, next: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Confirm new password</Label>
            <Input
              type="password"
              value={pwd.confirm}
              onChange={(e) => setPwd({ ...pwd, confirm: e.target.value })}
            />
          </div>
          <Button
            onClick={() => {
              if (pwd.next !== pwd.confirm) {
                toast.error("Passwords do not match");
                return;
              }
              if (pwd.next.length < 6) {
                toast.error("Password must be at least 6 characters");
                return;
              }
              pwdMut.mutate();
            }}
            disabled={pwdMut.isPending || !pwd.current || !pwd.next}
          >
            {pwdMut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
            Update password
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Your account</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Name</span>
            <span>{user?.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Username</span>
            <span className="font-mono">{user?.username}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Role</span>
            <Badge variant="outline">{user?.role}</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
