"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listExpenses, createExpense, deleteExpense, getPnl } from "@/lib/api/restaurant";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, formatDate } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { expenseSchema } from "@/lib/security/schemas";
import { DataTable, SortableHeader } from "@/components/data-table";
import { useDataTableState, useClientTable } from "@/hooks/use-data-table";

export default function FinancePage() {
  const qc = useQueryClient();
  const month = new Date().toISOString().slice(0, 7);
  const { data: expenses, isLoading } = useQuery({ queryKey: ["expenses", month], queryFn: () => listExpenses({ month }) });
  const { data: pnl } = useQuery({ queryKey: ["pnl", month], queryFn: () => getPnl({ period: "monthly", key: month }) });
  const [form, setForm] = useState({ date: new Date().toISOString().slice(0, 10), category: "supplies", description: "", amount: "" });
  const [categoryFilter, setCategoryFilter] = useState("all");
  const tableState = useDataTableState();
  const table = useClientTable(expenses, {
    state: tableState,
    searchKeys: ["category", "description", "date", (e) => e.amount],
    filterFn: (e) => (categoryFilter === "all" ? true : e.category === categoryFilter),
  });

  const createMut = useMutation({
    mutationFn: async () => {
      const parsed = expenseSchema.safeParse({
        ...form,
        amount: form.amount,
      });
      if (!parsed.success) {
        throw new Error(parsed.error.errors[0]?.message || "Invalid expense");
      }
      return createExpense(parsed.data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["expenses"] });
      qc.invalidateQueries({ queryKey: ["pnl"] });
      setForm({ ...form, description: "", amount: "" });
      toast.success("Expense added");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const delMut = useMutation({
    mutationFn: deleteExpense,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["expenses"] }); qc.invalidateQueries({ queryKey: ["pnl"] }); toast.success("Deleted"); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const p = (pnl?.pnl || {}) as Record<string, number>;

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          ["Net sales", p.netSales],
          ["Gross profit", p.grossProfit],
          ["Expenses", p.totalExpenses],
          ["Net profit", p.netProfit],
        ].map(([label, val]) => (
          <Card key={String(label)} className="card-interactive">
            <CardContent className="flex min-h-[88px] flex-col justify-center gap-2 py-5">
              <p className="text-xs font-medium text-muted-foreground leading-none">{label}</p>
              <p className="text-xl font-bold tracking-tight leading-none">{formatCurrency(Number(val) || 0)}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Add expense</CardTitle></CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Input type="date" className="w-40" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
          <select className="h-10 rounded-lg border border-input bg-background px-3 text-sm" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
            {["supplies", "rent", "utilities", "salaries", "marketing", "maintenance", "other"].map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <Input placeholder="Description" className="flex-1 min-w-[140px]" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <Input placeholder="Amount" type="number" className="w-28" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
          <Button onClick={() => createMut.mutate()} disabled={!form.amount}>Add</Button>
        </CardContent>
      </Card>

      <div>
        <h2 className="mb-3 text-base font-semibold">Expenses — {month}</h2>
        <DataTable
          search={tableState.search}
          onSearchChange={tableState.setSearch}
          searchPlaceholder="Search expenses…"
          hasActiveFilters={!!tableState.search || categoryFilter !== "all"}
          onClearFilters={() => {
            tableState.resetFilters();
            setCategoryFilter("all");
          }}
          toolbarExtra={
            <select
              className="h-9 rounded-md border border-input bg-background px-2 text-sm capitalize"
              value={categoryFilter}
              onChange={(e) => {
                setCategoryFilter(e.target.value);
                tableState.setPage(1);
              }}
            >
              <option value="all">All categories</option>
              {["supplies", "rent", "utilities", "salaries", "marketing", "maintenance", "other"].map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          }
          page={table.page}
          pageSize={table.pageSize}
          total={table.total}
          totalPages={table.totalPages}
          from={table.from}
          to={table.to}
          onPageChange={tableState.setPage}
          onPageSizeChange={tableState.setPageSize}
          loading={isLoading}
          skeletonCols={5}
          emptyTitle="No expenses found"
          emptyDescription="Add an expense or clear filters"
        >
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b bg-muted/40 text-left">
                <th className="px-4 py-3">
                  <SortableHeader label="Date" column="date" sortBy={tableState.sortBy} sortDir={tableState.sortDir} onSort={tableState.toggleSort} />
                </th>
                <th className="px-4 py-3">
                  <SortableHeader label="Category" column="category" sortBy={tableState.sortBy} sortDir={tableState.sortDir} onSort={tableState.toggleSort} />
                </th>
                <th className="px-4 py-3 font-medium text-muted-foreground">Description</th>
                <th className="px-4 py-3">
                  <SortableHeader label="Amount" column="amount" sortBy={tableState.sortBy} sortDir={tableState.sortDir} onSort={tableState.toggleSort} />
                </th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {table.rows.map((e) => (
                <tr key={e.id} className="border-b border-border/50 hover:bg-muted/30">
                  <td className="px-4 py-3">{formatDate(e.date)}</td>
                  <td className="px-4 py-3 capitalize">{e.category}</td>
                  <td className="px-4 py-3 text-muted-foreground">{e.description}</td>
                  <td className="px-4 py-3 font-semibold">{formatCurrency(e.amount)}</td>
                  <td className="px-4 py-3">
                    <Button size="sm" variant="ghost" className="text-destructive" onClick={() => delMut.mutate(e.id)}>Delete</Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </DataTable>
      </div>
    </div>
  );
}
