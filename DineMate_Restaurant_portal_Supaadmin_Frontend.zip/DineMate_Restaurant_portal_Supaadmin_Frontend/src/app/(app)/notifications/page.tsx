"use client";

import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listNotifications, markAllNotificationsRead } from "@/lib/api/restaurant";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select } from "@/components/ui/select";
import { relativeTime } from "@/lib/utils/format";
import { toast } from "sonner";
import { PageLoader } from "@/components/shared/loaders";
import { TablePagination } from "@/components/data-table/pagination";
import {
  DEFAULT_PAGE_SIZE,
  PAGE_SIZE_OPTIONS,
  type PageSizeOption,
} from "@/components/data-table/types";

export default function NotificationsPage() {
  const qc = useQueryClient();
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState<PageSizeOption>(DEFAULT_PAGE_SIZE);

  const { data, isLoading } = useQuery({
    queryKey: ["notifications"],
    queryFn: () => listNotifications(),
  });

  const markMut = useMutation({
    mutationFn: markAllNotificationsRead,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["notifications"] });
      toast.success("Marked all read");
    },
  });

  const items = data || [];
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize) || 1);
  const safePage = Math.min(page, totalPages);
  const paged = useMemo(
    () => items.slice((safePage - 1) * pageSize, safePage * pageSize),
    [items, safePage, pageSize]
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            {items.length.toLocaleString()} notification{items.length === 1 ? "" : "s"}
          </span>
          <Select
            className="h-9 w-36"
            value={String(pageSize)}
            onChange={(e) => {
              setPageSize(Number(e.target.value) as PageSizeOption);
              setPage(1);
            }}
            aria-label="Rows per page"
          >
            {PAGE_SIZE_OPTIONS.map((n) => (
              <option key={n} value={n}>
                {n} / page
              </option>
            ))}
          </Select>
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={() => markMut.mutate()}
          disabled={markMut.isPending || items.length === 0}
        >
          Mark all read
        </Button>
      </div>

      {isLoading ? (
        <PageLoader label="Loading notifications…" />
      ) : (
        <div className="space-y-2">
          {paged.map((n) => (
            <Card key={n.id}>
              <CardContent className="flex items-start justify-between gap-4 p-4">
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium">{n.title}</p>
                    {!n.read && (
                      <Badge variant="default" className="text-[10px]">
                        New
                      </Badge>
                    )}
                  </div>
                  <p className="mt-0.5 text-sm text-muted-foreground">{n.message}</p>
                </div>
                <span className="shrink-0 text-xs text-muted-foreground">
                  {relativeTime(n.createdAt)}
                </span>
              </CardContent>
            </Card>
          ))}

          {!items.length && (
            <p className="py-12 text-center text-muted-foreground">No notifications</p>
          )}

          {items.length > 0 && (
            <div className="rounded-lg border bg-muted/20 px-3">
              <TablePagination
                meta={{
                  page: safePage,
                  pageSize,
                  total: items.length,
                  totalPages,
                }}
                onPageChange={setPage}
                onPageSizeChange={(size) => {
                  setPageSize(size as PageSizeOption);
                  setPage(1);
                }}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
