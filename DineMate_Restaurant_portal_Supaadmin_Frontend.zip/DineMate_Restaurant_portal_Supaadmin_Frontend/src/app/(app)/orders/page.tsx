"use client";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listOrders, updateOrder, getOrderBill, getOrderKot, markKotPrinted } from "@/lib/api/restaurant";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Select } from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { formatCurrency, formatDateTime } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { Printer, FileText, Loader2 } from "lucide-react";
import { ButtonLoader } from "@/components/shared/loaders";
import { DataTable, SortableHeader } from "@/components/data-table";
import { useDataTableState, useClientTable } from "@/hooks/use-data-table";
import type { Order, RestaurantSettings } from "@/types";

export default function OrdersPage() {
  const qc = useQueryClient();
  const [activeOnly, setActiveOnly] = useState(true);
  const [statusFilter, setStatusFilter] = useState("");
  const [billData, setBillData] = useState<{ order: Order; settings: RestaurantSettings } | null>(null);
  const [cancelId, setCancelId] = useState<string | null>(null);
  const tableState = useDataTableState();

  const { data, isLoading } = useQuery({
    queryKey: ["orders", activeOnly],
    queryFn: () =>
      listOrders({
        active: activeOnly ? "1" : undefined,
        includeArchived: activeOnly ? undefined : "1",
      }),
    refetchInterval: 12000,
  });

  const table = useClientTable(data?.orders, {
    state: tableState,
    searchKeys: [
      "id",
      "billNumber",
      "status",
      "customerName",
      "waiterName",
      (o) => o.tableNumber,
      (o) => o.total,
    ],
    filterFn: (o) => (statusFilter ? o.status === statusFilter : true),
  });
  const orders = table.rows;

  const statusMut = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      updateOrder(id, { status } as never),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["orders"] });
      toast.success("Order updated");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const billMut = useMutation({
    mutationFn: (id: string) => getOrderBill(id),
    onSuccess: (d) => {
      qc.invalidateQueries({ queryKey: ["orders"] });
      qc.invalidateQueries({ queryKey: ["tables"] });
      setBillData(d);
      toast.success(`Bill ${d.order.billNumber || "generated"}`);
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const kotMut = useMutation({
    mutationFn: async (id: string) => {
      const d = await getOrderKot(id);
      await markKotPrinted(id);
      return d;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["orders"] });
      toast.success("KOT marked printed");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  function printBill() {
    window.print();
  }

  return (
    <div className="space-y-4">
      <PageHeader
        title="Orders"
        description="Live queue, status updates, billing & KOT"
        actions={
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant={activeOnly ? "default" : "outline"} onClick={() => setActiveOnly(true)}>
              Active
            </Button>
            <Button size="sm" variant={!activeOnly ? "default" : "outline"} onClick={() => setActiveOnly(false)}>
              History
            </Button>
          </div>
        }
      />

      <DataTable
        search={tableState.search}
        onSearchChange={tableState.setSearch}
        searchPlaceholder="Search orders, table, bill…"
        hasActiveFilters={!!tableState.search || !!statusFilter || !activeOnly}
        onClearFilters={() => {
          tableState.resetFilters();
          setStatusFilter("");
          setActiveOnly(true);
        }}
        toolbarExtra={
          <>
            <Select
              className="h-9 w-36"
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                tableState.setPage(1);
              }}
            >
              <option value="">All statuses</option>
              {["pending", "confirmed", "preparing", "ready", "served", "completed", "cancelled"].map(
                (s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                )
              )}
            </Select>
          </>
        }
        page={table.page}
        pageSize={table.pageSize}
        total={table.total}
        totalPages={table.totalPages}
        from={table.from}
        to={table.to}
        onPageChange={tableState.setPage}
        onPageSizeChange={tableState.setPageSize}
        loading={isLoading}
        skeletonCols={7}
        emptyTitle="No orders found"
        emptyDescription="Orders will appear here as customers place them"
      >
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b bg-muted/40 text-left">
              <th className="px-4 py-3">
                <SortableHeader label="Order" column="id" sortBy={tableState.sortBy} sortDir={tableState.sortDir} onSort={tableState.toggleSort} />
              </th>
              <th className="px-4 py-3">
                <SortableHeader label="Table" column="tableNumber" sortBy={tableState.sortBy} sortDir={tableState.sortDir} onSort={tableState.toggleSort} />
              </th>
              <th className="px-4 py-3 font-medium text-muted-foreground">Items</th>
              <th className="px-4 py-3">
                <SortableHeader label="Total" column="total" sortBy={tableState.sortBy} sortDir={tableState.sortDir} onSort={tableState.toggleSort} />
              </th>
              <th className="px-4 py-3">
                <SortableHeader label="Status" column="status" sortBy={tableState.sortBy} sortDir={tableState.sortDir} onSort={tableState.toggleSort} />
              </th>
              <th className="px-4 py-3">
                <SortableHeader label="Time" column="placedAt" sortBy={tableState.sortBy} sortDir={tableState.sortDir} onSort={tableState.toggleSort} />
              </th>
              <th className="px-4 py-3 font-medium text-muted-foreground">Actions</th>
            </tr>
          </thead>
<tbody>
                  {orders.map((o) => (
                    <tr key={o.id} className="border-b border-border/50 hover:bg-muted/20">
                      <td className="px-4 py-3">
                        <p className="font-mono text-xs">{o.id}</p>
                        {o.billNumber && (
                          <p className="text-[10px] text-muted-foreground">{o.billNumber}</p>
                        )}
                      </td>
                      <td className="px-4 py-3 font-medium">T{o.tableNumber}</td>
                      <td className="px-4 py-3">
                        <p className="text-sm font-medium">{o.items?.length ?? 0} item(s)</p>
                        <ul className="mt-0.5 max-w-[220px] space-y-0.5 text-[11px] text-muted-foreground">
                          {(o.items || []).slice(0, 4).map((it) => (
                            <li key={it.id} className="truncate">
                              {it.quantity}× {it.name}
                              {it.variant ? ` (${it.variant})` : ""}
                              {it.note ? (
                                <span className="block truncate text-amber-700 dark:text-amber-400">
                                  {it.note}
                                </span>
                              ) : null}
                            </li>
                          ))}
                          {(o.items?.length ?? 0) > 4 ? (
                            <li>+{(o.items?.length ?? 0) - 4} more</li>
                          ) : null}
                        </ul>
                      </td>
                      <td className="px-4 py-3 font-semibold">{formatCurrency(o.total)}</td>
                      <td className="px-4 py-3">
                        <Badge
                          variant={
                            o.status === "cancelled"
                              ? "destructive"
                              : o.status === "completed"
                                ? "success"
                                : "secondary"
                          }
                        >
                          {o.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">
                        {formatDateTime(o.placedAt)}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {!o.billGenerated && o.status !== "cancelled" && (
                            <>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => statusMut.mutate({ id: o.id, status: "preparing" })}
                              >
                                Prep
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => statusMut.mutate({ id: o.id, status: "ready" })}
                              >
                                Ready
                              </Button>
                              <Button
                                size="sm"
                                variant="secondary"
                                onClick={() => billMut.mutate(o.id)}
                                disabled={billMut.isPending}
                              >
                                {billMut.isPending ? (
                                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                                ) : (
                                  <FileText className="h-3.5 w-3.5" />
                                )}
                                Bill
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => kotMut.mutate(o.id)}
                              >
                                <Printer className="h-3.5 w-3.5" /> KOT
                              </Button>
                            </>
                          )}
                          {o.billGenerated && (
                            <Button size="sm" variant="outline" onClick={() => billMut.mutate(o.id)}>
                              <FileText className="h-3.5 w-3.5" /> View bill
                            </Button>
                          )}
                          {o.status !== "cancelled" && o.status !== "completed" && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-destructive"
                              onClick={() => setCancelId(o.id)}
                            >
                              Cancel
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
      </DataTable>

      {/* Bill dialog */}
      <Dialog open={!!billData} onOpenChange={(o) => !o && setBillData(null)}>
        <DialogContent className="max-w-md print:max-w-none print:border-0 print:shadow-none">
          <DialogHeader className="print:hidden">
            <DialogTitle>Invoice</DialogTitle>
          </DialogHeader>
          {billData && (
            <div id="bill-print" className="space-y-3 text-sm">
              <div className="text-center border-b pb-3">
                <p className="text-lg font-bold">{billData.settings.restaurantName}</p>
                {billData.settings.address && (
                  <p className="text-xs text-muted-foreground">{billData.settings.address}</p>
                )}
                {billData.settings.gstin && (
                  <p className="text-xs">GSTIN: {billData.settings.gstin}</p>
                )}
              </div>
              <div className="flex justify-between text-xs">
                <div>
                  <p>
                    <span className="text-muted-foreground">Bill #</span>{" "}
                    <span className="font-mono font-semibold">{billData.order.billNumber || "—"}</span>
                  </p>
                  <p>
                    <span className="text-muted-foreground">Order</span>{" "}
                    <span className="font-mono">{billData.order.id}</span>
                  </p>
                </div>
                <div className="text-right">
                  <p>Table {billData.order.tableNumber}</p>
                  <p className="text-muted-foreground">
                    {formatDateTime(billData.order.billedAt || billData.order.placedAt)}
                  </p>
                </div>
              </div>
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b text-left text-muted-foreground">
                    <th className="py-1">Item</th>
                    <th className="py-1 text-right">Qty</th>
                    <th className="py-1 text-right">Amt</th>
                  </tr>
                </thead>
                <tbody>
                  {billData.order.items.map((it) => (
                    <tr key={it.id} className="border-b border-dashed border-border/50">
                      <td className="py-1.5">
                        <div>
                          {it.name}
                          {it.variant && <span className="text-muted-foreground"> ({it.variant})</span>}
                        </div>
                        {it.note ? (
                          <p className="text-[11px] text-amber-700 dark:text-amber-400">{it.note}</p>
                        ) : null}
                      </td>
                      <td className="py-1.5 text-right">{it.quantity}</td>
                      <td className="py-1.5 text-right">{formatCurrency(it.price * it.quantity)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="space-y-1 border-t pt-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>{formatCurrency(billData.order.subtotal)}</span>
                </div>
                {billData.order.discountTotal > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>Discount</span>
                    <span>-{formatCurrency(billData.order.discountTotal)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-muted-foreground">
                    Tax ({billData.order.taxRatePercent ?? billData.settings.taxRatePercent}%)
                  </span>
                  <span>{formatCurrency(billData.order.taxAmount)}</span>
                </div>
                <div className="flex justify-between text-base font-bold">
                  <span>Grand total</span>
                  <span>{formatCurrency(billData.order.total)}</span>
                </div>
                {billData.order.paymentMethod && (
                  <div className="flex justify-between pt-1">
                    <span className="text-muted-foreground">Payment</span>
                    <span className="uppercase">{billData.order.paymentMethod}</span>
                  </div>
                )}
              </div>
              <p className="pt-2 text-center text-[10px] text-muted-foreground">
                Thank you for dining with us!
              </p>
            </div>
          )}
          <DialogFooter className="print:hidden">
            <Button variant="outline" onClick={() => setBillData(null)}>
              Close
            </Button>
            <Button onClick={printBill}>
              <Printer className="h-4 w-4" /> Print
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!cancelId}
        onOpenChange={(o) => !o && setCancelId(null)}
        title="Cancel order?"
        description="This cannot be undone. The order will be marked cancelled."
        confirmLabel="Cancel order"
        variant="destructive"
        loading={statusMut.isPending}
        onConfirm={() => {
          if (cancelId) {
            statusMut.mutate(
              { id: cancelId, status: "cancelled" },
              { onSuccess: () => setCancelId(null) }
            );
          }
        }}
      />

      <style jsx global>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #bill-print,
          #bill-print * {
            visibility: visible;
          }
          #bill-print {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
        }
      `}</style>
    </div>
  );
}
