export type UserRole = "super_admin" | "owner" | "manager" | "waiter";

export type OrderStatus =
  | "pending"
  | "confirmed"
  | "preparing"
  | "ready"
  | "served"
  | "completed"
  | "cancelled";

export type TableStatus = "available" | "occupied" | "reserved" | "cleaning";
export type OfferType = "percent" | "flat" | "bogo" | "combo" | "category" | "item" | "happy_hour" | "coupon";
export type FoodType = "veg" | "non-veg" | "egg" | "other";
export type PaymentMethod = "cash" | "card" | "upi";

export interface SessionUser {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  restaurantId: string | null;
}

export interface RestaurantSummary {
  id: string;
  name: string;
  status: string;
  subscriptionStatus?: string;
  subscriptionExpiresAt?: string;
  planId?: string;
  logoUrl?: string;
  ownerName?: string;
  email?: string;
  mobile?: string;
  address?: string;
  gstNumber?: string;
  renewedAt?: string;
}

export interface LoginResponse {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  restaurantId: string | null;
  restaurant: RestaurantSummary | null;
  accessToken: string;
  refreshToken: string;
}

export interface MenuCategory {
  id: string;
  restaurantId: string;
  name: string;
  icon?: string;
  sortOrder?: number;
  scheduleEnabled?: boolean;
  availableFrom?: string;
  availableTo?: string;
  availableNow?: boolean;
  outsideSchedule?: boolean;
}

export interface MenuVariant {
  id: string;
  label: string;
  priceDelta: number;
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  description?: string;
  categoryId: string;
  price: number;
  costPrice?: number;
  image?: string;
  available: boolean;
  foodType?: FoodType;
  spiceLevel?: "mild" | "medium" | "hot";
  isVeg?: boolean;
  prepTimeMinutes?: number;
  variants?: MenuVariant[];
  popular?: boolean;
  featured?: boolean;
  /** When true, item is only sellable between availableFrom and availableTo */
  scheduleEnabled?: boolean;
  /** Daily start time "HH:mm" e.g. "11:00" */
  availableFrom?: string;
  /** Daily end time "HH:mm" e.g. "15:00" */
  availableTo?: string;
  /** Computed by API for public menu */
  availableNow?: boolean;
  outsideSchedule?: boolean;
  jainAvailable?: boolean;
  jainOnly?: boolean;
  enableSpiceLevel?: boolean;
  spiceOptions?: string[];
  enableCookingRequest?: boolean;
  maxCookingRequestLength?: number;
  addOns?: Array<{ id: string; label: string; priceDelta: number; available?: boolean }>;
  tags?: string[];
  ingredients?: string[];
  allergens?: string[];
}

export interface RestaurantTable {
  id: string;
  restaurantId: string;
  number: number;
  capacity: number;
  status: TableStatus;
  currentOrderId?: string;
  waiterName?: string;
  qrPath?: string;
}

export interface OrderItem {
  id: string;
  itemId: string;
  name: string;
  quantity: number;
  price: number;
  note?: string;
  variant?: string;
  kotPrinted?: boolean;
  foodType?: FoodType;
  categoryId?: string;
  costPrice?: number;
  addedBy?: "customer" | "waiter";
}

export interface AppliedOffer {
  offerId: string;
  name: string;
  amount: number;
}

export interface Order {
  id: string;
  restaurantId: string;
  tableNumber: number;
  items: OrderItem[];
  status: OrderStatus | string;
  placedAt: string;
  updatedAt: string;
  total: number;
  subtotal: number;
  taxAmount: number;
  discountTotal: number;
  taxRatePercent?: number;
  manualDiscountPercent?: number;
  appliedOffers?: AppliedOffer[];
  customerName?: string;
  waiterName?: string;
  note?: string;
  estimatedMinutes?: number;
  kotBatches?: number;
  billGenerated?: boolean;
  billNumber?: string;
  billedAt?: string;
  paymentMethod?: PaymentMethod;
  cogsTotal?: number;
}

export interface StaffUser {
  id: string;
  username: string;
  name: string;
  role: string;
  active: boolean;
  createdAt?: string;
  permissions?: string[];
  lastLoginAt?: string;
}

export interface Expense {
  id: string;
  restaurantId: string;
  date: string;
  category: string;
  description: string;
  amount: number;
  monthKey?: string;
  yearKey?: string;
  createdAt?: string;
}

export interface Offer {
  id: string;
  restaurantId: string;
  name: string;
  description?: string;
  image?: string;
  type: OfferType | string;
  active: boolean;
  itemId?: string;
  categoryId?: string;
  itemIds?: string[];
  categoryIds?: string[];
  excludeItemIds?: string[];
  buyQty?: number;
  getQty?: number;
  discountPercent?: number;
  discountAmount?: number;
  maxDiscountAmount?: number;
  minOrderAmount?: number;
  startsAt?: string;
  endsAt?: string;
  daysOfWeek?: number[];
  timeFrom?: string;
  timeTo?: string;
  usageLimit?: number;
  usageCount?: number;
  perCustomerLimit?: number;
  couponCode?: string;
  autoApply?: boolean;
  stackable?: boolean;
  priority?: number;
  createdAt?: string;
  updatedAt?: string;
  /** Computed by API */
  status?: "active" | "scheduled" | "expired" | "inactive" | "exhausted";
  live?: boolean;
}

export interface AppNotification {
  id: string;
  type: string;
  title: string;
  message: string;
  read?: boolean;
  createdAt: string;
  targetRole?: string;
}

export interface RestaurantSettings {
  restaurantId: string;
  taxRatePercent: number;
  restaurantName: string;
  currency?: string;
  baseUrl?: string;
  openingTime?: string;
  closingTime?: string;
  address?: string;
  phone?: string;
  foodLicence?: string;
  gstin?: string;
  billPrefix?: string;
}

export interface Plan {
  id: string;
  name: string;
  durationDays: number;
  price: number;
  productLimit: number;
  orderLimit: number;
  userLimit: number;
  storageLimitMb: number;
  features: string[];
  active: boolean;
}

export interface DailyStat {
  restaurantId: string;
  dateKey: string;
  weekKey?: string;
  monthKey?: string;
  yearKey?: string;
  grossSales: number;
  discountTotal: number;
  netSales: number;
  taxTotal: number;
  totalCollected: number;
  cogsTotal: number;
  grossProfit: number;
  orderCount: number;
  itemsSold: number;
  updatedAt?: string;
}

export interface ActivityLog {
  id: string;
  restaurantId?: string;
  actorUserId?: string;
  actorName?: string;
  actorRole?: string;
  action: string;
  entityType?: string;
  entityId?: string;
  details?: unknown;
  createdAt: string;
}

export interface Pagination {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export interface ApiSuccess<T> {
  success: true;
  message: string;
  data: T;
  pagination?: Pagination;
}

export interface ApiError {
  success: false;
  message: string;
  errors?: unknown[];
}

export interface CheckoutPayload {
  orderId: string;
  amount: number;
  currency: string;
  keyId: string;
  planId?: string;
  restaurantId?: string;
}
