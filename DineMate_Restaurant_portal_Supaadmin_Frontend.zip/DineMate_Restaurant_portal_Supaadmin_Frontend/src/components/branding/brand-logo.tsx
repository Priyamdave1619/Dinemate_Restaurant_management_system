"use client";

import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils/cn";
import { APP_NAME } from "@/components/layout/nav-items";

export type BrandLogoVariant =
  | "sidebar"
  | "sidebar-collapsed"
  | "header"
  | "login"
  | "splash"
  | "empty"
  | "error";

export type BrandLogoSize = "xs" | "sm" | "md" | "lg" | "xl";

const SIZE_MAP: Record<BrandLogoSize, { box: string; img: number }> = {
  xs: { box: "h-7 w-7", img: 28 },
  sm: { box: "h-8 w-8", img: 32 },
  md: { box: "h-10 w-10", img: 40 },
  lg: { box: "h-14 w-14", img: 56 },
  xl: { box: "h-20 w-20", img: 80 },
};

/** Official brand assets
 *  Light mode → gold mark
 *  Dark mode  → navy/blue mark
 *  Theme switch is instant (no slide / fade animation on sidebar)
 */
const LOGO_LIGHT = "/logos/logo-gold.png";
const LOGO_DARK = "/logos/logo-blue.png";

interface BrandLogoProps {
  variant?: BrandLogoVariant;
  size?: BrandLogoSize;
  showName?: boolean;
  showTagline?: boolean;
  companyName?: string;
  tagline?: string;
  iconOnly?: boolean;
  className?: string;
  /** Override with restaurant-specific logo URL */
  customSrc?: string | null;
  alt?: string;
}

/**
 * Enterprise branding component.
 * Theme-aware logo swap with no slide/fade animation (instant switch).
 */
export function BrandLogo({
  variant = "sidebar",
  size = "md",
  showName = false,
  showTagline = false,
  companyName = APP_NAME,
  tagline = "Restaurant Portal",
  iconOnly = false,
  className,
  customSrc,
  alt,
}: BrandLogoProps) {
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  // Preload both theme logos
  useEffect(() => {
    if (typeof window === "undefined") return;
    const a = new window.Image();
    const b = new window.Image();
    a.src = LOGO_LIGHT;
    b.src = LOGO_DARK;
  }, []);

  const isDark = mounted && resolvedTheme === "dark";
  const { box, img } = SIZE_MAP[size];

  // Before mount always show light (gold) logo so SSR + first paint are never blank
  const defaultSrc = isDark ? LOGO_DARK : LOGO_LIGHT;
  const src = customSrc || defaultSrc;

  const isLogin = variant === "login";
  const isSidebar = variant === "sidebar" || variant === "sidebar-collapsed";

  const nameVisible =
    !iconOnly &&
    showName &&
    variant !== "sidebar-collapsed" &&
    variant !== "splash" &&
    !isLogin;

  const taglineVisible = nameVisible && showTagline;
  const altText = alt || `${companyName} logo`;

  // ── Login: large full lockup ─────────────────────────────────────────
  if (isLogin) {
    return (
      <div
        className={cn(
          "flex flex-col items-center justify-center text-center gap-1 w-full",
          className
        )}
        role="img"
        aria-label={altText}
      >
        <div className="relative mx-auto flex w-full max-w-[240px] items-center justify-center sm:max-w-[280px]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={src}
            alt={altText}
            width={320}
            height={220}
            className="mx-auto h-auto w-full max-h-[160px] object-contain drop-shadow-sm"
            draggable={false}
            onError={(e) => {
              const el = e.currentTarget;
              if (el.src.indexOf("logo-gold") === -1) {
                el.src = LOGO_LIGHT;
              }
            }}
          />
        </div>
        {showTagline && tagline ? (
          <p className="mt-1 text-sm text-muted-foreground">{tagline}</p>
        ) : null}
      </div>
    );
  }

  // ── Sidebar expanded: full brand mark (no animation on theme switch) ─
  if (isSidebar && !iconOnly && showName && variant === "sidebar") {
    return (
      <div
        className={cn(
          "flex flex-col items-center justify-center gap-1.5 min-w-0 w-full",
          className
        )}
        role="img"
        aria-label={altText}
      >
        <div className="relative flex h-14 w-full max-w-[150px] items-center justify-center shrink-0">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={src}
            alt={altText}
            width={150}
            height={56}
            className="h-14 w-auto max-w-full object-contain"
            draggable={false}
          />
        </div>
        {showTagline && tagline ? (
          <p className="truncate text-[10px] text-muted-foreground mt-0.5 w-full text-center">
            {tagline}
          </p>
        ) : null}
      </div>
    );
  }

  // ── Default / collapsed: icon only (no animation) ────────────────────
  return (
    <div
      className={cn(
        "flex items-center gap-2.5 min-w-0",
        variant === "sidebar-collapsed" && "justify-center",
        className
      )}
      role="img"
      aria-label={altText}
    >
      <div
        className={cn(
          "relative shrink-0 overflow-hidden rounded-xl bg-primary/5 ring-1 ring-primary/10",
          box
        )}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={src}
          alt={altText}
          width={img}
          height={img}
          className="h-full w-full object-contain p-1"
          draggable={false}
        />
      </div>

      {nameVisible && (
        <div className="min-w-0 overflow-hidden">
          <p
            className={cn(
              "truncate font-bold leading-tight tracking-tight text-foreground",
              size === "xs" || size === "sm" ? "text-sm" : "text-base"
            )}
          >
            {companyName}
          </p>
          {taglineVisible && (
            <p className="truncate text-[11px] text-muted-foreground mt-0.5">
              {tagline}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
