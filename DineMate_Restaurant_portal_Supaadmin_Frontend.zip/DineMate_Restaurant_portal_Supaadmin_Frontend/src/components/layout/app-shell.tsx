"use client";
import { Sidebar } from "./sidebar";
import { Header } from "./header";
import { useAuthStore } from "@/lib/stores/auth-store";
import { useRouter } from "next/navigation";
import { useEffect, useState, useCallback } from "react";
import { cn } from "@/lib/utils/cn";
import { SIDEBAR_STORAGE_KEY } from "./nav-items";
import { PageLoader } from "@/components/shared/loaders";

export function AppShell({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const user = useAuthStore((s) => s.user);
  const restaurant = useAuthStore((s) => s.restaurant);
  const [ready, setReady] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setReady(true);
    try {
      setCollapsed(localStorage.getItem(SIDEBAR_STORAGE_KEY) === "1");
    } catch {
      /* ignore */
    }

    // Sync across tabs only (same-tab updates go through onCollapsedChange)
    const onStorage = (e: StorageEvent) => {
      if (e.key === SIDEBAR_STORAGE_KEY) setCollapsed(e.newValue === "1");
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  useEffect(() => {
    if (!ready) return;
    if (!isAuthenticated()) {
      router.replace("/login");
      return;
    }
    if (user?.role === "super_admin") {
      router.replace("/login?error=use_platform_admin");
      return;
    }
    if (!user?.restaurantId) {
      router.replace("/login?error=no_restaurant");
    }
  }, [ready, isAuthenticated, user, router]);

  // Close mobile drawer on resize to desktop
  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth >= 768) setMobileOpen(false);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  const openMobile = useCallback(() => setMobileOpen(true), []);
  const closeMobile = useCallback(() => setMobileOpen(false), []);

  const expired =
    restaurant?.subscriptionExpiresAt &&
    new Date(restaurant.subscriptionExpiresAt).getTime() < Date.now() &&
    restaurant.subscriptionStatus !== "active";

  if (!ready) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <PageLoader label="Starting portal…" className="min-h-0 py-0" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar
        mobileOpen={mobileOpen}
        onMobileClose={closeMobile}
        collapsed={collapsed}
        onCollapsedChange={setCollapsed}
      />
      <div
        className={cn(
          "transition-[padding] duration-300 ease-spring",
          collapsed ? "md:pl-[72px]" : "md:pl-60"
        )}
      >
        <Header onMenuClick={openMobile} />
        {expired && user?.role === "owner" && (
          <div className="border-b border-amber-500/30 bg-amber-500/10 px-4 py-2.5 text-center text-sm text-amber-800 dark:text-amber-200 sm:px-5">
            Your subscription has expired.{" "}
            <a href="/subscription" className="font-semibold underline underline-offset-2">
              Renew now
            </a>{" "}
            to restore full access.
          </div>
        )}
        <main className="page-container animate-fade-in p-3 xs:p-4 sm:p-5 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
