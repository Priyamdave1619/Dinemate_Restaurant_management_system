"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import { useAuthStore } from "@/lib/stores/auth-store";
import { useEffect } from "react";
import { API_URL } from "@/lib/api/client";
import { BrandLogo } from "@/components/branding";
import {
  NAV_ITEMS,
  SIDEBAR_STORAGE_KEY,
  APP_NAME,
  APP_VERSION,
} from "./nav-items";

interface SidebarProps {
  mobileOpen?: boolean;
  onMobileClose?: () => void;
  collapsed?: boolean;
  onCollapsedChange?: (collapsed: boolean) => void;
}

export function Sidebar({
  mobileOpen = false,
  onMobileClose,
  collapsed = false,
  onCollapsedChange,
}: SidebarProps) {
  const pathname = usePathname();
  const { user, restaurant } = useAuthStore();
  const role = user?.role || "";

  // Lock body scroll when mobile drawer is open
  useEffect(() => {
    if (mobileOpen) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = prev;
      };
    }
  }, [mobileOpen]);

  function toggle() {
    const next = !collapsed;
    // Side effects OUTSIDE of any setState updater — avoids
    // "Cannot update AppShell while rendering Sidebar"
    try {
      localStorage.setItem(SIDEBAR_STORAGE_KEY, next ? "1" : "0");
    } catch {
      /* ignore */
    }
    onCollapsedChange?.(next);
  }

  const visible = NAV_ITEMS.filter((item) => {
    if (!item.roles) return true;
    return item.roles.includes(role);
  });

  const logoSrc = restaurant?.logoUrl
    ? restaurant.logoUrl.startsWith("http")
      ? restaurant.logoUrl
      : `${API_URL}${restaurant.logoUrl}`
    : null;

  const navContent = (
    <>
      {/* Branding — company logo lockup (matches official DineMate mark) */}
      <div className="border-b border-sidebar-border p-3">
        <div
          className={cn(
            "relative flex items-center gap-2 rounded-xl bg-muted/40 p-2 transition-all duration-200",
            collapsed && !mobileOpen ? "justify-center p-1.5" : "flex-col py-3"
          )}
        >
          <BrandLogo
            variant={collapsed && !mobileOpen ? "sidebar-collapsed" : "sidebar"}
            size="md"
            showName={!collapsed || mobileOpen}
            showTagline={false}
            companyName={APP_NAME}
            customSrc={logoSrc}
            iconOnly={collapsed && !mobileOpen}
            className="min-w-0 w-full"
          />
          {(!collapsed || mobileOpen) && restaurant?.name && restaurant.name !== APP_NAME && (
            <p className="w-full truncate text-center text-[10px] text-muted-foreground px-1">
              {restaurant.name}
              {restaurant.id ? ` · ${restaurant.id}` : ""}
            </p>
          )}
          {mobileOpen && (
            <button
              type="button"
              onClick={onMobileClose}
              className="absolute right-2 top-2 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground transition-colors md:hidden"
              aria-label="Close menu"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Desktop collapse toggle */}
        {!mobileOpen && (
          <button
            type="button"
            onClick={toggle}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className={cn(
              "mt-2 flex w-full items-center justify-center gap-2 rounded-lg border border-sidebar-border bg-background/60 py-1.5 text-xs text-muted-foreground",
              "transition-all duration-150 hover:bg-accent hover:text-foreground active:scale-[0.98]",
              collapsed && "px-0"
            )}
          >
            {collapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <>
                <ChevronLeft className="h-3.5 w-3.5" />
                <span>Collapse</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 space-y-0.5 overflow-y-auto overscroll-contain p-2">
        {visible.map((item) => {
          const active =
            pathname === item.href || pathname.startsWith(item.href + "/");
          const Icon = item.icon;
          const isCollapsed = collapsed && !mobileOpen;
          return (
            <Link
              key={item.href}
              href={item.href}
              title={isCollapsed ? item.label : undefined}
              onClick={() => onMobileClose?.()}
              className={cn(
                "relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium",
                "transition-colors duration-150",
                isCollapsed && "justify-center px-0",
                active
                  ? "text-primary"
                  : "text-muted-foreground hover:bg-accent hover:text-foreground"
              )}
            >
              {active && (
                <motion.div
                  layoutId={mobileOpen ? "nav-active-mobile" : "nav-active"}
                  className="absolute inset-0 rounded-lg bg-primary/10"
                  transition={{ type: "spring", bounce: 0.18, duration: 0.4 }}
                />
              )}
              <Icon className="relative z-10 h-[18px] w-[18px] shrink-0" />
              {!isCollapsed && (
                <span className="relative z-10 truncate">{item.label}</span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* User chip */}
      {(!collapsed || mobileOpen) && user && (
        <div className="px-3 pb-2">
          <div className="rounded-xl bg-muted/50 px-3 py-2">
            <p className="truncate text-xs font-medium">{user.name}</p>
            <p className="truncate text-[10px] capitalize text-muted-foreground">
              {user.role}
            </p>
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="mt-auto border-t border-sidebar-border p-3">
        <div
          className={cn(
            "flex items-center gap-2.5",
            collapsed && !mobileOpen && "flex-col justify-center"
          )}
        >
          <BrandLogo
            variant="sidebar-collapsed"
            size="xs"
            iconOnly
            className="shrink-0"
          />
          {(!collapsed || mobileOpen) && (
            <div className="min-w-0 leading-tight">
              <p className="truncate text-xs font-semibold">{APP_NAME}</p>
              <p className="truncate text-[10px] text-muted-foreground">
                v{APP_VERSION} · © {new Date().getFullYear()}
              </p>
            </div>
          )}
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-0 z-40 hidden h-screen flex-col border-r border-sidebar-border bg-sidebar",
          "transition-[width] duration-300 ease-spring md:flex",
          collapsed ? "w-[72px]" : "w-60"
        )}
      >
        {navContent}
      </aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              key="overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
              className="fixed inset-0 z-50 bg-black/50 backdrop-blur-[4px] md:hidden"
              onClick={onMobileClose}
              aria-hidden
            />
            <motion.aside
              key="drawer"
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              className="fixed left-0 top-0 z-50 flex h-screen w-[min(280px,85vw)] flex-col border-r border-sidebar-border bg-sidebar shadow-floating md:hidden"
            >
              {navContent}
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
