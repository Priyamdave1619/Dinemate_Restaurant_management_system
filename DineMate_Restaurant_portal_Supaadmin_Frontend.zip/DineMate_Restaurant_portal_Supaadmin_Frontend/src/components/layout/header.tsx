"use client";
import {
  Moon, Sun, Bell, User, CreditCard, Settings, LogOut, ChevronDown, Menu,
} from "lucide-react";
import { GlobalSearch } from "@/components/layout/global-search";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { usePathname, useRouter } from "next/navigation";
import { useAuthStore } from "@/lib/stores/auth-store";
import { useQuery } from "@tanstack/react-query";
import { listNotifications } from "@/lib/api/restaurant";
import { logout as apiLogout } from "@/lib/api/auth";
import { toast } from "sonner";
import Link from "next/link";
import { useState, useRef, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils/cn";
import { AnimatePresence, motion } from "framer-motion";

const titles: Record<string, string> = {
  "/dashboard": "Dashboard",
  "/orders": "Orders",
  "/menu": "Menu",
  "/tables": "Tables & QR",
  "/staff": "Staff",
  "/finance": "Finance",
  "/offers": "Offers",
  "/notifications": "Notifications",
  "/settings": "Settings",
  "/subscription": "Subscription",
  "/profile": "Profile",
  "/reports": "Reports",
  "/activity": "Activity Log",
};

interface HeaderProps {
  onMenuClick?: () => void;
}

export function Header({ onMenuClick }: HeaderProps) {
  const { theme, setTheme } = useTheme();
  const pathname = usePathname();
  const router = useRouter();
  const { user, restaurant, clearAuth, refreshToken } = useAuthStore();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const title =
    Object.entries(titles).find(
      ([k]) => pathname === k || pathname.startsWith(k + "/")
    )?.[1] || "Restaurant";

  const { data: notifications } = useQuery({
    queryKey: ["notifications-header"],
    queryFn: () => listNotifications({ unread: "1" }),
    refetchInterval: 30000,
  });
  const unread = notifications?.length ?? 0;

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  async function handleLogout() {
    try {
      await apiLogout(refreshToken || undefined);
    } catch {
      /* */
    }
    clearAuth();
    toast.success("Logged out");
    router.push("/login");
  }

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b bg-background/80 px-3 backdrop-blur-xl sm:gap-3 sm:px-5 safe-top">
      {/* Mobile menu button */}
      <Button
        variant="ghost"
        size="icon-sm"
        className="shrink-0 md:hidden"
        onClick={onMenuClick}
        aria-label="Open menu"
      >
        <Menu className="h-5 w-5" />
      </Button>

      <h1 className="min-w-0 flex-1 truncate text-base font-semibold tracking-tight sm:text-lg">
        {title}
      </h1>

      <GlobalSearch />

      <Link href="/notifications">
        <Button variant="ghost" size="icon-sm" className="relative sm:h-10 sm:w-10">
          <Bell className="h-4 w-4" />
          {unread > 0 && (
            <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
              {unread > 9 ? "9+" : unread}
            </span>
          )}
        </Button>
      </Link>

      <Button
        variant="ghost"
        size="icon-sm"
        className="relative sm:h-10 sm:w-10"
        onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
        aria-label="Toggle theme"
      >
        <Sun className="h-4 w-4 rotate-0 scale-100 transition-all duration-300 dark:-rotate-90 dark:scale-0" />
        <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all duration-300 dark:rotate-0 dark:scale-100" />
      </Button>

      <div className="relative" ref={menuRef}>
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className={cn(
            "flex items-center gap-2 rounded-lg px-1.5 py-1 text-sm",
            "transition-colors duration-150 hover:bg-accent active:scale-[0.98] sm:px-2 sm:py-1.5"
          )}
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/15 text-xs font-bold text-primary">
            {(user?.name || "U").slice(0, 1).toUpperCase()}
          </div>
          <div className="hidden text-left sm:block">
            <p className="text-xs font-medium leading-none">{user?.name}</p>
            <p className="mt-0.5 text-[10px] capitalize text-muted-foreground">
              {user?.role}
            </p>
          </div>
          <ChevronDown
            className={cn(
              "hidden h-3.5 w-3.5 text-muted-foreground transition-transform duration-200 sm:block",
              menuOpen && "rotate-180"
            )}
          />
        </button>

        <AnimatePresence>
          {menuOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: -4 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: -2 }}
              transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
              className="absolute right-0 mt-2 w-56 overflow-hidden rounded-xl border bg-card shadow-floating origin-top-right"
            >
              <div className="border-b px-3 py-2.5">
                <p className="text-sm font-medium">{user?.name}</p>
                <p className="text-xs text-muted-foreground">{restaurant?.name}</p>
                {restaurant?.subscriptionStatus && (
                  <Badge variant="secondary" className="mt-1 text-[10px]">
                    {restaurant.subscriptionStatus}
                  </Badge>
                )}
              </div>
              <div className="p-1">
                <Link
                  href="/profile"
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors hover:bg-accent"
                >
                  <User className="h-4 w-4" /> My Profile
                </Link>
                {user?.role === "owner" && (
                  <Link
                    href="/subscription"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors hover:bg-accent"
                  >
                    <CreditCard className="h-4 w-4" /> Subscription
                  </Link>
                )}
                <Link
                  href="/settings"
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors hover:bg-accent"
                >
                  <Settings className="h-4 w-4" /> Settings
                </Link>
              </div>
              <div className="border-t p-1">
                <button
                  onClick={handleLogout}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-destructive transition-colors hover:bg-destructive/10"
                >
                  <LogOut className="h-4 w-4" /> Logout
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  );
}
