"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useRouter } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import {
  Search,
  X,
  Receipt,
  UtensilsCrossed,
  Loader2,
  ArrowRight,
  LayoutDashboard,
} from "lucide-react";
import { listOrders, listMenu } from "@/lib/api/restaurant";
import { validateSearch } from "@/lib/security/validators";
import { cn } from "@/lib/utils/cn";

interface GlobalSearchProps {
  className?: string;
}

/**
 * Header quick-search: opens with a click or Cmd/Ctrl+K.
 * Searches Orders (server) and Menu items (client), navigates on select.
 */
export function GlobalSearch({ className }: GlobalSearchProps) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [raw, setRaw] = useState("");
  const [debounced, setDebounced] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(raw), 300);
    return () => clearTimeout(t);
  }, [raw]);

  const safeQuery = useMemo(() => {
    const r = validateSearch(debounced);
    return r ?? "";
  }, [debounced]);

  const enabled = open && safeQuery.length >= 2;

  const { data: orderResults, isFetching: ordersLoading } = useQuery({
    queryKey: ["global-search-orders", safeQuery],
    queryFn: () => listOrders({ search: safeQuery, pageSize: 5 }),
    enabled,
    staleTime: 15_000,
  });

  const { data: menuItems, isFetching: menuLoading } = useQuery({
    queryKey: ["global-search-menu"],
    queryFn: () => listMenu(),
    enabled: open,
    staleTime: 60_000,
  });

  const menuResults = useMemo(() => {
    if (!enabled || !menuItems) return [];
    const q = safeQuery.toLowerCase();
    return menuItems
      .filter((item) => item.name.toLowerCase().includes(q))
      .slice(0, 8);
  }, [menuItems, safeQuery, enabled]);

  const orders = orderResults?.orders ?? [];
  const loading = enabled && (ordersLoading || menuLoading);
  const hasResults = orders.length > 0 || menuResults.length > 0;

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "Escape" && open) {
        e.preventDefault();
        setOpen(false);
      }
    }
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [open]);

  // Lock body scroll while open
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  useEffect(() => {
    if (open) {
      const t = setTimeout(() => inputRef.current?.focus(), 40);
      return () => clearTimeout(t);
    }
    setRaw("");
    setDebounced("");
  }, [open]);

  function goTo(path: string) {
    setOpen(false);
    router.push(path);
  }

  const modal =
    open && mounted
      ? createPortal(
          <AnimatePresence>
            {open && (
              <div className="fixed inset-0 z-[100] flex items-start justify-center px-4 pt-[10vh] sm:pt-[12vh]">
                {/* Backdrop — click closes */}
                <motion.button
                  type="button"
                  aria-label="Close search"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.15 }}
                  className="absolute inset-0 bg-black/40 backdrop-blur-sm"
                  onClick={() => setOpen(false)}
                />

                {/* Panel */}
                <motion.div
                  ref={panelRef}
                  role="dialog"
                  aria-modal="true"
                  aria-label="Global search"
                  initial={{ opacity: 0, scale: 0.96, y: -12 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.96, y: -8 }}
                  transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
                  className="relative z-[101] w-full max-w-xl overflow-hidden rounded-2xl border border-border/80 bg-background shadow-2xl"
                  onClick={(e) => e.stopPropagation()}
                >
                  {/* Search field */}
                  <div className="flex items-center gap-3 border-b border-border/70 px-4 py-3.5">
                    <Search className="h-5 w-5 shrink-0 text-muted-foreground" />
                    <input
                      ref={inputRef}
                      value={raw}
                      onChange={(e) => setRaw(e.target.value)}
                      placeholder="Search orders, menu items…"
                      className="h-7 flex-1 bg-transparent text-[15px] outline-none placeholder:text-muted-foreground/70"
                      autoComplete="off"
                      spellCheck={false}
                    />
                    {loading && (
                      <Loader2 className="h-4 w-4 shrink-0 animate-spin text-muted-foreground" />
                    )}
                    {raw && !loading && (
                      <button
                        type="button"
                        onClick={() => {
                          setRaw("");
                          setDebounced("");
                          inputRef.current?.focus();
                        }}
                        className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
                        aria-label="Clear"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    )}
                    <kbd className="hidden shrink-0 rounded-md border bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground sm:inline-block">
                      ESC
                    </kbd>
                  </div>

                  {/* Results */}
                  <div className="max-h-[min(60vh,420px)] overflow-y-auto overscroll-contain p-2">
                    {safeQuery.length < 2 && (
                      <div className="space-y-1 px-1 py-2">
                        <p className="px-3 pb-2 text-xs text-muted-foreground">
                          Type at least 2 characters, or jump to a page:
                        </p>
                        <QuickLink
                          icon={<UtensilsCrossed className="h-4 w-4" />}
                          label="Menu"
                          hint="Products & categories"
                          onClick={() => goTo("/menu")}
                        />
                        <QuickLink
                          icon={<Receipt className="h-4 w-4" />}
                          label="Orders"
                          hint="Live & past orders"
                          onClick={() => goTo("/orders")}
                        />
                        <QuickLink
                          icon={<LayoutDashboard className="h-4 w-4" />}
                          label="Dashboard"
                          hint="Overview"
                          onClick={() => goTo("/")}
                        />
                      </div>
                    )}

                    {safeQuery.length >= 2 && !loading && !hasResults && (
                      <div className="px-3 py-10 text-center">
                        <Search className="mx-auto mb-3 h-8 w-8 text-muted-foreground/40" />
                        <p className="text-sm font-medium text-foreground">
                          No results for &ldquo;{safeQuery}&rdquo;
                        </p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          Try another name, table number, or bill id
                        </p>
                      </div>
                    )}

                    {orders.length > 0 && (
                      <section className="mb-1">
                        <p className="px-3 pb-1.5 pt-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                          Orders
                        </p>
                        {orders.map((order) => (
                          <button
                            key={order.id}
                            type="button"
                            onClick={() => goTo("/orders")}
                            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm transition-colors hover:bg-accent"
                          >
                            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted">
                              <Receipt className="h-4 w-4 text-muted-foreground" />
                            </span>
                            <span className="min-w-0 flex-1">
                              <span className="block truncate font-medium">
                                Table {order.tableNumber}
                                {order.customerName ? ` · ${order.customerName}` : ""}
                              </span>
                              <span className="block truncate text-xs capitalize text-muted-foreground">
                                {order.status}
                              </span>
                            </span>
                            <ArrowRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground/50" />
                          </button>
                        ))}
                      </section>
                    )}

                    {menuResults.length > 0 && (
                      <section className="mb-1">
                        <p className="px-3 pb-1.5 pt-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                          Menu items
                        </p>
                        {menuResults.map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => goTo("/menu")}
                            className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm transition-colors hover:bg-accent"
                          >
                            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted">
                              <UtensilsCrossed className="h-4 w-4 text-muted-foreground" />
                            </span>
                            <span className="min-w-0 flex-1 truncate font-medium">
                              {item.name}
                            </span>
                            <span className="shrink-0 text-xs font-medium tabular-nums text-muted-foreground">
                              ₹{item.price}
                            </span>
                          </button>
                        ))}
                      </section>
                    )}
                  </div>

                  {/* Footer hint */}
                  <div className="flex items-center justify-between border-t border-border/70 bg-muted/30 px-4 py-2 text-[11px] text-muted-foreground">
                    <span>
                      <kbd className="rounded border bg-background px-1 py-0.5 font-mono text-[10px]">
                        ↑↓
                      </kbd>{" "}
                      navigate ·{" "}
                      <kbd className="rounded border bg-background px-1 py-0.5 font-mono text-[10px]">
                        ↵
                      </kbd>{" "}
                      open
                    </span>
                    <span>
                      <kbd className="rounded border bg-background px-1 py-0.5 font-mono text-[10px]">
                        esc
                      </kbd>{" "}
                      close
                    </span>
                  </div>
                </motion.div>
              </div>
            )}
          </AnimatePresence>,
          document.body
        )
      : null;

  return (
    <div className={cn("relative", className)}>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="hidden items-center gap-2 rounded-lg border bg-muted/40 px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:border-muted-foreground/30 hover:bg-muted/60 lg:flex"
      >
        <Search className="h-3.5 w-3.5" />
        <span className="text-xs">Quick search…</span>
        <kbd className="ml-2 rounded border bg-background px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
          ⌘K
        </kbd>
      </button>
      {modal}
    </div>
  );
}

function QuickLink({
  icon,
  label,
  hint,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  hint: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors hover:bg-accent"
    >
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground">
        {icon}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-sm font-medium">{label}</span>
        <span className="block text-xs text-muted-foreground">{hint}</span>
      </span>
      <ArrowRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground/40" />
    </button>
  );
}
