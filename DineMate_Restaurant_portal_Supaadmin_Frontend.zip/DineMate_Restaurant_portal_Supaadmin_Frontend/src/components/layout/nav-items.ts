import {
  LayoutDashboard, UtensilsCrossed, Armchair, ClipboardList, Users,
  Wallet, Tag, Settings, Bell, CreditCard, UserCircle, BarChart3, Activity,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export type NavItem = {
  href: string;
  label: string;
  icon: LucideIcon;
  roles?: string[];
};

export const NAV_ITEMS: NavItem[] = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/orders", label: "Orders", icon: ClipboardList },
  { href: "/menu", label: "Menu", icon: UtensilsCrossed },
  { href: "/tables", label: "Tables & QR", icon: Armchair },
  { href: "/staff", label: "Staff", icon: Users, roles: ["owner", "manager"] },
  { href: "/finance", label: "Finance", icon: Wallet, roles: ["owner", "manager"] },
  { href: "/offers", label: "Offers", icon: Tag, roles: ["owner", "manager"] },
  { href: "/reports", label: "Reports", icon: BarChart3, roles: ["owner", "manager"] },
  { href: "/subscription", label: "Subscription", icon: CreditCard, roles: ["owner"] },
  { href: "/notifications", label: "Alerts", icon: Bell },
  { href: "/activity", label: "Activity", icon: Activity, roles: ["owner", "manager"] },
  { href: "/profile", label: "Profile", icon: UserCircle },
  { href: "/settings", label: "Settings", icon: Settings },
];

export const SIDEBAR_STORAGE_KEY = "dinemate-sidebar-collapsed";
export const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME || "DineMate";
export const APP_VERSION = "1.0.0";
