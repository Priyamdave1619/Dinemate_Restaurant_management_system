import type { ReactNode } from "react";

export type SortDir = "asc" | "desc";

export interface PaginationMeta {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export interface ColumnDef<T> {
  id: string;
  header: string;
  /** Accessor for client-side sort/search; optional if you only render */
  accessor?: (row: T) => string | number | boolean | null | undefined;
  sortable?: boolean;
  className?: string;
  headerClassName?: string;
  cell: (row: T) => ReactNode;
}

export const PAGE_SIZE_OPTIONS = [10, 50, 200, 400, 1000] as const;
export type PageSizeOption = (typeof PAGE_SIZE_OPTIONS)[number];
export const DEFAULT_PAGE_SIZE: PageSizeOption = 10;
