"use client";

import { cn } from "@/lib/utils/cn";
import { DataTableToolbar } from "./data-table-toolbar";
import { DataTablePagination } from "./data-table-pagination";
import type { PageSize, SortDir } from "@/hooks/use-data-table";
import { EmptyState } from "@/components/shared/empty-state";
import { TableSkeleton } from "@/components/shared/loaders";
import { Search } from "lucide-react";

type Props = {
  /** Search box */
  search: string;
  onSearchChange: (v: string) => void;
  searchPlaceholder?: string;
  onClearFilters?: () => void;
  hasActiveFilters?: boolean;
  toolbarExtra?: React.ReactNode;

  /** Pagination */
  page: number;
  pageSize: PageSize;
  total: number;
  totalPages: number;
  from: number;
  to: number;
  onPageChange: (page: number) => void;
  onPageSizeChange: (size: PageSize) => void;

  /** Table body */
  loading?: boolean;
  skeletonRows?: number;
  skeletonCols?: number;
  emptyTitle?: string;
  emptyDescription?: string;
  emptyAction?: React.ReactNode;

  children: React.ReactNode;
  className?: string;
};

/**
 * Enterprise data table shell: toolbar + sticky scroll area + pagination.
 * Pass a <table> as children.
 */
export function DataTable({
  search,
  onSearchChange,
  searchPlaceholder,
  onClearFilters,
  hasActiveFilters,
  toolbarExtra,
  page,
  pageSize,
  total,
  totalPages,
  from,
  to,
  onPageChange,
  onPageSizeChange,
  loading,
  skeletonRows = 6,
  skeletonCols = 5,
  emptyTitle = "No records found",
  emptyDescription = "Try adjusting search or filters",
  emptyAction,
  children,
  className,
}: Props) {
  return (
    <div
      className={cn(
        "overflow-hidden rounded-xl border border-border/60 bg-card shadow-soft",
        className
      )}
    >
      <div className="border-b border-border/60 p-3 sm:p-4">
        <DataTableToolbar
          search={search}
          onSearchChange={onSearchChange}
          placeholder={searchPlaceholder}
          onClear={onClearFilters}
          hasActiveFilters={hasActiveFilters}
        >
          {toolbarExtra}
        </DataTableToolbar>
      </div>

      {loading ? (
        <div className="p-2">
          <TableSkeleton rows={skeletonRows} cols={skeletonCols} />
        </div>
      ) : total === 0 ? (
        <div className="p-6">
          <EmptyState
            icon={Search}
            title={emptyTitle}
            description={emptyDescription}
            action={emptyAction}
          />
        </div>
      ) : (
        <div className="table-scroll table-sticky">{children}</div>
      )}

      <DataTablePagination
        page={page}
        pageSize={pageSize}
        total={total}
        totalPages={totalPages}
        from={from}
        to={to}
        onPageChange={onPageChange}
        onPageSizeChange={onPageSizeChange}
      />
    </div>
  );
}

export type { PageSize, SortDir };
