"use client";

import { cn } from "@/lib/utils/cn";
import type { LucideIcon } from "lucide-react";
import { Inbox } from "lucide-react";
import { BrandLogo } from "@/components/branding";

interface EmptyStateProps {
  icon?: LucideIcon;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
  /** Show brand mark instead of icon */
  branded?: boolean;
}

export function EmptyState({
  icon: Icon = Inbox,
  title,
  description,
  action,
  className,
  branded = false,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center px-4 py-12 text-center animate-fade-in",
        className
      )}
      role="status"
      aria-live="polite"
    >
      {branded ? (
        <div className="mb-4">
          <BrandLogo variant="empty" size="md" iconOnly />
        </div>
      ) : (
        <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
          <Icon className="h-6 w-6" aria-hidden />
        </div>
      )}
      <p className="text-sm font-medium text-foreground">{title}</p>
      {description && (
        <p className="mt-1 max-w-sm text-sm text-muted-foreground">{description}</p>
      )}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
