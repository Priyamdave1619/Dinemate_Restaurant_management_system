export function FieldError({
  id,
  message,
}: {
  id?: string;
  message?: string;
}) {
  if (!message) return null;
  return (
    <p id={id} className="text-xs text-destructive animate-fade-in" role="alert">
      {message}
    </p>
  );
}
