"use client";

import { useMemo } from "react";
import { cn } from "@/lib/utils/cn";

interface PasswordStrengthProps {
  password: string;
  className?: string;
}

type Strength = 0 | 1 | 2 | 3 | 4;

function scorePassword(pw: string): Strength {
  if (!pw) return 0;
  let s = 0;
  if (pw.length >= 12) s++;
  if (pw.length >= 16) s++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++;
  if (/[0-9]/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  // Cap at 4
  return Math.min(4, s) as Strength;
}

const LABELS = ["", "Weak", "Fair", "Good", "Strong"] as const;
const COLORS = [
  "bg-muted",
  "bg-destructive",
  "bg-amber-500",
  "bg-emerald-500",
  "bg-primary",
] as const;

export function PasswordStrength({ password, className }: PasswordStrengthProps) {
  const score = useMemo(() => scorePassword(password), [password]);
  if (!password) return null;

  return (
    <div className={cn("space-y-1.5", className)} aria-live="polite">
      <div className="flex gap-1" role="meter" aria-valuenow={score} aria-valuemin={0} aria-valuemax={4} aria-label="Password strength">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={cn(
              "h-1.5 flex-1 rounded-full transition-colors duration-200",
              i <= score ? COLORS[score] : "bg-muted"
            )}
          />
        ))}
      </div>
      <p
        className={cn(
          "text-[11px] font-medium",
          score <= 1 && "text-destructive",
          score === 2 && "text-amber-600 dark:text-amber-400",
          score >= 3 && "text-emerald-600 dark:text-emerald-400"
        )}
      >
        {LABELS[score]}
        {score < 4 && (
          <span className="font-normal text-muted-foreground">
            {" "}
            — use 12+ chars with upper, lower, number & symbol
          </span>
        )}
      </p>
    </div>
  );
}
