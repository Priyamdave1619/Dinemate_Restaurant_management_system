"use client";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils/cn";
import type { LucideIcon } from "lucide-react";
import { motion } from "framer-motion";

interface StatCardProps {
  label: string;
  value: React.ReactNode;
  icon: LucideIcon;
  color?: string;
  bg?: string;
  index?: number;
  className?: string;
}

export function StatCard({
  label,
  value,
  icon: Icon,
  color = "text-primary",
  bg = "bg-primary/10",
  index = 0,
  className,
}: StatCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04, duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      <Card className="card-interactive h-full overflow-hidden">
        {/* py-5 overrides default pt-0 so content is vertically balanced */}
        <CardContent className="flex items-center justify-between gap-3 py-5">
          <div className="min-w-0 flex-1 space-y-2">
            <p className="truncate text-xs font-medium leading-none text-muted-foreground">
              {label}
            </p>
            <p className="truncate text-2xl font-bold leading-none tracking-tight">
              {value}
            </p>
          </div>
          <div
            className={cn(
              "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl",
              bg
            )}
          >
            <Icon className={cn("h-5 w-5", color)} />
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
