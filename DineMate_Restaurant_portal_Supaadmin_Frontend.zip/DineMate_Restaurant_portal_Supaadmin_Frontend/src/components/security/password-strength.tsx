"use client";

import { useMemo } from "react";
import { passwordStrength } from "@/lib/security/validators";
import { cn } from "@/lib/utils/cn";

interface PasswordStrengthMeterProps {
  password: string;
  className?: string;
}

const COLORS = [
  "bg-muted",
  "bg-destructive",
  "bg-amber-500",
  "bg-emerald-500",
  "bg-primary",
] as const;

export function PasswordStrengthMeter({ password, className }: PasswordStrengthMeterProps) {
  const result = useMemo(() => passwordStrength(password), [password]);

  if (!password) return null;

  const { score, label, feedback } = result;

  return (
    <div className={cn("space-y-1.5", className)} aria-live="polite">
      <div
        className="flex gap-1"
        role="meter"
        aria-valuenow={score}
        aria-valuemin={0}
        aria-valuemax={4}
        aria-label="Password strength"
      >
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={cn(
              "h-1.5 flex-1 rounded-full transition-colors duration-200",
              i <= score ? COLORS[score] : "bg-muted"
            )}
          />
        ))}
      </div>

      {label && (
        <p
          className={cn(
            "text-[11px] font-medium",
            score <= 1 && "text-destructive",
            score === 2 && "text-amber-600 dark:text-amber-400",
            score >= 3 && "text-emerald-600 dark:text-emerald-400"
          )}
        >
          {label}
        </p>
      )}

      {feedback.length > 0 && (
        <ul className="space-y-0.5">
          {feedback.map((tip) => (
            <li key={tip} className="text-[11px] text-muted-foreground">
              • {tip}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
