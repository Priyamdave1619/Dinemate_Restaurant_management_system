"use client";

import Image from "next/image";
import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils/cn";

const LOGO_LIGHT = "/logos/logo-gold.png";
const LOGO_DARK = "/logos/logo-blue.png";

type LogoProps = {
  /** full = login size; compact = sidebar expanded; icon = sidebar collapsed / header */
  variant?: "full" | "compact" | "icon";
  className?: string;
  priority?: boolean;
};

/**
 * Theme-aware DineMate company logo (instant switch, no animation).
 * - Light mode → gold mark
 * - Dark mode  → navy/blue mark
 */
export function Logo({ variant = "full", className, priority }: LogoProps) {
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const a = new window.Image();
    const b = new window.Image();
    a.src = LOGO_LIGHT;
    b.src = LOGO_DARK;
  }, []);

  const isDark = mounted && resolvedTheme === "dark";
  const src = isDark ? LOGO_DARK : LOGO_LIGHT;

  if (variant === "icon") {
    return (
      <div
        className={cn(
          "relative flex h-11 w-11 items-center justify-center overflow-hidden rounded-xl",
          className
        )}
      >
        <Image
          src={src}
          alt="DineMate"
          width={64}
          height={64}
          className="h-full w-full object-contain object-center"
          priority={priority}
        />
      </div>
    );
  }

  if (variant === "compact") {
    return (
      <div className={cn("relative flex w-full items-center justify-center overflow-hidden h-16", className)}>
        <Image
          src={src}
          alt="DineMate"
          width={220}
          height={100}
          className="h-16 w-auto max-w-full object-contain"
          priority={priority}
        />
      </div>
    );
  }

  return (
    <div className={cn("relative mx-auto w-full max-w-[280px]", className)}>
      <Image
        src={src}
        alt="DineMate"
        width={320}
        height={180}
        className="h-auto w-full object-contain"
        priority={priority}
      />
    </div>
  );
}
