"use client";
import { useEffect, useRef, useState } from "react";
import type { QrStyleConfig } from "@/lib/qr-style";
import { cn } from "@/lib/utils/cn";
import { api } from "@/lib/api/client";

type Props = {
  dataUrl: string | null;
  tableNumber: number;
  restaurantName?: string;
  address?: string;
  logoSrc?: string | null;
  style: QrStyleConfig;
  className?: string;
  id?: string;
  error?: string | null;
};

/**
 * Print-ready QR table card.
 * Uses fixed card proportions so Print and on-screen preview match.
 */
export function QrPreviewCard({
  dataUrl,
  tableNumber,
  restaurantName,
  address,
  logoSrc,
  style,
  className,
  id,
  error,
}: Props) {
  const frameClass =
    style.frameStyle === "double"
      ? "ring-2 ring-offset-4"
      : style.frameStyle === "dashed"
        ? "border-2 border-dashed"
        : style.frameStyle === "simple"
          ? "border border-black/10 shadow-lg"
          : "shadow-md";

  // Scale QR for display: clamp so card stays balanced on screen
  const qrDisplay = Math.min(Math.max(style.qrSize, 180), 280);

  return (
    <div
      id={id}
      className={cn("qr-table-card mx-auto overflow-hidden text-center", className)}
      style={{
        background: style.cardBg,
        borderRadius: style.borderRadius,
        color: style.textColor,
        width: "100%",
        maxWidth: 360,
        padding: "28px 24px 32px",
        boxSizing: "border-box",
      }}
    >
      {style.showLogo && logoSrc && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={logoSrc}
          alt=""
          className="qr-card-logo mx-auto mb-3 object-cover"
          style={{ width: 56, height: 56, borderRadius: 12 }}
        />
      )}
      {style.showRestaurantName && restaurantName && (
        <p
          className="qr-card-name mb-1 font-bold tracking-tight"
          style={{ color: style.textColor, fontSize: 15, lineHeight: 1.3 }}
        >
          {restaurantName}
        </p>
      )}
      {style.showTableLabel && (
        <p
          className="qr-card-table mb-4 font-extrabold tracking-tight"
          style={{ color: style.accentColor, fontSize: 28, lineHeight: 1.15 }}
        >
          Table {tableNumber}
        </p>
      )}

      <div
        className={cn("qr-card-frame mx-auto inline-flex bg-white p-3", frameClass)}
        style={{
          borderRadius: Math.max(8, style.borderRadius / 2),
          // @ts-expect-error css custom property for ring
          "--tw-ring-color": style.accentColor,
        }}
      >
        {dataUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={dataUrl}
            alt={`QR Table ${tableNumber}`}
            width={qrDisplay}
            height={qrDisplay}
            className="qr-card-img block"
            style={{ width: qrDisplay, height: qrDisplay }}
          />
        ) : error ? (
          <div
            className="flex items-center justify-center text-xs text-red-600"
            style={{ width: qrDisplay, height: qrDisplay }}
          >
            {error}
          </div>
        ) : (
          <div
            className="animate-pulse bg-muted"
            style={{ width: qrDisplay, height: qrDisplay }}
          />
        )}
      </div>

      {style.showAddress && address && (
        <p
          className="qr-card-address mx-auto mt-3 text-xs opacity-70"
          style={{ maxWidth: 260, lineHeight: 1.4 }}
        >
          {address}
        </p>
      )}
      {style.showWelcome && style.welcomeMessage && (
        <p
          className="qr-card-welcome mt-4 font-medium opacity-80"
          style={{ fontSize: 13 }}
        >
          {style.welcomeMessage}
        </p>
      )}
    </div>
  );
}

/** Generate QR data URL via API or client fallback */
export function useQrDataUrl(
  url: string | undefined,
  style: QrStyleConfig,
  tableId?: string,
  /** When true (e.g. after Regenerate), force server to rebuild PNG */
  forceServerRefresh?: boolean
) {
  const [dataUrl, setDataUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const genRef = useRef(0);

  useEffect(() => {
    if (!url) {
      setDataUrl(null);
      return;
    }
    const gen = ++genRef.current;
    setError(null);
    setDataUrl(null);

    let cancelled = false;

    async function run() {
      try {
        // Prefer client-side encode of the *current* url so preview always
        // matches the link shown (encrypted token after regenerate).
        // Server PNG is used only when client encode is unavailable.
        try {
          const QRCode = (await import("qrcode")).default;
          if (cancelled || gen !== genRef.current) return;
          const data = await QRCode.toDataURL(url!, {
            width: Math.max(256, style.qrSize * 2),
            margin: style.qrMargin ?? 2,
            errorCorrectionLevel: style.errorCorrectionLevel || "M",
            color: {
              dark: style.fgColor || "#000000",
              light: style.bgColor || "#ffffff",
            },
          });
          if (!cancelled && gen === genRef.current) {
            setDataUrl(data);
            // Best-effort: refresh server cache in background after regenerate
            if (forceServerRefresh && tableId) {
              void api.get(`/api/tables/${tableId}/qr`, {
                params: { format: "png", regenerate: "1" },
                responseType: "blob",
              }).catch(() => undefined);
            }
            return;
          }
        } catch {
          /* fall through to server PNG */
        }

        if (tableId) {
          try {
            const res = await api.get(`/api/tables/${tableId}/qr`, {
              params: {
                format: "png",
                ...(forceServerRefresh ? { regenerate: "1" } : {}),
              },
              responseType: "blob",
            });
            if (cancelled || gen !== genRef.current) return;
            const blob = res.data as Blob;
            if (blob && blob.size > 0) {
              const reader = new FileReader();
              reader.onload = () => {
                if (!cancelled && gen === genRef.current) {
                  setDataUrl(reader.result as string);
                }
              };
              reader.readAsDataURL(blob);
              return;
            }
          } catch {
            /* fall through to client QR */
          }
        }

        // Client-side QR via dynamic import of qrcode if available
        try {
          const QRCode = (await import("qrcode")).default;
          if (cancelled || gen !== genRef.current) return;
          const data = await QRCode.toDataURL(url!, {
            width: Math.max(256, style.qrSize * 2),
            margin: style.qrMargin ?? 2,
            errorCorrectionLevel: style.errorCorrectionLevel || "M",
            color: {
              dark: style.fgColor || "#000000",
              light: style.bgColor || "#ffffff",
            },
          });
          if (!cancelled && gen === genRef.current) setDataUrl(data);
        } catch {
          // Last resort: Google Charts API (offline-safe fallback not available)
          if (!cancelled && gen === genRef.current) {
            const size = Math.max(256, style.qrSize * 2);
            const chart = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(url!)}`;
            setDataUrl(chart);
          }
        }
      } catch (e) {
        if (!cancelled && gen === genRef.current) {
          setError(e instanceof Error ? e.message : "Failed to generate QR");
        }
      }
    }

    run();
    return () => {
      cancelled = true;
    };
  }, [
    url,
    tableId,
    forceServerRefresh,
    style.qrSize,
    style.qrMargin,
    style.errorCorrectionLevel,
    style.fgColor,
    style.bgColor,
  ]);

  return { dataUrl, error };
}
