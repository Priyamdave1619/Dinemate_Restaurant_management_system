"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

export const PAGE_SIZE_OPTIONS = [10, 50, 200, 400, 1000] as const;
export type PageSize = (typeof PAGE_SIZE_OPTIONS)[number];

const STORAGE_KEY = "dinemate-table-page-size";

export function loadPageSize(defaultSize: PageSize = 10): PageSize {
  if (typeof window === "undefined") return defaultSize;
  try {
    const n = Number(localStorage.getItem(STORAGE_KEY));
    if ((PAGE_SIZE_OPTIONS as readonly number[]).includes(n)) return n as PageSize;
  } catch {
    /* ignore */
  }
  return defaultSize;
}

export function savePageSize(size: PageSize) {
  try {
    localStorage.setItem(STORAGE_KEY, String(size));
  } catch {
    /* ignore */
  }
}

export type SortDir = "asc" | "desc";

export type DataTableState = {
  page: number;
  pageSize: PageSize;
  search: string;
  debouncedSearch: string;
  sortBy: string | null;
  sortDir: SortDir;
  setPage: (p: number) => void;
  setPageSize: (s: PageSize) => void;
  setSearch: (q: string) => void;
  toggleSort: (column: string) => void;
  resetFilters: () => void;
};

export function useDataTableState(opts?: {
  defaultPageSize?: PageSize;
  debounceMs?: number;
}): DataTableState {
  const [page, setPage] = useState(1);
  const [pageSize, setPageSizeState] = useState<PageSize>(10);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [sortBy, setSortBy] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<SortDir>("asc");

  useEffect(() => {
    setPageSizeState(loadPageSize(opts?.defaultPageSize ?? 10));
  }, [opts?.defaultPageSize]);

  useEffect(() => {
    const ms = opts?.debounceMs ?? 350;
    const t = setTimeout(() => setDebouncedSearch(search.trim()), ms);
    return () => clearTimeout(t);
  }, [search, opts?.debounceMs]);

  // Reset to page 1 when search or page size changes
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, pageSize]);

  const setPageSize = useCallback((s: PageSize) => {
    setPageSizeState(s);
    savePageSize(s);
    setPage(1);
  }, []);

  const toggleSort = useCallback((column: string) => {
    setSortBy((prev) => {
      if (prev === column) {
        setSortDir((d) => (d === "asc" ? "desc" : "asc"));
        return column;
      }
      setSortDir("asc");
      return column;
    });
    setPage(1);
  }, []);

  const resetFilters = useCallback(() => {
    setSearch("");
    setDebouncedSearch("");
    setSortBy(null);
    setSortDir("asc");
    setPage(1);
  }, []);

  return {
    page,
    pageSize,
    search,
    debouncedSearch,
    sortBy,
    sortDir,
    setPage,
    setPageSize,
    setSearch,
    toggleSort,
    resetFilters,
  };
}

/** Client-side filter + sort + paginate */
export function useClientTable<T>(
  rows: T[] | undefined,
  opts: {
    state: DataTableState;
    /** Columns to search (string keys or getter) */
    searchKeys?: (keyof T | ((row: T) => string | number | null | undefined))[];
    /** Optional extra filter predicate */
    filterFn?: (row: T) => boolean;
  }
) {
  const { state, searchKeys, filterFn } = opts;

  const processed = useMemo(() => {
    let list = rows ? [...rows] : [];
    if (filterFn) list = list.filter(filterFn);

    const q = state.debouncedSearch.toLowerCase();
    if (q && searchKeys?.length) {
      list = list.filter((row) =>
        searchKeys.some((key) => {
          const val =
            typeof key === "function" ? key(row) : (row[key] as unknown);
          return String(val ?? "")
            .toLowerCase()
            .includes(q);
        })
      );
    }

    if (state.sortBy) {
      const key = state.sortBy as keyof T;
      const dir = state.sortDir === "asc" ? 1 : -1;
      list.sort((a, b) => {
        const av = a[key] as unknown;
        const bv = b[key] as unknown;
        if (typeof av === "number" && typeof bv === "number") return (av - bv) * dir;
        return String(av ?? "").localeCompare(String(bv ?? ""), undefined, {
          numeric: true,
          sensitivity: "base",
        }) * dir;
      });
    }

    return list;
  }, [rows, state.debouncedSearch, state.sortBy, state.sortDir, searchKeys, filterFn]);

  const total = processed.length;
  const totalPages = Math.max(1, Math.ceil(total / state.pageSize));
  const safePage = Math.min(state.page, totalPages);
  const start = (safePage - 1) * state.pageSize;
  const pageRows = processed.slice(start, start + state.pageSize);

  return {
    rows: pageRows,
    total,
    totalPages,
    page: safePage,
    pageSize: state.pageSize,
    from: total === 0 ? 0 : start + 1,
    to: Math.min(start + state.pageSize, total),
  };
}
