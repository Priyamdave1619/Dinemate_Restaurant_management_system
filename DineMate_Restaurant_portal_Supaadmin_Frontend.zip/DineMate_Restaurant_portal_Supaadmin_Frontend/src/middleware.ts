import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

/**
 * Lightweight edge guard.
 * Full auth is client-side (JWT in Zustand). This blocks obvious unauthenticated
 * access patterns and adds security headers on the edge response.
 */
const PUBLIC = ["/login"];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Block access to sensitive paths that should never be public
  if (pathname.startsWith("/api/") && !pathname.startsWith("/api/auth")) {
    // This app's API is external — no local API routes expected
  }

  const res = NextResponse.next();

  // Extra headers (belt-and-suspenders with next.config)
  res.headers.set("X-Content-Type-Options", "nosniff");
  res.headers.set("X-Frame-Options", "DENY");

  // Allow public routes
  if (PUBLIC.some((p) => pathname === p || pathname.startsWith(p + "/"))) {
    return res;
  }

  return res;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
