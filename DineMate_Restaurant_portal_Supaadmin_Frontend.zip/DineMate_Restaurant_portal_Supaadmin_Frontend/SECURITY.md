# Security Guide — DineMate Restaurant Portal

## Scope

This repository is the **restaurant admin frontend** (Next.js). It talks to an external API.
Frontend controls reduce risk and improve UX; **authoritative security lives on the backend**.

## Implemented (Frontend)

| Control | Implementation |
|--------|----------------|
| Input validation | Zod schemas in `src/lib/security/schemas.ts` |
| XSS sanitization | `src/lib/security/sanitize.ts` |
| Login rate limit (client) | `src/lib/security/rate-limit.ts` (5/min) |
| Safe error messages | `getErrorMessage()` never leaks stacks/paths |
| JWT handling | Token shape checks; reject malformed tokens |
| Auth rehydrate | Role allow-list; invalid sessions cleared |
| Security headers | CSP, XFO, nosniff, Referrer-Policy, COOP, CORP, HSTS (prod) |
| `X-Powered-By` | Disabled |
| File upload checks | MIME, extension, size, double-extension reject |
| Duplicate submit | Ref guards on login |
| RBAC (UI) | `canManage` / `isOwner` + nav role filters |

## Required (Backend — must implement)

1. **Validate every request** with the same rules (Zod/Joi) — never trust the client  
2. **Argon2id or bcrypt** (cost ≥ 12) for passwords  
3. **Short-lived access tokens** (5–15 min) + **refresh rotation** + server-side revoke list  
4. **HttpOnly + Secure + SameSite=Strict** cookies preferred over localStorage for tokens  
5. **RBAC on every route**; enforce `restaurantId` ownership  
6. **Rate limit** login (e.g. 5/15min/IP+user) and general API  
7. **CSRF** if cookie-based sessions  
8. **CORS** allowlist only known admin origins  
9. **File uploads**: magic-byte check, re-encode images, store outside web root, random names  
10. **Parameterized queries** / ORM only — no string-concat SQL  
11. **Central error handler** — generic client messages, detailed server logs (no secrets)  
12. **Helmet / security headers** on API  
13. **Dependency scanning** (`npm audit`, Snyk) in CI  

## Token storage note

Tokens are currently in `localStorage` via Zustand persist for SPA compatibility with the existing API.
For highest security, migrate the API to HttpOnly cookie sessions and remove tokens from JS-accessible storage.

## Reporting

Report vulnerabilities privately to the platform security contact. Do not open public issues with exploit details.
