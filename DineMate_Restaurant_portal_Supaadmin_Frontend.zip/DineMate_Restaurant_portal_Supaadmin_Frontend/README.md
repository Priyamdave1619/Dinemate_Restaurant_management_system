# Sevusal Restaurant Portal

Owner / Manager / Staff portal for a single restaurant tenant.

## Stack

Next.js 15 · React 19 · TypeScript · Tailwind · TanStack Query · Zustand · Axios · Zod · Recharts · Framer Motion · next-themes

## Features

| Module | Capabilities |
|--------|----------------|
| **Auth** | Login (Restaurant ID or staff username), JWT + refresh, role-aware shell |
| **Dashboard** | Live orders, table floor map, revenue cards |
| **Orders** | Active queue + history, status updates, generate bill |
| **Menu** | List/add products, show/hide, delete |
| **Tables** | CRUD, status, QR code link |
| **Staff** | Create waiter/manager, activate/deactivate, delete |
| **Finance** | Expenses + monthly P&L snapshot |
| **Offers** | View active offers |
| **Notifications** | In-app alerts, mark all read |
| **Settings** | Tax rate, restaurant name, subscription info |

## Setup

```bash
cp .env.example .env.local
# NEXT_PUBLIC_API_URL=http://localhost:3000

npm install
npm run dev
```

Open **http://localhost:3002**

### Login

- **Owner**: username = Restaurant ID (e.g. `REST000021`), password set at registration  
- **Manager / Waiter**: username assigned by owner  

Ensure backend `ALLOWED_ORIGINS` includes `http://localhost:3002`.

## Structure

```
src/
  app/(app)/     Protected pages
  app/login/     Public login
  lib/api/       Axios client + restaurant services
  lib/stores/    Auth (Zustand)
  components/    UI + layout
```
