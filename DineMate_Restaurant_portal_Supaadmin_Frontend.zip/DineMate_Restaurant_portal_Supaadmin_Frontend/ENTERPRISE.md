# DineMate Restaurant Portal — Enterprise SaaS Frontend

Production-oriented restaurant owner/manager/staff portal with Royal Navy Blue design system, unified branding, enterprise data tables, and OWASP-aligned frontend security.

## Stack

Next.js 15 · React 19 · TypeScript · Tailwind · TanStack Query/Table · Zustand · Axios · Zod · Recharts · Framer Motion · next-themes

## Design system

- **Primary**: Royal Navy Blue — `hsl(221 83% 28%)` (light) / `hsl(221 70% 52%)` (dark)
- Tokens drive buttons, sidebar, header, focus rings, badges, tables, pagination, dialogs
- Consistent radius, elevation, and motion

## Branding (public assets)

| Asset | Path |
|-------|------|
| Favicon | `/public/favicon.ico`, `favicon.png`, light/dark variants |
| PWA / Android | `favicon-*-192.png` |
| Apple Touch | `apple-touch-icon.png` |
| Logos | `/public/logos/logo-dark.png`, `logo-light.png` |

`BrandLogo` (`src/components/branding/`) is used on:

- Login (centered, animated)
- Sidebar (expanded name + logo / collapsed icon)
- Header title bar (desktop)
- 404 / error
- Optional empty states (`branded`)

Theme switch swaps dark↔light logos with fade/scale (~220ms). Restaurant logo overrides when available.

## Data tables

- Shared `DataTable` + toolbar + pagination + sortable headers
- Page sizes: **10 / 50 / 100 / 200 / 400** (remembered)
- Debounced search, clear filters, sticky headers, skeletons, “No records found”
- Hook: `useDataTable` (`src/hooks/use-data-table.ts`)

## Security (frontend defense-in-depth)

| Area | Implementation |
|------|----------------|
| Validation | Zod schemas in `src/lib/security/schemas.ts` |
| XSS / HTML | `sanitizeText`, `stripHtml`, `escapeHtml` |
| SQLi / command / path | `looksMalicious()` expanded pattern set |
| Unicode | NFC normalize + strip zero-width |
| Passwords | Min 12, complexity, anti-repeat/sequence, common-password block; strength meter UI |
| Uploads | MIME, extension, size, double-ext, path checks (`validateUploadFile`) |
| Rate limit | Login cooldown client-side |
| Errors | `getErrorMessage()` — no stacks/secrets |
| Headers | CSP, HSTS, XFO, nosniff, COOP, CORP in `next.config.ts` |
| RBAC | Nav role filters + auth store rehydrate allow-list |
| Dev logging | `logSecurityEvent()` — development only |

**Backend must enforce the same rules.**

## Accessibility

- Focus-visible rings, ARIA on pagination/login/strength meter, empty `role="status"`
- Keyboard-friendly dialogs and menus

## Run

```bash
npm install   # or pnpm install
npm run dev   # http://localhost:3002
```

Ensure `.env` has `NEXT_PUBLIC_API_URL` and backend `ALLOWED_ORIGINS` includes the portal origin.

## Login

- Owner: Restaurant ID (e.g. `REST000021`) + registration password  
- Staff: username assigned by owner  
