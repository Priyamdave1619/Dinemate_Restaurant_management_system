export type UserRole = "owner" | "manager" | "waiter";

export type OrderStatus =
  | "pending"
  | "accepted"
  | "preparing"
  | "ready"
  | "served"
  | "completed"
  | "cancelled";

export type PaymentMethod = "cash" | "card" | "upi";

export type TableStatus = "available" | "occupied" | "reserved" | "cleaning";

export interface SessionUser {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  restaurantId: string | null;
}

export interface RestaurantSummary {
  id: string;
  name: string;
  status: string;
  logoUrl?: string;
  address?: string;
  mobile?: string;
  email?: string;
  gstNumber?: string;
  currency?: string;
}

/** Full tenant profile from GET /api/restaurants/me */
export interface RestaurantProfile {
  id: string;
  name: string;
  ownerName?: string;
  email?: string;
  mobile?: string;
  address?: string;
  logoUrl?: string;
  gstNumber?: string;
  timezone?: string;
  currency?: string;
  status?: string;
}

export interface LoginResponse {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  restaurantId: string | null;
  restaurant: RestaurantSummary | null;
  accessToken: string;
  refreshToken: string;
}

export interface RestaurantTable {
  id: string;
  number: number;
  capacity: number;
  status: TableStatus;
  currentOrderId?: string;
  waiterName?: string;
  qrPath?: string;
}

export interface AppliedOffer {
  offerId: string;
  name: string;
  amount: number;
}

export interface OrderItem {
  id: string;
  itemId: string;
  name: string;
  quantity: number;
  price: number;
  note?: string;
  variant?: string;
  kotPrinted?: boolean;
  addedBy?: "customer" | "waiter";
  foodType?: string;
  categoryId?: string;
}

export interface Order {
  id: string;
  restaurantId: string;
  tableNumber: number;
  items: OrderItem[];
  status: OrderStatus | string;
  placedAt: string;
  updatedAt: string;
  total: number;
  subtotal: number;
  manualDiscountPercent?: number;
  appliedOffers?: AppliedOffer[];
  discountTotal?: number;
  taxRatePercent?: number;
  taxAmount?: number;
  /** Display-only on bill when provided locally — not persisted by waiter app */
  customerName?: string;
  /** Display-only on bill when provided locally — not persisted by waiter app */
  customerPhone?: string;
  waiterName?: string;
  note?: string;
  estimatedMinutes?: number;
  kotBatches?: number;
  billGenerated?: boolean;
  billNumber?: string;
  billedAt?: string;
  paymentMethod?: PaymentMethod;
}

export interface MenuItem {
  id: string;
  name: string;
  price: number;
  categoryId: string;
  available: boolean;
  description?: string;
  image?: string;
  isVeg?: boolean;
  foodType?: string;
  spiceLevel?: string;
  variants?: Array<{ id: string; label: string; priceDelta: number }>;
}

export interface MenuCategory {
  id: string;
  name: string;
  icon?: string;
}

export interface Offer {
  id: string;
  name: string;
  type: string;
  active: boolean;
  description?: string;
  discountPercent?: number;
  discountAmount?: number;
  couponCode?: string;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type?: string;
  read?: boolean;
  createdAt: string;
  relatedEntityType?: string;
  relatedEntityId?: string;
}

export interface RestaurantSettings {
  restaurantId: string;
  taxRatePercent: number;
  restaurantName: string;
  address?: string;
  gstin?: string;
  baseUrl?: string;
  currency?: string;
  openingTime?: string;
  closingTime?: string;
  billPrefix?: string;
}

export interface ApiSuccess<T> {
  success: true;
  message: string;
  data: T;
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
  };
}

export interface CreateOrderBody {
  tableNumber: number;
  items: Array<{
    itemId: string;
    name?: string;
    quantity?: number;
    price?: number;
    variant?: string;
    note?: string;
  }>;
  note?: string;
  waiterName?: string;
}

export interface AddOrderItemsBody {
  items: Array<{
    itemId: string;
    name?: string;
    quantity?: number;
    price?: number;
    variant?: string;
    note?: string;
  }>;
}

export interface UpdateOrderBody {
  status?: OrderStatus | string;
  manualDiscountPercent?: number;
  paymentMethod?: PaymentMethod;
  waiterName?: string;
  note?: string;
}

export interface ListOrdersParams {
  active?: string;
  tableNumber?: string | number;
  search?: string;
  includeArchived?: string;
  page?: number;
  pageSize?: number;
}
