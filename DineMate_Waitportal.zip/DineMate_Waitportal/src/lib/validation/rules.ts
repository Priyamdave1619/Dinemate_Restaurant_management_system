import {
  normalizeSpaces,
  sanitizePhone,
  sanitizeText,
  sanitizeUsername,
  stripControlChars,
} from "./sanitize";

export type FieldResult = { ok: true; value: string } | { ok: false; message: string };
export type NumberResult = { ok: true; value: number } | { ok: false; message: string };

const USERNAME_RE = /^[a-z0-9][a-z0-9._-]{1,39}$/;
const PHONE_RE = /^\+?[0-9]{7,15}$/;

export function requiredText(
  raw: string,
  label: string,
  opts?: { min?: number; max?: number }
): FieldResult {
  const value = sanitizeText(raw, opts?.max ?? 500);
  if (!value) return { ok: false, message: `${label} is required` };
  if (opts?.min && value.length < opts.min) {
    return { ok: false, message: `${label} must be at least ${opts.min} characters` };
  }
  if (opts?.max && value.length > opts.max) {
    return { ok: false, message: `${label} must be at most ${opts.max} characters` };
  }
  return { ok: true, value };
}

export function validateUsername(raw: string): FieldResult {
  const value = sanitizeUsername(raw);
  if (!value) return { ok: false, message: "Username is required" };
  if (value.length < 3) return { ok: false, message: "Username must be at least 3 characters" };
  if (!USERNAME_RE.test(value)) {
    return {
      ok: false,
      message: "Username: letters, numbers, dots, dashes and underscores only",
    };
  }
  return { ok: true, value };
}

export function validateLoginPassword(raw: string): FieldResult {
  const value = stripControlChars(raw);
  if (!value) return { ok: false, message: "Password is required" };
  if (value.length < 6) return { ok: false, message: "Password must be at least 6 characters" };
  if (value.length > 200) return { ok: false, message: "Password is too long" };
  return { ok: true, value };
}

export function validateOptionalName(raw: string): FieldResult {
  const value = sanitizeText(raw, 120);
  if (!value) return { ok: true, value: "" };
  if (value.length < 2) return { ok: false, message: "Name must be at least 2 characters" };
  return { ok: true, value };
}

export function validateOptionalPhone(raw: string): FieldResult {
  const value = sanitizePhone(raw);
  if (!value) return { ok: true, value: "" };
  if (!PHONE_RE.test(value)) {
    return { ok: false, message: "Enter a valid phone (7–15 digits)" };
  }
  return { ok: true, value };
}

export function validateDiscountPercent(raw: string): NumberResult {
  const trimmed = normalizeSpaces(raw);
  if (!trimmed) return { ok: false, message: "Enter a discount percentage" };
  if (!/^\d+(\.\d{1,2})?$/.test(trimmed)) {
    return { ok: false, message: "Discount must be a number" };
  }
  const n = Number(trimmed);
  if (Number.isNaN(n)) return { ok: false, message: "Discount must be a number" };
  if (n < 0 || n > 100) return { ok: false, message: "Discount must be between 0 and 100" };
  return { ok: true, value: n };
}

export function validateTableNumber(raw: string | number): NumberResult {
  const n = typeof raw === "number" ? raw : Number(String(raw).trim());
  if (!Number.isFinite(n) || !Number.isInteger(n) || n < 1) {
    return { ok: false, message: "Select a valid table" };
  }
  if (n > 9999) return { ok: false, message: "Invalid table number" };
  return { ok: true, value: n };
}

export function validateQuantity(n: number): NumberResult {
  if (!Number.isInteger(n) || n < 1) return { ok: false, message: "Quantity must be at least 1" };
  if (n > 999) return { ok: false, message: "Quantity is too high" };
  return { ok: true, value: n };
}

export function validateSearchQuery(raw: string, max = 80): FieldResult {
  const value = sanitizeText(raw, max);
  return { ok: true, value };
}

export function validateOrderCart(
  lines: Array<{ itemId: string; quantity: number }>
): { ok: true } | { ok: false; message: string } {
  if (!lines.length) return { ok: false, message: "Add at least one item" };
  for (const l of lines) {
    if (!l.itemId) return { ok: false, message: "Invalid cart item" };
    const q = validateQuantity(l.quantity);
    if (!q.ok) return q;
  }
  return { ok: true };
}
