const CONTROL_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
const HTML_TAGS = /<\/?[^>]+(>|$)/g;
const SCRIPTISH = /javascript\s*:|data\s*:|vbscript\s*:|on\w+\s*=/gi;

export function normalizeSpaces(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

export function stripControlChars(value: string): string {
  return value.replace(CONTROL_CHARS, "");
}

export function stripHtml(value: string): string {
  return value.replace(HTML_TAGS, "").replace(SCRIPTISH, "");
}

export function sanitizeText(value: string, maxLen = 500): string {
  let v = stripControlChars(value);
  v = stripHtml(v);
  v = normalizeSpaces(v);
  if (v.length > maxLen) v = v.slice(0, maxLen);
  return v;
}

export function sanitizeUsername(value: string): string {
  return stripControlChars(value)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9._-]/g, "")
    .slice(0, 40);
}

export function sanitizePhone(value: string): string {
  const v = stripControlChars(value).trim();
  const hasPlus = v.startsWith("+");
  const digits = v.replace(/\D/g, "").slice(0, 15);
  return hasPlus ? `+${digits}` : digits;
}

export function sanitizeNumberInput(value: string, allowDecimal = true): string {
  let v = value.replace(/[^\d.]/g, "");
  if (!allowDecimal) return v.replace(/\./g, "");
  const parts = v.split(".");
  if (parts.length > 2) v = parts[0] + "." + parts.slice(1).join("");
  return v;
}

export function sanitizeSearch(value: string, maxLen = 80): string {
  return sanitizeText(value, maxLen);
}
