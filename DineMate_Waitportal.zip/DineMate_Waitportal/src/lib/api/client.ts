import axios, { type AxiosError, type InternalAxiosRequestConfig } from "axios";
import { useAuthStore } from "@/lib/stores/auth-store";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000";
export const api = axios.create({
  baseURL: API_URL,
  headers: { "Content-Type": "application/json" },
  timeout: 30000,
});

let refreshing: Promise<string | null> | null = null;

/**
 * Refresh access token. NEVER clears the session here.
 * Session is only cleared by explicit Logout (clearAuth on Me page).
 */
export async function refreshAccessToken(): Promise<string | null> {
  const { refreshToken, accessToken, setTokens } = useAuthStore.getState();
  if (!refreshToken) {
    // Still have access token → keep using it
    return accessToken;
  }

  try {
    const res = await axios.post(
      `${API_URL}/api/auth/refresh`,
      { refreshToken },
      {
        headers: {
          Authorization: `Bearer ${refreshToken}`,
          "Content-Type": "application/json",
        },
        timeout: 20000,
      }
    );
    const d = res.data?.data ?? res.data;
    if (d?.accessToken) {
      setTokens(d.accessToken, d.refreshToken || refreshToken);
      return d.accessToken as string;
    }
    return accessToken;
  } catch {
    // Network / server error / invalid refresh — keep existing session.
    // Do NOT call clearAuth(). Waiter stays logged in until they press Logout.
    return useAuthStore.getState().accessToken;
  }
}

export async function ensureAccessToken(): Promise<string | null> {
  const { accessToken, refreshToken } = useAuthStore.getState();
  if (accessToken) return accessToken;
  if (!refreshToken) return null;
  if (!refreshing) {
    refreshing = refreshAccessToken().finally(() => {
      refreshing = null;
    });
  }
  return refreshing;
}

api.interceptors.request.use(async (config: InternalAxiosRequestConfig) => {
  let token = useAuthStore.getState().accessToken;
  if (!token && useAuthStore.getState().refreshToken) {
    token = await ensureAccessToken();
  }
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (r) => r,
  async (error: AxiosError) => {
    const original = error.config as InternalAxiosRequestConfig & { _retry?: boolean };
    if (error.response?.status === 401 && original && !original._retry) {
      original._retry = true;
      if (!refreshing) {
        refreshing = refreshAccessToken().finally(() => {
          refreshing = null;
        });
      }
      const t = await refreshing;
      if (t) {
        original.headers.Authorization = `Bearer ${t}`;
        return api(original);
      }
      // Still have a session in storage → do NOT force login redirect.
      // User stays on the app until they explicitly log out.
    }
    return Promise.reject(error);
  }
);

export function getErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    const data = error.response?.data as { message?: string; success?: boolean } | undefined;
    // Prefer server message envelope; never expose stack/debug payloads
    if (data?.message && typeof data.message === "string") {
      return data.message.slice(0, 300);
    }
    if (error.code === "ECONNABORTED") return "Request timed out — try again";
    if (!error.response) return "Network error — check your connection";
    if (error.response.status >= 500) return "Server error — try again shortly";
    return "Request failed";
  }
  if (error instanceof Error && error.message) return error.message.slice(0, 300);
  return "Something went wrong";
}
