import { api } from "./client";
import type {
  ApiSuccess,
  LoginResponse,
  RestaurantTable,
  Order,
  MenuItem,
  MenuCategory,
  SessionUser,
  RestaurantSummary,
  AppNotification,
  RestaurantSettings,
  RestaurantProfile,
  Offer,
  CreateOrderBody,
  AddOrderItemsBody,
  UpdateOrderBody,
  ListOrdersParams,
} from "@/types";

// ─── Auth ───────────────────────────────────────────────────────────────────

export async function login(username: string, password: string) {
  const { data } = await api.post<ApiSuccess<LoginResponse>>("/api/auth/login", {
    username,
    password,
  });
  return data.data;
}

export async function logout(refreshToken?: string) {
  await api.post("/api/auth/logout", refreshToken ? { refreshToken } : undefined);
}

export async function getMe() {
  const { data } = await api.get<
    ApiSuccess<{ user: SessionUser | null; restaurant: RestaurantSummary | null }>
  >("/api/auth/me");
  return data.data;
}

// ─── Tables ─────────────────────────────────────────────────────────────────

export async function listTables() {
  const { data } = await api.get<ApiSuccess<{ tables: RestaurantTable[] }>>("/api/tables");
  return data.data.tables;
}

export async function updateTable(
  id: string,
  body: Partial<Pick<RestaurantTable, "status" | "waiterName" | "currentOrderId" | "capacity">>
) {
  const { data } = await api.patch<
    ApiSuccess<{ tables?: RestaurantTable[]; table?: RestaurantTable }>
  >(`/api/tables/${id}`, body);
  if (data.data.tables) return data.data.tables;
  return listTables();
}

// ─── Orders — full backend surface ──────────────────────────────────────────

/** GET /api/orders — returns order array (pagination available via listOrdersPage) */
export async function listOrders(params?: ListOrdersParams) {
  const { data } = await api.get<ApiSuccess<{ orders: Order[] }>>("/api/orders", { params });
  return data.data.orders ?? [];
}

/** Same as listOrders but includes pagination metadata */
export async function listOrdersPage(params?: ListOrdersParams) {
  const { data } = await api.get<ApiSuccess<{ orders: Order[] }>>("/api/orders", { params });
  return {
    orders: data.data.orders ?? [],
    pagination: data.pagination,
  };
}

/** GET /api/orders/[id] */
export async function getOrder(id: string) {
  const { data } = await api.get<ApiSuccess<{ order: Order }>>(`/api/orders/${id}`);
  return data.data.order;
}

/** POST /api/orders */
export async function createOrder(body: CreateOrderBody) {
  const { data } = await api.post<ApiSuccess<{ order: Order }>>("/api/orders", body);
  return data.data.order;
}

/**
 * PATCH /api/orders/[id]
 * status | manualDiscountPercent | paymentMethod | waiterName | note
 */
export async function updateOrder(id: string, body: UpdateOrderBody) {
  const { data } = await api.patch<ApiSuccess<{ order: Order }>>(`/api/orders/${id}`, body);
  return data.data.order;
}

/** POST /api/orders/[id]/items — add lines to an open order */
export async function addOrderItems(id: string, body: AddOrderItemsBody) {
  const { data } = await api.post<ApiSuccess<{ order: Order }>>(`/api/orders/${id}/items`, body);
  return data.data.order;
}

/** GET /api/orders/[id]/kot — unprinted kitchen items */
export async function getOrderKot(id: string) {
  const { data } = await api.get<ApiSuccess<{ order: Order; itemsToPrint: Order["items"] }>>(
    `/api/orders/${id}/kot`
  );
  return data.data;
}

/** POST /api/orders/[id]/kot — mark pending items as printed */
export async function markKotPrinted(id: string) {
  const { data } = await api.post<ApiSuccess<{ order: Order }>>(`/api/orders/${id}/kot`);
  return data.data.order;
}

/**
 * GET /api/orders/[id]/bill
 * First call finalizes + archives; later calls return archived bill.
 */
export async function getOrderBill(id: string) {
  const { data } = await api.get<ApiSuccess<{ order: Order; settings?: RestaurantSettings }>>(
    `/api/orders/${id}/bill`
  );
  return data.data;
}


// ─── Restaurant profile (logo, address, GST for bills) ──────────────────────

export async function getRestaurantProfile() {
  const { data } = await api.get<ApiSuccess<{ restaurant: RestaurantProfile }>>(
    "/api/restaurants/me"
  );
  return data.data.restaurant;
}
// ─── Menu ───────────────────────────────────────────────────────────────────

export async function listMenu() {
  const { data } = await api.get<ApiSuccess<{ items?: MenuItem[]; menu?: MenuItem[] }>>("/api/menu");
  return data.data.items ?? data.data.menu ?? [];
}

export async function listCategories() {
  const { data } = await api.get<
    ApiSuccess<{ categories?: MenuCategory[]; items?: MenuCategory[] }>
  >("/api/categories");
  return data.data.categories ?? data.data.items ?? [];
}

// ─── Offers ─────────────────────────────────────────────────────────────────

export async function listOffers() {
  const { data } = await api.get<ApiSuccess<{ offers?: Offer[] }>>("/api/offers");
  return data.data.offers ?? [];
}

// ─── Settings ───────────────────────────────────────────────────────────────

export async function getSettings() {
  const { data } = await api.get<ApiSuccess<{ settings: RestaurantSettings } | RestaurantSettings>>(
    "/api/settings"
  );
  const d = data.data as { settings?: RestaurantSettings } & RestaurantSettings;
  return d.settings ?? d;
}

// ─── Notifications ──────────────────────────────────────────────────────────

export async function listNotifications(params?: { unread?: string }) {
  const { data } = await api.get<ApiSuccess<{ notifications: AppNotification[] }>>(
    "/api/notifications",
    { params }
  );
  return data.data.notifications ?? [];
}

export async function markAllNotificationsRead() {
  const { data } = await api.patch<ApiSuccess<{ notifications?: AppNotification[] }>>(
    "/api/notifications",
    { markAllRead: true }
  );
  return data.data;
}

export async function markNotificationRead(id: string) {
  const { data } = await api.patch<ApiSuccess<{ notification?: AppNotification }>>(
    `/api/notifications/${id}`,
    { read: true }
  );
  return data.data;
}
