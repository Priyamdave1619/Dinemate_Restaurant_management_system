"use client";
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { SessionUser, RestaurantSummary } from "@/types";

interface AuthState {
  user: SessionUser | null;
  restaurant: RestaurantSummary | null;
  accessToken: string | null;
  refreshToken: string | null;
  _hydrated: boolean;
  setAuth: (p: {
    user: SessionUser;
    restaurant: RestaurantSummary | null;
    accessToken: string;
    refreshToken: string;
  }) => void;
  setTokens: (a: string, r: string) => void;
  /** ONLY call from explicit Logout button */
  clearAuth: () => void;
  /**
   * Logged in if we have user + (accessToken OR refreshToken).
   * Presence of accessToken alone is enough to keep the session.
   */
  isAuthenticated: () => boolean;
  setHydrated: (v: boolean) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      restaurant: null,
      accessToken: null,
      refreshToken: null,
      _hydrated: false,
      setAuth: (p) => set(p),
      setTokens: (accessToken, refreshToken) => set({ accessToken, refreshToken }),
      clearAuth: () =>
        set({ user: null, restaurant: null, accessToken: null, refreshToken: null }),
      isAuthenticated: () => {
        const s = get();
        // Access token present → always keep session
        if (s.accessToken && s.user) return true;
        // Or refresh token + user (access may be temporarily missing)
        if (s.refreshToken && s.user) return true;
        return false;
      },
      setHydrated: (v) => set({ _hydrated: v }),
    }),
    {
      name: "sevusal-waiter-auth",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        user: s.user,
        restaurant: s.restaurant,
        accessToken: s.accessToken,
        refreshToken: s.refreshToken,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    }
  )
);
