"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Loader2, Eye, EyeOff } from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";
import { toast } from "sonner";
import { login } from "@/lib/api/waiter";
import { useAuthStore } from "@/lib/stores/auth-store";
import { getErrorMessage } from "@/lib/api/client";
import { validateUsername, validateLoginPassword } from "@/lib/validation";
import { FieldError } from "@/components/field-error";
import { useSubmitGuard } from "@/hooks/use-submit-guard";

export default function LoginPage() {
  const router = useRouter();
  const setAuth = useAuthStore((s) => s.setAuth);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [userErr, setUserErr] = useState<string | null>(null);
  const [passErr, setPassErr] = useState<string | null>(null);
  const { pending: guardPending, run: guarded } = useSubmitGuard();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const hydrated = useAuthStore((s) => s._hydrated);

  useEffect(() => {
    document.title = "Login | Waiter Portal";
  }, []);

  useEffect(() => {
    if (hydrated && isAuthenticated()) {
      router.replace("/floor");
    }
  }, [hydrated, isAuthenticated, router]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const u = validateUsername(username);
    const pw = validateLoginPassword(password);
    setUserErr(u.ok ? null : u.message);
    setPassErr(pw.ok ? null : pw.message);
    if (!u.ok || !pw.ok) return;

    await guarded(async () => {
    setLoading(true);
    try {
      const res = await login(u.value, pw.value);
      if (!["waiter", "manager", "owner"].includes(res.role)) {
        toast.error("This app is for restaurant staff only");
        return;
      }
      if (!res.restaurantId) {
        toast.error("No restaurant linked to this account");
        return;
      }
      setAuth({
        user: {
          id: res.id,
          username: res.username,
          name: res.name,
          role: res.role as "waiter" | "manager" | "owner",
          restaurantId: res.restaurantId,
        },
        restaurant: res.restaurant,
        accessToken: res.accessToken,
        refreshToken: res.refreshToken,
      });
      toast.success(`Welcome, ${res.name}`);
      router.replace("/floor");
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
    });
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-brand-soft p-6">
      <div className="pointer-events-none absolute -top-24 left-1/2 h-72 w-72 -translate-x-1/2 rounded-full bg-brand-400/20 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 right-0 h-56 w-56 rounded-full bg-brand-600/10 blur-3xl" />

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35 }}
        className="relative w-full max-w-sm"
      >
        <div className="mb-8 text-center">
          <div className="mx-auto mb-5 flex justify-center">
            <div className="rounded-2xl border border-line bg-white p-4 shadow-elev">
              <BrandLogo variant="full" height={48} priority alt="Company logo" />
            </div>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-ink">Waiter portal</h1>
          <p className="mt-1.5 text-sm text-ink-secondary">Sign in with your staff account</p>
        </div>

        <form
          onSubmit={onSubmit}
          className="space-y-3 rounded-3xl border border-white/70 bg-white/90 p-6 shadow-elev backdrop-blur-xl"
        >
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-ink-secondary">Username</label>
            <input
              className="input-premium"
              placeholder="Username"
              autoComplete="username"
              autoCapitalize="none"
              spellCheck={false}
              value={username}
              aria-invalid={!!userErr}
              aria-describedby={userErr ? "username-err" : undefined}
              onChange={(e) => {
                setUsername(e.target.value);
                if (userErr) setUserErr(null);
              }}
              onBlur={() => {
                const r = validateUsername(username);
                setUserErr(r.ok ? null : r.message);
              }}
              required
              maxLength={40}
            />
            <FieldError id="username-err" message={userErr} />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-semibold text-ink-secondary">Password</label>
            <div className="relative">
              <input
                className="input-premium pr-11"
                type={show ? "text" : "password"}
                placeholder="Password"
                autoComplete="current-password"
                value={password}
                aria-invalid={!!passErr}
                aria-describedby={passErr ? "password-err" : undefined}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (passErr) setPassErr(null);
                }}
                onBlur={() => {
                  const r = validateLoginPassword(password);
                  setPassErr(r.ok ? null : r.message);
                }}
                required
                maxLength={200}
              />
              <button
                type="button"
                className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-1 text-ink-muted hover:bg-brand-50 hover:text-brand-600"
                onClick={() => setShow(!show)}
              >
                {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>
          <button type="submit" disabled={loading} className="btn-primary mt-2 w-full py-3.5">
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            Sign in
          </button>
        </form>
      </motion.div>
    </div>
  );
}
