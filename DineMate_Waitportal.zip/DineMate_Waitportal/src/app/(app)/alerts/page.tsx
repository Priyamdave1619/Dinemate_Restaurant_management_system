"use client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listNotifications, markAllNotificationsRead, markNotificationRead } from "@/lib/api/waiter";
import { relativeTime } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { cn } from "@/lib/utils/cn";
import Link from "next/link";

export default function AlertsPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["notifications"],
    queryFn: () => listNotifications(),
    refetchInterval: 15000,
  });

  const markAll = useMutation({
    mutationFn: markAllNotificationsRead,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["notifications"] });
      toast.success("All marked read");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const markOne = useMutation({
    mutationFn: (id: string) => markNotificationRead(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }),
  });

  const unread = (data || []).filter((n) => !n.read).length;

  return (
    <div>
      <header className="sticky top-0 z-20 border-b border-line/60 bg-white/75 px-4 py-3 backdrop-blur-xl-xl">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-bold">
            Alerts
            {unread > 0 && (
              <span className="ml-2 rounded-full bg-brand-gradient px-2 py-0.5 text-xs font-bold text-white shadow-glow">
                {unread}
              </span>
            )}
          </h1>
          {unread > 0 && (
            <button
              type="button"
              disabled={markAll.isPending}
              onClick={() => markAll.mutate()}
              className="text-xs font-semibold text-brand-600"
            >
              Mark all read
            </button>
          )}
        </div>
      </header>
      <main className="space-y-2 p-4">
        {isLoading && <div className="h-24 animate-pulse rounded-2xl border bg-white" />}
        {(data || []).map((n) => {
          const body = (
            <div
              className={cn(
                "rounded-2xl border p-4",
                n.read ? "border-line bg-white" : "border-brand-200 bg-brand-50/50"
              )}
            >
              <div className="flex justify-between gap-2">
                <p className="text-sm font-semibold">{n.title}</p>
                <span className="shrink-0 text-[10px] text-ink-muted">{relativeTime(n.createdAt)}</span>
              </div>
              <p className="mt-1 text-sm text-ink-secondary">{n.message}</p>
            </div>
          );
          if (n.relatedEntityType === "order" && n.relatedEntityId) {
            return (
              <Link
                key={n.id}
                href={`/orders/${n.relatedEntityId}`}
                onClick={() => {
                  if (!n.read) markOne.mutate(n.id);
                }}
              >
                {body}
              </Link>
            );
          }
          return (
            <button
              key={n.id}
              type="button"
              className="w-full text-left"
              onClick={() => {
                if (!n.read) markOne.mutate(n.id);
              }}
            >
              {body}
            </button>
          );
        })}
        {!isLoading && !data?.length && (
          <p className="py-16 text-center text-sm text-ink-muted">No alerts</p>
        )}
      </main>
    </div>
  );
}
