"use client";
import { useAuthStore } from "@/lib/stores/auth-store";
import { logout as apiLogout } from "@/lib/api/waiter";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { LogOut } from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";

export default function MePage() {
  const { user, restaurant, clearAuth, refreshToken } = useAuthStore();
  const router = useRouter();

  async function handleLogout() {
    try {
      await apiLogout(refreshToken || undefined);
    } catch {
      /* ignore */
    }
    clearAuth();
    toast.success("Logged out");
    router.replace("/login");
  }

  return (
    <div>
      <header className="sticky top-0 z-20 border-b border-line/60 bg-white/75 px-4 py-3 backdrop-blur-xl">
        <h1 className="text-lg font-bold">Profile</h1>
      </header>
      <main className="space-y-4 p-4">
        <div className="card-premium flex justify-center py-4">
          <BrandLogo variant="full" height={40} alt="Company logo" />
        </div>
        <div className="card-premium space-y-3 p-5 text-sm">
          <div className="flex justify-between">
            <span className="text-ink-secondary">Name</span>
            <span className="font-semibold">{user?.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-ink-secondary">Username</span>
            <span className="font-semibold">{user?.username}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-ink-secondary">Role</span>
            <span className="font-semibold capitalize">{user?.role}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-ink-secondary">Restaurant</span>
            <span className="font-semibold text-right">{restaurant?.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-ink-secondary">ID</span>
            <span className="font-mono text-xs">{restaurant?.id}</span>
          </div>
        </div>

        <button
          type="button"
          onClick={handleLogout}
          className="btn-danger w-full py-3.5"
        >
          <LogOut className="h-4 w-4" /> Log out
        </button>
      </main>
    </div>
  );
}
