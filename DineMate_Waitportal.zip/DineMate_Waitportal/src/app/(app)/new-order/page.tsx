"use client";
import { useMemo, useState, useRef, useEffect, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { useQuery, useMutation } from "@tanstack/react-query";
import { listMenu, listTables, listCategories, createOrder } from "@/lib/api/waiter";
import { formatCurrency } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { Minus, Plus, Loader2, Search, X, ShoppingCart, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils/cn";
import type { MenuItem } from "@/types";
import {
  validateTableNumber,
  validateOrderCart,
  sanitizeSearch,
} from "@/lib/validation";

type Line = { itemId: string; name: string; price: number; quantity: number };

function rankMatch(name: string, q: string): number {
  const n = name.toLowerCase();
  if (n === q) return 0;
  if (n.startsWith(q)) return 1;
  if (n.includes(` ${q}`)) return 2;
  if (n.includes(q)) return 3;
  // token match (e.g. "chicken" matches "Tequila Chicken")
  const tokens = n.split(/\s+/);
  if (tokens.some((t) => t.startsWith(q))) return 4;
  return 99;
}

function NewOrderInner() {
  const params = useSearchParams();
  const router = useRouter();
  const preTable = params.get("table") || "";
  const searchRef = useRef<HTMLInputElement>(null);

  const [tableNumber, setTableNumber] = useState(preTable);
  const [lines, setLines] = useState<Line[]>([]);
  const [search, setSearch] = useState("");
  const [categoryId, setCategoryId] = useState<string>("all");
  const [showCart, setShowCart] = useState(false);

  const { data: menu, isLoading: menuLoading } = useQuery({
    queryKey: ["menu"],
    queryFn: listMenu,
  });
  const { data: categories } = useQuery({ queryKey: ["categories"], queryFn: listCategories });
  const { data: tables } = useQuery({ queryKey: ["tables"], queryFn: listTables });

  // Auto-focus search for quick entry on floor
  useEffect(() => {
    const t = setTimeout(() => searchRef.current?.focus(), 200);
    return () => clearTimeout(t);
  }, []);

  const categoryNameById = useMemo(() => {
    const m = new Map<string, string>();
    for (const c of categories || []) m.set(c.id, c.name);
    return m;
  }, [categories]);

  const activeCategories = useMemo(() => {
    const counts = new Map<string, number>();
    for (const item of menu || []) {
      if (item.available === false) continue;
      counts.set(item.categoryId, (counts.get(item.categoryId) || 0) + 1);
    }
    return (categories || []).filter((c) => (counts.get(c.id) || 0) > 0);
  }, [menu, categories]);

  const q = search.trim().toLowerCase();
  const isSearching = q.length > 0;

  const filtered = useMemo(() => {
    let list = (menu || []).filter((m) => m.available !== false);

    // While searching, search ALL categories so any item is easy to find
    if (!isSearching && categoryId !== "all") {
      list = list.filter((m) => m.categoryId === categoryId);
    }

    if (isSearching) {
      list = list
        .map((m) => {
          const nameScore = rankMatch(m.name, q);
          const cat = (categoryNameById.get(m.categoryId) || "").toLowerCase();
          const catScore = cat.includes(q) ? 5 : 99;
          const score = Math.min(nameScore, catScore);
          return { m, score };
        })
        .filter((x) => x.score < 99)
        .sort((a, b) => a.score - b.score || a.m.name.localeCompare(b.m.name))
        .map((x) => x.m);
    }

    return list;
  }, [menu, q, isSearching, categoryId, categoryNameById]);

  const grouped = useMemo(() => {
    // Flat list while searching — faster to scan
    if (isSearching) {
      return [{ id: "_search", name: "Results", items: filtered }];
    }
    if (categoryId !== "all") {
      return [
        {
          id: categoryId,
          name: categoryNameById.get(categoryId) || "Category",
          items: filtered,
        },
      ];
    }
    const groups: Array<{ id: string; name: string; items: MenuItem[] }> = [];
    for (const c of activeCategories) {
      const items = filtered.filter((i) => i.categoryId === c.id);
      if (items.length) groups.push({ id: c.id, name: c.name, items });
    }
    const known = new Set(activeCategories.map((c) => c.id));
    const rest = filtered.filter((i) => !known.has(i.categoryId));
    if (rest.length) groups.push({ id: "_other", name: "Other", items: rest });
    return groups;
  }, [filtered, isSearching, categoryId, activeCategories, categoryNameById]);

  function add(item: { id: string; name: string; price: number }) {
    setLines((prev) => {
      const ex = prev.find((l) => l.itemId === item.id);
      if (ex) return prev.map((l) => (l.itemId === item.id ? { ...l, quantity: l.quantity + 1 } : l));
      return [...prev, { itemId: item.id, name: item.name, price: item.price, quantity: 1 }];
    });
  }

  function setQty(itemId: string, qty: number) {
    if (qty <= 0) setLines((p) => p.filter((l) => l.itemId !== itemId));
    else {
      const q = Math.min(999, Math.max(1, Math.floor(qty)));
      setLines((p) => p.map((l) => (l.itemId === itemId ? { ...l, quantity: q } : l)));
    }
  }

  function clearCart() {
    setLines([]);
    setShowCart(false);
  }

  const cartCount = lines.reduce((s, l) => s + l.quantity, 0);
  const total = lines.reduce((s, l) => s + l.price * l.quantity, 0);
  const qtyInCart = (itemId: string) => lines.find((l) => l.itemId === itemId)?.quantity ?? 0;

  const placeMut = useMutation({
    mutationFn: () => {
      const table = validateTableNumber(tableNumber);
      if (!table.ok) throw new Error(table.message);
      const cart = validateOrderCart(lines);
      if (!cart.ok) throw new Error(cart.message);
      return createOrder({
        tableNumber: table.value,
        items: lines.map((l) => ({
          itemId: l.itemId,
          name: l.name,
          quantity: l.quantity,
          price: l.price,
        })),
      });
    },
    onSuccess: (order) => {
      toast.success("Order placed");
      router.replace(`/orders/${order.id}`);
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  function highlightName(name: string) {
    if (!isSearching) return name;
    const lower = name.toLowerCase();
    const idx = lower.indexOf(q);
    if (idx < 0) return name;
    return (
      <>
        {name.slice(0, idx)}
        <mark className="rounded bg-amber-200 px-0.5 text-inherit">{name.slice(idx, idx + q.length)}</mark>
        {name.slice(idx + q.length)}
      </>
    );
  }

  return (
    <div className={cn("pb-36", showCart && "pb-4")}>
      <header className="sticky top-0 z-20 border-b border-line bg-white px-4 pt-3 pb-2">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-lg font-bold">New order</h1>
          {cartCount > 0 && (
            <button
              type="button"
              onClick={() => setShowCart(true)}
              className="relative inline-flex items-center gap-1.5 rounded-full bg-brand-gradient px-3 py-1.5 text-xs font-bold text-white shadow-glow"
            >
              <ShoppingCart className="h-3.5 w-3.5" />
              Cart · {cartCount}
            </button>
          )}
        </div>

        <select
          className="mt-2 w-full rounded-xl border border-line bg-surface-muted px-3 py-2.5 text-sm font-semibold"
          value={tableNumber}
          onChange={(e) => setTableNumber(e.target.value)}
        >
          <option value="">Select table</option>
          {(tables || []).map((t) => (
            <option key={t.id} value={t.number}>
              Table {t.number} ({t.status})
            </option>
          ))}
        </select>

        {/* Big search — primary action for waiters */}
        <div className="relative mt-2">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
          <input
            ref={searchRef}
            className="w-full rounded-xl border border-line bg-surface-muted py-3 pl-10 pr-10 text-base outline-none focus:border-brand-400 focus:bg-white focus:ring-2 focus:ring-brand-100"
            placeholder="Search any item…"
            value={search}
            onChange={(e) => setSearch(sanitizeSearch(e.target.value, 80))}
            maxLength={80}
            autoComplete="off"
            autoCorrect="off"
            spellCheck={false}
          />
          {search && (
            <button
              type="button"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-ink-muted hover:bg-slate-200"
              onClick={() => {
                setSearch("");
                searchRef.current?.focus();
              }}
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Categories hidden while searching — search spans all */}
        {!isSearching && (
          <div className="-mx-4 mt-2 flex gap-2 overflow-x-auto px-4 pb-1">
            <button
              type="button"
              onClick={() => setCategoryId("all")}
              className={cn(
                "shrink-0 rounded-full px-3 py-1.5 text-xs font-bold",
                categoryId === "all" ? "chip-active" : "chip-idle"
              )}
            >
              All
            </button>
            {activeCategories.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setCategoryId(c.id)}
                className={cn(
                  "shrink-0 rounded-full px-3 py-1.5 text-xs font-bold",
                  categoryId === c.id ? "chip-active" : "chip-idle"
                )}
              >
                {c.icon ? `${c.icon} ` : ""}
                {c.name}
              </button>
            ))}
          </div>
        )}
        {isSearching && (
          <p className="mt-1.5 text-[11px] text-ink-muted">
            Searching all categories · {filtered.length} match{filtered.length === 1 ? "" : "es"}
          </p>
        )}
      </header>

      <main className="space-y-3 p-4">
        {menuLoading && (
          <div className="space-y-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-16 animate-pulse rounded-xl bg-white border border-slate-100" />
            ))}
          </div>
        )}

        {grouped.map((group) => (
          <section key={group.id}>
            {!isSearching && categoryId === "all" && (
              <h2 className="mb-2 text-xs font-bold uppercase tracking-wide text-ink-muted">
                {group.name}
              </h2>
            )}
            <div className="space-y-2">
              {group.items.map((item) => {
                const qty = qtyInCart(item.id);
                return (
                  <div
                    key={item.id}
                    className={cn(
                      "flex items-center gap-3 rounded-xl border bg-white p-3 shadow-sm",
                      qty > 0 ? "border-brand-300 ring-1 ring-brand-100" : "border-line"
                    )}
                  >
                    <button
                      type="button"
                      className="min-w-0 flex-1 text-left"
                      onClick={() => add(item)}
                    >
                      <p className="text-sm font-semibold leading-snug">{highlightName(item.name)}</p>
                      <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-xs">
                        <span className="font-bold text-brand-700">{formatCurrency(item.price)}</span>
                        <span className="text-ink-muted">
                          {categoryNameById.get(item.categoryId) || ""}
                        </span>
                      </div>
                    </button>

                    {qty > 0 ? (
                      <div className="flex items-center gap-1 rounded-full border border-brand-200 bg-brand-50 px-1">
                        <button
                          type="button"
                          className="flex h-9 w-9 items-center justify-center rounded-full active:bg-brand-100"
                          onClick={() => setQty(item.id, qty - 1)}
                          aria-label="Decrease"
                        >
                          <Minus className="h-4 w-4" />
                        </button>
                        <span className="w-6 text-center text-sm font-bold tabular-nums">{qty}</span>
                        <button
                          type="button"
                          className="flex h-9 w-9 items-center justify-center rounded-full active:bg-brand-100"
                          onClick={() => add(item)}
                          aria-label="Increase"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => add(item)}
                        className="flex h-10 min-w-[4.5rem] items-center justify-center gap-1 rounded-full bg-brand-gradient px-3 text-sm font-bold text-white shadow-glow active:scale-95"
                      >
                        <Plus className="h-4 w-4" /> Add
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        ))}

        {!menuLoading && !filtered.length && (
          <p className="py-16 text-center text-sm text-ink-muted">
            {isSearching ? `No items matching “${search.trim()}”` : "No items in this category"}
          </p>
        )}
      </main>

      {/* Sticky cart / place order bar */}
      {cartCount > 0 && !showCart && (
        <div className="fixed inset-x-0 bottom-16 z-30 mx-auto max-w-lg border-t border-line bg-white/80 p-3 backdrop-blur-xl">
          <button
            type="button"
            onClick={() => setShowCart(true)}
            className="mb-2 flex w-full items-center justify-between rounded-xl bg-surface-muted px-3 py-2 text-sm"
          >
            <span className="font-semibold text-ink">
              <ShoppingCart className="mr-1 inline h-4 w-4" />
              {cartCount} item{cartCount === 1 ? "" : "s"} in cart
            </span>
            <span className="font-bold text-brand-700">{formatCurrency(total)}</span>
          </button>
          <button
            type="button"
            disabled={!tableNumber || placeMut.isPending}
            onClick={() => placeMut.mutate()}
            className="flex w-full items-center justify-center gap-2 btn-primary w-full py-3.5 disabled:opacity-50"
          >
            {placeMut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
            Place order · {formatCurrency(total)}
          </button>
          {!tableNumber && (
            <p className="mt-1 text-center text-[11px] text-amber-600">Select a table first</p>
          )}
        </div>
      )}

      {/* Full cart sheet */}
      {showCart && (
        <div className="fixed inset-0 z-50 flex flex-col bg-black/40">
          <button type="button" className="flex-1" onClick={() => setShowCart(false)} aria-label="Close" />
          <div className="mx-auto w-full max-w-lg rounded-t-2xl bg-white shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
              <h2 className="text-base font-bold">Cart ({cartCount})</h2>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={clearCart}
                  className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-semibold text-red-600"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Clear
                </button>
                <button type="button" onClick={() => setShowCart(false)} className="rounded-full p-1.5 hover:bg-slate-100">
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
            <ul className="max-h-[50vh] space-y-2 overflow-y-auto p-4">
              {lines.map((l) => (
                <li key={l.itemId} className="flex items-center gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{l.name}</p>
                    <p className="text-xs text-ink-secondary">{formatCurrency(l.price)} each</p>
                  </div>
                  <div className="flex items-center gap-1 rounded-full border border-line bg-surface-muted px-1">
                    <button type="button" className="p-2" onClick={() => setQty(l.itemId, l.quantity - 1)}>
                      <Minus className="h-3.5 w-3.5" />
                    </button>
                    <span className="w-5 text-center text-sm font-bold">{l.quantity}</span>
                    <button type="button" className="p-2" onClick={() => setQty(l.itemId, l.quantity + 1)}>
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <span className="w-16 text-right text-sm font-bold">
                    {formatCurrency(l.price * l.quantity)}
                  </span>
                </li>
              ))}
            </ul>
            <div className="border-t border-slate-100 p-4">
              <div className="mb-3 flex justify-between text-sm">
                <span className="text-ink-secondary">Total</span>
                <span className="text-lg font-bold text-brand-700">{formatCurrency(total)}</span>
              </div>
              <button
                type="button"
                disabled={!tableNumber || placeMut.isPending}
                onClick={() => placeMut.mutate()}
                className="flex w-full items-center justify-center gap-2 btn-primary w-full py-3.5 disabled:opacity-50"
              >
                {placeMut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                Place order
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function NewOrderPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center text-sm text-ink-muted">Loading…</div>}>
      <NewOrderInner />
    </Suspense>
  );
}
