"use client";
import { useQuery } from "@tanstack/react-query";
import { listOrders } from "@/lib/api/waiter";
import { formatCurrency, relativeTime } from "@/lib/utils/format";
import Link from "next/link";
import { useState } from "react";
import { cn } from "@/lib/utils/cn";
import { sanitizeSearch } from "@/lib/validation";
import { Search } from "lucide-react";

type Filter = "active" | "recent" | "archived";

export default function OrdersPage() {
  const [filter, setFilter] = useState<Filter>("active");
  const [search, setSearch] = useState("");
  const [q, setQ] = useState("");

  const params =
    filter === "active"
      ? { active: "1" as const, search: q || undefined }
      : filter === "archived"
        ? { includeArchived: "1" as const, search: q || undefined }
        : { search: q || undefined };

  const { data: orders, isLoading } = useQuery({
    queryKey: ["orders", filter, q],
    queryFn: () => listOrders(params),
    refetchInterval: 10000,
  });

  return (
    <div>
      <header className="sticky top-0 z-20 border-b border-line/60 bg-white/75 px-4 py-3 backdrop-blur-xl-xl">
        <h1 className="text-lg font-bold">Orders</h1>
        <div className="mt-2 flex gap-2">
          {(
            [
              ["active", "Active"],
              ["recent", "Recent"],
              ["archived", "Archived"],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setFilter(key)}
              className={cn(
                "rounded-full px-3 py-1 text-xs font-semibold",
                filter === key ? "chip-active" : "chip-idle"
              )}
            >
              {label}
            </button>
          ))}
        </div>
        <form
          className="relative mt-2"
          onSubmit={(e) => {
            e.preventDefault();
            setQ(sanitizeSearch(search, 80));
          }}
        >
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" />
          <input
            className="input-premium py-2.5 pl-9 pr-3"
            placeholder="Search id, bill, customer, waiter…"
            value={search}
            onChange={(e) => setSearch(sanitizeSearch(e.target.value, 80))}
            maxLength={80}
          />
        </form>
      </header>

      <main className="space-y-2 p-4">
        {isLoading &&
          Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-20 animate-pulse rounded-2xl border border-slate-100 bg-white" />
          ))}
        {(orders || []).map((o) => (
          <Link
            key={o.id}
            href={`/orders/${o.id}`}
            className="block card-premium p-4 hover:shadow-elev active:scale-[0.99]"
          >
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-bold">Table {o.tableNumber}</p>
                <p className="text-xs text-ink-secondary">
                  {o.items?.length ?? 0} items · {relativeTime(o.placedAt)}
                  {o.customerName ? ` · ${o.customerName}` : ""}
                  {o.billNumber ? ` · #${o.billNumber}` : ""}
                </p>
              </div>
              <div className="text-right">
                <p className="font-bold text-brand-600">{formatCurrency(o.total)}</p>
                <span className="mt-0.5 inline-block rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-bold uppercase text-ink-secondary">
                  {o.status}
                </span>
              </div>
            </div>
          </Link>
        ))}
        {!isLoading && !orders?.length && (
          <p className="py-16 text-center text-sm text-ink-muted">No orders</p>
        )}
      </main>
    </div>
  );
}
