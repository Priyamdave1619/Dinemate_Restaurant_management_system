"use client";
import { use, useMemo, useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getOrder,
  updateOrder,
  getOrderBill,
  getOrderKot,
  markKotPrinted,
  addOrderItems,
  listMenu,
  listCategories,
  getSettings,
  getRestaurantProfile,
} from "@/lib/api/waiter";
import { formatCurrency, relativeTime } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import Link from "next/link";
import {
  ArrowLeft,
  Loader2,
  Printer,
  Plus,
  Minus,
  Receipt,
  Percent,
  CreditCard,
  Share2,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";
import type { PaymentMethod, MenuItem } from "@/types";
import { BillReceipt } from "@/components/bill-receipt";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { FieldError } from "@/components/field-error";
import {
  validateDiscountPercent,
  validateOptionalName,
  validateOptionalPhone,
  sanitizeNumberInput,
  sanitizeSearch,
  sanitizePhone,
  sanitizeText,
} from "@/lib/validation";

const STATUS_FLOW = [
  { s: "accepted", l: "Accept" },
  { s: "preparing", l: "Preparing" },
  { s: "ready", l: "Ready" },
  { s: "served", l: "Served" },
] as const;

export default function OrderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const qc = useQueryClient();
  const [showAdd, setShowAdd] = useState(false);
  const [showBill, setShowBill] = useState(false);
  const [confirmBill, setConfirmBill] = useState(false);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [discount, setDiscount] = useState("");
  const [discountErr, setDiscountErr] = useState<string | null>(null);
  const [nameErr, setNameErr] = useState<string | null>(null);
  const [phoneErr, setPhoneErr] = useState<string | null>(null);
  const [payment, setPayment] = useState<PaymentMethod | "">("");
  /** Local only — shown on bill/share, never sent to API */
  const [billCustomerName, setBillCustomerName] = useState("");
  const [billCustomerPhone, setBillCustomerPhone] = useState("");
  const [menuSearch, setMenuSearch] = useState("");
  const [addCategoryId, setAddCategoryId] = useState<string>("all");
  const [addLines, setAddLines] = useState<
    Array<{ itemId: string; name: string; price: number; quantity: number }>
  >([]);

  const { data: order, isLoading } = useQuery({
    queryKey: ["order", id],
    queryFn: () => getOrder(id),
    refetchInterval: 8000,
  });

  const { data: restaurant } = useQuery({
    queryKey: ["restaurant-me"],
    queryFn: getRestaurantProfile,
    staleTime: 60_000,
  });

  const { data: settings } = useQuery({
    queryKey: ["settings"],
    queryFn: getSettings,
    staleTime: 60_000,
  });

  const { data: kot } = useQuery({
    queryKey: ["order-kot", id],
    queryFn: () => getOrderKot(id),
    enabled: !!order && !order.billGenerated && order.status !== "cancelled",
    refetchInterval: 10000,
  });

  const { data: menu } = useQuery({
    queryKey: ["menu"],
    queryFn: listMenu,
    enabled: showAdd,
  });

  const { data: categories } = useQuery({
    queryKey: ["categories"],
    queryFn: listCategories,
    enabled: showAdd,
  });


  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ["order", id] });
    qc.invalidateQueries({ queryKey: ["order-kot", id] });
    qc.invalidateQueries({ queryKey: ["orders"] });
    qc.invalidateQueries({ queryKey: ["orders-active"] });
  };

  const statusMut = useMutation({
    mutationFn: (status: string) => updateOrder(id, { status }),
    onSuccess: () => {
      invalidate();
      toast.success("Status updated");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const billMut = useMutation({
    mutationFn: () => getOrderBill(id),
    onSuccess: (res) => {
      invalidate();
      const o = res.order;
      toast.success(o.billNumber ? `Bill ${o.billNumber}` : "Bill generated");
      setShowBill(true);
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const kotMut = useMutation({
    mutationFn: () => markKotPrinted(id),
    onSuccess: () => {
      invalidate();
      toast.success("KOT marked as printed");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const discountMut = useMutation({
    mutationFn: (pct: number) => updateOrder(id, { manualDiscountPercent: pct }),
    onSuccess: () => {
      invalidate();
      toast.success("Discount applied");
      setDiscount("");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const paymentMut = useMutation({
    mutationFn: (method: PaymentMethod) => updateOrder(id, { paymentMethod: method }),
    onSuccess: () => {
      invalidate();
      toast.success("Payment method saved");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const addItemsMut = useMutation({
    mutationFn: () =>
      addOrderItems(id, {
        items: addLines.map((l) => ({
          itemId: l.itemId,
          name: l.name,
          quantity: l.quantity,
          price: l.price,
        })),
      }),
    onSuccess: () => {
      invalidate();
      setAddLines([]);
      setShowAdd(false);
      toast.success("Items added");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const categoryNameById = useMemo(() => {
    const m = new Map<string, string>();
    for (const c of categories || []) m.set(c.id, c.name);
    return m;
  }, [categories]);

  const activeCategories = useMemo(() => {
    const counts = new Map<string, number>();
    for (const item of menu || []) {
      if (item.available === false) continue;
      counts.set(item.categoryId, (counts.get(item.categoryId) || 0) + 1);
    }
    return (categories || []).filter((c) => (counts.get(c.id) || 0) > 0);
  }, [menu, categories]);

  const filteredMenu = useMemo(() => {
    let list = (menu || []).filter((m) => m.available !== false);
    const q = menuSearch.trim().toLowerCase();
    // While searching, ignore category chip so any item is findable
    if (!q && addCategoryId !== "all") {
      list = list.filter((m) => m.categoryId === addCategoryId);
    }
    if (q) {
      list = list
        .map((m) => {
          const n = m.name.toLowerCase();
          let score = 99;
          if (n === q) score = 0;
          else if (n.startsWith(q)) score = 1;
          else if (n.includes(q)) score = 2;
          else if ((categoryNameById.get(m.categoryId) || "").toLowerCase().includes(q)) score = 3;
          return { m, score };
        })
        .filter((x) => x.score < 99)
        .sort((a, b) => a.score - b.score || a.m.name.localeCompare(b.m.name))
        .map((x) => x.m);
    }
    return list;
  }, [menu, menuSearch, addCategoryId, categoryNameById]);

  function toggleAddItem(item: MenuItem) {
    setAddLines((prev) => {
      const ex = prev.find((l) => l.itemId === item.id);
      if (ex) return prev.map((l) => (l.itemId === item.id ? { ...l, quantity: l.quantity + 1 } : l));
      return [...prev, { itemId: item.id, name: item.name, price: item.price, quantity: 1 }];
    });
  }

  function setAddQty(itemId: string, qty: number) {
    if (qty <= 0) setAddLines((p) => p.filter((l) => l.itemId !== itemId));
    else setAddLines((p) => p.map((l) => (l.itemId === itemId ? { ...l, quantity: qty } : l)));
  }

  if (isLoading || !order) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-brand-500" />
      </div>
    );
  }

  const closed = order.status === "cancelled" || order.status === "completed" || order.billGenerated;
  const pendingKot = kot?.itemsToPrint?.length ?? order.items?.filter((i) => !i.kotPrinted).length ?? 0;
  const billOrder = order; // latest order state for receipt

  return (
    <div className="pb-8">
      <header className="sticky top-0 z-20 border-b border-line bg-white px-4 py-3">
        <Link href="/orders" className="inline-flex items-center gap-1 text-sm text-ink-secondary">
          <ArrowLeft className="h-4 w-4" /> Orders
        </Link>
        <div className="mt-1 flex items-start justify-between gap-2">
          <div>
            <h1 className="text-xl font-bold">Table {order.tableNumber}</h1>
            <p className="text-xs text-ink-secondary">
              {order.id} · {relativeTime(order.placedAt)}
              {order.waiterName ? ` · ${order.waiterName}` : ""}
            </p>
          </div>
          <span className="rounded-full bg-brand-50 px-2.5 py-1 text-xs font-bold uppercase text-brand-700">
            {order.status}
          </span>
        </div>
      </header>

      <main className="space-y-4 p-4">
        <section className="card-premium p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold text-ink-secondary">Items</h2>
            {!closed && (
              <button
                type="button"
                onClick={() => setShowAdd((v) => !v)}
                className="inline-flex items-center gap-1 rounded-lg bg-brand-50 px-2 py-1 text-xs font-bold text-brand-700"
              >
                <Plus className="h-3.5 w-3.5" /> Add items
              </button>
            )}
          </div>
          <ul className="space-y-2">
            {order.items?.map((it) => (
              <li key={it.id} className="flex justify-between gap-2 text-sm">
                <span className="min-w-0">
                  <span className="font-bold">{it.quantity}×</span> {it.name}
                  {it.variant && <span className="text-ink-muted"> ({it.variant})</span>}
                  {it.note && <span className="block text-xs text-amber-700">Note: {it.note}</span>}
                  {it.kotPrinted === false && (
                    <span className="ml-1 rounded bg-amber-100 px-1 text-[10px] font-bold text-amber-800">
                      NEW
                    </span>
                  )}
                </span>
                <span className="shrink-0 font-medium">{formatCurrency(it.price * it.quantity)}</span>
              </li>
            ))}
          </ul>

          <div className="mt-3 space-y-1 border-t border-slate-100 pt-3 text-sm">
            <div className="flex justify-between text-ink-secondary">
              <span>Subtotal</span>
              <span>{formatCurrency(order.subtotal ?? order.total)}</span>
            </div>
            {(order.discountTotal ?? 0) > 0 && (
              <div className="flex justify-between text-emerald-700">
                <span>Discount</span>
                <span>-{formatCurrency(order.discountTotal!)}</span>
              </div>
            )}
            {(order.taxAmount ?? 0) > 0 && (
              <div className="flex justify-between text-ink-secondary">
                <span>Tax ({order.taxRatePercent ?? 0}%)</span>
                <span>{formatCurrency(order.taxAmount!)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold">
              <span>Total</span>
              <span className="text-brand-700">{formatCurrency(order.total)}</span>
            </div>
            {order.billNumber && (
              <p className="mt-1 text-xs text-ink-secondary">Bill #{order.billNumber}</p>
            )}
            {order.paymentMethod && (
              <p className="text-xs capitalize text-ink-secondary">Paid via {order.paymentMethod}</p>
            )}
          </div>
        </section>

        {showAdd && !closed && (
          <section className="rounded-2xl border border-brand-200 bg-brand-50/40 p-4">
            <h2 className="mb-2 text-sm font-semibold text-brand-800">Add to order</h2>
            <div className="-mx-1 mb-2 flex gap-1.5 overflow-x-auto px-1 pb-0.5">
              <button
                type="button"
                onClick={() => setAddCategoryId("all")}
                className={cn(
                  "shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold",
                  addCategoryId === "all" ? "bg-brand-gradient text-white shadow-glow" : "bg-white text-ink-secondary border border-line"
                )}
              >
                All
              </button>
              {activeCategories.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setAddCategoryId(c.id)}
                  className={cn(
                    "shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold",
                    addCategoryId === c.id
                      ? "bg-brand-gradient text-white shadow-glow"
                      : "bg-white text-ink-secondary border border-line"
                  )}
                >
                  {c.name}
                </button>
              ))}
            </div>
            <input
              className="mb-2 w-full rounded-xl border border-line bg-white px-3 py-2 text-sm outline-none focus:border-brand-400"
              placeholder="Search any item…"
              value={menuSearch}
              onChange={(e) => setMenuSearch(sanitizeSearch(e.target.value, 80))}
              maxLength={80}
            />
            <div className="max-h-48 space-y-1 overflow-y-auto">
              {filteredMenu.map((item) => {
                const line = addLines.find((l) => l.itemId === item.id);
                return (
                  <div
                    key={item.id}
                    className="flex items-center gap-2 rounded-lg border border-line bg-white px-2 py-1.5"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{item.name}</p>
                      <p className="text-xs text-brand-700">{formatCurrency(item.price)}</p>
                    </div>
                    {line ? (
                      <div className="flex items-center gap-1">
                        <button type="button" className="p-1" onClick={() => setAddQty(item.id, line.quantity - 1)}>
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="w-5 text-center text-sm font-bold">{line.quantity}</span>
                        <button type="button" className="p-1" onClick={() => setAddQty(item.id, line.quantity + 1)}>
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => toggleAddItem(item)}
                        className="rounded-full bg-brand-gradient px-2.5 py-1 text-[10px] font-bold text-white shadow-glow"
                      >
                        Add
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
            {addLines.length > 0 && (
              <button
                type="button"
                disabled={addItemsMut.isPending}
                onClick={() => addItemsMut.mutate()}
                className="mt-3 flex w-full items-center justify-center gap-2 btn-primary w-full py-3 disabled:opacity-50"
              >
                {addItemsMut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                Add {addLines.reduce((s, l) => s + l.quantity, 0)} item(s)
              </button>
            )}
          </section>
        )}

        {!closed && (
          <section className="card-premium p-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h2 className="text-sm font-semibold text-ink">Kitchen (KOT)</h2>
                <p className="text-xs text-ink-secondary">
                  {pendingKot > 0
                    ? `${pendingKot} item(s) not yet printed · batch ${order.kotBatches ?? 0}`
                    : `All items printed · batch ${order.kotBatches ?? 0}`}
                </p>
              </div>
              <button
                type="button"
                disabled={kotMut.isPending || pendingKot === 0}
                onClick={() => kotMut.mutate()}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold",
                  pendingKot > 0 ? "bg-amber-500 text-white" : "bg-slate-100 text-ink-muted"
                )}
              >
                {kotMut.isPending ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Printer className="h-3.5 w-3.5" />
                )}
                Mark printed
              </button>
            </div>
            {pendingKot > 0 && kot?.itemsToPrint && (
              <ul className="mt-2 space-y-1 border-t border-slate-100 pt-2 text-sm">
                {kot.itemsToPrint.map((it) => (
                  <li key={it.id}>
                    <span className="font-bold">{it.quantity}×</span> {it.name}
                  </li>
                ))}
              </ul>
            )}
          </section>
        )}

        {!closed && (
          <section className="grid grid-cols-2 gap-2">
            {STATUS_FLOW.map(({ s, l }) => (
              <button
                key={s}
                type="button"
                disabled={statusMut.isPending || order.status === s}
                onClick={() => statusMut.mutate(s)}
                className={cn(
                  "rounded-xl border py-3 text-sm font-bold active:bg-surface-muted disabled:opacity-50",
                  order.status === s
                    ? "border-brand-300 bg-brand-50 text-brand-800"
                    : "border-line bg-white"
                )}
              >
                {l}
              </button>
            ))}
          </section>
        )}

        {!closed && (
          <section className="card-premium p-4">
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink">
              <Percent className="h-4 w-4" /> Manual discount %
            </div>
            <div className="flex gap-2">
              <input
                type="number"
                min={0}
                max={100}
                placeholder={String(order.manualDiscountPercent ?? 0)}
                value={discount}
                onChange={(e) => {
                  setDiscount(sanitizeNumberInput(e.target.value, true));
                  if (discountErr) setDiscountErr(null);
                }}
                inputMode="decimal"
                maxLength={6}

                className="flex-1 rounded-xl border border-line bg-surface-muted px-3 py-2.5 text-sm outline-none focus:border-brand-400"
              />
              <button
                type="button"
                disabled={discountMut.isPending || discount === ""}
                onClick={() => {
                  const r = validateDiscountPercent(discount);
                  if (!r.ok) {
                    setDiscountErr(r.message);
                    toast.error(r.message);
                    return;
                  }
                  setDiscountErr(null);
                  discountMut.mutate(r.value);
                }}
                className="rounded-xl bg-slate-900 px-4 text-sm font-bold text-white disabled:opacity-50"
              >
                Apply
              </button>
            </div>
            <FieldError message={discountErr} />
          </section>
        )}

        {/* Customer on bill only — not stored on server */}
        <section className="card-premium p-4">
          <h2 className="mb-1 text-sm font-semibold text-ink">Customer on bill</h2>
          <p className="mb-2 text-[11px] text-ink-muted">Printed/shared only — not saved</p>
          <div className="space-y-2">
            <input
              className="w-full rounded-xl border border-line bg-surface-muted px-3 py-2.5 text-sm outline-none focus:border-brand-400"
              placeholder="Customer name (optional)"
              value={billCustomerName}
              onChange={(e) => {
                setBillCustomerName(sanitizeText(e.target.value, 120));
                if (nameErr) setNameErr(null);
              }}
              maxLength={120}
              onBlur={() => {
                const r = validateOptionalName(billCustomerName);
                setNameErr(r.ok ? null : r.message);
              }}

            />
            <input
              className="w-full rounded-xl border border-line bg-surface-muted px-3 py-2.5 text-sm outline-none focus:border-brand-400"
              placeholder="Phone (optional)"
              type="tel"
              inputMode="tel"
              value={billCustomerPhone}
              onChange={(e) => {
                setBillCustomerPhone(sanitizePhone(e.target.value));
                if (phoneErr) setPhoneErr(null);
              }}
              maxLength={16}
              onBlur={() => {
                const r = validateOptionalPhone(billCustomerPhone);
                setPhoneErr(r.ok ? null : r.message);
              }}

            />
            <FieldError message={nameErr} />
            <FieldError message={phoneErr} />
          </div>
        </section>

        {!closed && (
          <section className="card-premium p-4">
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-ink">
              <CreditCard className="h-4 w-4" /> Payment method
            </div>
            <div className="grid grid-cols-3 gap-2">
              {(["cash", "card", "upi"] as PaymentMethod[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  disabled={paymentMut.isPending}
                  onClick={() => {
                    setPayment(m);
                    paymentMut.mutate(m);
                  }}
                  className={cn(
                    "rounded-xl border py-2.5 text-sm font-bold capitalize",
                    (payment || order.paymentMethod) === m
                      ? "border-brand-300 bg-brand-50 text-brand-800"
                      : "border-line bg-white"
                  )}
                >
                  {m}
                </button>
              ))}
            </div>
          </section>
        )}

        {/* Generate / View bill */}
        {!order.billGenerated ? (
          <button
            type="button"
            disabled={billMut.isPending || order.status === "cancelled"}
            onClick={() => setConfirmBill(true)}
            className="flex w-full items-center justify-center gap-2 btn-primary w-full py-3.5 disabled:opacity-50"
          >
            {billMut.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Receipt className="h-4 w-4" />
            )}
            Generate bill
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setShowBill(true)}
            className="flex w-full items-center justify-center gap-2 btn-primary w-full py-3.5"
          >
            <Share2 className="h-4 w-4" />
            View / Share bill
            {order.billNumber ? ` · ${order.billNumber}` : ""}
          </button>
        )}

        {!closed && (
          <button
            type="button"
            onClick={() => setConfirmCancel(true)}
            className="w-full rounded-xl border border-red-200 py-3 text-sm font-bold text-red-600"
          >
            Cancel order
          </button>
        )}
      </main>

      {showBill && billOrder && (
        <BillReceipt
          order={{
            ...billOrder,
            customerName: billCustomerName.trim() || undefined,
            customerPhone: billCustomerPhone.trim() || undefined,
          }}
          restaurant={restaurant ?? null}
          settings={settings ?? null}
          onClose={() => setShowBill(false)}
        />
      )}

      <ConfirmDialog
        open={confirmBill}
        title="Generate bill?"
        description="This finalizes the order, creates a bill number, and archives it. You can still view and share the bill afterward."
        confirmLabel="Generate bill"
        cancelLabel="Not now"
        variant="primary"
        loading={billMut.isPending}
        onCancel={() => setConfirmBill(false)}
        onConfirm={() => {
          billMut.mutate(undefined, {
            onSettled: () => setConfirmBill(false),
          });
        }}
      />

      <ConfirmDialog
        open={confirmCancel}
        title="Cancel this order?"
        description="The order will be marked cancelled. This cannot be undone from the waiter app."
        confirmLabel="Cancel order"
        cancelLabel="Keep order"
        variant="danger"
        loading={statusMut.isPending}
        onCancel={() => setConfirmCancel(false)}
        onConfirm={() => {
          statusMut.mutate("cancelled", {
            onSettled: () => setConfirmCancel(false),
          });
        }}
      />
    </div>
  );
}
