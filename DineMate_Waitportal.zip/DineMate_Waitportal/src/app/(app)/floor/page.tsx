"use client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listTables, updateTable, listOrders } from "@/lib/api/waiter";
import { useAuthStore } from "@/lib/stores/auth-store";
import { relativeTime } from "@/lib/utils/format";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import Link from "next/link";
import { RefreshCw } from "lucide-react";
import { cn } from "@/lib/utils/cn";

const statusStyle: Record<string, string> = {
  available: "border-emerald-200/80 bg-emerald-50/90 text-emerald-800 shadow-soft",
  occupied: "border-orange-200/80 bg-orange-50/90 text-orange-900 shadow-soft",
  reserved: "border-brand-200/80 bg-brand-50/90 text-brand-800 shadow-soft",
  cleaning: "border-amber-200/80 bg-amber-50/90 text-amber-900 shadow-soft",
};

export default function FloorPage() {
  const restaurant = useAuthStore((s) => s.restaurant);
  const user = useAuthStore((s) => s.user);
  const qc = useQueryClient();

  const { data: tables, isLoading, isFetching, refetch } = useQuery({
    queryKey: ["tables"],
    queryFn: listTables,
    refetchInterval: 12000,
  });

  const { data: activeOrders } = useQuery({
    queryKey: ["orders-active"],
    queryFn: () => listOrders({ active: "1" }),
    refetchInterval: 12000,
  });

  const ordersByTable = new Map<number, NonNullable<typeof activeOrders>[0]>();
  for (const o of activeOrders || []) {
    const existing = ordersByTable.get(o.tableNumber);
    if (!existing || new Date(o.placedAt) > new Date(existing.placedAt)) {
      ordersByTable.set(o.tableNumber, o);
    }
  }

  const statusMut = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) => updateTable(id, { status } as never),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tables"] });
      toast.success("Table updated");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  return (
    <div>
      <header className="sticky top-0 z-20 border-b border-line/60 bg-white/70 px-4 py-3 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold tracking-tight text-ink">Tables</h1>
            <p className="text-xs text-ink-secondary">{user?.name} · {user?.role}</p>
          </div>
          <button
            type="button"
            onClick={() => refetch()}
            className="rounded-full border border-line p-2.5 hover:bg-surface-muted"
          >
            <RefreshCw className={cn("h-4 w-4", isFetching && "animate-spin")} />
          </button>
        </div>
      </header>

      <main className="grid grid-cols-2 gap-3 p-4 sm:grid-cols-3">
        {isLoading &&
          Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-28 animate-pulse rounded-2xl bg-white border border-slate-100" />
          ))}
        {(tables || []).map((t) => {
          const order = ordersByTable.get(t.number);
          return (
            <div
              key={t.id}
              className={cn(
                "flex flex-col rounded-2xl border-2 p-3 shadow-sm transition",
                statusStyle[t.status] || "border-line bg-white"
              )}
            >
              <div className="flex items-start justify-between">
                <span className="text-2xl font-black">T{t.number}</span>
                <span className="rounded-full bg-white/70 px-2 py-0.5 text-[10px] font-bold uppercase">
                  {t.status}
                </span>
              </div>
              <p className="mt-1 text-[11px] opacity-70">{t.capacity} seats</p>
              {order && (
                <Link
                  href={`/orders/${order.id}`}
                  className="mt-2 block rounded-lg bg-white/80 px-2 py-1.5 text-[11px] font-medium underline-offset-2 hover:underline"
                >
                  Order · {relativeTime(order.placedAt)} · {order.status}
                </Link>
              )}
              <div className="mt-auto flex flex-wrap gap-1 pt-3">
                {t.status !== "available" && (
                  <button
                    type="button"
                    className="rounded-lg border border-white/60 bg-white/90 px-2 py-1 text-[10px] font-bold shadow-soft"
                    onClick={() => statusMut.mutate({ id: t.id, status: "available" })}
                  >
                    Free
                  </button>
                )}
                {t.status === "available" && (
                  <button
                    type="button"
                    className="rounded-lg border border-white/60 bg-white/90 px-2 py-1 text-[10px] font-bold shadow-soft"
                    onClick={() => statusMut.mutate({ id: t.id, status: "occupied" })}
                  >
                    Seat
                  </button>
                )}
                <Link
                  href={`/new-order?table=${t.number}`}
                  className="rounded-lg bg-brand-gradient px-2.5 py-1 text-[10px] font-bold text-white shadow-glow"
                >
                  Order
                </Link>
              </div>
            </div>
          );
        })}
        {!isLoading && !tables?.length && (
          <p className="col-span-full py-12 text-center text-sm text-ink-muted">No tables yet</p>
        )}
      </main>
    </div>
  );
}
