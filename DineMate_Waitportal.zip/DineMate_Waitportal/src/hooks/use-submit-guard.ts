"use client";

import { useCallback, useRef, useState } from "react";

export function useSubmitGuard() {
  const [pending, setPending] = useState(false);
  const lock = useRef(false);

  const run = useCallback(async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    if (lock.current) return undefined;
    lock.current = true;
    setPending(true);
    try {
      return await fn();
    } finally {
      lock.current = false;
      setPending(false);
    }
  }, []);

  return { pending, run };
}
