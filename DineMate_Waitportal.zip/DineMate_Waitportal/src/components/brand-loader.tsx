"use client";

import Image from "next/image";
import { cn } from "@/lib/utils/cn";

interface BrandLoaderProps {
  label?: string;
  fullScreen?: boolean;
  className?: string;
}

/**
 * Premium branded loader — logo + royal-blue pulse ring.
 */
export function BrandLoader({
  label = "Loading…",
  fullScreen = true,
  className,
}: BrandLoaderProps) {
  const inner = (
    <div className={cn("flex flex-col items-center justify-center gap-5", className)}>
      <div className="relative flex h-20 w-20 items-center justify-center">
        {/* Soft glow */}
        <div className="absolute inset-0 rounded-3xl bg-brand-500/15 blur-xl" />
        {/* Pulse ring */}
        <div className="absolute inset-0 animate-ping rounded-3xl border-2 border-brand-400/40" style={{ animationDuration: "1.6s" }} />
        <div className="absolute inset-1 animate-pulse rounded-[1.15rem] border border-brand-300/50" />
        <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl border border-line bg-white shadow-elev">
          <Image
            src="/favicon-light-192.png"
            alt=""
            width={40}
            height={40}
            className="object-contain"
            priority
          />
        </div>
      </div>
      {label && (
        <p className="text-xs font-semibold tracking-wide text-ink-muted animate-pulse">{label}</p>
      )}
    </div>
  );

  if (!fullScreen) return inner;

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-brand-soft">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(37,99,235,0.08),transparent_65%)]" />
      {inner}
    </div>
  );
}
