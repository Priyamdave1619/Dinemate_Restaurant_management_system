"use client";

import { cn } from "@/lib/utils/cn";

export function FieldError({
  message,
  id,
  className,
}: {
  message?: string | null;
  id?: string;
  className?: string;
}) {
  if (!message) return null;
  return (
    <p
      id={id}
      role="alert"
      className={cn("mt-1.5 text-xs font-medium text-danger animate-fade-in", className)}
    >
      {message}
    </p>
  );
}
