"use client";

import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { useAuthStore } from "@/lib/stores/auth-store";
import { BrandLogo } from "./brand-logo";

const PAGE_LABELS: Record<string, string> = {
  "/floor": "Floor",
  "/orders": "Orders",
  "/new-order": "New order",
  "/alerts": "Alerts",
  "/me": "Profile",
};

function pageLabel(pathname: string): string {
  if (pathname.startsWith("/orders/")) return "Order";
  return PAGE_LABELS[pathname] || "Waiter";
}

export function TitleBar() {
  const restaurant = useAuthStore((s) => s.restaurant);
  const pathname = usePathname();
  const name = restaurant?.name?.trim() || "Restaurant";
  const section = pageLabel(pathname);

  useEffect(() => {
    document.title = `${section} | ${name}`;
  }, [name, section]);

  return (
    <header className="sticky top-0 z-30 border-b border-line/80 bg-white/80 px-4 py-2.5 shadow-soft backdrop-blur-xl">
      <div className="mx-auto flex max-w-lg items-center gap-3">
        <BrandLogo variant="mark" height={32} className="shrink-0" alt="Brand" />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold tracking-tight text-ink">{name}</p>
          <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-brand-600">
            {section}
          </p>
        </div>
        <div
          className="h-1.5 w-1.5 rounded-full bg-success shadow-[0_0_8px_rgba(34,197,94,0.6)]"
          title="Online"
        />
      </div>
    </header>
  );
}
