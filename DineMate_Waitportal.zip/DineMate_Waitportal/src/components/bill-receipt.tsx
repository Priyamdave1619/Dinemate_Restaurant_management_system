"use client";

import { useRef, useState } from "react";
import type { Order, RestaurantProfile, RestaurantSettings } from "@/types";
import { formatCurrency } from "@/lib/utils/format";
import { Share2, Printer, X, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";


/** Strip tenant id (REST######) from bill/order labels for customer-facing receipt */
function displayBillNumber(billNumber?: string): string {
  if (!billNumber) return "—";
  return billNumber.replace(/^REST\d+[-_]?/i, "").replace(/^-+/, "") || billNumber;
}

function displayOrderNumber(orderId: string): string {
  // ord-REST000002-1005 → 1005
  const m = /^ord-REST\d+-(\d+)$/i.exec(orderId);
  if (m) return m[1];
  // fallback: last segment after dash
  const parts = orderId.split("-");
  const last = parts[parts.length - 1];
  if (/^\d+$/.test(last)) return last;
  return orderId.replace(/REST\d+/gi, "").replace(/^ord-+/i, "").replace(/^-+/, "") || orderId;
}

function formatDateTime(iso?: string) {
  if (!iso) return { date: "—", time: "—" };
  const d = new Date(iso);
  const date = d.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
  const time = d.toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
  return { date, time };
}

function buildShareText(
  order: Order,
  restaurant: RestaurantProfile | null,
  settings: RestaurantSettings | null
) {
  const name = restaurant?.name || settings?.restaurantName || "Restaurant";
  const { date, time } = formatDateTime(order.billedAt || order.updatedAt || order.placedAt);
  const lines: string[] = [];
  lines.push(name.toUpperCase());
  if (restaurant?.address || settings?.address) lines.push(restaurant?.address || settings?.address || "");
  if (restaurant?.mobile) lines.push(`PH: ${restaurant.mobile}`);
  if (restaurant?.gstNumber || settings?.gstin)
    lines.push(`GSTIN: ${restaurant?.gstNumber || settings?.gstin}`);
  lines.push("—".repeat(24));
  lines.push(`Bill: ${displayBillNumber(order.billNumber)}`);
  lines.push(`Order: ${displayOrderNumber(order.id)}`);
  lines.push(`Table: ${order.tableNumber}${order.waiterName ? `  Waiter: ${order.waiterName}` : ""}`);
  lines.push(`Date: ${date}  Time: ${time}`);
  if (order.customerName) lines.push(`Customer: ${order.customerName}`);
  if (order.customerPhone) lines.push(`Phone: ${order.customerPhone}`);
  if (order.paymentMethod) lines.push(`Payment: ${order.paymentMethod.toUpperCase()}`);
  lines.push("—".repeat(24));
  for (const it of order.items || []) {
    const lineTotal = (it.price * it.quantity).toFixed(2);
    lines.push(`${it.name}`);
    lines.push(`  ${it.price.toFixed(2)} x ${it.quantity} = ${lineTotal}`);
  }
  lines.push("—".repeat(24));
  lines.push(`Subtotal: ${formatCurrency(order.subtotal ?? order.total)}`);
  if ((order.discountTotal ?? 0) > 0) {
    lines.push(`Discount: -${formatCurrency(order.discountTotal!)}`);
  }
  if ((order.taxAmount ?? 0) > 0) {
    lines.push(`Tax (${order.taxRatePercent ?? settings?.taxRatePercent ?? 0}%): ${formatCurrency(order.taxAmount!)}`);
  }
  lines.push(`NET AMOUNT: ${formatCurrency(order.total)}`);
  lines.push("—".repeat(24));
  lines.push("Thank you! Visit again.");
  return lines.filter(Boolean).join("\n");
}

export interface BillReceiptProps {
  order: Order;
  restaurant: RestaurantProfile | null;
  settings: RestaurantSettings | null;
  onClose?: () => void;
  /** When true, render as full-screen modal overlay */
  modal?: boolean;
}

export function BillReceipt({ order, restaurant, settings, onClose, modal = true }: BillReceiptProps) {
  const printRef = useRef<HTMLDivElement>(null);
  const [sharing, setSharing] = useState(false);

  const name = restaurant?.name || settings?.restaurantName || "Restaurant";
  const address = restaurant?.address || settings?.address;
  const phone = restaurant?.mobile;
  const gst = restaurant?.gstNumber || settings?.gstin;
  const logo = restaurant?.logoUrl;
  const { date, time } = formatDateTime(order.billedAt || order.updatedAt || order.placedAt);
  const currency = restaurant?.currency || settings?.currency || "INR";

  async function handleShare() {
    setSharing(true);
    try {
      const text = buildShareText(order, restaurant, settings);
      const title = `Bill ${displayBillNumber(order.billNumber) === "—" ? "" : displayBillNumber(order.billNumber)} — ${name}`.replace(/^Bill  —/, "Bill —");

      // Prefer native share (Android / iOS / desktop Chromium)
      if (typeof navigator !== "undefined" && navigator.share) {
        // Try sharing as text first — most reliable across platforms
        const payload: ShareData = { title, text };
        // If Web Share Level 2 supports files, also try a plain-text file
        try {
          const blob = new Blob([text], { type: "text/plain" });
          const file = new File([blob], `bill-${displayBillNumber(order.billNumber) === "—" ? "receipt" : displayBillNumber(order.billNumber)}.txt`, {
            type: "text/plain",
          });
          if (navigator.canShare?.({ files: [file] })) {
            await navigator.share({ title, text, files: [file] });
            toast.success("Bill shared");
            return;
          }
        } catch {
          /* fall through to text-only share */
        }
        await navigator.share(payload);
        toast.success("Bill shared");
        return;
      }

      // Fallback: copy to clipboard
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
        toast.success("Bill copied — paste into WhatsApp, SMS, etc.");
        return;
      }

      toast.error("Sharing not supported on this device");
    } catch (err) {
      // User cancelled share sheet — not an error
      if (err instanceof Error && err.name === "AbortError") return;
      toast.error("Could not share bill");
    } finally {
      setSharing(false);
    }
  }

  function handlePrint() {
    const node = printRef.current;
    if (!node) return;
    const win = window.open("", "_blank", "noopener,noreferrer,width=400,height=700");
    if (!win) {
      toast.error("Allow pop-ups to print the bill");
      return;
    }
    win.document.write(`<!DOCTYPE html><html><head><title>Bill ${displayBillNumber(order.billNumber) === "—" ? "Receipt" : displayBillNumber(order.billNumber)}</title>
<style>
  @page { size: 80mm auto; margin: 4mm; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
         font-size: 12px; color: #111; padding: 8px; width: 80mm; max-width: 100%; }
  .center { text-align: center; }
  .logo { max-width: 72px; max-height: 72px; object-fit: contain; margin: 0 auto 6px; display: block; }
  h1 { font-size: 15px; font-weight: 700; letter-spacing: 0.02em; text-transform: uppercase; }
  .muted { color: #444; font-size: 11px; line-height: 1.35; }
  hr { border: none; border-top: 1px dashed #333; margin: 8px 0; }
  table { width: 100%; border-collapse: collapse; }
  th, td { padding: 2px 0; vertical-align: top; }
  th { font-size: 10px; text-align: left; border-bottom: 1px solid #333; }
  .right { text-align: right; }
  .meta td { font-size: 11px; padding: 1px 0; }
  .totals td { padding: 2px 0; }
  .net { font-size: 14px; font-weight: 700; }
  .footer { margin-top: 10px; text-align: center; font-size: 11px; }
</style></head><body>`);
    win.document.write(node.innerHTML);
    win.document.write("</body></html>");
    win.document.close();
    // Wait for images (logo) then print
    setTimeout(() => {
      win.focus();
      win.print();
    }, 350);
  }

  const content = (
    <div
      ref={printRef}
      className="mx-auto w-full max-w-[320px] bg-white px-3 py-4 text-[12px] text-ink"
      style={{ fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace" }}
    >
      {/* Header */}
      <div className="text-center">
        {logo ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={logo} alt={name} className="logo mx-auto mb-2 max-h-[72px] max-w-[72px] object-contain" />
        ) : null}
        <h1 className="text-[15px] font-bold uppercase tracking-wide">{name}</h1>
        {address && <p className="mt-1 text-[11px] leading-snug text-ink-secondary">{address}</p>}
        {phone && <p className="text-[11px] text-ink-secondary">PH: {phone}</p>}
        {gst && <p className="text-[11px] text-ink-secondary">GSTIN: {gst}</p>}
        <p className="mt-1 text-[11px] font-semibold tracking-wide">CASH / BILL</p>
      </div>

      <hr className="my-2 border-dashed border-slate-400" />

      {/* Meta */}
      <table className="meta w-full text-[11px]">
        <tbody>
          <tr>
            <td>Bill No</td>
            <td className="right font-semibold">{displayBillNumber(order.billNumber)}</td>
          </tr>
          <tr>
            <td>Order No</td>
            <td className="right">{displayOrderNumber(order.id)}</td>
          </tr>
          <tr>
            <td>Waiter</td>
            <td className="right">{order.waiterName || "—"}</td>
          </tr>
          <tr>
            <td>Table</td>
            <td className="right">{order.tableNumber}</td>
          </tr>
          <tr>
            <td>Date / Time</td>
            <td className="right">
              {date} {time}
            </td>
          </tr>
          {order.paymentMethod && (
            <tr>
              <td>Payment</td>
              <td className="right uppercase">{order.paymentMethod}</td>
            </tr>
          )}
          {order.customerName && (
            <tr>
              <td>Customer</td>
              <td className="right">{order.customerName}</td>
            </tr>
          )}
          {order.customerPhone && (
            <tr>
              <td>Phone</td>
              <td className="right">{order.customerPhone}</td>
            </tr>
          )}
        </tbody>
      </table>

      <hr className="my-2 border-dashed border-slate-400" />

      {/* Items */}
      <table className="w-full">
        <thead>
          <tr className="border-b border-slate-400 text-[10px] uppercase">
            <th className="pb-1 text-left font-semibold">Item</th>
            <th className="pb-1 text-right font-semibold">Price</th>
            <th className="pb-1 text-right font-semibold">Qty</th>
            <th className="pb-1 text-right font-semibold">Total</th>
          </tr>
        </thead>
        <tbody>
          {(order.items || []).map((it) => (
            <tr key={it.id}>
              <td className="py-0.5 pr-1">
                <span className="font-medium">{it.name}</span>
                {it.variant && <span className="block text-[10px] text-ink-secondary">{it.variant}</span>}
                {it.note && <span className="block text-[10px] text-amber-700">Note: {it.note}</span>}
              </td>
              <td className="py-0.5 text-right tabular-nums">{it.price.toFixed(2)}</td>
              <td className="py-0.5 text-right tabular-nums">{it.quantity}</td>
              <td className="py-0.5 text-right tabular-nums">{(it.price * it.quantity).toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <hr className="my-2 border-dashed border-slate-400" />

      {/* Totals */}
      <table className="totals w-full text-[12px]">
        <tbody>
          <tr>
            <td>Total Quantity</td>
            <td className="right tabular-nums">
              {(order.items || []).reduce((s, i) => s + i.quantity, 0)}
            </td>
          </tr>
          <tr>
            <td>Gross / Subtotal</td>
            <td className="right tabular-nums">{(order.subtotal ?? order.total).toFixed(2)}</td>
          </tr>
          {(order.discountTotal ?? 0) > 0 && (
            <tr>
              <td>
                Discount
                {(order.manualDiscountPercent ?? 0) > 0
                  ? ` (${order.manualDiscountPercent}%)`
                  : ""}
              </td>
              <td className="right tabular-nums">-{(order.discountTotal ?? 0).toFixed(2)}</td>
            </tr>
          )}
          {(order.appliedOffers || []).map((o) => (
            <tr key={o.offerId}>
              <td className="text-[11px] text-ink-secondary">Offer: {o.name}</td>
              <td className="right tabular-nums text-[11px]">-{o.amount.toFixed(2)}</td>
            </tr>
          ))}
          {(order.taxAmount ?? 0) > 0 && (
            <tr>
              <td>
                Tax / GST ({order.taxRatePercent ?? settings?.taxRatePercent ?? 0}%)
              </td>
              <td className="right tabular-nums">{(order.taxAmount ?? 0).toFixed(2)}</td>
            </tr>
          )}
          <tr className="net">
            <td className="pt-1 font-bold">Net Amount ({currency})</td>
            <td className="right pt-1 font-bold tabular-nums">{order.total.toFixed(2)}</td>
          </tr>
        </tbody>
      </table>

      <hr className="my-2 border-dashed border-slate-400" />

      <p className="footer text-center text-[11px] text-ink-secondary">
        Thank you! Visit again.
      </p>
      <p className="mt-1 text-center text-[10px] text-ink-secondary">Order {displayOrderNumber(order.id)}</p>
    </div>
  );

  if (!modal) return content;

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black/50 backdrop-blur-sm">
      <div className="mx-auto flex h-full w-full max-w-lg flex-col bg-surface-muted shadow-elev">
        <div className="flex items-center justify-between border-b border-line/80 bg-white/90 px-4 py-3 backdrop-blur-xl">
          <h2 className="text-base font-bold">Bill</h2>
          {onClose && (
            <button type="button" onClick={onClose} className="rounded-full p-1.5 hover:bg-slate-100" aria-label="Close">
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          <div className="rounded-xl border border-line bg-white shadow-sm">{content}</div>
        </div>

        <div className="safe-pb grid grid-cols-2 gap-2 border-t border-line bg-white p-4">
          <button
            type="button"
            onClick={handlePrint}
            className="btn-secondary py-3"
          >
            <Printer className="h-4 w-4" /> Print
          </button>
          <button
            type="button"
            disabled={sharing}
            onClick={handleShare}
            className="btn-primary py-3"
          >
            {sharing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Share2 className="h-4 w-4" />}
            Share
          </button>
          <button
            type="button"
            onClick={async () => {
              try {
                const text = buildShareText(order, restaurant, settings);
                await navigator.clipboard.writeText(text);
                toast.success("Bill text copied");
              } catch {
                toast.error("Copy failed");
              }
            }}
            className="col-span-2 inline-flex items-center justify-center gap-2 rounded-xl border border-line bg-surface-muted py-2.5 text-xs font-semibold text-ink"
          >
            <Download className="h-3.5 w-3.5" /> Copy bill text
          </button>
        </div>
      </div>
    </div>
  );
}
