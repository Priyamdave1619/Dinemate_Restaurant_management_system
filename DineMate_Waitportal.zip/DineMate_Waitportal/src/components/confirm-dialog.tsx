"use client";

import { useEffect } from "react";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils/cn";

export type ConfirmVariant = "default" | "danger" | "primary";

export interface ConfirmDialogProps {
  open: boolean;
  title: string;
  description?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: ConfirmVariant;
  loading?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  variant = "default",
  loading = false,
  onConfirm,
  onCancel,
}: ConfirmDialogProps) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !loading) onCancel();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, loading, onCancel]);

  if (!open) return null;

  const confirmClass =
    variant === "danger"
      ? "bg-danger text-white shadow-lg shadow-red-500/25 hover:brightness-110"
      : variant === "primary"
        ? "bg-brand-gradient text-white shadow-glow"
        : "bg-ink text-white";

  return (
    <div
      className="fixed inset-0 z-[100] flex items-end justify-center p-4 sm:items-center animate-fade-in"
      role="dialog"
      aria-modal="true"
      aria-labelledby="confirm-title"
    >
      <button
        type="button"
        className="absolute inset-0 bg-slate-900/40 backdrop-blur-md"
        aria-label="Dismiss"
        disabled={loading}
        onClick={() => !loading && onCancel()}
      />
      <div className="relative z-10 w-full max-w-sm animate-slide-up overflow-hidden rounded-3xl border border-white/50 bg-white shadow-elev">
        <div className="h-1 w-full bg-brand-gradient" />
        <div className="px-5 pt-5 pb-2">
          <h2 id="confirm-title" className="text-lg font-bold tracking-tight text-ink">
            {title}
          </h2>
          {description && (
            <p className="mt-2 text-sm leading-relaxed text-ink-secondary">{description}</p>
          )}
        </div>
        <div className="flex gap-2.5 p-4 pt-3">
          <button
            type="button"
            disabled={loading}
            onClick={onCancel}
            className="btn-secondary flex-1 py-3"
          >
            {cancelLabel}
          </button>
          <button
            type="button"
            disabled={loading}
            onClick={onConfirm}
            className={cn(
              "flex flex-1 items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold transition-all disabled:opacity-60",
              confirmClass
            )}
          >
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
