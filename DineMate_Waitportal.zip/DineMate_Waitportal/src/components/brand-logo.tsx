"use client";

import Image from "next/image";
import { cn } from "@/lib/utils/cn";

export type BrandLogoVariant = "full" | "mark" | "wordmark";

interface BrandLogoProps {
  /** full = horizontal logo, mark = favicon-style icon only */
  variant?: BrandLogoVariant;
  /** Prefer light logo on light backgrounds (default), dark logo for dark UI */
  theme?: "light" | "dark";
  className?: string;
  /** Pixel height hint for layout */
  height?: number;
  priority?: boolean;
  alt?: string;
}

/**
 * Company logo — uses light mark on light UI, dark mark when theme="dark".
 */
export function BrandLogo({
  variant = "full",
  theme = "light",
  className,
  height = 36,
  priority = false,
  alt = "Company logo",
}: BrandLogoProps) {
  const src =
    variant === "mark"
      ? theme === "dark"
        ? "/favicon-dark-192.png"
        : "/favicon-light-192.png"
      : theme === "dark"
        ? "/logos/logo-dark.png"
        : "/logos/logo-light.png";

  const width = variant === "mark" ? height : Math.round(height * 3.2);

  return (
    <span className={cn("relative inline-flex items-center justify-center", className)}>
      <Image
        src={src}
        alt={alt}
        width={width}
        height={height}
        priority={priority}
        className="h-auto w-auto object-contain"
        style={{ maxHeight: height, width: "auto" }}
      />
    </span>
  );
}
