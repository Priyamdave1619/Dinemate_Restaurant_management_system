"use client";
import { useAuthStore } from "@/lib/stores/auth-store";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { BottomNav } from "./bottom-nav";
import { SessionKeeper } from "./session-keeper";
import { TitleBar } from "./title-bar";
import { BrandLoader } from "./brand-loader";

export function AppShell({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const user = useAuthStore((s) => s.user);
  const accessToken = useAuthStore((s) => s.accessToken);
  const refreshToken = useAuthStore((s) => s.refreshToken);
  const hydrated = useAuthStore((s) => s._hydrated);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!hydrated) return;
    setReady(true);

    const hasSession = !!(accessToken || refreshToken) && !!user;
    if (!hasSession) {
      router.replace("/login");
      return;
    }
    if (!user?.restaurantId || user.role === ("super_admin" as string)) {
      router.replace("/login?error=unauthorized");
    }
  }, [hydrated, accessToken, refreshToken, user, router]);

  if (!ready || !hydrated) {
    return <BrandLoader label="Starting…" />;
  }

  if (!(accessToken || refreshToken) || !user) {
    return <BrandLoader label="Checking session…" />;
  }

  return (
    <div className="mx-auto min-h-screen max-w-lg bg-transparent pb-24">
      <SessionKeeper />
      <TitleBar />
      <div className="animate-fade-in">{children}</div>
      <BottomNav />
    </div>
  );
}
