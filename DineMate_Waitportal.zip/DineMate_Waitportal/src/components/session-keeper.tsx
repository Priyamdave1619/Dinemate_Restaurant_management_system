"use client";

import { useEffect } from "react";
import { useAuthStore } from "@/lib/stores/auth-store";
import { refreshAccessToken } from "@/lib/api/client";

/**
 * Keeps the waiter session alive until explicit logout:
 * - On mount / tab focus: refresh access token if we have a refresh token
 * - Every 10 minutes while the app is open: proactive refresh
 * Network failures do not log the user out.
 */
const REFRESH_INTERVAL_MS = 10 * 60 * 1000;

export function SessionKeeper() {
  const refreshToken = useAuthStore((s) => s.refreshToken);
  const user = useAuthStore((s) => s.user);
  const hydrated = useAuthStore((s) => s._hydrated);

  useEffect(() => {
    if (!hydrated || !user || !refreshToken) return;

    let cancelled = false;

    async function tick() {
      if (cancelled) return;
      await refreshAccessToken();
    }

    // Immediate refresh after hydrate so a cold start with only refresh token works
    void tick();

    const interval = setInterval(() => void tick(), REFRESH_INTERVAL_MS);

    const onVisible = () => {
      if (document.visibilityState === "visible") void tick();
    };
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", onVisible);

    return () => {
      cancelled = true;
      clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisible);
      window.removeEventListener("focus", onVisible);
    };
  }, [hydrated, user, refreshToken]);

  return null;
}
