"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutGrid, ClipboardList, PlusCircle, Bell, User } from "lucide-react";
import { cn } from "@/lib/utils/cn";

const items = [
  { href: "/floor", label: "Floor", icon: LayoutGrid },
  { href: "/orders", label: "Orders", icon: ClipboardList },
  { href: "/new-order", label: "New", icon: PlusCircle },
  { href: "/alerts", label: "Alerts", icon: Bell },
  { href: "/me", label: "Me", icon: User },
];

export function BottomNav() {
  const pathname = usePathname();
  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 safe-pb">
      <div className="mx-auto max-w-lg border-t border-line/80 bg-white/90 px-1 pt-1 shadow-[0_-8px_30px_rgba(15,23,42,0.06)] backdrop-blur-xl">
        <div className="flex items-stretch justify-around">
          {items.map((item) => {
            const active =
              pathname === item.href || pathname.startsWith(item.href + "/");
            const Icon = item.icon;
            const isNew = item.href === "/new-order";
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "relative flex flex-1 flex-col items-center gap-0.5 py-2 text-[10px] font-semibold transition-all duration-200",
                  active ? "text-brand-600" : "text-ink-muted hover:text-ink-secondary"
                )}
              >
                {isNew ? (
                  <span
                    className={cn(
                      "mb-0.5 flex h-10 w-10 items-center justify-center rounded-2xl transition-all",
                      active
                        ? "bg-brand-gradient text-white shadow-glow"
                        : "bg-brand-50 text-brand-600"
                    )}
                  >
                    <Icon className="h-5 w-5" strokeWidth={2.4} />
                  </span>
                ) : (
                  <Icon
                    className={cn("h-5 w-5 transition-transform", active && "scale-110")}
                    strokeWidth={active ? 2.5 : 2}
                  />
                )}
                {item.label}
                {active && !isNew && (
                  <span className="absolute bottom-1 h-1 w-1 rounded-full bg-brand-500" />
                )}
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
