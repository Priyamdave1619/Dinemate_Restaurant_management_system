# Sevusal Waiter Portal

Mobile-first floor app for **waiters**, **managers**, and **owners**.

Runs on **port 3004**.

## Features

| Screen | What it does |
|--------|----------------|
| **Floor** | Live table grid (free / seat / open order), auto-refresh |
| **Orders** | Active + recent orders |
| **Order detail** | KOT list, status (accept → prep → ready → served), generate bill, cancel |
| **New order** | Pick table + menu items, place order quickly |
| **Alerts** | Restaurant notifications |
| **Me** | Profile + logout |

## Setup

```bash
cp .env.example .env.local
# NEXT_PUBLIC_API_URL=http://localhost:3000

npm install
npm run dev
```

Open **http://localhost:3004**

Log in with a **waiter / manager / owner** account from the restaurant portal.

Add `http://localhost:3004` to backend `ALLOWED_ORIGINS`.

## Design

- Phone-width max layout (`max-w-lg`)
- Bottom tab navigation
- Large touch targets for floor use
- Auto-polling tables & orders every ~10–12s
