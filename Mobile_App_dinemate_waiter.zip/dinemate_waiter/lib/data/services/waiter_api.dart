import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/network/api_client.dart';
import '../../features/auth/auth_state.dart';
import '../models/models.dart';

class WaiterApi {
  final ApiClient _api;

  WaiterApi(this._api);

  // ── Tables ──────────────────────────────────────────────────────────────
  Future<List<RestaurantTable>> listTables() async {
    return _api.get(
      '/api/tables',
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final list = (d is Map ? d['tables'] : null) as List? ?? [];
        return list.map((e) => RestaurantTable.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      },
    );
  }

  Future<List<RestaurantTable>> updateTable(String id, Map<String, dynamic> body) async {
    final result = await _api.patch<List<RestaurantTable>?>(
      '/api/tables/$id',
      data: body,
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        if (d is Map && d['tables'] is List) {
          return (d['tables'] as List)
              .map((e) => RestaurantTable.fromJson(Map<String, dynamic>.from(e as Map)))
              .toList();
        }
        return null;
      },
    );
    if (result != null) return result;
    return listTables();
  }

  // ── Orders ──────────────────────────────────────────────────────────────
  Future<List<Order>> listOrders({
    String? active,
    String? tableNumber,
    String? search,
    String? includeArchived,
    int? page,
    int? pageSize,
  }) async {
    final params = <String, dynamic>{};
    if (active != null) params['active'] = active;
    if (tableNumber != null) params['tableNumber'] = tableNumber;
    if (search != null && search.isNotEmpty) params['search'] = search;
    if (includeArchived != null) params['includeArchived'] = includeArchived;
    if (page != null) params['page'] = page;
    if (pageSize != null) params['pageSize'] = pageSize;

    return _api.get(
      '/api/orders',
      queryParameters: params.isEmpty ? null : params,
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final list = (d is Map ? d['orders'] : null) as List? ?? [];
        return list.map((e) => Order.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      },
    );
  }

  Future<Order> getOrder(String id) async {
    return _api.get(
      '/api/orders/$id',
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final o = d is Map ? d['order'] ?? d : d;
        return Order.fromJson(Map<String, dynamic>.from(o as Map));
      },
    );
  }

  Future<Order> createOrder({
    required int tableNumber,
    required List<Map<String, dynamic>> items,
    String? note,
    String? waiterName,
  }) async {
    return _api.post(
      '/api/orders',
      data: {
        'tableNumber': tableNumber,
        'items': items,
        if (note != null) 'note': note,
        if (waiterName != null) 'waiterName': waiterName,
      },
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final o = d is Map ? d['order'] ?? d : d;
        return Order.fromJson(Map<String, dynamic>.from(o as Map));
      },
    );
  }

  Future<Order> updateOrder(String id, Map<String, dynamic> body) async {
    return _api.patch(
      '/api/orders/$id',
      data: body,
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final o = d is Map ? d['order'] ?? d : d;
        return Order.fromJson(Map<String, dynamic>.from(o as Map));
      },
    );
  }

  Future<Order> addOrderItems(String id, List<Map<String, dynamic>> items) async {
    return _api.post(
      '/api/orders/$id/items',
      data: {'items': items},
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final o = d is Map ? d['order'] ?? d : d;
        return Order.fromJson(Map<String, dynamic>.from(o as Map));
      },
    );
  }

  /// GET /api/orders/:id/kot — unprinted kitchen items
  /// Returns { order?, itemsToPrint: List<OrderItem> }
  Future<Map<String, dynamic>> getOrderKot(String id) async {
    return _api.get(
      '/api/orders/$id/kot',
      parser: (raw) {
        final m = raw as Map;
        final d = Map<String, dynamic>.from((m['data'] ?? m) as Map);
        final list = (d['itemsToPrint'] as List?) ??
            (d['items'] as List?) ??
            const [];
        d['itemsToPrint'] = list
            .map((e) => OrderItem.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList();
        if (d['order'] is Map) {
          d['order'] = Order.fromJson(Map<String, dynamic>.from(d['order'] as Map));
        }
        return d;
      },
    );
  }

  /// POST /api/orders/:id/kot — mark pending items as printed
  Future<Order> markKotPrinted(String id) async {
    return _api.post(
      '/api/orders/$id/kot',
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final o = d is Map ? d['order'] ?? d : d;
        return Order.fromJson(Map<String, dynamic>.from(o as Map));
      },
    );
  }

  /// GET /api/orders/:id/bill — first call finalizes; later returns archived bill.
  /// Returns { order: Order, settings?: RestaurantSettings }
  Future<Map<String, dynamic>> getOrderBill(String id) async {
    return _api.get(
      '/api/orders/$id/bill',
      parser: (raw) {
        final m = raw as Map;
        final d = Map<String, dynamic>.from((m['data'] ?? m) as Map);
        if (d['order'] is Map) {
          d['order'] = Order.fromJson(Map<String, dynamic>.from(d['order'] as Map));
        }
        if (d['settings'] is Map) {
          d['settings'] =
              RestaurantSettings.fromJson(Map<String, dynamic>.from(d['settings'] as Map));
        }
        return d;
      },
    );
  }

  // ── Menu ────────────────────────────────────────────────────────────────
  Future<List<MenuItem>> listMenu() async {
    return _api.get(
      '/api/menu',
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final list = (d is Map ? (d['items'] ?? d['menu']) : null) as List? ?? [];
        return list.map((e) => MenuItem.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      },
    );
  }

  Future<List<MenuCategory>> listCategories() async {
    return _api.get(
      '/api/categories',
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final list = (d is Map ? (d['categories'] ?? d['items']) : null) as List? ?? [];
        return list.map((e) => MenuCategory.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      },
    );
  }

  // ── Notifications ───────────────────────────────────────────────────────
  Future<List<AppNotification>> listNotifications({String? unread}) async {
    return _api.get(
      '/api/notifications',
      queryParameters: unread != null ? {'unread': unread} : null,
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final list = (d is Map ? d['notifications'] : null) as List? ?? [];
        return list.map((e) => AppNotification.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      },
    );
  }

  Future<void> markAllNotificationsRead() async {
    await _api.patch('/api/notifications', data: {'markAllRead': true});
  }

  Future<void> markNotificationRead(String id) async {
    await _api.patch('/api/notifications/$id', data: {'read': true});
  }

  // ── Restaurant ──────────────────────────────────────────────────────────
  Future<RestaurantProfile> getRestaurantProfile() async {
    return _api.get(
      '/api/restaurants/me',
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final r = d is Map ? d['restaurant'] ?? d : d;
        return RestaurantProfile.fromJson(Map<String, dynamic>.from(r as Map));
      },
    );
  }

  Future<RestaurantSettings> getSettings() async {
    return _api.get(
      '/api/settings',
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final s = d is Map && d['settings'] != null ? d['settings'] : d;
        return RestaurantSettings.fromJson(Map<String, dynamic>.from(s as Map));
      },
    );
  }

  Future<List<Offer>> listOffers() async {
    return _api.get(
      '/api/offers',
      parser: (raw) {
        final m = raw as Map;
        final d = m['data'] ?? m;
        final list = (d is Map ? d['offers'] : null) as List? ?? [];
        return list.map((e) => Offer.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      },
    );
  }
}

final waiterApiProvider = Provider<WaiterApi>((ref) {
  final api = ref.watch(apiClientProvider);
  return WaiterApi(api);
});
