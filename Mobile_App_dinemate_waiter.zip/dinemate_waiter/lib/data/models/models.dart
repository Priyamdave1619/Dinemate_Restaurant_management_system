import 'package:equatable/equatable.dart';

typedef UserRole = String; // owner | manager | waiter
typedef OrderStatus = String;
typedef PaymentMethod = String;
typedef TableStatus = String;

class SessionUser extends Equatable {
  final String id;
  final String username;
  final String name;
  final UserRole role;
  final String? restaurantId;

  const SessionUser({
    required this.id,
    required this.username,
    required this.name,
    required this.role,
    this.restaurantId,
  });

  factory SessionUser.fromJson(Map<String, dynamic> j) => SessionUser(
        id: j['id']?.toString() ?? '',
        username: j['username']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        role: j['role']?.toString() ?? 'waiter',
        restaurantId: j['restaurantId']?.toString(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'name': name,
        'role': role,
        'restaurantId': restaurantId,
      };

  @override
  List<Object?> get props => [id, username, name, role, restaurantId];
}

class RestaurantSummary extends Equatable {
  final String id;
  final String name;
  final String status;
  final String? logoUrl;
  final String? address;
  final String? mobile;
  final String? email;
  final String? gstNumber;
  final String? currency;

  const RestaurantSummary({
    required this.id,
    required this.name,
    required this.status,
    this.logoUrl,
    this.address,
    this.mobile,
    this.email,
    this.gstNumber,
    this.currency,
  });

  factory RestaurantSummary.fromJson(Map<String, dynamic> j) => RestaurantSummary(
        id: j['id']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        status: j['status']?.toString() ?? '',
        logoUrl: j['logoUrl']?.toString(),
        address: j['address']?.toString(),
        mobile: j['mobile']?.toString(),
        email: j['email']?.toString(),
        gstNumber: j['gstNumber']?.toString(),
        currency: j['currency']?.toString(),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'status': status,
        'logoUrl': logoUrl,
        'address': address,
        'mobile': mobile,
        'email': email,
        'gstNumber': gstNumber,
        'currency': currency,
      };

  @override
  List<Object?> get props => [id, name];
}

class RestaurantProfile extends Equatable {
  final String id;
  final String name;
  final String? ownerName;
  final String? email;
  final String? mobile;
  final String? address;
  final String? logoUrl;
  final String? gstNumber;
  final String? timezone;
  final String? currency;
  final String? status;

  const RestaurantProfile({
    required this.id,
    required this.name,
    this.ownerName,
    this.email,
    this.mobile,
    this.address,
    this.logoUrl,
    this.gstNumber,
    this.timezone,
    this.currency,
    this.status,
  });

  factory RestaurantProfile.fromJson(Map<String, dynamic> j) => RestaurantProfile(
        id: j['id']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        ownerName: j['ownerName']?.toString(),
        email: j['email']?.toString(),
        mobile: j['mobile']?.toString(),
        address: j['address']?.toString(),
        logoUrl: j['logoUrl']?.toString(),
        gstNumber: j['gstNumber']?.toString(),
        timezone: j['timezone']?.toString(),
        currency: j['currency']?.toString(),
        status: j['status']?.toString(),
      );

  @override
  List<Object?> get props => [id, name];
}

class LoginResponse {
  final String id;
  final String username;
  final String name;
  final UserRole role;
  final String? restaurantId;
  final RestaurantSummary? restaurant;
  final String accessToken;
  final String refreshToken;

  LoginResponse({
    required this.id,
    required this.username,
    required this.name,
    required this.role,
    this.restaurantId,
    this.restaurant,
    required this.accessToken,
    required this.refreshToken,
  });

  factory LoginResponse.fromJson(Map<String, dynamic> j) => LoginResponse(
        id: j['id']?.toString() ?? '',
        username: j['username']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        role: j['role']?.toString() ?? 'waiter',
        restaurantId: j['restaurantId']?.toString(),
        restaurant: j['restaurant'] != null
            ? RestaurantSummary.fromJson(Map<String, dynamic>.from(j['restaurant']))
            : null,
        accessToken: j['accessToken']?.toString() ?? '',
        refreshToken: j['refreshToken']?.toString() ?? '',
      );
}

class RestaurantTable extends Equatable {
  final String id;
  final int number;
  final int capacity;
  final TableStatus status;
  final String? currentOrderId;
  final String? waiterName;
  final String? qrPath;

  const RestaurantTable({
    required this.id,
    required this.number,
    required this.capacity,
    required this.status,
    this.currentOrderId,
    this.waiterName,
    this.qrPath,
  });

  factory RestaurantTable.fromJson(Map<String, dynamic> j) => RestaurantTable(
        id: j['id']?.toString() ?? '',
        number: (j['number'] as num?)?.toInt() ?? 0,
        capacity: (j['capacity'] as num?)?.toInt() ?? 0,
        status: j['status']?.toString() ?? 'available',
        currentOrderId: j['currentOrderId']?.toString(),
        waiterName: j['waiterName']?.toString(),
        qrPath: j['qrPath']?.toString(),
      );

  @override
  List<Object?> get props => [id, number, status];
}

class AppliedOffer {
  final String offerId;
  final String name;
  final double amount;

  AppliedOffer({required this.offerId, required this.name, required this.amount});

  factory AppliedOffer.fromJson(Map<String, dynamic> j) => AppliedOffer(
        offerId: j['offerId']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        amount: (j['amount'] as num?)?.toDouble() ?? 0,
      );
}

class OrderItem extends Equatable {
  final String id;
  final String itemId;
  final String name;
  final int quantity;
  final double price;
  final String? note;
  final String? variant;
  final bool? kotPrinted;
  final String? addedBy;
  final String? foodType;
  final String? categoryId;

  const OrderItem({
    required this.id,
    required this.itemId,
    required this.name,
    required this.quantity,
    required this.price,
    this.note,
    this.variant,
    this.kotPrinted,
    this.addedBy,
    this.foodType,
    this.categoryId,
  });

  factory OrderItem.fromJson(Map<String, dynamic> j) => OrderItem(
        id: j['id']?.toString() ?? '',
        itemId: j['itemId']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        quantity: (j['quantity'] as num?)?.toInt() ?? 1,
        price: (j['price'] as num?)?.toDouble() ?? 0,
        note: j['note']?.toString(),
        variant: j['variant']?.toString(),
        kotPrinted: j['kotPrinted'] as bool?,
        addedBy: j['addedBy']?.toString(),
        foodType: j['foodType']?.toString(),
        categoryId: j['categoryId']?.toString(),
      );

  double get lineTotal => price * quantity;

  @override
  List<Object?> get props => [id, itemId, quantity, price];
}

class Order extends Equatable {
  final String id;
  final String restaurantId;
  final int tableNumber;
  final List<OrderItem> items;
  final OrderStatus status;
  final String placedAt;
  final String updatedAt;
  final double total;
  final double subtotal;
  final double? manualDiscountPercent;
  final List<AppliedOffer>? appliedOffers;
  final double? discountTotal;
  final double? taxRatePercent;
  final double? taxAmount;
  final String? customerName;
  final String? customerPhone;
  final String? waiterName;
  final String? note;
  final int? estimatedMinutes;
  final int? kotBatches;
  final bool? billGenerated;
  final String? billNumber;
  final String? billedAt;
  final PaymentMethod? paymentMethod;

  const Order({
    required this.id,
    required this.restaurantId,
    required this.tableNumber,
    required this.items,
    required this.status,
    required this.placedAt,
    required this.updatedAt,
    required this.total,
    required this.subtotal,
    this.manualDiscountPercent,
    this.appliedOffers,
    this.discountTotal,
    this.taxRatePercent,
    this.taxAmount,
    this.customerName,
    this.customerPhone,
    this.waiterName,
    this.note,
    this.estimatedMinutes,
    this.kotBatches,
    this.billGenerated,
    this.billNumber,
    this.billedAt,
    this.paymentMethod,
  });

  factory Order.fromJson(Map<String, dynamic> j) => Order(
        id: j['id']?.toString() ?? '',
        restaurantId: j['restaurantId']?.toString() ?? '',
        tableNumber: (j['tableNumber'] as num?)?.toInt() ?? 0,
        items: (j['items'] as List? ?? [])
            .map((e) => OrderItem.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
        status: j['status']?.toString() ?? 'pending',
        placedAt: j['placedAt']?.toString() ?? '',
        updatedAt: j['updatedAt']?.toString() ?? '',
        total: (j['total'] as num?)?.toDouble() ?? 0,
        subtotal: (j['subtotal'] as num?)?.toDouble() ?? 0,
        manualDiscountPercent: (j['manualDiscountPercent'] as num?)?.toDouble(),
        appliedOffers: (j['appliedOffers'] as List?)
            ?.map((e) => AppliedOffer.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
        discountTotal: (j['discountTotal'] as num?)?.toDouble(),
        taxRatePercent: (j['taxRatePercent'] as num?)?.toDouble(),
        taxAmount: (j['taxAmount'] as num?)?.toDouble(),
        customerName: j['customerName']?.toString(),
        customerPhone: j['customerPhone']?.toString(),
        waiterName: j['waiterName']?.toString(),
        note: j['note']?.toString(),
        estimatedMinutes: (j['estimatedMinutes'] as num?)?.toInt(),
        kotBatches: (j['kotBatches'] as num?)?.toInt(),
        billGenerated: j['billGenerated'] as bool?,
        billNumber: j['billNumber']?.toString(),
        billedAt: j['billedAt']?.toString(),
        paymentMethod: j['paymentMethod']?.toString(),
      );

  @override
  List<Object?> get props => [id, status, total, items.length];
}

class MenuItem extends Equatable {
  final String id;
  final String name;
  final double price;
  final String categoryId;
  final bool available;
  final String? description;
  final String? image;
  final bool? isVeg;
  final String? foodType;
  final String? spiceLevel;
  final List<MenuVariant>? variants;
  /// Optional API translations
  final String? nameHi;
  final String? nameGu;
  final String? descriptionHi;
  final String? descriptionGu;

  const MenuItem({
    required this.id,
    required this.name,
    required this.price,
    required this.categoryId,
    required this.available,
    this.description,
    this.image,
    this.isVeg,
    this.foodType,
    this.spiceLevel,
    this.variants,
    this.nameHi,
    this.nameGu,
    this.descriptionHi,
    this.descriptionGu,
  });

  factory MenuItem.fromJson(Map<String, dynamic> j) {
    // Support nested translations object if backend sends it
    Map<String, dynamic>? tr;
    if (j['translations'] is Map) {
      tr = Map<String, dynamic>.from(j['translations'] as Map);
    }
    String? pick(List<String> keys) {
      for (final k in keys) {
        final v = j[k] ?? tr?[k];
        if (v != null && v.toString().trim().isNotEmpty) return v.toString();
      }
      return null;
    }

    return MenuItem(
      id: j['id']?.toString() ?? '',
      name: j['name']?.toString() ?? j['nameEn']?.toString() ?? j['name_en']?.toString() ?? '',
      price: (j['price'] as num?)?.toDouble() ?? 0,
      categoryId: j['categoryId']?.toString() ?? '',
      available: j['available'] as bool? ?? true,
      description: j['description']?.toString(),
      image: j['image']?.toString(),
      isVeg: j['isVeg'] as bool?,
      foodType: j['foodType']?.toString(),
      spiceLevel: j['spiceLevel']?.toString(),
      variants: (j['variants'] as List?)
          ?.map((e) => MenuVariant.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      nameHi: pick(['nameHi', 'nameHindi', 'name_hi', 'name_hindi', 'hi']),
      nameGu: pick(['nameGu', 'nameGujarati', 'name_gu', 'name_gujarati', 'gu']),
      descriptionHi: pick(['descriptionHi', 'descriptionHindi', 'description_hi']),
      descriptionGu: pick(['descriptionGu', 'descriptionGujarati', 'description_gu']),
    );
  }

  @override
  List<Object?> get props => [id, name, price];
}

class MenuVariant {
  final String id;
  final String label;
  final double priceDelta;

  MenuVariant({required this.id, required this.label, required this.priceDelta});

  factory MenuVariant.fromJson(Map<String, dynamic> j) => MenuVariant(
        id: j['id']?.toString() ?? '',
        label: j['label']?.toString() ?? '',
        priceDelta: (j['priceDelta'] as num?)?.toDouble() ?? 0,
      );
}

class MenuCategory extends Equatable {
  final String id;
  final String name;
  final String? icon;
  final String? nameHi;
  final String? nameGu;

  const MenuCategory({
    required this.id,
    required this.name,
    this.icon,
    this.nameHi,
    this.nameGu,
  });

  factory MenuCategory.fromJson(Map<String, dynamic> j) => MenuCategory(
        id: j['id']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        icon: j['icon']?.toString(),
        nameHi: (j['nameHi'] ?? j['nameHindi'] ?? j['name_hi'])?.toString(),
        nameGu: (j['nameGu'] ?? j['nameGujarati'] ?? j['name_gu'])?.toString(),
      );

  @override
  List<Object?> get props => [id, name];
}

class AppNotification extends Equatable {
  final String id;
  final String title;
  final String message;
  final String? type;
  final bool? read;
  final String createdAt;
  final String? relatedEntityType;
  final String? relatedEntityId;

  const AppNotification({
    required this.id,
    required this.title,
    required this.message,
    this.type,
    this.read,
    required this.createdAt,
    this.relatedEntityType,
    this.relatedEntityId,
  });

  factory AppNotification.fromJson(Map<String, dynamic> j) => AppNotification(
        id: j['id']?.toString() ?? '',
        title: j['title']?.toString() ?? '',
        message: j['message']?.toString() ?? '',
        type: j['type']?.toString(),
        read: j['read'] as bool?,
        createdAt: j['createdAt']?.toString() ?? '',
        relatedEntityType: j['relatedEntityType']?.toString(),
        relatedEntityId: j['relatedEntityId']?.toString(),
      );

  @override
  List<Object?> get props => [id, read];
}

class RestaurantSettings {
  final String restaurantId;
  final double taxRatePercent;
  final String restaurantName;
  final String? address;
  final String? gstin;
  final String? baseUrl;
  final String? currency;
  final String? openingTime;
  final String? closingTime;
  final String? billPrefix;

  RestaurantSettings({
    required this.restaurantId,
    required this.taxRatePercent,
    required this.restaurantName,
    this.address,
    this.gstin,
    this.baseUrl,
    this.currency,
    this.openingTime,
    this.closingTime,
    this.billPrefix,
  });

  factory RestaurantSettings.fromJson(Map<String, dynamic> j) => RestaurantSettings(
        restaurantId: j['restaurantId']?.toString() ?? '',
        taxRatePercent: (j['taxRatePercent'] as num?)?.toDouble() ?? 0,
        restaurantName: j['restaurantName']?.toString() ?? j['name']?.toString() ?? '',
        address: j['address']?.toString(),
        gstin: j['gstin']?.toString() ?? j['gstNumber']?.toString(),
        baseUrl: j['baseUrl']?.toString(),
        currency: j['currency']?.toString(),
        openingTime: j['openingTime']?.toString(),
        closingTime: j['closingTime']?.toString(),
        billPrefix: j['billPrefix']?.toString(),
      );
}

class Offer {
  final String id;
  final String name;
  final String type;
  final bool active;
  final String? description;
  final double? discountPercent;
  final double? discountAmount;
  final String? couponCode;

  Offer({
    required this.id,
    required this.name,
    required this.type,
    required this.active,
    this.description,
    this.discountPercent,
    this.discountAmount,
    this.couponCode,
  });

  factory Offer.fromJson(Map<String, dynamic> j) => Offer(
        id: j['id']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        type: j['type']?.toString() ?? '',
        active: j['active'] as bool? ?? false,
        description: j['description']?.toString(),
        discountPercent: (j['discountPercent'] as num?)?.toDouble(),
        discountAmount: (j['discountAmount'] as num?)?.toDouble(),
        couponCode: j['couponCode']?.toString(),
      );
}

/// Cart line for new order
class CartLine {
  final MenuItem item;
  final int quantity;
  final String? variant;
  final String? note;
  final double unitPrice;

  CartLine({
    required this.item,
    required this.quantity,
    this.variant,
    this.note,
    required this.unitPrice,
  });

  CartLine copyWith({int? quantity, String? variant, String? note}) => CartLine(
        item: item,
        quantity: quantity ?? this.quantity,
        variant: variant ?? this.variant,
        note: note ?? this.note,
        unitPrice: unitPrice,
      );

  double get lineTotal => unitPrice * quantity;
}
