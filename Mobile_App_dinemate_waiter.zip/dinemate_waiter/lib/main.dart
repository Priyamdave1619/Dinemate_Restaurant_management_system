import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/theme/app_theme.dart';
import 'core/theme/brand.dart';
import 'core/routing/app_router.dart';
import 'features/auth/auth_state.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Allow all orientations — responsive layouts handle phone/tablet/landscape
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const ProviderScope(child: DineMateWaiterApp()));
}

class DineMateWaiterApp extends ConsumerWidget {
  const DineMateWaiterApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(routerProvider);
    // Ensure auth hydrates early
    ref.watch(authProvider);

    return MaterialApp.router(
      title: Brand.fullAppName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: ThemeMode.system,
      routerConfig: router,
    );
  }
}
