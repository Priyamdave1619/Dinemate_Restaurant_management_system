import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import '../config/app_config.dart';
import '../errors/app_exception.dart';

typedef TokenGetter = Future<String?> Function();
typedef TokenRefresher = Future<String?> Function();
typedef OnUnauthorized = void Function();

class ApiClient {
  late final Dio _dio;
  TokenGetter? _getAccessToken;
  TokenRefresher? _refreshToken;
  OnUnauthorized? _onUnauthorized;
  bool _refreshing = false;

  ApiClient() {
    _dio = Dio(BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: AppConfig.connectTimeout,
      receiveTimeout: AppConfig.receiveTimeout,
      headers: {'Content-Type': 'application/json'},
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await _getAccessToken?.call();
        if (token != null && token.isNotEmpty) {
          options.headers['Authorization'] = 'Bearer $token';
        }
        return handler.next(options);
      },
      onError: (error, handler) async {
        if (error.response?.statusCode == 401 && error.requestOptions.extra['_retry'] != true) {
          error.requestOptions.extra['_retry'] = true;
          final newToken = await _tryRefresh();
          if (newToken != null) {
            error.requestOptions.headers['Authorization'] = 'Bearer $newToken';
            try {
              final response = await _dio.fetch(error.requestOptions);
              return handler.resolve(response);
            } catch (e) {
              return handler.next(error);
            }
          }
        }
        return handler.next(error);
      },
    ));

    if (kDebugMode) {
      _dio.interceptors.add(LogInterceptor(
        requestBody: true,
        responseBody: true,
        error: true,
        requestHeader: false,
        responseHeader: false,
      ));
    }
  }

  void configure({
    required TokenGetter getAccessToken,
    required TokenRefresher refreshToken,
    OnUnauthorized? onUnauthorized,
  }) {
    _getAccessToken = getAccessToken;
    _refreshToken = refreshToken;
    _onUnauthorized = onUnauthorized;
  }

  Future<String?> _tryRefresh() async {
    if (_refreshing) return null;
    _refreshing = true;
    try {
      return await _refreshToken?.call();
    } finally {
      _refreshing = false;
    }
  }

  Future<T> get<T>(
    String path, {
    Map<String, dynamic>? queryParameters,
    T Function(dynamic data)? parser,
  }) async {
    try {
      final res = await _dio.get(path, queryParameters: queryParameters);
      return _parse(res.data, parser);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  Future<T> post<T>(
    String path, {
    dynamic data,
    T Function(dynamic data)? parser,
  }) async {
    try {
      final res = await _dio.post(path, data: data);
      return _parse(res.data, parser);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  Future<T> patch<T>(
    String path, {
    dynamic data,
    T Function(dynamic data)? parser,
  }) async {
    try {
      final res = await _dio.patch(path, data: data);
      return _parse(res.data, parser);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  Future<T> delete<T>(
    String path, {
    dynamic data,
    T Function(dynamic data)? parser,
  }) async {
    try {
      final res = await _dio.delete(path, data: data);
      return _parse(res.data, parser);
    } on DioException catch (e) {
      throw _mapError(e);
    }
  }

  /// Direct post without auth interceptor side-effects (for refresh)
  Future<Response> rawPost(String path, {dynamic data, Map<String, dynamic>? headers}) {
    return Dio(BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 20),
      headers: {'Content-Type': 'application/json', ...?headers},
    )).post(path, data: data);
  }

  T _parse<T>(dynamic data, T Function(dynamic data)? parser) {
    if (parser != null) return parser(data);
    return data as T;
  }

  AppException _mapError(DioException e) {
    if (e.type == DioExceptionType.connectionTimeout ||
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.sendTimeout) {
      return const TimeoutException();
    }
    if (e.type == DioExceptionType.connectionError) {
      return const NetworkException();
    }
    final status = e.response?.statusCode;
    final body = e.response?.data;
    String message = 'Something went wrong. Please try again.';
    if (body is Map) {
      message = body['message']?.toString() ??
          body['error']?.toString() ??
          (body['data'] is Map ? (body['data'] as Map)['message']?.toString() : null) ??
          message;
    }
    if (status == 401) return UnauthorizedException(message);
    if (status == 400 || status == 422) return ValidationException(message);
    if (status != null && status >= 500) return ServerException(message);
    return AppException(message, statusCode: status);
  }
}
