import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../features/auth/auth_state.dart';
import '../../presentation/screens/login/login_screen.dart';
import '../../presentation/screens/floor/floor_screen.dart';
import '../../presentation/screens/orders/orders_screen.dart';
import '../../presentation/screens/order_detail/order_detail_screen.dart';
import '../../presentation/screens/new_order/new_order_screen.dart';
import '../../presentation/screens/alerts/alerts_screen.dart';
import '../../presentation/screens/me/me_screen.dart';
import '../../presentation/widgets/app_shell.dart';

/// Holds a listenable that GoRouter can refresh without recreating the router.
class AuthRefreshNotifier extends ChangeNotifier {
  void ping() => notifyListeners();
}

final authRefreshProvider = Provider<AuthRefreshNotifier>((ref) {
  final notifier = AuthRefreshNotifier();
  ref.listen<AuthState>(authProvider, (prev, next) {
    // Only refresh when auth-relevant fields change
    if (prev?.hydrated != next.hydrated ||
        prev?.isAuthenticated != next.isAuthenticated ||
        prev?.user?.id != next.user?.id ||
        prev?.user?.restaurantId != next.user?.restaurantId) {
      notifier.ping();
    }
  });
  return notifier;
});

final routerProvider = Provider<GoRouter>((ref) {
  final refresh = ref.watch(authRefreshProvider);

  // Read auth inside redirect so we never recreate GoRouter on every state tick
  return GoRouter(
    initialLocation: '/floor',
    refreshListenable: refresh,
    redirect: (context, state) {
      final auth = ref.read(authProvider);
      final loc = state.matchedLocation;
      final isLogin = loc == '/login';

      if (!auth.hydrated) return null;

      if (!auth.isAuthenticated && !isLogin) return '/login';
      if (auth.isAuthenticated && isLogin) return '/floor';

      if (auth.isAuthenticated) {
        final user = auth.user;
        if (user?.restaurantId == null || user?.role == 'super_admin') {
          return '/login';
        }
      }
      return null;
    },
    routes: [
      GoRoute(
        path: '/login',
        builder: (c, s) => const LoginScreen(),
      ),
      ShellRoute(
        builder: (context, state, child) {
          return AppShell(
            location: state.matchedLocation,
            child: child,
          );
        },
        routes: [
          GoRoute(
            path: '/floor',
            pageBuilder: (c, s) => const NoTransitionPage(child: FloorScreen()),
          ),
          GoRoute(
            path: '/orders',
            pageBuilder: (c, s) => const NoTransitionPage(child: OrdersScreen()),
          ),
          GoRoute(
            path: '/orders/:id',
            builder: (c, s) => OrderDetailScreen(orderId: s.pathParameters['id']!),
          ),
          GoRoute(
            path: '/new-order',
            pageBuilder: (c, s) {
              final table = s.uri.queryParameters['table'];
              return NoTransitionPage(
                child: NewOrderScreen(
                  preselectedTable: table != null ? int.tryParse(table) : null,
                ),
              );
            },
          ),
          GoRoute(
            path: '/alerts',
            pageBuilder: (c, s) => const NoTransitionPage(child: AlertsScreen()),
          ),
          GoRoute(
            path: '/me',
            pageBuilder: (c, s) => const NoTransitionPage(child: MeScreen()),
          ),
        ],
      ),
    ],
  );
});
