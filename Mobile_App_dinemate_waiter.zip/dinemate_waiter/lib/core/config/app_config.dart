class AppConfig {
  AppConfig._();

  static const String appName = 'DineMate Waiter';
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'your_api_url',
  );

  static const Duration connectTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);
  static const Duration tablesPollInterval = Duration(seconds: 12);
  static const Duration ordersPollInterval = Duration(seconds: 12);
  static const Duration tokenRefreshInterval = Duration(minutes: 10);

  static const int maxUsernameLength = 40;
  static const int maxPasswordLength = 200;
  static const int maxSearchLength = 80;
}