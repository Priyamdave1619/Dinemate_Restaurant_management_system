import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'app_colors.dart';

class AppTypography {
  AppTypography._();

  static TextTheme textTheme(Brightness brightness) {
    final base = GoogleFonts.interTextTheme();
    final color = brightness == Brightness.dark ? AppColors.darkInk : AppColors.ink;
    final secondary = brightness == Brightness.dark ? AppColors.darkInkSecondary : AppColors.inkSecondary;
    final heading = brightness == Brightness.dark ? AppColors.darkInk : AppColors.primary900;

    return base.copyWith(
      displayLarge: base.displayLarge?.copyWith(color: heading, fontWeight: FontWeight.w800),
      displayMedium: base.displayMedium?.copyWith(color: heading, fontWeight: FontWeight.w700),
      headlineLarge: base.headlineLarge?.copyWith(color: heading, fontWeight: FontWeight.w700, fontSize: 24),
      headlineMedium: base.headlineMedium?.copyWith(color: heading, fontWeight: FontWeight.w700, fontSize: 20),
      titleLarge: base.titleLarge?.copyWith(color: heading, fontWeight: FontWeight.w700, fontSize: 18),
      titleMedium: base.titleMedium?.copyWith(color: color, fontWeight: FontWeight.w600, fontSize: 16),
      titleSmall: base.titleSmall?.copyWith(color: color, fontWeight: FontWeight.w600, fontSize: 14),
      bodyLarge: base.bodyLarge?.copyWith(color: color, fontSize: 16),
      bodyMedium: base.bodyMedium?.copyWith(color: secondary, fontSize: 14),
      bodySmall: base.bodySmall?.copyWith(color: secondary, fontSize: 12),
      labelLarge: base.labelLarge?.copyWith(color: color, fontWeight: FontWeight.w600, fontSize: 14),
      labelMedium: base.labelMedium?.copyWith(color: secondary, fontWeight: FontWeight.w500, fontSize: 12),
      labelSmall: base.labelSmall?.copyWith(color: secondary, fontWeight: FontWeight.w500, fontSize: 10),
    );
  }
}
