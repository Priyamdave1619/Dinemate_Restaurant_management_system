import 'package:flutter/material.dart';

/// Royal Navy Blue design tokens — single source of truth for color.
///
/// Primary brand: #0B1F3A (Primary 800)
/// Use tonal scale by hierarchy; never hardcode ad-hoc blues in widgets.
class AppColors {
  AppColors._();

  // ── Primary scale (Royal Navy) ───────────────────────────────────────────
  static const Color primary50 = Color(0xFFF3F6FA);
  static const Color primary100 = Color(0xFFE5EBF3);
  static const Color primary200 = Color(0xFFCBD7E6);
  static const Color primary300 = Color(0xFFA8BAD0);
  static const Color primary400 = Color(0xFF7894B4);
  static const Color primary500 = Color(0xFF4A6B91);
  static const Color primary600 = Color(0xFF294C73);
  static const Color primary700 = Color(0xFF16385F);
  static const Color primary800 = Color(0xFF0B1F3A); // core brand
  static const Color primary900 = Color(0xFF07162A);

  /// Alias used across the app for primary brand actions.
  static const Color brand50 = primary50;
  static const Color brand100 = primary100;
  static const Color brand200 = primary200;
  static const Color brand400 = primary400;
  static const Color brand500 = primary500;
  static const Color brand600 = primary800; // primary CTA → core navy
  static const Color brand700 = primary700;
  static const Color brand800 = primary800;
  static const Color brand900 = primary900;

  // ── Light surfaces ───────────────────────────────────────────────────────
  static const Color surface = Color(0xFFF8FAFC); // page bg
  static const Color surfaceMute = Color(0xFFF1F5F9);
  static const Color white = Color(0xFFFFFFFF);
  static const Color line = Color(0xFFD9E1EA);

  // ── Light text ───────────────────────────────────────────────────────────
  static const Color ink = Color(0xFF0F172A);
  static const Color inkSecondary = Color(0xFF475569);
  static const Color inkMuted = Color(0xFF64748B);

  // ── Semantic (unchanged meaning) ─────────────────────────────────────────
  static const Color success = Color(0xFF16A34A);
  static const Color successBg = Color(0xFFECFDF5);
  static const Color warning = Color(0xFFD97706);
  static const Color warningBg = Color(0xFFFFFBEB);
  static const Color error = Color(0xFFDC2626);
  static const Color errorBg = Color(0xFFFEF2F2);
  static const Color info = primary600;

  // ── Table status (floor) — keep readable, navy-adjacent accents ──────────
  static const Color availableBg = Color(0xFFECFDF5);
  static const Color availableBorder = Color(0xFFA7F3D0);
  static const Color availableText = Color(0xFF065F46);
  static const Color occupiedBg = Color(0xFFFFF7ED);
  static const Color occupiedBorder = Color(0xFFFED7AA);
  static const Color occupiedText = Color(0xFF9A3412);
  static const Color reservedBg = primary50;
  static const Color reservedBorder = primary200;
  static const Color reservedText = primary800;
  static const Color cleaningBg = Color(0xFFFFFBEB);
  static const Color cleaningBorder = Color(0xFFFDE68A);
  static const Color cleaningText = Color(0xFF92400E);

  // ── Dark mode ────────────────────────────────────────────────────────────
  static const Color darkSurface = Color(0xFF07111F); // page bg
  static const Color darkCard = Color(0xFF0D1B2E); // surface
  static const Color darkElevated = Color(0xFF12243A);
  static const Color darkInk = Color(0xFFF8FAFC);
  static const Color darkInkSecondary = Color(0xFFA8B5C5);
  static const Color darkLine = Color(0xFF23364D);
  /// Lighter navy for CTAs on dark backgrounds (accessible).
  static const Color darkPrimary = Color(0xFF7894B4); // primary400
  static const Color darkPrimaryHover = Color(0xFFA8BAD0);
}
