/// Centralized DineMate branding configuration.
class Brand {
  Brand._();

  static const String companyName = 'DineMate';
  static const String appName = 'Waiter Portal';
  static const String fullAppName = 'DineMate Waiter';
  static const String logoAlt = 'DineMate logo';

  /// Logo for light-mode UI (matches original Next.js theme="light").
  static const String logoLightMode = 'assets/logos/logo-light.png';

  /// Logo for dark-mode UI (matches original Next.js theme="dark").
  static const String logoDarkMode = 'assets/logos/logo-dark.png';

  /// Preferred sizes (logical pixels, height).
  static const double sizeXs = 20;
  static const double sizeSm = 28;
  static const double sizeMd = 36;
  static const double sizeLg = 48;
  static const double sizeXl = 64;
  static const double sizeHero = 80;
}
