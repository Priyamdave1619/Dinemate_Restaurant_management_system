class ValidationResult {
  final bool ok;
  final String? message;
  final String value;

  const ValidationResult.ok(this.value)
      : ok = true,
        message = null;
  const ValidationResult.fail(this.message)
      : ok = false,
        value = '';
}

ValidationResult validateUsername(String raw) {
  final v = raw.trim();
  if (v.isEmpty) return const ValidationResult.fail('Username is required');
  if (v.length < 2) return const ValidationResult.fail('Username is too short');
  if (v.length > 40) return const ValidationResult.fail('Username is too long');
  return ValidationResult.ok(v);
}

ValidationResult validateLoginPassword(String raw) {
  if (raw.isEmpty) return const ValidationResult.fail('Password is required');
  if (raw.length < 4) return const ValidationResult.fail('Password is too short');
  if (raw.length > 200) return const ValidationResult.fail('Password is too long');
  return ValidationResult.ok(raw);
}

String sanitizeSearch(String raw, [int max = 80]) {
  final cleaned = raw.trim().replaceAll(RegExp(r'\s+'), ' ');
  if (cleaned.length <= max) return cleaned;
  return cleaned.substring(0, max);
}
