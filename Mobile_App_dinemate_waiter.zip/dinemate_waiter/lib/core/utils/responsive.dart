import 'package:flutter/material.dart';

/// Breakpoints aligned with common device classes.
class Breakpoints {
  static const double phone = 600;
  static const double tablet = 900;
  static const double desktop = 1200;
}

enum DeviceType { phone, tablet, desktop }

class Responsive {
  final BuildContext context;
  final Size size;

  Responsive(this.context) : size = MediaQuery.sizeOf(context);

  double get width => size.width;
  double get height => size.height;
  double get shortest => size.shortestSide;
  bool get isLandscape => size.width > size.height;

  DeviceType get device {
    // Use shortest side so landscape phones stay "phone"
    if (shortest < Breakpoints.phone) return DeviceType.phone;
    if (shortest < Breakpoints.tablet) return DeviceType.tablet;
    return DeviceType.desktop;
  }

  bool get isPhone => device == DeviceType.phone;
  bool get isTablet => device == DeviceType.tablet;
  bool get isDesktop => device == DeviceType.desktop;

  /// Max content width so the app doesn't stretch edge-to-edge on tablets/desktop.
  double get contentMaxWidth {
    if (isPhone) return double.infinity;
    if (isTablet) return 720;
    return 960;
  }

  /// Horizontal page padding.
  double get pagePadding {
    if (width < 360) return 12;
    if (isPhone) return 16;
    if (isTablet) return 24;
    return 32;
  }

  /// Floor grid columns.
  int get tableColumns {
    if (width < 360) return 2;
    if (isPhone) return isLandscape ? 3 : 2;
    if (isTablet) return isLandscape ? 4 : 3;
    return 5;
  }

  /// Menu / list density.
  double get listItemExtent => isPhone ? 72 : 80;

  /// Scale factor for touch targets (min ~44).
  double get touchMin => isPhone ? 44 : 48;

  T value<T>({required T phone, T? tablet, T? desktop}) {
    switch (device) {
      case DeviceType.desktop:
        return desktop ?? tablet ?? phone;
      case DeviceType.tablet:
        return tablet ?? phone;
      case DeviceType.phone:
        return phone;
    }
  }
}

/// Centers child and clamps width on large screens.
class ResponsiveBody extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;

  const ResponsiveBody({super.key, required this.child, this.padding});

  @override
  Widget build(BuildContext context) {
    final r = Responsive(context);
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: r.contentMaxWidth),
        child: Padding(
          padding: padding ?? EdgeInsets.symmetric(horizontal: r.pagePadding),
          child: child,
        ),
      ),
    );
  }
}
