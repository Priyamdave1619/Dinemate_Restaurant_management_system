import 'package:intl/intl.dart';

String formatCurrency(num amount, {String currency = '₹'}) {
  final f = NumberFormat.currency(symbol: currency, decimalDigits: 2);
  return f.format(amount);
}

String relativeTime(String iso) {
  try {
    final dt = DateTime.parse(iso).toLocal();
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inSeconds < 60) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return DateFormat('dd MMM').format(dt);
  } catch (_) {
    return iso;
  }
}

String formatTime(String iso) {
  try {
    return DateFormat('hh:mm a').format(DateTime.parse(iso).toLocal());
  } catch (_) {
    return iso;
  }
}

String formatDateTime(String iso) {
  try {
    return DateFormat('dd MMM yyyy, hh:mm a').format(DateTime.parse(iso).toLocal());
  } catch (_) {
    return iso;
  }
}
