import 'dart:io';
import 'dart:typed_data';

import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import '../../data/models/models.dart';

String displayBillNumber(String? billNumber) {
  if (billNumber == null || billNumber.isEmpty) return '—';
  return billNumber
      .replaceFirst(RegExp(r'^REST\d+[-_]?', caseSensitive: false), '')
      .replaceFirst(RegExp(r'^-+'), '');
}

String displayOrderNumber(String orderId) {
  final m = RegExp(r'^ord-REST\d+-(\d+)$', caseSensitive: false).firstMatch(orderId);
  if (m != null) return m.group(1)!;
  final parts = orderId.split('-');
  final last = parts.isNotEmpty ? parts.last : orderId;
  if (RegExp(r'^\d+$').hasMatch(last)) return last;
  return orderId
      .replaceAll(RegExp(r'REST\d+', caseSensitive: false), '')
      .replaceFirst(RegExp(r'^ord-+', caseSensitive: false), '');
}

String formatBillDateTime(String? iso) {
  if (iso == null || iso.isEmpty) return '—';
  try {
    final d = DateTime.parse(iso).toLocal();
    final date =
        '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
    final time =
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    return '$date $time';
  } catch (_) {
    return iso;
  }
}

String billFileName(Order order) {
  final n = displayBillNumber(order.billNumber);
  final safe = (n == '—' ? displayOrderNumber(order.id) : n)
      .replaceAll(RegExp(r'[^\w\-]+'), '_');
  return 'bill_$safe.pdf';
}

/// Build bill PDF bytes (receipt layout matching Waitportal BillReceipt).
Future<Uint8List> buildBillPdf({
  required Order order,
  RestaurantProfile? restaurant,
  RestaurantSettings? settings,
}) async {
  final name = restaurant?.name ?? settings?.restaurantName ?? 'Restaurant';
  final address = restaurant?.address ?? settings?.address;
  final phone = restaurant?.mobile;
  final gst = restaurant?.gstNumber ?? settings?.gstin;
  final currency = restaurant?.currency ?? settings?.currency ?? 'INR';
  final when = formatBillDateTime(
    order.billedAt ?? (order.updatedAt.isNotEmpty ? order.updatedAt : order.placedAt),
  );
  final totalQty = order.items.fold<int>(0, (s, i) => s + i.quantity);

  // Optional logo from network
  pw.ImageProvider? logoImage;
  final logoUrl = restaurant?.logoUrl;
  if (logoUrl != null && logoUrl.isNotEmpty) {
    try {
      logoImage = await networkImage(logoUrl);
    } catch (_) {
      logoImage = null;
    }
  }

  final doc = pw.Document();

  pw.Widget dashedLine() => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 6),
        child: pw.Divider(thickness: 0.6, color: PdfColors.grey700, height: 1),
      );

  pw.Widget metaRow(String k, String v) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 1),
        child: pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text(k, style: const pw.TextStyle(fontSize: 8)),
            pw.Text(v, style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
          ],
        ),
      );

  doc.addPage(
    pw.MultiPage(
      pageFormat: const PdfPageFormat(226.77, 841.89, marginAll: 12), // 80mm x A4 height
      build: (ctx) {
        return [
          pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            if (logoImage != null) ...[
              pw.Center(child: pw.Image(logoImage, height: 40, fit: pw.BoxFit.contain)),
              pw.SizedBox(height: 4),
            ],
            pw.Text(
              name.toUpperCase(),
              textAlign: pw.TextAlign.center,
              style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold),
            ),
            if (address != null && address.isNotEmpty)
              pw.Text(address, textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey700)),
            if (phone != null && phone.isNotEmpty)
              pw.Text('PH: $phone', textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey700)),
            if (gst != null && gst.isNotEmpty)
              pw.Text('GSTIN: $gst', textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey700)),
            pw.SizedBox(height: 3),
            pw.Text('CASH / BILL', textAlign: pw.TextAlign.center, style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
            dashedLine(),
            metaRow('Bill No', displayBillNumber(order.billNumber)),
            metaRow('Order No', displayOrderNumber(order.id)),
            metaRow('Waiter', order.waiterName ?? '—'),
            metaRow('Table', '${order.tableNumber}'),
            metaRow('Date / Time', when),
            if (order.paymentMethod != null) metaRow('Payment', order.paymentMethod!.toUpperCase()),
            if (order.customerName != null) metaRow('Customer', order.customerName!),
            if (order.customerPhone != null) metaRow('Phone', order.customerPhone!),
            dashedLine(),
            // Items header
            pw.Row(
              children: [
                pw.Expanded(flex: 4, child: pw.Text('ITEM', style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold))),
                pw.Expanded(child: pw.Text('PRICE', textAlign: pw.TextAlign.right, style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold))),
                pw.Expanded(child: pw.Text('QTY', textAlign: pw.TextAlign.right, style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold))),
                pw.Expanded(child: pw.Text('TOTAL', textAlign: pw.TextAlign.right, style: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold))),
              ],
            ),
            pw.SizedBox(height: 3),
            ...order.items.map((it) {
              return pw.Padding(
                padding: const pw.EdgeInsets.symmetric(vertical: 2),
                child: pw.Row(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Expanded(
                      flex: 4,
                      child: pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Text(it.name, style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold)),
                          if (it.variant != null)
                            pw.Text(it.variant!, style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey700)),
                          if (it.note != null)
                            pw.Text('Note: ${it.note}', style: const pw.TextStyle(fontSize: 7, color: PdfColors.orange800)),
                        ],
                      ),
                    ),
                    pw.Expanded(child: pw.Text(it.price.toStringAsFixed(2), textAlign: pw.TextAlign.right, style: const pw.TextStyle(fontSize: 8))),
                    pw.Expanded(child: pw.Text('${it.quantity}', textAlign: pw.TextAlign.right, style: const pw.TextStyle(fontSize: 8))),
                    pw.Expanded(
                      child: pw.Text(
                        (it.price * it.quantity).toStringAsFixed(2),
                        textAlign: pw.TextAlign.right,
                        style: const pw.TextStyle(fontSize: 8),
                      ),
                    ),
                  ],
                ),
              );
            }),
            dashedLine(),
            metaRow('Total Quantity', '$totalQty'),
            metaRow('Gross / Subtotal', order.subtotal.toStringAsFixed(2)),
            if ((order.discountTotal ?? 0) > 0)
              metaRow(
                (order.manualDiscountPercent ?? 0) > 0
                    ? 'Discount (${order.manualDiscountPercent}%)'
                    : 'Discount',
                '-${order.discountTotal!.toStringAsFixed(2)}',
              ),
            if ((order.taxAmount ?? 0) > 0)
              metaRow(
                'Tax / GST (${order.taxRatePercent ?? settings?.taxRatePercent ?? 0}%)',
                order.taxAmount!.toStringAsFixed(2),
              ),
            pw.SizedBox(height: 4),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Net Amount ($currency)', style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold)),
                pw.Text(order.total.toStringAsFixed(2), style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold)),
              ],
            ),
            dashedLine(),
            pw.Text('Thank you! Visit again.', textAlign: pw.TextAlign.center, style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700)),
            pw.Text(
              'Order ${displayOrderNumber(order.id)}',
              textAlign: pw.TextAlign.center,
              style: const pw.TextStyle(fontSize: 7, color: PdfColors.grey600),
            ),
          ],
          ),
        ];
      },
    ),
  );

  return doc.save();
}

/// Save PDF under app documents and return the file path.
Future<File> saveBillPdf({
  required Order order,
  RestaurantProfile? restaurant,
  RestaurantSettings? settings,
}) async {
  final bytes = await buildBillPdf(order: order, restaurant: restaurant, settings: settings);
  final dir = await getApplicationDocumentsDirectory();
  final file = File('${dir.path}/${billFileName(order)}');
  await file.writeAsBytes(bytes, flush: true);
  return file;
}

/// Share bill as PDF via system share sheet.
Future<void> shareBillPdf({
  required Order order,
  RestaurantProfile? restaurant,
  RestaurantSettings? settings,
}) async {
  final file = await saveBillPdf(order: order, restaurant: restaurant, settings: settings);
  final name = restaurant?.name ?? settings?.restaurantName ?? 'Restaurant';
  final title = 'Bill ${displayBillNumber(order.billNumber)} — $name';
  await Share.shareXFiles(
    [XFile(file.path, mimeType: 'application/pdf', name: billFileName(order))],
    subject: title,
    text: title,
  );
}

/// Open system print dialog for the bill PDF.
Future<void> printBillPdf({
  required Order order,
  RestaurantProfile? restaurant,
  RestaurantSettings? settings,
}) async {
  final bytes = await buildBillPdf(order: order, restaurant: restaurant, settings: settings);
  await Printing.layoutPdf(
    onLayout: (_) async => bytes,
    name: billFileName(order),
  );
}
