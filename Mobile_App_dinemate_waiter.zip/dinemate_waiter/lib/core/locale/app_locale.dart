import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum AppLanguage {
  en,
  hi,
  gu;

  String get code => name;

  String get label {
    switch (this) {
      case AppLanguage.en:
        return 'English';
      case AppLanguage.hi:
        return 'हिन्दी';
      case AppLanguage.gu:
        return 'ગુજરાતી';
    }
  }

  String get nativeLabel {
    switch (this) {
      case AppLanguage.en:
        return 'English';
      case AppLanguage.hi:
        return 'Hindi';
      case AppLanguage.gu:
        return 'Gujarati';
    }
  }

  static AppLanguage fromCode(String? code) {
    switch (code) {
      case 'hi':
        return AppLanguage.hi;
      case 'gu':
        return AppLanguage.gu;
      default:
        return AppLanguage.en;
    }
  }
}

class LocaleNotifier extends StateNotifier<AppLanguage> {
  LocaleNotifier() : super(AppLanguage.en) {
    _load();
  }

  static const _key = 'app_language';

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    state = AppLanguage.fromCode(prefs.getString(_key));
  }

  Future<void> setLanguage(AppLanguage lang) async {
    state = lang;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, lang.code);
  }
}

final localeProvider = StateNotifierProvider<LocaleNotifier, AppLanguage>((ref) {
  return LocaleNotifier();
});

/// UI string catalog for waiter app screens.
class S {
  final AppLanguage lang;
  const S(this.lang);

  static S of(WidgetRef ref) => S(ref.watch(localeProvider));
  static S ofLang(AppLanguage lang) => S(lang);

  String _t(String en, String hi, String gu) {
    switch (lang) {
      case AppLanguage.hi:
        return hi;
      case AppLanguage.gu:
        return gu;
      case AppLanguage.en:
        return en;
    }
  }

  // ── Navigation ──────────────────────────────────────────────────────────
  String get navFloor => _t('Floor', 'फ्लोर', 'ફ્લોર');
  String get navOrders => _t('Orders', 'ऑर्डर', 'ઓર્ડર');
  String get navNew => _t('New', 'नया', 'નવું');
  String get navAlerts => _t('Alerts', 'अलर्ट', 'એલર્ટ');
  String get navMe => _t('Me', 'मैं', 'હું');

  String get sectionFloor => _t('FLOOR', 'फ्लोर', 'ફ્લોર');
  String get sectionOrders => _t('ORDERS', 'ऑर्डर', 'ઓર્ડર');
  String get sectionNewOrder => _t('NEW ORDER', 'नया ऑर्डर', 'નવો ઓર્ડર');
  String get sectionAlerts => _t('ALERTS', 'अलर्ट', 'એલર્ટ');
  String get sectionProfile => _t('PROFILE', 'प्रोफ़ाइल', 'પ્રોફાઇલ');
  String get sectionWaiter => _t('WAITER', 'वेटर', 'વેટર');

  String get starting => _t('Starting…', 'शुरू हो रहा है…', 'શરૂ થઈ રહ્યું છે…');
  String get checkingSession => _t('Checking session…', 'सेशन जाँच…', 'સેશન તપાસ…');

  // ── Common ──────────────────────────────────────────────────────────────
  String get retry => _t('Retry', 'फिर कोशिश', 'ફરી પ્રયાસ');
  String get cancel => _t('Cancel', 'रद्द', 'રદ');
  String get done => _t('Done', 'हो गया', 'થઈ ગયું');
  String get error => _t('Error', 'त्रुटि', 'ભૂલ');
  String get loading => _t('Loading…', 'लोड हो रहा है…', 'લોડ થઈ રહ્યું છે…');
  String get language => _t('Language', 'भाषा', 'ભાષા');
  String get signOut => _t('Sign out', 'साइन आउट', 'સાઇન આઉટ');
  String get signOutConfirm => _t('Sign out?', 'साइन आउट?', 'સાઇન આઉટ?');
  String get signOutBody => _t(
        'You will need to sign in again to use the app.',
        'ऐप उपयोग करने के लिए फिर से साइन इन करना होगा।',
        'એપ્લિકેશન વાપરવા માટે ફરીથી સાઇન ઇન કરવું પડશે.',
      );
  String get keepOrder => _t('Keep order', 'ऑर्डर रखें', 'ઓર્ડર રાખો');
  String get profile => _t('Profile', 'प्रोफ़ाइल', 'પ્રોફાઇલ');
  String get welcome => _t('Welcome', 'स्वागत है', 'સ્વાગત છે');
  String get unableSignIn => _t(
        'Unable to sign in. Please try again.',
        'साइन इन नहीं हो सका। फिर कोशिश करें।',
        'સાઇન ઇન થઈ શક્યું નહીં. ફરી પ્રયાસ કરો.',
      );

  // ── Login ───────────────────────────────────────────────────────────────
  String get signInSubtitle => _t(
        'Sign in to manage the floor',
        'फ्लोर प्रबंधित करने के लिए साइन इन करें',
        'ફ્લોર મેનેજ કરવા માટે સાઇન ઇન કરો',
      );
  String get username => _t('Username', 'यूज़रनेम', 'યૂઝરનેમ');
  String get password => _t('Password', 'पासवर्ड', 'પાસવર્ડ');
  String get signIn => _t('Sign in', 'साइन इन', 'સાઇન ઇન');

  // ── Floor ───────────────────────────────────────────────────────────────
  String get tables => _t('Tables', 'टेबल', 'ટેબલ');
  String get tableUpdated => _t('Table updated', 'टेबल अपडेट', 'ટેબલ અપડેટ');
  String get available => _t('available', 'खाली', 'ખાલી');
  String get occupied => _t('occupied', 'व्यस्त', 'વ્યસ્ત');
  String get reserved => _t('reserved', 'आरक्षित', 'આરક્ષિત');
  String get cleaning => _t('cleaning', 'सफाई', 'સફાઈ');
  String get seats => _t('seats', 'सीट', 'સીટ');
  String get viewOrder => _t('View order', 'ऑर्डर देखें', 'ઓર્ડર જુઓ');
  String get newOrderShort => _t('New order', 'नया ऑर्डर', 'નવો ઓર્ડર');
  String get setStatus => _t('Set status', 'स्थिति सेट करें', 'સ્થિતિ સેટ કરો');
  String get noTables => _t('No tables found', 'कोई टेबल नहीं', 'કોઈ ટેબલ નથી');

  String tableStatus(String status) {
    switch (status) {
      case 'available':
        return available;
      case 'occupied':
        return occupied;
      case 'reserved':
        return reserved;
      case 'cleaning':
        return cleaning;
      default:
        return status;
    }
  }

  // ── Orders list ─────────────────────────────────────────────────────────
  String get orders => _t('Orders', 'ऑर्डर', 'ઓર્ડર');
  String get active => _t('Active', 'सक्रिय', 'સક્રિય');
  String get all => _t('All', 'सभी', 'બધા');
  String get searchOrders => _t(
        'Search id, bill, customer, waiter…',
        'आईडी, बिल, ग्राहक, वेटर खोजें…',
        'આઈડી, બિલ, ગ્રાહક, વેટર શોધો…',
      );
  String get noOrders => _t('No orders', 'कोई ऑर्डर नहीं', 'કોઈ ઓર્ડર નથી');
  String get items => _t('items', 'आइटम', 'આઇટમ');

  // ── New order (existing + aliases) ──────────────────────────────────────
  String get newOrder => _t('New Order', 'नया ऑर्डर', 'નવો ઓર્ડર');
  String get table => _t('Table', 'टेबल', 'ટેબલ');
  String get searchMenu => _t('Search menu items…', 'मेनू आइटम खोजें…', 'મેનૂ આઇટમ શોધો…');
  String get placeOrder => _t('Place order', 'ऑर्डर करें', 'ઓર્ડર કરો');
  String get cart => _t('Cart', 'कार्ट', 'કાર્ટ');
  String get clear => _t('Clear', 'साफ़ करें', 'સાફ કરો');
  String get total => _t('Total', 'कुल', 'કુલ');
  String get selectTable => _t('Select a table', 'टेबल चुनें', 'ટેબલ પસંદ કરો');
  String get addAtLeastOne => _t('Add at least one item', 'कम से कम एक आइटम जोड़ें', 'ઓછામાં ઓછી એક આઇટમ ઉમેરો');
  String get orderPlaced => _t('Order placed', 'ऑर्डर लग गया', 'ઓર્ડર મૂકાયો');
  String get added => _t('Added', 'जोड़ा गया', 'ઉમેર્યું');
  String get inCart => _t('in cart', 'कार्ट में', 'કાર્ટમાં');
  String get noItems => _t('No menu items available', 'कोई मेनू आइटम उपलब्ध नहीं', 'કોઈ મેનૂ આઇટમ ઉપલબ્ધ નથી');
  String get clearFilters => _t('Clear filters', 'फ़िल्टर हटाएँ', 'ફિલ્ટર સાફ કરો');
  String get tapToView => _t('Tap to view', 'देखने के लिए टैप करें', 'જોવા માટે ટૅપ કરો');
  String get cartEmpty => _t('Cart is empty', 'कार्ट खाली है', 'કાર્ટ ખાલી છે');

  String item(int n) => _t(n == 1 ? 'item' : 'items', 'आइटम', 'આઇટમ');

  // ── Order detail ────────────────────────────────────────────────────────
  String get orderDetail => _t('Order Detail', 'ऑर्डर विवरण', 'ઓર્ડર વિગત');
  String get kitchenKot => _t('Kitchen (KOT)', 'किचन (KOT)', 'કિચન (KOT)');
  String get markPrinted => _t('Mark printed', 'प्रिंट किया', 'પ્રિન્ટ કર્યું');
  String get printing => _t('Printing…', 'प्रिंट हो रहा है…', 'પ્રિન્ટ થઈ રહ્યું છે…');
  String get kotMarked => _t('KOT marked as printed', 'KOT प्रिंट के रूप में चिह्नित', 'KOT પ્રિન્ટ તરીકે ચિહ્નિત');
  String get updateStatus => _t('Update status', 'स्थिति अपडेट', 'સ્થિતિ અપડેટ');
  String get generateBill => _t('Generate bill', 'बिल बनाएँ', 'બિલ બનાવો');
  String get generating => _t('Generating…', 'बनाया जा रहा है…', 'બનાવાઈ રહ્યું છે…');
  String get viewShareBill => _t('View / Share bill', 'बिल देखें / शेयर', 'બિલ જુઓ / શેર');
  String get generateBillTitle => _t('Generate bill?', 'बिल बनाएँ?', 'બિલ બનાવો?');
  String get generateBillBody => _t(
        'This finalizes the order, creates a bill number, and archives it. You can still view and share the bill afterward.',
        'यह ऑर्डर को अंतिम रूप देता है, बिल नंबर बनाता है और संग्रहित करता है। बाद में भी बिल देख/शेयर कर सकते हैं।',
        'આ ઓર્ડરને અંતિમ કરે છે, બિલ નંબર બનાવે છે અને આર્કાઇવ કરે છે. પછી પણ બિલ જોઈ/શેર કરી શકો છો.',
      );
  String get notNow => _t('Not now', 'अभी नहीं', 'હમણાં નહીં');
  String get cancelOrder => _t('Cancel order', 'ऑर्डर रद्द करें', 'ઓર્ડર રદ કરો');
  String get cancelOrderTitle => _t('Cancel this order?', 'यह ऑर्डर रद्द करें?', 'આ ઓર્ડર રદ કરો?');
  String get cancelOrderBody => _t(
        'The order will be marked cancelled. This cannot be undone from the waiter app.',
        'ऑर्डर रद्द चिह्नित होगा। वेटर ऐप से इसे वापस नहीं किया जा सकता।',
        'ઓર્ડર રદ ચિહ્નિત થશે. વેટર એપમાંથી પાછું ફેરવી શકાશે નહીં.',
      );
  String get bill => _t('Bill', 'बिल', 'બિલ');
  String get print => _t('Print', 'प्रिंट', 'પ્રિન્ટ');
  String get sharePdf => _t('Share PDF', 'PDF शेयर', 'PDF શેર');
  String get downloadPdf => _t('Download PDF', 'PDF डाउनलोड', 'PDF ડાઉનલોડ');
  String get copyBillText => _t('Copy bill text', 'बिल टेक्स्ट कॉपी', 'બિલ ટેક્સ્ટ કૉપી');
  String get subtotal => _t('Subtotal', 'उप-योग', 'પેટા-કુલ');
  String get discount => _t('Discount', 'छूट', 'ડિસ્કાઉન્ટ');
  String get tax => _t('Tax', 'कर', 'ટેક્સ');
  String get waiter => _t('Waiter', 'वेटर', 'વેટર');
  String get accept => _t('Accept', 'स्वीकार', 'સ્વીકાર');
  String get preparing => _t('Preparing', 'तैयारी', 'તૈયારી');
  String get ready => _t('Ready', 'तैयार', 'તૈયાર');
  String get served => _t('Served', 'परोसा', 'પીરસ્યું');
  String get statusUpdated => _t('Status updated', 'स्थिति अपडेट', 'સ્થિતિ અપડેટ');
  String get allItemsPrinted => _t('All items printed', 'सभी आइटम प्रिंट', 'બધી આઇટમ પ્રિન્ટ');
  String get itemsNotPrinted => _t('item(s) not yet printed', 'आइटम अभी प्रिंट नहीं', 'આઇટમ હજુ પ્રિન્ટ નથી');
  String get batch => _t('batch', 'बैच', 'બેચ');
  String get newBadge => _t('NEW', 'नया', 'નવું');
  String get couldNotLoadKot => _t('Could not load KOT', 'KOT लोड नहीं हुआ', 'KOT લોડ થયું નહીં');

  // ── Alerts ──────────────────────────────────────────────────────────────
  String get alerts => _t('Alerts', 'अलर्ट', 'એલર્ટ');
  String get markAllRead => _t('Mark all read', 'सभी पढ़ा चिह्नित', 'બધા વાંચેલા');
  String get allMarkedRead => _t('All marked read', 'सभी पढ़े गए', 'બધા વાંચેલા');
  String get noAlerts => _t('No alerts', 'कोई अलर्ट नहीं', 'કોઈ એલર્ટ નથી');
  String get failedToLoad => _t('Failed to load', 'लोड विफल', 'લોડ નિષ્ફળ');
}

/// Resolve menu item display name for [lang].
/// Priority: API translation fields → built-in dictionary → English name.
String localizeMenuName({
  required String name,
  String? nameHi,
  String? nameGu,
  required AppLanguage lang,
}) {
  switch (lang) {
    case AppLanguage.hi:
      if (nameHi != null && nameHi.trim().isNotEmpty) return nameHi.trim();
      return menuNameDictionary[name.toLowerCase().trim()]?.hi ?? name;
    case AppLanguage.gu:
      if (nameGu != null && nameGu.trim().isNotEmpty) return nameGu.trim();
      return menuNameDictionary[name.toLowerCase().trim()]?.gu ?? name;
    case AppLanguage.en:
      return name;
  }
}

String localizeMenuDescription({
  required String? description,
  String? descriptionHi,
  String? descriptionGu,
  required AppLanguage lang,
}) {
  if (description == null || description.isEmpty) return '';
  switch (lang) {
    case AppLanguage.hi:
      if (descriptionHi != null && descriptionHi.trim().isNotEmpty) return descriptionHi.trim();
      return description;
    case AppLanguage.gu:
      if (descriptionGu != null && descriptionGu.trim().isNotEmpty) return descriptionGu.trim();
      return description;
    case AppLanguage.en:
      return description;
  }
}

class _Tr {
  final String hi;
  final String gu;
  const _Tr(this.hi, this.gu);
}

/// Common Indian restaurant menu translations (English key → HI / GU).
const Map<String, _Tr> menuNameDictionary = {
  // Bread
  'roti': _Tr('रोटी', 'રોટલી'),
  'chapati': _Tr('चपाती', 'ચપાતી'),
  'naan': _Tr('नान', 'નાન'),
  'butter naan': _Tr('बटर नान', 'બટર નાન'),
  'garlic naan': _Tr('गार्लिक नान', 'ગાર્લિક નાન'),
  'plain naan': _Tr('प्लेन नान', 'પ્લેન નાન'),
  'paratha': _Tr('पराठा', 'પરોઠા'),
  'aloo paratha': _Tr('आलू पराठा', 'બટાકા પરોઠા'),
  'thepla': _Tr('थेपला', 'થેપલા'),
  'bhakhri': _Tr('भाखरी', 'ભાખરી'),
  'puri': _Tr('पूरी', 'પૂરી'),
  // Rice
  'rice': _Tr('चावल', 'ભાત'),
  'jeera rice': _Tr('जीरा राइस', 'જીરું રાઈસ'),
  'plain rice': _Tr('सादा चावल', 'સાદો ભાત'),
  'steamed rice': _Tr('स्टीम्ड राइस', 'સ્ટીમ્ડ રાઈસ'),
  'biryani': _Tr('बिरयानी', 'બિરયાની'),
  'veg biryani': _Tr('वेज बिरयानी', 'વેજ બિરયાની'),
  'chicken biryani': _Tr('चिकन बिरयानी', 'ચિકન બિરયાની'),
  'mutton biryani': _Tr('मटन बिरयानी', 'મટન બિરયાની'),
  'pulao': _Tr('पुलाव', 'પુલાવ'),
  'veg pulao': _Tr('वेज पुलाव', 'વેજ પુલાવ'),
  'khichdi': _Tr('खिचड़ी', 'ખીચડી'),
  // Curries / sabzi
  'dal': _Tr('दाल', 'દાળ'),
  'dal fry': _Tr('दाल फ्राई', 'દાળ ફ્રાય'),
  'dal tadka': _Tr('दाल तड़का', 'દાળ તડકા'),
  'dal makhani': _Tr('दाल मखनी', 'દાળ મખની'),
  'paneer butter masala': _Tr('पनीर बटर मसाला', 'પનીર બટર મસાલા'),
  'butter paneer': _Tr('बटर पनीर', 'બટર પનીર'),
  'paneer tikka': _Tr('पनीर टिक्का', 'પનીર ટિક્કા'),
  'paneer tikka masala': _Tr('पनीर टिक्का मसाला', 'પનીર ટિક્કા મસાલા'),
  'kadai paneer': _Tr('कढ़ाई पनीर', 'કઢાઈ પનીર'),
  'shahi paneer': _Tr('शाही पनीर', 'શાહી પનીર'),
  'palak paneer': _Tr('पालक पनीर', 'પાલક પનીર'),
  'matar paneer': _Tr('मटर पनीर', 'મટર પનીર'),
  'malai kofta': _Tr('मलाई कोफ्ता', 'મલાઈ કોફ્તા'),
  'veg kolhapuri': _Tr('वेज कोल्हापुरी', 'વેજ કોલ્હાપુરી'),
  'mix veg': _Tr('मिक्स वेज', 'મિક્સ વેજ'),
  'mixed vegetable': _Tr('मिक्स वेजिटेबल', 'મિક્સ વેજીટેબલ'),
  'aloo gobi': _Tr('आलू गोभी', 'બટાકા ફૂલગોબી'),
  'bhindi masala': _Tr('भिंडी मसाला', 'ભીંડા મસાલા'),
  'baingan bharta': _Tr('बैंगन भर्ता', 'રીંગણ ભરતું'),
  'chole': _Tr('छोले', 'ચોલે'),
  'chana masala': _Tr('चना मसाला', 'ચણા મસાલા'),
  'rajma': _Tr('राजमा', 'રાજમા'),
  'kadi': _Tr('कढ़ी', 'કઢી'),
  'kadhi': _Tr('कढ़ी', 'કઢી'),
  'undhiyu': _Tr('उंधियू', 'ઊંધિયું'),
  'sev tameta': _Tr('सेव टमेटो', 'સેવ ટમેટા'),
  'ringan no olo': _Tr('बैंगन का भर्ता', 'રીંગણ નો ઓળો'),
  // Non-veg
  'butter chicken': _Tr('बटर चिकन', 'બટર ચિકન'),
  'chicken curry': _Tr('चिकन करी', 'ચિકન કરી'),
  'chicken tikka': _Tr('चिकन टिक्का', 'ચિકન ટિક્કા'),
  'chicken tikka masala': _Tr('चिकन टिक्का मसाला', 'ચિકન ટિક્કા મસાલા'),
  'tandoori chicken': _Tr('तंदूरी चिकन', 'તંદૂરી ચિકન'),
  'fish curry': _Tr('फिश करी', 'ફિશ કરી'),
  'egg curry': _Tr('एग करी', 'એગ કરી'),
  // Snacks / starters
  'samosa': _Tr('समोसा', 'સમોસા'),
  'kachori': _Tr('कचौरी', 'કચોરી'),
  'pakora': _Tr('पकोड़ा', 'પકોડા'),
  'bhajiya': _Tr('भजिया', 'ભજીયા'),
  'fafda': _Tr('फाफडा', 'ફાફડા'),
  'dhokla': _Tr('ढोकला', 'ઢોકળા'),
  'khandvi': _Tr('खांडवी', 'ખાંડવી'),
  'patra': _Tr('पात्रा', 'પાત્રા'),
  'vada pav': _Tr('वड़ा पाव', 'વડા પાવ'),
  'pav bhaji': _Tr('पाव भाजी', 'પાવ ભાજી'),
  'dabeli': _Tr('दबेली', 'દાબેલી'),
  'pani puri': _Tr('पानी पूरी', 'પાણી પૂરી'),
  'bhel': _Tr('भेल', 'ભેળ'),
  'bhel puri': _Tr('भेल पूरी', 'ભેળ પૂરી'),
  'sev puri': _Tr('सेव पूरी', 'સેવ પૂરી'),
  'dahi puri': _Tr('दही पूरी', 'દહીં પૂરી'),
  'spring roll': _Tr('स्प्रिंग रोल', 'સ્પ્રિંગ રોલ'),
  'french fries': _Tr('फ्रेंच फ्राइज़', 'ફ્રેંચ ફ્રાઈસ'),
  'manchurian': _Tr('मंचूरियन', 'મંચુરિયન'),
  'veg manchurian': _Tr('वेज मंचूरियन', 'વેજ મંચુરિયન'),
  'hakka noodles': _Tr('हक्का नूडल्स', 'હક્કા નૂડલ્સ'),
  'fried rice': _Tr('फ्राइड राइस', 'ફ્રાઈડ રાઈસ'),
  // South Indian
  'dosa': _Tr('डोसा', 'ડોસા'),
  'masala dosa': _Tr('मसाला डोसा', 'મસાલા ડોસા'),
  'plain dosa': _Tr('प्लेन डोसा', 'પ્લેન ડોસા'),
  'idli': _Tr('इडली', 'ઈડલી'),
  'vada': _Tr('वड़ा', 'વડા'),
  'uttapam': _Tr('उत्तपम', 'ઉત્તપમ'),
  'medu vada': _Tr('मेदू वड़ा', 'મેદુ વડા'),
  // Sweets / desserts
  'gulab jamun': _Tr('गुलाब जामुन', 'ગુલાબ જામુન'),
  'rasgulla': _Tr('रसगुल्ला', 'રસગુલ્લા'),
  'jalebi': _Tr('जलेबी', 'જલેબી'),
  'ice cream': _Tr('आइसक्रीम', 'આઈસ્ક્રીમ'),
  'kulfi': _Tr('कुलफी', 'કુલ્ફી'),
  'shrikhand': _Tr('श्रीखंड', 'શ્રીખંડ'),
  'basundi': _Tr('बासुंदी', 'બાસુંદી'),
  'halwa': _Tr('हलवा', 'હલવો'),
  'laddu': _Tr('लड्डू', 'લાડુ'),
  // Drinks
  'tea': _Tr('चाय', 'ચા'),
  'chai': _Tr('चाय', 'ચા'),
  'coffee': _Tr('कॉफी', 'કૉફી'),
  'lassi': _Tr('लस्सी', 'લસ્સી'),
  'sweet lassi': _Tr('मीठी लस्सी', 'મીઠી લસ્સી'),
  'buttermilk': _Tr('छाछ', 'છાશ'),
  'chaas': _Tr('छाछ', 'છાશ'),
  'nimbu pani': _Tr('निम्बू पानी', 'લીંબુ પાણી'),
  'lemonade': _Tr('लेमोनेड', 'લેમોનેડ'),
  'water': _Tr('पानी', 'પાણી'),
  'mineral water': _Tr('मिनरल वाटर', 'મિનરલ વોટર'),
  'soft drink': _Tr('सॉफ्ट ड्रिंक', 'સોફ્ટ ડ્રિંક'),
  'coke': _Tr('कोक', 'કોક'),
  'pepsi': _Tr('पेप्सी', 'પેપ્સી'),
  'thums up': _Tr('थम्स अप', 'થમ્સ અપ'),
  'sprite': _Tr('स्प्राइट', 'સ્પ્રાઈટ'),
  'masala soda': _Tr('मसाला सोडा', 'મસાલા સોડા'),
  // Gujarati thali items
  'gujarati thali': _Tr('गुजराती थाली', 'ગુજરાતી થાળી'),
  'thali': _Tr('थाली', 'થાળી'),
  'full thali': _Tr('फुल थाली', 'ફુલ થાળી'),
  'mini thali': _Tr('मिनी थाली', 'મિની થાળી'),
  'rotli': _Tr('रोटली', 'રોટલી'),
  'shaak': _Tr('शाक', 'શાક'),
  'kathol': _Tr('कठोल', 'કઠોળ'),
  'farsan': _Tr('फरसाण', 'ફરસાણ'),
  'sukahdi': _Tr('सुखड़ी', 'સુખડી'),
  'mathia': _Tr('मठिया', 'મઠીયા'),
  'ganthiya': _Tr('गंठिया', 'ગાંઠિયા'),
  'papad': _Tr('पापड़', 'પાપડ'),
  'pickle': _Tr('अचार', 'અથાણું'),
  'achar': _Tr('अचार', 'અથાણું'),
  'salad': _Tr('सलाद', 'સલાડ'),
  'raita': _Tr('रायता', 'રાઈતું'),
  'curd': _Tr('दही', 'દહીં'),
  'dahi': _Tr('दही', 'દહીં'),
  // Categories often used as names
  'starters': _Tr('स्टार्टर्स', 'સ્ટાર્ટર્સ'),
  'main course': _Tr('मेन कोर्स', 'મેન કોર્સ'),
  'beverages': _Tr('पेय', 'પીણાં'),
  'desserts': _Tr('मिठाई', 'મીઠાઈ'),
  'soups': _Tr('सूप', 'સૂપ'),
  'combos': _Tr('कॉम्बो', 'કોમ્બો'),
};
