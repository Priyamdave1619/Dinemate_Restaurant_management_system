import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/brand.dart';
import 'branding/brand_logo.dart';

/// Branded full-screen loader / splash — shown on cold start while auth
/// state hydrates and while the session is being verified.
///
/// Always renders on the deep navy brand surface (independent of the app's
/// light/dark theme) so the mark, glow, and gold accents read consistently
/// on every device.
class BrandLoader extends StatelessWidget {
  final String label;
  const BrandLoader({super.key, this.label = 'Loading…'});

  static const Color _gold = Color(0xFFD9B657);

  @override
  Widget build(BuildContext context) {
    final reduceMotion = MediaQuery.disableAnimationsOf(context);
    final textTheme = Theme.of(context).textTheme;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light.copyWith(
        statusBarColor: Colors.transparent,
        systemNavigationBarColor: AppColors.primary900,
        systemNavigationBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: AppColors.primary900,
        body: DecoratedBox(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppColors.primary900,
                AppColors.primary800,
                AppColors.primary700,
              ],
            ),
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Center(child: _AmbientGlow(reduceMotion: reduceMotion)),
              SafeArea(
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _AnimatedMark(reduceMotion: reduceMotion),
                      const SizedBox(height: 18),
                      Text(
                        Brand.companyName,
                        style: textTheme.headlineSmall?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.0,
                        ),
                      )
                          .animate(delay: 260.ms)
                          .fadeIn(duration: 480.ms, curve: Curves.easeOut)
                          .slideY(
                            begin: 0.3,
                            end: 0,
                            duration: 480.ms,
                            curve: Curves.easeOutCubic,
                          ),
                      const SizedBox(height: 4),
                      Text(
                        Brand.appName.toUpperCase(),
                        style: textTheme.bodySmall?.copyWith(
                          color: Colors.white.withOpacity(0.62),
                          letterSpacing: 3.0,
                          fontWeight: FontWeight.w500,
                        ),
                      ).animate(delay: 400.ms).fadeIn(duration: 460.ms),
                      const SizedBox(height: 48),
                      _PulseDots(reduceMotion: reduceMotion, color: _gold)
                          .animate(delay: 520.ms)
                          .fadeIn(duration: 400.ms),
                      const SizedBox(height: 22),
                      Text(
                        label,
                        style: textTheme.bodySmall?.copyWith(
                          color: Colors.white.withOpacity(0.55),
                        ),
                      ).animate(delay: 600.ms).fadeIn(duration: 400.ms),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Soft, breathing radial glow that sits behind the brand mark.
class _AmbientGlow extends StatelessWidget {
  final bool reduceMotion;
  const _AmbientGlow({required this.reduceMotion});

  @override
  Widget build(BuildContext context) {
    Widget glow = Container(
      width: 260,
      height: 260,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [
            BrandLoader._gold.withOpacity(0.22),
            BrandLoader._gold.withOpacity(0.0),
          ],
        ),
      ),
    );

    if (reduceMotion) return glow;

    return glow
        .animate(onPlay: (c) => c.repeat(reverse: true))
        .scaleXY(
          begin: 0.88,
          end: 1.08,
          duration: 2200.ms,
          curve: Curves.easeInOut,
        )
        .fadeIn(duration: 900.ms);
  }
}

/// Entrance + idle "breathing" animation for the DineMate mark.
class _AnimatedMark extends StatelessWidget {
  final bool reduceMotion;
  const _AnimatedMark({required this.reduceMotion});

  @override
  Widget build(BuildContext context) {
    // Force the gold-on-dark mark regardless of the app's active theme,
    // since this screen always renders on the navy brand surface.
    Widget mark = Theme(
      data: Theme.of(context).copyWith(brightness: Brightness.dark),
      child: const BrandLogo(height: Brand.sizeHero + 14),
    );

    mark = mark
        .animate()
        .fadeIn(duration: 560.ms, curve: Curves.easeOut)
        .scale(
          begin: const Offset(0.8, 0.8),
          end: const Offset(1, 1),
          duration: 640.ms,
          curve: Curves.easeOutBack,
        );

    if (reduceMotion) return mark;

    return mark.animate(onPlay: (c) => c.repeat(reverse: true), delay: 700.ms).scaleXY(
          begin: 1,
          end: 1.035,
          duration: 1700.ms,
          curve: Curves.easeInOut,
        );
  }
}

/// Three-dot "wave" loader used in place of a plain spinner.
class _PulseDots extends StatelessWidget {
  final bool reduceMotion;
  final Color color;
  const _PulseDots({required this.reduceMotion, required this.color});

  @override
  Widget build(BuildContext context) {
    Widget dot(int index) {
      Widget d = Container(
        width: 8,
        height: 8,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      );

      if (reduceMotion) {
        return Opacity(opacity: 0.75, child: d);
      }

      return d
          .animate(
            onPlay: (c) => c.repeat(reverse: true),
            delay: (index * 160).ms,
          )
          .scaleXY(begin: 0.55, end: 1.0, duration: 620.ms, curve: Curves.easeInOut)
          .fadeIn(begin: 0.4, duration: 620.ms);
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, dot),
    );
  }
}
