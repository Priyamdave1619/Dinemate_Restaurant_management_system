import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/config/app_config.dart';
import '../../features/auth/auth_state.dart';

class SessionKeeper extends ConsumerStatefulWidget {
  const SessionKeeper({super.key});

  @override
  ConsumerState<SessionKeeper> createState() => _SessionKeeperState();
}

class _SessionKeeperState extends ConsumerState<SessionKeeper> with WidgetsBindingObserver {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _start();
  }

  void _start() {
    _tick();
    _timer?.cancel();
    _timer = Timer.periodic(AppConfig.tokenRefreshInterval, (_) => _tick());
  }

  Future<void> _tick() async {
    final auth = ref.read(authProvider);
    if (!auth.hydrated || auth.user == null || auth.refreshToken == null) return;
    await ref.read(authProvider.notifier).refreshAccessToken();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _tick();
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}
