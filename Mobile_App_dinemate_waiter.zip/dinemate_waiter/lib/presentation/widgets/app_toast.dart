import 'dart:async';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

enum AppToastType { success, error, warning, info }

/// App-wide top-center toast/banner — replaces the default bottom [SnackBar]
/// so success, error, and warning messages all appear consistently at the
/// top of the screen with a short slide + fade animation.
///
/// Usage:
///   AppToast.success(context, 'Table updated');
///   AppToast.error(context, 'Invalid username or password');
class AppToast {
  AppToast._();

  static OverlayEntry? _entry;
  static Timer? _timer;
  static GlobalKey<_ToastCardState>? _cardKey;

  static void success(BuildContext context, String message, {Duration? duration}) =>
      show(context, message, type: AppToastType.success, duration: duration);

  static void error(BuildContext context, String message, {Duration? duration}) =>
      show(context, message, type: AppToastType.error, duration: duration ?? const Duration(seconds: 4));

  static void warning(BuildContext context, String message, {Duration? duration}) =>
      show(context, message, type: AppToastType.warning, duration: duration);

  static void info(BuildContext context, String message, {Duration? duration}) =>
      show(context, message, type: AppToastType.info, duration: duration);

  static void show(
    BuildContext context,
    String message, {
    AppToastType type = AppToastType.info,
    Duration? duration,
  }) {
    final overlay = Overlay.maybeOf(context, rootOverlay: true);
    if (overlay == null) return;

    _dismiss(immediate: true);

    final cardKey = GlobalKey<_ToastCardState>();
    _cardKey = cardKey;

    final entry = OverlayEntry(
      builder: (_) => _ToastCard(
        key: cardKey,
        message: message,
        type: type,
        onDismissed: _clear,
      ),
    );

    _entry = entry;
    overlay.insert(entry);

    _timer = Timer(duration ?? const Duration(seconds: 3), () => _dismiss());
  }

  static void _dismiss({bool immediate = false}) {
    _timer?.cancel();
    _timer = null;
    if (immediate) {
      _entry?.remove();
      _entry = null;
      _cardKey = null;
    } else {
      _cardKey?.currentState?.close();
    }
  }

  static void _clear() {
    _entry?.remove();
    _entry = null;
    _cardKey = null;
  }
}

class _ToastCard extends StatefulWidget {
  final String message;
  final AppToastType type;
  final VoidCallback onDismissed;
  const _ToastCard({super.key, required this.message, required this.type, required this.onDismissed});

  @override
  State<_ToastCard> createState() => _ToastCardState();
}

class _ToastCardState extends State<_ToastCard> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<Offset> _slide;
  late final Animation<double> _fade;
  bool _closing = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    _slide = Tween<Offset>(begin: const Offset(0, -0.4), end: Offset.zero)
        .animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _controller.forward();
  }

  Future<void> close() async {
    if (_closing || !mounted) return;
    _closing = true;
    await _controller.reverse();
    widget.onDismissed();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  _ToastStyle get _style {
    switch (widget.type) {
      case AppToastType.success:
        return const _ToastStyle(bg: AppColors.success, icon: Icons.check_circle_rounded);
      case AppToastType.error:
        return const _ToastStyle(bg: AppColors.error, icon: Icons.error_rounded);
      case AppToastType.warning:
        return const _ToastStyle(bg: AppColors.warning, icon: Icons.warning_rounded);
      case AppToastType.info:
        return const _ToastStyle(bg: AppColors.primary800, icon: Icons.info_rounded);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = _style;
    final topInset = MediaQuery.of(context).padding.top;

    return Positioned(
      top: topInset + 10,
      left: 16,
      right: 16,
      child: SafeArea(
        bottom: false,
        child: SlideTransition(
          position: _slide,
          child: FadeTransition(
            opacity: _fade,
            child: Material(
              color: Colors.transparent,
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: close,
                onVerticalDragEnd: (d) {
                  if ((d.primaryVelocity ?? 0) < 0) close();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: s.bg,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.20),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(s.icon, color: Colors.white, size: 22),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          widget.message,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 14.5,
                            height: 1.3,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Icon(Icons.close_rounded, color: Colors.white.withOpacity(0.8), size: 18),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ToastStyle {
  final Color bg;
  final IconData icon;
  const _ToastStyle({required this.bg, required this.icon});
}
