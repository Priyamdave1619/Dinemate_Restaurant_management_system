import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/brand.dart';
import '../../core/utils/responsive.dart';
import '../../core/locale/app_locale.dart';
import '../../features/auth/auth_state.dart';
import 'branding/brand_logo.dart';

class TitleBar extends ConsumerWidget {
  final String location;
  const TitleBar({super.key, required this.location});

  String _section(String loc, S s) {
    if (loc.startsWith('/floor')) return s.sectionFloor;
    if (loc.startsWith('/orders')) return s.sectionOrders;
    if (loc.startsWith('/new-order')) return s.sectionNewOrder;
    if (loc.startsWith('/alerts')) return s.sectionAlerts;
    if (loc.startsWith('/me')) return s.sectionProfile;
    return s.sectionWaiter;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final s = S.of(ref);
    final restaurantName = auth.restaurant?.name;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final r = Responsive(context);
    final logoHeight = r.isPhone ? Brand.sizeSm : Brand.sizeMd;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: r.pagePadding,
        vertical: r.isPhone ? 8 : 10,
      ),
      decoration: BoxDecoration(
        color: (isDark ? AppColors.darkCard : AppColors.white).withValues(alpha: 0.92),
        border: Border(
          bottom: BorderSide(
            color: isDark ? AppColors.darkLine : AppColors.line.withValues(alpha: 0.6),
          ),
        ),
      ),
      child: Row(
        children: [
          BrandLogo(height: logoHeight, linkToHome: true),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  restaurantName ?? Brand.companyName,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.2,
                      ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  _section(location, s),
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.4,
                    color: isDark ? AppColors.brand400 : AppColors.brand600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: AppColors.success,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: AppColors.success.withValues(alpha: 0.6), blurRadius: 8),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
