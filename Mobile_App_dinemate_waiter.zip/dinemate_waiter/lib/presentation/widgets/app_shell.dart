import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/responsive.dart';
import '../../features/auth/auth_state.dart';
import 'bottom_nav.dart';
import 'brand_loader.dart';
import 'title_bar.dart';
import 'session_keeper.dart';
import 'branding/brand_logo.dart';
import '../../core/theme/brand.dart';
import '../../core/locale/app_locale.dart';

class AppShell extends ConsumerWidget {
  final Widget child;
  final String location;

  const AppShell({
    super.key,
    required this.child,
    required this.location,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final r = Responsive(context);

    if (!auth.hydrated) {
      return BrandLoader(label: S.of(ref).starting);
    }
    if (!auth.isAuthenticated) {
      return BrandLoader(label: S.of(ref).checkingSession);
    }

    final useRail = r.shortest >= Breakpoints.phone && (r.isTablet || r.isDesktop);

    if (useRail) {
      return Scaffold(
        body: Row(
          children: [
            _SideRail(location: location),
            const VerticalDivider(width: 1, thickness: 1),
            Expanded(
              child: SafeArea(
                child: Column(
                  children: [
                    const SessionKeeper(),
                    TitleBar(location: location),
                    Expanded(
                      child: Center(
                        child: ConstrainedBox(
                          constraints: BoxConstraints(maxWidth: r.contentMaxWidth),
                          child: child,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            const SessionKeeper(),
            TitleBar(location: location),
            Expanded(
              child: Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: r.contentMaxWidth),
                  child: child,
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(location: location),
    );
  }
}

class _SideRail extends ConsumerWidget {
  final String location;
  const _SideRail({required this.location});



  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final r = Responsive(context);
    final extended = r.width >= Breakpoints.desktop;
    final s = S.of(ref);
    final items = [
      (path: '/floor', label: s.navFloor, icon: Icons.grid_view_rounded),
      (path: '/orders', label: s.navOrders, icon: Icons.receipt_long_rounded),
      (path: '/new-order', label: s.navNew, icon: Icons.add_circle_rounded),
      (path: '/alerts', label: s.navAlerts, icon: Icons.notifications_rounded),
      (path: '/me', label: s.navMe, icon: Icons.person_rounded),
    ];

    int selected = 0;
    for (var i = 0; i < items.length; i++) {
      if (location.startsWith(items[i].path)) {
        selected = i;
        break;
      }
    }

    return Material(
      color: isDark ? AppColors.primary900 : AppColors.primary800,
      child: SafeArea(
        right: false,
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.fromLTRB(extended ? 16 : 8, 16, extended ? 16 : 8, 8),
              child: Theme(
                // Force light logo asset on navy rail
                data: Theme.of(context).copyWith(brightness: Brightness.dark),
                child: extended
                    ? BrandLogo.withName(height: Brand.sizeMd, linkToHome: true)
                    : const BrandLogo.compact(height: Brand.sizeMd, linkToHome: true),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: NavigationRail(
                extended: extended,
                selectedIndex: selected.clamp(0, items.length - 1),
                onDestinationSelected: (i) {
                  final path = items[i].path;
                  if (location != path) context.go(path);
                },
                labelType: extended ? NavigationRailLabelType.none : NavigationRailLabelType.all,
                backgroundColor: Colors.transparent,
                selectedIconTheme: const IconThemeData(color: Colors.white),
                selectedLabelTextStyle: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
                unselectedIconTheme: IconThemeData(color: Colors.white.withValues(alpha: 0.65)),
                indicatorColor: AppColors.primary600,
                destinations: [
                  for (final item in items)
                    NavigationRailDestination(
                      icon: Icon(item.icon),
                      selectedIcon: Icon(item.icon),
                      label: Text(item.label),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
