import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_colors.dart';
import '../../core/locale/app_locale.dart';

class BottomNav extends ConsumerWidget {
  final String location;
  const BottomNav({super.key, required this.location});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = S.of(ref);
    final items = [
      _NavItem('/floor', s.navFloor, Icons.grid_view_rounded),
      _NavItem('/orders', s.navOrders, Icons.receipt_long_rounded),
      _NavItem('/new-order', s.navNew, Icons.add_circle_rounded),
      _NavItem('/alerts', s.navAlerts, Icons.notifications_rounded),
      _NavItem('/me', s.navMe, Icons.person_rounded),
    ];

    int index = 0;
    for (var i = 0; i < items.length; i++) {
      if (location.startsWith(items[i].path)) {
        index = i;
        break;
      }
    }

    final isDark = Theme.of(context).brightness == Brightness.dark;
    final active = isDark ? AppColors.darkPrimary : AppColors.primary800;
    final inactive = isDark ? AppColors.darkInkSecondary : AppColors.inkMuted;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkCard : AppColors.white,
        border: Border(
          top: BorderSide(
            color: isDark ? AppColors.darkLine : AppColors.line.withValues(alpha: 0.9),
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary900.withValues(alpha: 0.06),
            blurRadius: 24,
            offset: const Offset(0, -6),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Row(
            children: List.generate(items.length, (i) {
              final item = items[i];
              final selected = i == index;
              final isCenter = i == 2;
              return Expanded(
                child: InkWell(
                  onTap: () {
                    if (location != item.path) context.go(item.path);
                  },
                  borderRadius: BorderRadius.circular(12),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          item.icon,
                          size: isCenter ? 28 : 24,
                          color: selected ? active : inactive,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          item.label,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                            color: selected ? active : inactive,
                          ),
                        ),
                        if (selected) ...[
                          const SizedBox(height: 3),
                          Container(
                            width: 16,
                            height: 3,
                            decoration: BoxDecoration(
                              color: active,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  final String path;
  final String label;
  final IconData icon;
  const _NavItem(this.path, this.label, this.icon);
}
