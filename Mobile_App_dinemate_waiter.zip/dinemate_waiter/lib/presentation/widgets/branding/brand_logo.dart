import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/brand.dart';
import '../../../core/theme/app_colors.dart';

enum BrandLogoVariant {
  full,
  compact,
  withName,
}

/// Centralized DineMate logo — theme-aware light/dark assets.
class BrandLogo extends StatelessWidget {
  final BrandLogoVariant variant;
  final double? height;
  final bool linkToHome;
  final bool showName;
  final String? semanticLabel;
  final BoxFit fit;
  final VoidCallback? onTap;

  const BrandLogo({
    super.key,
    this.variant = BrandLogoVariant.full,
    this.height,
    this.linkToHome = false,
    this.showName = false,
    this.semanticLabel,
    this.fit = BoxFit.contain,
    this.onTap,
  });

  const BrandLogo.compact({
    super.key,
    this.height = Brand.sizeSm,
    this.linkToHome = false,
    this.onTap,
  })  : variant = BrandLogoVariant.compact,
        showName = false,
        semanticLabel = null,
        fit = BoxFit.contain;

  const BrandLogo.withName({
    super.key,
    this.height = Brand.sizeMd,
    this.linkToHome = false,
    this.onTap,
  })  : variant = BrandLogoVariant.withName,
        showName = true,
        semanticLabel = null,
        fit = BoxFit.contain;

  /// Matches original Next.js: light theme → logo-light, dark theme → logo-dark.
  String _assetFor(Brightness brightness) {
    return brightness == Brightness.dark ? Brand.logoDarkMode : Brand.logoLightMode;
  }

  double get _height {
    if (height != null) return height!;
    switch (variant) {
      case BrandLogoVariant.compact:
        return Brand.sizeSm;
      case BrandLogoVariant.withName:
        return Brand.sizeMd;
      case BrandLogoVariant.full:
        return Brand.sizeLg;
    }
  }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final asset = _assetFor(brightness);
    final h = _height;
    final label = semanticLabel ?? Brand.logoAlt;

    Widget image = Image.asset(
      asset,
      height: h,
      fit: fit,
      filterQuality: FilterQuality.medium,
      semanticLabel: label,
      errorBuilder: (_, __, ___) => _FallbackMark(size: h),
    );

    image = ConstrainedBox(
      constraints: BoxConstraints(
        maxHeight: h,
        maxWidth: variant == BrandLogoVariant.compact ? h * 1.4 : h * 4.5,
      ),
      child: image,
    );

    Widget content;
    if (variant == BrandLogoVariant.withName || showName) {
      content = Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          image,
          const SizedBox(width: 10),
          Flexible(
            child: Text(
              Brand.companyName,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                  ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      );
    } else {
      content = image;
    }

    content = Semantics(
      label: label,
      image: true,
      button: linkToHome || onTap != null,
      child: content,
    );

    if (linkToHome || onTap != null) {
      return InkWell(
        onTap: onTap ??
            () {
              if (context.mounted) context.go('/floor');
            },
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
          child: content,
        ),
      );
    }

    return content;
  }
}

class _FallbackMark extends StatelessWidget {
  final double size;
  const _FallbackMark({required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppColors.brand500, AppColors.brand700],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(size * 0.22),
      ),
      alignment: Alignment.center,
      child: Text(
        'D',
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w800,
          fontSize: size * 0.45,
        ),
      ),
    );
  }
}
