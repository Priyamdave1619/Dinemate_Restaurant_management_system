import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_colors.dart';
import '../../../features/auth/auth_state.dart';
import '../../../core/utils/responsive.dart';
import '../../widgets/branding/brand_logo.dart';
import '../../../core/theme/brand.dart';
import '../../../core/locale/app_locale.dart';

class MeScreen extends ConsumerWidget {
  const MeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final user = auth.user;
    final restaurant = auth.restaurant;

    return ListView(
      padding: EdgeInsets.all(Responsive(context).pagePadding),
      children: [
        Text(S.of(ref).profile, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 20),
        const Center(child: BrandLogo(height: Brand.sizeXl)),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                CircleAvatar(
                  radius: 36,
                  backgroundColor: AppColors.brand100,
                  child: Text(
                    (user?.name.isNotEmpty == true ? user!.name[0] : '?').toUpperCase(),
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: AppColors.brand700),
                  ),
                ),
                const SizedBox(height: 12),
                Text(user?.name ?? '—', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                Text('@${user?.username ?? ''}', style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.brand50,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    (user?.role ?? '').toUpperCase(),
                    style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppColors.brand700),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        if (restaurant != null)
          Card(
            child: ListTile(
              leading: const Icon(Icons.storefront_rounded, color: AppColors.brand600),
              title: Text(restaurant.name, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(restaurant.address ?? restaurant.status),
            ),
          ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.translate_rounded, color: AppColors.brand600),
                    const SizedBox(width: 10),
                    Text(S.of(ref).language, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  ],
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final l in AppLanguage.values)
                      ChoiceChip(
                        label: Text('${l.label} · ${l.nativeLabel}'),
                        selected: ref.watch(localeProvider) == l,
                        onSelected: (_) => ref.read(localeProvider.notifier).setLanguage(l),
                        selectedColor: AppColors.brand100,
                        labelStyle: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: ref.watch(localeProvider) == l ? AppColors.brand800 : null,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 24),
        FilledButton.icon(
          onPressed: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (ctx) => AlertDialog(
                title: Text(S.of(ref).signOutConfirm),
                content: Text(S.of(ref).signOutBody),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(S.of(ref).cancel)),
                  FilledButton(
                    onPressed: () => Navigator.pop(ctx, true),
                    style: FilledButton.styleFrom(backgroundColor: AppColors.error),
                    child: Text(S.of(ref).signOut),
                  ),
                ],
              ),
            );
            if (ok == true) {
              await ref.read(authProvider.notifier).logout();
            }
          },
          icon: const Icon(Icons.logout_rounded),
          label: Text(S.of(ref).signOut),
          style: FilledButton.styleFrom(
            backgroundColor: AppColors.error,
            padding: const EdgeInsets.symmetric(vertical: 14),
          ),
        ),
      ],
    );
  }
}
