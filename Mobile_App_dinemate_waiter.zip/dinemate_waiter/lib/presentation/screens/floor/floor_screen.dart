import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/format.dart';
import '../../../core/config/app_config.dart';
import '../../../core/errors/app_exception.dart';
import '../../../data/models/models.dart';
import '../../../data/services/waiter_api.dart';
import '../../../features/auth/auth_state.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/locale/app_locale.dart';
import '../../widgets/app_toast.dart';

final tablesProvider = FutureProvider.autoDispose<List<RestaurantTable>>((ref) async {
  final api = ref.watch(waiterApiProvider);
  return api.listTables();
});

final activeOrdersProvider = FutureProvider.autoDispose<List<Order>>((ref) async {
  final api = ref.watch(waiterApiProvider);
  return api.listOrders(active: '1');
});

class FloorScreen extends ConsumerStatefulWidget {
  const FloorScreen({super.key});

  @override
  ConsumerState<FloorScreen> createState() => _FloorScreenState();
}

class _FloorScreenState extends ConsumerState<FloorScreen> {
  @override
  void initState() {
    super.initState();
    // Auto-refresh
    Future.delayed(AppConfig.tablesPollInterval, _poll);
  }

  void _poll() {
    if (!mounted) return;
    ref.invalidate(tablesProvider);
    ref.invalidate(activeOrdersProvider);
    Future.delayed(AppConfig.tablesPollInterval, _poll);
  }

  Color _bg(String status) {
    switch (status) {
      case 'available': return AppColors.availableBg;
      case 'occupied': return AppColors.occupiedBg;
      case 'reserved': return AppColors.reservedBg;
      case 'cleaning': return AppColors.cleaningBg;
      default: return AppColors.white;
    }
  }

  Color _border(String status) {
    switch (status) {
      case 'available': return AppColors.availableBorder;
      case 'occupied': return AppColors.occupiedBorder;
      case 'reserved': return AppColors.reservedBorder;
      case 'cleaning': return AppColors.cleaningBorder;
      default: return AppColors.line;
    }
  }

  Color _text(String status) {
    switch (status) {
      case 'available': return AppColors.availableText;
      case 'occupied': return AppColors.occupiedText;
      case 'reserved': return AppColors.reservedText;
      case 'cleaning': return AppColors.cleaningText;
      default: return AppColors.ink;
    }
  }

  Future<void> _setStatus(String id, String status) async {
    try {
      await ref.read(waiterApiProvider).updateTable(id, {'status': status});
      ref.invalidate(tablesProvider);
      if (mounted) {
        AppToast.success(context, S.ofLang(ref.read(localeProvider)).tableUpdated);
      }
    } on AppException catch (e) {
      if (mounted) {
        AppToast.error(context, e.message);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authProvider);
    final tablesAsync = ref.watch(tablesProvider);
    final ordersAsync = ref.watch(activeOrdersProvider);

    final ordersByTable = <int, Order>{};
    ordersAsync.whenData((orders) {
      for (final o in orders) {
        final existing = ordersByTable[o.tableNumber];
        if (existing == null || DateTime.tryParse(o.placedAt)?.isAfter(DateTime.tryParse(existing.placedAt) ?? DateTime(0)) == true) {
          ordersByTable[o.tableNumber] = o;
        }
      }
    });

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(S.of(ref).tables, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                    Text(
                      '${auth.user?.name ?? ''} · ${auth.user?.role ?? ''}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: () {
                  ref.invalidate(tablesProvider);
                  ref.invalidate(activeOrdersProvider);
                },
                icon: const Icon(Icons.refresh_rounded),
                style: IconButton.styleFrom(
                  side: BorderSide(color: Theme.of(context).dividerColor),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: tablesAsync.when(
            loading: () {
              final r = Responsive(context);
              return GridView.builder(
              padding: EdgeInsets.all(r.pagePadding),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: r.tableColumns,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: r.isPhone ? 0.9 : 1.05,
              ),
              itemCount: 6,
              itemBuilder: (_, __) => Container(
                decoration: BoxDecoration(
                  color: AppColors.surfaceMute,
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            );
            },
            error: (e, _) => Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(e is AppException ? e.message : S.of(ref).failedToLoad),
                  const SizedBox(height: 12),
                  FilledButton(onPressed: () => ref.invalidate(tablesProvider), child: Text(S.of(ref).retry)),
                ],
              ),
            ),
            data: (tables) {
              if (tables.isEmpty) {
                return Center(child: Text(S.of(ref).noTables));
              }
              final r = Responsive(context);
              return RefreshIndicator(
                onRefresh: () async {
                  ref.invalidate(tablesProvider);
                  ref.invalidate(activeOrdersProvider);
                  await ref.read(tablesProvider.future);
                },
                child: GridView.builder(
                  padding: EdgeInsets.fromLTRB(r.pagePadding, 4, r.pagePadding, 24),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: r.tableColumns,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: r.isPhone ? 0.9 : 1.05,
                  ),
                  itemCount: tables.length,
                  itemBuilder: (context, i) {
                    final t = tables[i];
                    final order = ordersByTable[t.number];
                    return Container(
                      decoration: BoxDecoration(
                        color: _bg(t.status),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _border(t.status), width: 2),
                      ),
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'T${t.number}',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w900,
                                  color: _text(t.status),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.7),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  S.of(ref).tableStatus(t.status).toUpperCase(),
                                  style: TextStyle(
                                    fontSize: 9,
                                    fontWeight: FontWeight.w800,
                                    color: _text(t.status),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Text('${t.capacity} ${S.of(ref).seats}', style: TextStyle(fontSize: 11, color: _text(t.status).withValues(alpha: 0.7))),
                          if (order != null) ...[
                            const SizedBox(height: 6),
                            GestureDetector(
                              onTap: () => context.push('/orders/${order.id}'),
                              child: Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.white.withValues(alpha: 0.8),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  '${S.of(ref).orders} · ${relativeTime(order.placedAt)} · ${order.status}',
                                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ),
                          ],
                          const Spacer(),
                          Wrap(
                            spacing: 4,
                            runSpacing: 4,
                            children: [
                              if (t.status != 'available')
                                _miniBtn(S.of(ref).available, () => _setStatus(t.id, 'available')),
                              if (t.status == 'available')
                                _miniBtn(S.of(ref).occupied, () => _setStatus(t.id, 'occupied')),
                              _miniBtn(S.of(ref).navNew, () => context.go('/new-order?table=${t.number}'), primary: true),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _miniBtn(String label, VoidCallback onTap, {bool primary = false}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(
          color: primary ? AppColors.brand600 : Colors.white.withValues(alpha: 0.9),
          borderRadius: BorderRadius.circular(8),
          border: primary ? null : Border.all(color: Colors.white.withValues(alpha: 0.6)),
          boxShadow: primary
              ? [BoxShadow(color: AppColors.primary900.withValues(alpha: 0.25), blurRadius: 6)]
              : null,
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w800,
            color: primary ? Colors.white : AppColors.ink,
          ),
        ),
      ),
    );
  }
}
