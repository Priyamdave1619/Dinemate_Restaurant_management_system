import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/format.dart';
import '../../../core/utils/validation.dart';
import '../../../core/errors/app_exception.dart';
import '../../../data/models/models.dart';
import '../../../data/services/waiter_api.dart';
import '../../../features/auth/auth_state.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/locale/app_locale.dart';
import '../../widgets/app_toast.dart';

final menuProvider = FutureProvider.autoDispose<List<MenuItem>>((ref) {
  return ref.watch(waiterApiProvider).listMenu();
});

final categoriesProvider = FutureProvider.autoDispose<List<MenuCategory>>((ref) {
  return ref.watch(waiterApiProvider).listCategories();
});

final tablesForOrderProvider = FutureProvider.autoDispose<List<RestaurantTable>>((ref) {
  return ref.watch(waiterApiProvider).listTables();
});

class NewOrderScreen extends ConsumerStatefulWidget {
  final int? preselectedTable;
  const NewOrderScreen({super.key, this.preselectedTable});

  @override
  ConsumerState<NewOrderScreen> createState() => _NewOrderScreenState();
}

class _NewOrderScreenState extends ConsumerState<NewOrderScreen> {
  int? _tableNumber;
  final List<CartLine> _cart = [];
  String? _selectedCategoryId;
  bool _submitting = false;
  final _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void initState() {
    super.initState();
    _tableNumber = widget.preselectedTable;
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  String _itemName(MenuItem item) {
    final lang = ref.read(localeProvider);
    return localizeMenuName(
      name: item.name,
      nameHi: item.nameHi,
      nameGu: item.nameGu,
      lang: lang,
    );
  }

  String _itemDesc(MenuItem item) {
    final lang = ref.read(localeProvider);
    return localizeMenuDescription(
      description: item.description,
      descriptionHi: item.descriptionHi,
      descriptionGu: item.descriptionGu,
      lang: lang,
    );
  }

  String _catName(MenuCategory c) {
    final lang = ref.read(localeProvider);
    return localizeMenuName(name: c.name, nameHi: c.nameHi, nameGu: c.nameGu, lang: lang);
  }


  void _onSearchChanged(String value) {
    setState(() => _query = sanitizeSearch(value, 80).toLowerCase());
  }

  void _clearSearch() {
    _searchCtrl.clear();
    setState(() => _query = '');
  }

  List<MenuItem> _filterItems(List<MenuItem> items) {
    var list = items.where((i) => i.available).toList();
    if (_selectedCategoryId != null) {
      list = list.where((i) => i.categoryId == _selectedCategoryId).toList();
    }
    if (_query.isNotEmpty) {
      final lang = ref.read(localeProvider);
      list = list.where((i) {
        final name = i.name.toLowerCase();
        final local = localizeMenuName(
          name: i.name, nameHi: i.nameHi, nameGu: i.nameGu, lang: lang,
        ).toLowerCase();
        final desc = (i.description ?? '').toLowerCase();
        final food = (i.foodType ?? '').toLowerCase();
        return name.contains(_query) ||
            local.contains(_query) ||
            desc.contains(_query) ||
            food.contains(_query);
      }).toList();
    }
    return list;
  }

  void _addItem(MenuItem item) {
    setState(() {
      final idx = _cart.indexWhere((c) => c.item.id == item.id && c.variant == null);
      if (idx >= 0) {
        _cart[idx] = _cart[idx].copyWith(quantity: _cart[idx].quantity + 1);
      } else {
        _cart.add(CartLine(item: item, quantity: 1, unitPrice: item.price));
      }
    });
    // Brief top-center confirmation tip.
    AppToast.info(
      context,
      '${S.ofLang(ref.read(localeProvider)).added} ${_itemName(item)}',
      duration: const Duration(milliseconds: 900),
    );
  }

  void _changeQty(int index, int delta) {
    setState(() {
      final q = _cart[index].quantity + delta;
      if (q <= 0) {
        _cart.removeAt(index);
      } else {
        _cart[index] = _cart[index].copyWith(quantity: q);
      }
    });
  }

  void _removeLine(int index) {
    setState(() => _cart.removeAt(index));
  }

  int get _itemCount => _cart.fold(0, (s, c) => s + c.quantity);

  double get _total => _cart.fold(0.0, (s, c) => s + c.lineTotal);

  Future<void> _placeOrder() async {
    if (_tableNumber == null) {
      AppToast.warning(context, S.ofLang(ref.read(localeProvider)).selectTable);
      return;
    }
    if (_cart.isEmpty) {
      AppToast.warning(context, S.ofLang(ref.read(localeProvider)).addAtLeastOne);
      return;
    }
    setState(() => _submitting = true);
    try {
      final user = ref.read(authProvider).user;
      final order = await ref.read(waiterApiProvider).createOrder(
            tableNumber: _tableNumber!,
            items: _cart
                .map((c) => {
                      'itemId': c.item.id,
                      'name': c.item.name,
                      'quantity': c.quantity,
                      'price': c.unitPrice,
                      if (c.variant != null) 'variant': c.variant,
                      if (c.note != null) 'note': c.note,
                    })
                .toList(),
            waiterName: user?.name,
          );
      if (mounted) {
        AppToast.success(context, S.ofLang(ref.read(localeProvider)).orderPlaced);
        context.go('/orders/${order.id}');
      }
    } on AppException catch (e) {
      if (mounted) {
        AppToast.error(context, e.message);
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  void _openCartSheet() {
    if (_cart.isEmpty) return;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            void sync(VoidCallback fn) {
              setState(fn);
              setModalState(() {});
            }

            final isDark = Theme.of(ctx).brightness == Brightness.dark;
            return Container(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * 0.85),
              decoration: BoxDecoration(
                color: isDark ? AppColors.darkCard : AppColors.white,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 10),
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(color: AppColors.line, borderRadius: BorderRadius.circular(2)),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 12, 8),
                    child: Row(
                      children: [
                        Text(
                          '${S.of(ref).cart} ($_itemCount)',
                          style: Theme.of(ctx).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        const Spacer(),
                        TextButton(
                          onPressed: _cart.isEmpty
                              ? null
                              : () {
                                  sync(() => _cart.clear());
                                  Navigator.pop(ctx);
                                },
                          child: Text(S.of(ref).clear),
                        ),
                      ],
                    ),
                  ),
                  const Divider(height: 1),
                  Flexible(
                    child: _cart.isEmpty
                        ? const Padding(
                            padding: EdgeInsets.all(32),
                            child: Text('Cart is empty'),
                          )
                        : ListView.separated(
                            shrinkWrap: true,
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            itemCount: _cart.length,
                            separatorBuilder: (_, __) => const Divider(height: 1),
                            itemBuilder: (_, i) {
                              final c = _cart[i];
                              return ListTile(
                                title: Text(_itemName(c.item), style: const TextStyle(fontWeight: FontWeight.w600)),
                                subtitle: Text(formatCurrency(c.unitPrice)),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                      visualDensity: VisualDensity.compact,
                                      onPressed: () => sync(() => _changeQty(i, -1)),
                                      icon: const Icon(Icons.remove_circle_outline),
                                      color: AppColors.brand700,
                                    ),
                                    Text(
                                      '${c.quantity}',
                                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                                    ),
                                    IconButton(
                                      visualDensity: VisualDensity.compact,
                                      onPressed: () => sync(() => _changeQty(i, 1)),
                                      icon: const Icon(Icons.add_circle_outline),
                                      color: AppColors.brand700,
                                    ),
                                    IconButton(
                                      visualDensity: VisualDensity.compact,
                                      onPressed: () {
                                        sync(() => _removeLine(i));
                                        if (_cart.isEmpty) Navigator.pop(ctx);
                                      },
                                      icon: const Icon(Icons.delete_outline_rounded),
                                      color: AppColors.error,
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                  ),
                  Container(
                    padding: EdgeInsets.fromLTRB(20, 12, 20, 12 + MediaQuery.of(ctx).padding.bottom),
                    decoration: BoxDecoration(
                      border: Border(top: BorderSide(color: Theme.of(ctx).dividerColor)),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(S.of(ref).total, style: Theme.of(ctx).textTheme.bodySmall),
                              Text(
                                formatCurrency(_total),
                                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                              ),
                            ],
                          ),
                        ),
                        FilledButton(
                          onPressed: _submitting || _cart.isEmpty
                              ? null
                              : () {
                                  Navigator.pop(ctx);
                                  _placeOrder();
                                },
                          child: Text(S.of(ref).placeOrder),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final menuAsync = ref.watch(menuProvider);
    final catsAsync = ref.watch(categoriesProvider);
    final tablesAsync = ref.watch(tablesForOrderProvider);
    final r = Responsive(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(r.pagePadding, 12, r.pagePadding, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      S.of(ref).newOrder,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                    ),
                  ),
                  _LanguagePill(),
                ],
              ),
              const SizedBox(height: 10),
              tablesAsync.when(
                loading: () => const LinearProgressIndicator(),
                error: (_, __) => const Text('Could not load tables'),
                data: (tables) {
                  return DropdownButtonFormField<int>(
                    value: _tableNumber,
                    decoration: InputDecoration(labelText: S.of(ref).table, isDense: true),
                    items: tables
                        .map((t) => DropdownMenuItem(
                              value: t.number,
                              child: Text('${S.of(ref).table} ${t.number} (${t.status})'),
                            ))
                        .toList(),
                    onChanged: (v) => setState(() => _tableNumber = v),
                  );
                },
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _searchCtrl,
                onChanged: _onSearchChanged,
                textInputAction: TextInputAction.search,
                maxLength: 80,
                decoration: InputDecoration(
                  hintText: S.of(ref).searchMenu,
                  counterText: '',
                  isDense: true,
                  prefixIcon: const Icon(Icons.search_rounded, size: 20),
                  suffixIcon: _query.isNotEmpty
                      ? IconButton(
                          tooltip: 'Clear search',
                          icon: const Icon(Icons.close_rounded, size: 18),
                          onPressed: _clearSearch,
                        )
                      : null,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
              ),
            ],
          ),
        ),
        // Categories
        catsAsync.when(
          data: (cats) => SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: r.pagePadding, vertical: 8),
              children: [
                _catChip(null, S.of(ref).all),
                ...cats.map((c) => _catChip(c.id, _catName(c))),
              ],
            ),
          ),
          loading: () => const SizedBox.shrink(),
          error: (_, __) => const SizedBox.shrink(),
        ),
        // Menu list
        Expanded(
          child: menuAsync.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text(e is AppException ? e.message : 'Error')),
            data: (items) {
              final filtered = _filterItems(items);
              if (filtered.isEmpty) {
                return Center(
                  child: Padding(
                    padding: EdgeInsets.all(r.pagePadding),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.search_off_rounded, size: 40, color: AppColors.inkMuted),
                        const SizedBox(height: 12),
                        Text(
                          _query.isNotEmpty ? 'No items match “$_query”' : 'No menu items available',
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                        if (_query.isNotEmpty || _selectedCategoryId != null) ...[
                          const SizedBox(height: 12),
                          TextButton(
                            onPressed: () {
                              _clearSearch();
                              setState(() => _selectedCategoryId = null);
                            },
                            child: Text(S.of(ref).clearFilters),
                          ),
                        ],
                      ],
                    ),
                  ),
                );
              }
              // Bottom padding so last items clear the cart bar
              final bottomPad = _cart.isEmpty ? 16.0 : 96.0;
              return ListView.builder(
                padding: EdgeInsets.fromLTRB(r.pagePadding, 0, r.pagePadding, bottomPad),
                itemCount: filtered.length,
                itemBuilder: (ctx, i) {
                  final item = filtered[i];
                  final inCart = _cart.where((c) => c.item.id == item.id).fold<int>(0, (s, c) => s + c.quantity);
                  return Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                      title: Text(_itemName(item), style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (_itemDesc(item).isNotEmpty)
                            Text(_itemDesc(item), maxLines: 1, overflow: TextOverflow.ellipsis),
                          if (inCart > 0)
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text(
                                '$inCart ${S.of(ref).inCart}',
                                style: const TextStyle(
                                  color: AppColors.brand700,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                        ],
                      ),
                      isThreeLine: item.description != null && inCart > 0,
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            formatCurrency(item.price),
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(width: 8),
                          IconButton.filled(
                            onPressed: () => _addItem(item),
                            icon: const Icon(Icons.add_rounded, size: 20),
                            style: IconButton.styleFrom(
                              backgroundColor: AppColors.brand600,
                              foregroundColor: Colors.white,
                              minimumSize: const Size(40, 40),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
        // Sticky cart bar — always reserved space when cart has items
        if (_cart.isNotEmpty)
          Material(
            elevation: 12,
            color: isDark ? AppColors.darkElevated : AppColors.white,
            child: SafeArea(
              top: false,
              // bottom: false — shell already has bottom nav with its own SafeArea
              bottom: false,
              child: InkWell(
                onTap: _openCartSheet,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
                  decoration: BoxDecoration(
                    border: Border(
                      top: BorderSide(color: isDark ? AppColors.darkLine : AppColors.line),
                    ),
                  ),
                  child: Row(
                    children: [
                      // Badge + count
                      Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: AppColors.primary800,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Icon(Icons.shopping_bag_rounded, color: Colors.white, size: 22),
                          ),
                          Positioned(
                            right: -6,
                            top: -6,
                            child: Container(
                              width: 20,
                              height: 20,
                              padding: const EdgeInsets.symmetric(horizontal: 5),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: AppColors.error,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                '$_itemCount',
                                style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              '$_itemCount ${S.of(ref).item(_itemCount)} · ${S.of(ref).tapToView}',
                              style: TextStyle(
                                fontSize: 13,
                                color: isDark ? AppColors.darkInkSecondary : AppColors.inkSecondary,
                              ),
                            ),
                            Text(
                              formatCurrency(_total),
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                            ),
                          ],
                        ),
                      ),
                      FilledButton(
                        onPressed: _submitting ? null : _placeOrder,
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                        ),
                        child: _submitting
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                              )
                            : Text(S.of(ref).placeOrder),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _catChip(String? id, String label) {
    final selected = _selectedCategoryId == id;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => setState(() => _selectedCategoryId = id),
        selectedColor: AppColors.brand100,
        checkmarkColor: AppColors.brand700,
      ),
    );
  }
}


class _LanguagePill extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final lang = ref.watch(localeProvider);
    return PopupMenuButton<AppLanguage>(
      tooltip: S.of(ref).language,
      initialValue: lang,
      onSelected: (v) => ref.read(localeProvider.notifier).setLanguage(v),
      itemBuilder: (ctx) => [
        for (final l in AppLanguage.values)
          PopupMenuItem(
            value: l,
            child: Row(
              children: [
                if (l == lang) const Icon(Icons.check_rounded, size: 18, color: AppColors.brand600),
                if (l != lang) const SizedBox(width: 18),
                const SizedBox(width: 8),
                Text('${l.label} (${l.nativeLabel})'),
              ],
            ),
          ),
      ],
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: AppColors.brand50,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.brand200),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.translate_rounded, size: 16, color: AppColors.brand700),
            const SizedBox(width: 4),
            Text(
              lang.label,
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12, color: AppColors.brand800),
            ),
            const Icon(Icons.arrow_drop_down_rounded, size: 18, color: AppColors.brand700),
          ],
        ),
      ),
    );
  }
}
