import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/validation.dart';
import '../../../core/theme/brand.dart';
import '../../widgets/branding/brand_logo.dart';
import '../../widgets/app_toast.dart';
import '../../../core/errors/app_exception.dart';
import '../../../features/auth/auth_state.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/locale/app_locale.dart';

class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _userCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _showPass = false;
  String? _userErr;
  String? _passErr;
  bool _submitting = false;

  @override
  void dispose() {
    _userCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final u = validateUsername(_userCtrl.text);
    final p = validateLoginPassword(_passCtrl.text);
    setState(() {
      _userErr = u.ok ? null : u.message;
      _passErr = p.ok ? null : p.message;
    });
    if (!u.ok || !p.ok) return;

    setState(() => _submitting = true);
    try {
      await ref.read(authProvider.notifier).login(u.value, p.value);
      if (mounted) {
        AppToast.success(
          context,
          '${S.ofLang(ref.read(localeProvider)).welcome}, ${ref.read(authProvider).user?.name ?? ''}',
        );
      }
    } on AppException catch (e) {
      if (mounted) {
        AppToast.error(context, e.message);
      }
    } catch (_) {
      if (mounted) {
        AppToast.error(context, S.ofLang(ref.read(localeProvider)).unableSignIn);
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            child: ConstrainedBox(
              constraints: BoxConstraints(maxWidth: Responsive(context).value(phone: 400.0, tablet: 440.0, desktop: 480.0)),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const BrandLogo(height: Brand.sizeHero)
                      .animate()
                      .fadeIn(duration: 400.ms)
                      .scale(begin: const Offset(0.9, 0.9)),
                  const SizedBox(height: 20),
                  Text(
                    Brand.appName,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800),
                  ).animate().fadeIn(delay: 100.ms),
                  const SizedBox(height: 6),
                  Text(
                    S.of(ref).signInSubtitle,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ).animate().fadeIn(delay: 150.ms),
                  const SizedBox(height: 36),
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: isDark ? AppColors.darkCard : AppColors.white,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: isDark ? AppColors.darkLine : AppColors.line),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.04),
                          blurRadius: 24,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Text(S.of(ref).username, style: Theme.of(context).textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w600)),
                        const SizedBox(height: 6),
                        TextField(
                          controller: _userCtrl,
                          autofillHints: const [AutofillHints.username],
                          textInputAction: TextInputAction.next,
                          maxLength: 40,
                          decoration: InputDecoration(
                            hintText: 'Username',
                            counterText: '',
                            errorText: _userErr,
                          ),
                          onChanged: (_) {
                            if (_userErr != null) setState(() => _userErr = null);
                          },
                        ),
                        const SizedBox(height: 16),
                        Text(S.of(ref).password, style: Theme.of(context).textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w600)),
                        const SizedBox(height: 6),
                        TextField(
                          controller: _passCtrl,
                          obscureText: !_showPass,
                          autofillHints: const [AutofillHints.password],
                          textInputAction: TextInputAction.done,
                          maxLength: 200,
                          onSubmitted: (_) => _submit(),
                          decoration: InputDecoration(
                            hintText: 'Password',
                            counterText: '',
                            errorText: _passErr,
                            suffixIcon: IconButton(
                              icon: Icon(_showPass ? Icons.visibility_off_rounded : Icons.visibility_rounded, size: 20),
                              onPressed: () => setState(() => _showPass = !_showPass),
                            ),
                          ),
                          onChanged: (_) {
                            if (_passErr != null) setState(() => _passErr = null);
                          },
                        ),
                        const SizedBox(height: 24),
                        FilledButton(
                          onPressed: _submitting ? null : _submit,
                          style: FilledButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                          child: _submitting
                              ? const SizedBox(
                                  width: 22,
                                  height: 22,
                                  child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                                )
                              : Text(S.of(ref).signIn, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.08, end: 0, duration: 400.ms),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
