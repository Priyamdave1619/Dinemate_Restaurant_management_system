import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/format.dart';
import '../../../core/utils/validation.dart';
import '../../../core/config/app_config.dart';
import '../../../core/errors/app_exception.dart';
import '../../../data/models/models.dart';
import '../../../data/services/waiter_api.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/locale/app_locale.dart';

final ordersFilterProvider = StateProvider<String>((_) => 'active');
final ordersSearchProvider = StateProvider<String>((_) => '');

final ordersListProvider = FutureProvider.autoDispose<List<Order>>((ref) async {
  final filter = ref.watch(ordersFilterProvider);
  final search = ref.watch(ordersSearchProvider);
  final api = ref.watch(waiterApiProvider);
  return api.listOrders(
    active: filter == 'active' ? '1' : null,
    includeArchived: filter == 'all' ? '1' : null,
    search: search.isEmpty ? null : search,
  );
});

class OrdersScreen extends ConsumerStatefulWidget {
  const OrdersScreen({super.key});

  @override
  ConsumerState<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends ConsumerState<OrdersScreen> {
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    Future.delayed(AppConfig.ordersPollInterval, _poll);
  }

  void _poll() {
    if (!mounted) return;
    ref.invalidate(ordersListProvider);
    Future.delayed(AppConfig.ordersPollInterval, _poll);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filter = ref.watch(ordersFilterProvider);
    final ordersAsync = ref.watch(ordersListProvider);

    return Column(
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(Responsive(context).pagePadding, 12, Responsive(context).pagePadding, 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(S.of(ref).orders, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Row(
                children: [
                  _chip(S.of(ref).active, 'active', filter),
                  const SizedBox(width: 8),
                  _chip(S.of(ref).all, 'all', filter),
                ],
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _searchCtrl,
                decoration: InputDecoration(
                  hintText: S.of(ref).searchOrders,
                  prefixIcon: const Icon(Icons.search_rounded, size: 20),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  isDense: true,
                ),
                maxLength: 80,
                onSubmitted: (v) {
                  ref.read(ordersSearchProvider.notifier).state = sanitizeSearch(v, 80);
                },
              ),
            ],
          ),
        ),
        Expanded(
          child: ordersAsync.when(
            loading: () => ListView.builder(
              padding: EdgeInsets.all(Responsive(context).pagePadding),
              itemCount: 4,
              itemBuilder: (_, __) => Container(
                height: 80,
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: AppColors.surfaceMute,
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
            error: (e, _) => Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(e is AppException ? e.message : 'Failed to load'),
                  FilledButton(onPressed: () => ref.invalidate(ordersListProvider), child: Text(S.of(ref).retry)),
                ],
              ),
            ),
            data: (orders) {
              if (orders.isEmpty) {
                return Center(child: Text(S.of(ref).noOrders));
              }
              return RefreshIndicator(
                onRefresh: () async {
                  ref.invalidate(ordersListProvider);
                  await ref.read(ordersListProvider.future);
                },
                child: ListView.builder(
                  padding: EdgeInsets.all(Responsive(context).pagePadding),
                  itemCount: orders.length,
                  itemBuilder: (context, i) {
                    final o = orders[i];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      child: InkWell(
                        onTap: () => context.push('/orders/${o.id}'),
                        borderRadius: BorderRadius.circular(16),
                        child: Padding(
                          padding: EdgeInsets.all(Responsive(context).pagePadding),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Table ${o.tableNumber}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                                    const SizedBox(height: 4),
                                    Text(
                                      '${o.items.length} items · ${relativeTime(o.placedAt)}'
                                      '${o.customerName != null ? ' · ${o.customerName}' : ''}'
                                      '${o.billNumber != null ? ' · #${o.billNumber}' : ''}',
                                      style: Theme.of(context).textTheme.bodySmall,
                                    ),
                                  ],
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(formatCurrency(o.total), style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.brand600)),
                                  const SizedBox(height: 4),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: AppColors.surfaceMute,
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      o.status.toUpperCase(),
                                      style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.inkSecondary),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _chip(String label, String value, String current) {
    final selected = current == value;
    return GestureDetector(
      onTap: () => ref.read(ordersFilterProvider.notifier).state = value,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? AppColors.brand600 : AppColors.surfaceMute,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: selected ? Colors.white : AppColors.inkSecondary,
          ),
        ),
      ),
    );
  }
}
