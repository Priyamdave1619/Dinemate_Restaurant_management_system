import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/format.dart';
import '../../../core/errors/app_exception.dart';
import '../../../data/models/models.dart';
import '../../../data/services/waiter_api.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/locale/app_locale.dart';
import '../../widgets/app_toast.dart';

final notificationsProvider = FutureProvider.autoDispose<List<AppNotification>>((ref) {
  return ref.watch(waiterApiProvider).listNotifications();
});

class AlertsScreen extends ConsumerWidget {
  const AlertsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(notificationsProvider);

    return Column(
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(Responsive(context).pagePadding, 12, Responsive(context).pagePadding, 8),
          child: Row(
            children: [
              Expanded(
                child: Text(S.of(ref).alerts, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
              ),
              TextButton(
                onPressed: () async {
                  try {
                    await ref.read(waiterApiProvider).markAllNotificationsRead();
                    ref.invalidate(notificationsProvider);
                    if (context.mounted) {
                      AppToast.success(context, S.of(ref).allMarkedRead);
                    }
                  } catch (_) {}
                },
                child: Text(S.of(ref).markAllRead),
              ),
            ],
          ),
        ),
        Expanded(
          child: async.when(
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(e is AppException ? e.message : S.of(ref).failedToLoad),
                  FilledButton(onPressed: () => ref.invalidate(notificationsProvider), child: Text(S.of(ref).retry)),
                ],
              ),
            ),
            data: (list) {
              if (list.isEmpty) {
                return Center(child: Text(S.of(ref).noAlerts));
              }
              return RefreshIndicator(
                onRefresh: () async {
                  ref.invalidate(notificationsProvider);
                  await ref.read(notificationsProvider.future);
                },
                child: ListView.builder(
                  padding: EdgeInsets.all(Responsive(context).pagePadding),
                  itemCount: list.length,
                  itemBuilder: (ctx, i) {
                    final n = list[i];
                    final unread = n.read != true;
                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      color: unread ? AppColors.brand50.withValues(alpha: 0.5) : null,
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: unread ? AppColors.brand100 : AppColors.surfaceMute,
                          child: Icon(
                            Icons.notifications_rounded,
                            color: unread ? AppColors.brand600 : AppColors.inkMuted,
                            size: 20,
                          ),
                        ),
                        title: Text(n.title, style: TextStyle(fontWeight: unread ? FontWeight.w700 : FontWeight.w500)),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(n.message, maxLines: 2, overflow: TextOverflow.ellipsis),
                            const SizedBox(height: 4),
                            Text(relativeTime(n.createdAt), style: Theme.of(context).textTheme.labelSmall),
                          ],
                        ),
                        onTap: () async {
                          if (unread) {
                            try {
                              await ref.read(waiterApiProvider).markNotificationRead(n.id);
                              ref.invalidate(notificationsProvider);
                            } catch (_) {}
                          }
                        },
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
