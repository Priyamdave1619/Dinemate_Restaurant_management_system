import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/utils/format.dart';
import '../../../core/errors/app_exception.dart';
import '../../../data/models/models.dart';
import '../../../data/services/waiter_api.dart';
import '../../../core/utils/responsive.dart';
import '../../../core/locale/app_locale.dart';
import '../../../core/utils/bill_pdf.dart' as bill_pdf;
import '../../widgets/app_toast.dart';

final orderDetailProvider = FutureProvider.autoDispose.family<Order, String>((ref, id) async {
  return ref.watch(waiterApiProvider).getOrder(id);
});

/// KOT payload: { itemsToPrint: List<OrderItem>, order?: Order }
final orderKotProvider = FutureProvider.autoDispose.family<Map<String, dynamic>, String>((ref, id) async {
  return ref.watch(waiterApiProvider).getOrderKot(id);
});

final restaurantProfileProvider = FutureProvider.autoDispose<RestaurantProfile>((ref) {
  return ref.watch(waiterApiProvider).getRestaurantProfile();
});

final settingsProvider = FutureProvider.autoDispose<RestaurantSettings>((ref) {
  return ref.watch(waiterApiProvider).getSettings();
});

class OrderDetailScreen extends ConsumerStatefulWidget {
  final String orderId;
  const OrderDetailScreen({super.key, required this.orderId});

  @override
  ConsumerState<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends ConsumerState<OrderDetailScreen> {
  List<(String, String)> _statusFlowFor(S s) => [
        ('accepted', s.accept),
        ('preparing', s.preparing),
        ('ready', s.ready),
        ('served', s.served),
      ];

  bool _kotBusy = false;
  bool _billBusy = false;
  bool _statusBusy = false;

  String get orderId => widget.orderId;

  Future<void> _updateStatus(String status) async {
    setState(() => _statusBusy = true);
    try {
      await ref.read(waiterApiProvider).updateOrder(orderId, {'status': status});
      ref.invalidate(orderDetailProvider(orderId));
      ref.invalidate(orderKotProvider(orderId));
      if (mounted) {
        AppToast.success(context, '${S.ofLang(ref.read(localeProvider)).statusUpdated} → $status');
      }
    } on AppException catch (e) {
      if (mounted) {
        AppToast.error(context, e.message);
      }
    } finally {
      if (mounted) setState(() => _statusBusy = false);
    }
  }

  /// Same as web: POST markKotPrinted — backend handles kitchen printer if configured.
  Future<void> _markKotPrinted() async {
    setState(() => _kotBusy = true);
    try {
      await ref.read(waiterApiProvider).markKotPrinted(orderId);
      ref.invalidate(orderDetailProvider(orderId));
      ref.invalidate(orderKotProvider(orderId));
      if (mounted) {
        AppToast.success(context, S.ofLang(ref.read(localeProvider)).kotMarked);
      }
    } on AppException catch (e) {
      if (mounted) {
        AppToast.error(context, e.message);
      }
    } catch (e) {
      if (mounted) {
        AppToast.error(context, 'KOT failed: $e');
      }
    } finally {
      if (mounted) setState(() => _kotBusy = false);
    }
  }

  Future<void> _generateOrViewBill({required bool alreadyGenerated, Order? current}) async {
    if (alreadyGenerated && current != null) {
      await _showBillReceipt(current);
      return;
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(S.of(ref).generateBillTitle),
        content: Text(S.of(ref).generateBillBody),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(S.of(ref).notNow)),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(S.of(ref).generateBill)),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    setState(() => _billBusy = true);
    try {
      final data = await ref.read(waiterApiProvider).getOrderBill(orderId);
      ref.invalidate(orderDetailProvider(orderId));
      ref.invalidate(orderKotProvider(orderId));

      Order? order = data['order'] is Order ? data['order'] as Order : null;
      order ??= await ref.read(waiterApiProvider).getOrder(orderId);

      if (mounted) {
        final num = order.billNumber;
        AppToast.success(context, num != null ? 'Bill $num' : 'Bill generated');
        await _showBillReceipt(
          order,
          settingsFromBill: data['settings'] is RestaurantSettings
              ? data['settings'] as RestaurantSettings
              : null,
        );
      }
    } on AppException catch (e) {
      if (mounted) {
        AppToast.error(context, e.message);
      }
    } catch (e) {
      if (mounted) {
        AppToast.error(context, 'Bill failed: $e');
      }
    } finally {
      if (mounted) setState(() => _billBusy = false);
    }
  }

  Future<void> _showBillReceipt(Order order, {RestaurantSettings? settingsFromBill}) async {
    final restaurant = ref.read(restaurantProfileProvider).valueOrNull;
    final settings = settingsFromBill ?? ref.read(settingsProvider).valueOrNull;

    if (!mounted) return;
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _BillReceiptSheet(
        order: order,
        restaurant: restaurant,
        settings: settings,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(orderDetailProvider(orderId));
    ref.watch(restaurantProfileProvider);
    ref.watch(settingsProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(S.of(ref).orderDetail),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(e is AppException ? e.message : 'Error'),
              FilledButton(
                onPressed: () => ref.invalidate(orderDetailProvider(orderId)),
                child: Text(S.of(ref).retry),
              ),
            ],
          ),
        ),
        data: (order) => _buildBody(order),
      ),
    );
  }

  Widget _buildBody(Order order) {
    final closed = order.status == 'cancelled' ||
        order.status == 'completed' ||
        (order.billGenerated == true);
    final r = Responsive(context);
    final kotAsync = closed ? null : ref.watch(orderKotProvider(orderId));
    final pendingFromOrder = order.items.where((i) => i.kotPrinted == false).length;

    return ListView(
      padding: EdgeInsets.all(r.pagePadding),
      children: [
        Card(
          child: Padding(
            padding: EdgeInsets.all(r.pagePadding),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Table ${order.tableNumber}',
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.brand50,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        order.status.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: AppColors.brand700,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  '${relativeTime(order.placedAt)}${order.waiterName != null ? ' · ${order.waiterName}' : ''}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                if (order.billNumber != null)
                  Text(
                    'Bill #${_displayBillNumber(order.billNumber)}',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Items', style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                ...order.items.map((item) {
                  final isNew = item.kotPrinted == false;
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: TextSpan(
                                  style: DefaultTextStyle.of(context).style,
                                  children: [
                                    TextSpan(
                                      text: '${item.quantity}× ',
                                      style: const TextStyle(fontWeight: FontWeight.w800),
                                    ),
                                    TextSpan(
                                      text: item.name,
                                      style: const TextStyle(fontWeight: FontWeight.w600),
                                    ),
                                    if (item.variant != null)
                                      TextSpan(
                                        text: ' (${item.variant})',
                                        style: TextStyle(color: AppColors.inkMuted, fontSize: 13),
                                      ),
                                  ],
                                ),
                              ),
                              if (item.note != null)
                                Text('Note: ${item.note}', style: const TextStyle(fontSize: 12, color: Color(0xFFB45309))),
                              if (isNew)
                                Container(
                                  margin: const EdgeInsets.only(top: 4),
                                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFFEF3C7),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    S.of(ref).newBadge,
                                    style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: Color(0xFF92400E)),
                                  ),
                                ),
                            ],
                          ),
                        ),
                        Text(
                          formatCurrency(item.lineTotal),
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  );
                }),
                const Divider(height: 20),
                _row(S.of(ref).subtotal, formatCurrency(order.subtotal)),
                if ((order.discountTotal ?? 0) > 0)
                  _row(S.of(ref).discount, '-${formatCurrency(order.discountTotal!)}', valueColor: AppColors.success),
                if ((order.taxAmount ?? 0) > 0)
                  _row('${S.of(ref).tax} (${order.taxRatePercent ?? 0}%)', formatCurrency(order.taxAmount!)),
                const SizedBox(height: 4),
                _row(S.of(ref).total, formatCurrency(order.total), bold: true, valueColor: AppColors.brand600),
                if (order.paymentMethod != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      'Paid via ${order.paymentMethod}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (!closed) ...[
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(S.of(ref).kitchenKot, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                            const SizedBox(height: 2),
                            if (kotAsync != null)
                              kotAsync.when(
                                loading: () => Text(
                                  'Loading… · batch ${order.kotBatches ?? 0}',
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                                error: (e, _) => Text(
                                  e is AppException ? e.message : 'Could not load KOT',
                                  style: const TextStyle(color: AppColors.error, fontSize: 12),
                                ),
                                data: (kot) {
                                  final items = (kot['itemsToPrint'] as List<OrderItem>?) ?? const <OrderItem>[];
                                  final pending = items.isNotEmpty ? items.length : pendingFromOrder;
                                  return Text(
                                    pending > 0
                                        ? '$pending ${S.of(ref).itemsNotPrinted} · ${S.of(ref).batch} ${order.kotBatches ?? 0}'
                                        : '${S.of(ref).allItemsPrinted} · ${S.of(ref).batch} ${order.kotBatches ?? 0}',
                                    style: Theme.of(context).textTheme.bodySmall,
                                  );
                                },
                              ),
                          ],
                        ),
                      ),
                      Builder(
                        builder: (ctx) {
                          int pending = pendingFromOrder;
                          if (kotAsync != null && kotAsync.hasValue) {
                            final items =
                                (kotAsync.value!['itemsToPrint'] as List<OrderItem>?) ?? const <OrderItem>[];
                            if (items.isNotEmpty) pending = items.length;
                          }
                          final canPrint = pending > 0 && !_kotBusy;
                          return FilledButton.icon(
                            onPressed: canPrint ? _markKotPrinted : null,
                            style: FilledButton.styleFrom(
                              backgroundColor: canPrint ? const Color(0xFFF59E0B) : null,
                              foregroundColor: canPrint ? Colors.white : null,
                              disabledBackgroundColor: AppColors.surfaceMute,
                              disabledForegroundColor: AppColors.inkMuted,
                            ),
                            icon: _kotBusy
                                ? const SizedBox(
                                    width: 16,
                                    height: 16,
                                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                                  )
                                : const Icon(Icons.print_rounded, size: 18),
                            label: Text(_kotBusy ? S.of(ref).printing : S.of(ref).markPrinted),
                          );
                        },
                      ),
                    ],
                  ),
                  if (kotAsync != null)
                    kotAsync.when(
                      loading: () => const SizedBox.shrink(),
                      error: (_, __) => const SizedBox.shrink(),
                      data: (kot) {
                        final items = (kot['itemsToPrint'] as List<OrderItem>?) ?? const <OrderItem>[];
                        if (items.isEmpty) return const SizedBox.shrink();
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Divider(height: 20),
                            ...items.map(
                              (it) => Padding(
                                padding: const EdgeInsets.symmetric(vertical: 3),
                                child: Text(
                                  '${it.quantity}× ${it.name}${it.variant != null ? ' (${it.variant})' : ''}'
                                  '${it.note != null ? ' — ${it.note}' : ''}',
                                  style: const TextStyle(fontWeight: FontWeight.w600),
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(S.of(ref).updateStatus, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 2.8,
            children: [
              for (final entry in _statusFlowFor(S.of(ref)))
                OutlinedButton(
                  onPressed: _statusBusy || order.status == entry.$1 ? null : () => _updateStatus(entry.$1),
                  style: OutlinedButton.styleFrom(
                    backgroundColor: order.status == entry.$1 ? AppColors.brand50 : null,
                    side: BorderSide(
                      color: order.status == entry.$1 ? AppColors.brand200 : AppColors.line,
                    ),
                  ),
                  child: Text(
                    entry.$2,
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: order.status == entry.$1 ? AppColors.brand800 : null,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 16),
        ],
        if (order.billGenerated == true)
          FilledButton.icon(
            onPressed: _billBusy ? null : () => _generateOrViewBill(alreadyGenerated: true, current: order),
            icon: const Icon(Icons.receipt_long_rounded),
            label: Text(
              '${S.of(ref).viewShareBill}${order.billNumber != null ? ' · ${_displayBillNumber(order.billNumber)}' : ''}',
            ),
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
          )
        else if (order.status != 'cancelled')
          FilledButton.icon(
            onPressed: _billBusy ? null : () => _generateOrViewBill(alreadyGenerated: false, current: order),
            icon: _billBusy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.receipt_rounded),
            label: Text(_billBusy ? S.of(ref).generating : S.of(ref).generateBill),
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48)),
          ),
        if (!closed) ...[
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: _statusBusy
                ? null
                : () async {
                    final ok = await showDialog<bool>(
                      context: context,
                      builder: (ctx) => AlertDialog(
                        title: Text(S.of(ref).cancelOrderTitle),
                        content: Text(S.of(ref).cancelOrderBody),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(S.of(ref).keepOrder)),
                          FilledButton(
                            style: FilledButton.styleFrom(backgroundColor: AppColors.error),
                            onPressed: () => Navigator.pop(ctx, true),
                            child: Text(S.of(ref).cancelOrder),
                          ),
                        ],
                      ),
                    );
                    if (ok == true) _updateStatus('cancelled');
                  },
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.error,
              minimumSize: const Size.fromHeight(44),
            ),
            child: Text(S.of(ref).cancelOrder),
          ),
        ],
        const SizedBox(height: 32),
      ],
    );
  }

  Widget _row(String label, String value, {bool bold = false, Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontWeight: bold ? FontWeight.w800 : FontWeight.w400, fontSize: bold ? 16 : 14)),
          Text(
            value,
            style: TextStyle(
              fontWeight: bold ? FontWeight.w800 : FontWeight.w500,
              fontSize: bold ? 16 : 14,
              color: valueColor,
            ),
          ),
        ],
      ),
    );
  }
}

String _displayBillNumber(String? billNumber) {
  if (billNumber == null || billNumber.isEmpty) return '—';
  return billNumber
      .replaceFirst(RegExp(r'^REST\d+[-_]?', caseSensitive: false), '')
      .replaceFirst(RegExp(r'^-+'), '');
}

String _displayOrderNumber(String orderId) {
  final m = RegExp(r'^ord-REST\d+-(\d+)$', caseSensitive: false).firstMatch(orderId);
  if (m != null) return m.group(1)!;
  final parts = orderId.split('-');
  final last = parts.isNotEmpty ? parts.last : orderId;
  if (RegExp(r'^\d+$').hasMatch(last)) return last;
  return orderId
      .replaceAll(RegExp(r'REST\d+', caseSensitive: false), '')
      .replaceFirst(RegExp(r'^ord-+', caseSensitive: false), '');
}

String _formatBillDateTime(String? iso) {
  if (iso == null || iso.isEmpty) return '—';
  try {
    final d = DateTime.parse(iso).toLocal();
    final date =
        '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
    final time =
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    return '$date $time';
  } catch (_) {
    return iso;
  }
}

String buildBillShareText({
  required Order order,
  RestaurantProfile? restaurant,
  RestaurantSettings? settings,
}) {
  final name = restaurant?.name ?? settings?.restaurantName ?? 'Restaurant';
  final address = restaurant?.address ?? settings?.address;
  final phone = restaurant?.mobile;
  final gst = restaurant?.gstNumber ?? settings?.gstin;
  final when = _formatBillDateTime(
    order.billedAt ?? (order.updatedAt.isNotEmpty ? order.updatedAt : order.placedAt),
  );

  final lines = <String>[
    name.toUpperCase(),
    if (address != null && address.isNotEmpty) address,
    if (phone != null && phone.isNotEmpty) 'PH: $phone',
    if (gst != null && gst.isNotEmpty) 'GSTIN: $gst',
    '------------------------',
    'Bill: ${_displayBillNumber(order.billNumber)}',
    'Order: ${_displayOrderNumber(order.id)}',
    'Table: ${order.tableNumber}${order.waiterName != null ? '  Waiter: ${order.waiterName}' : ''}',
    'Date: $when',
    if (order.customerName != null) 'Customer: ${order.customerName}',
    if (order.customerPhone != null) 'Phone: ${order.customerPhone}',
    if (order.paymentMethod != null) 'Payment: ${order.paymentMethod!.toUpperCase()}',
    '------------------------',
  ];
  for (final it in order.items) {
    lines.add(it.name);
    lines.add(
      '  ${it.price.toStringAsFixed(2)} x ${it.quantity} = ${(it.price * it.quantity).toStringAsFixed(2)}',
    );
  }
  lines.add('------------------------');
  lines.add('Subtotal: ${formatCurrency(order.subtotal)}');
  if ((order.discountTotal ?? 0) > 0) {
    lines.add('Discount: -${formatCurrency(order.discountTotal!)}');
  }
  if ((order.taxAmount ?? 0) > 0) {
    lines.add(
      'Tax (${order.taxRatePercent ?? settings?.taxRatePercent ?? 0}%): ${formatCurrency(order.taxAmount!)}',
    );
  }
  lines.add('NET AMOUNT: ${formatCurrency(order.total)}');
  lines.add('------------------------');
  lines.add('Thank you! Visit again.');
  return lines.where((l) => l.isNotEmpty).join('\n');
}

class _BillReceiptSheet extends ConsumerWidget {
  final Order order;
  final RestaurantProfile? restaurant;
  final RestaurantSettings? settings;

  const _BillReceiptSheet({
    required this.order,
    this.restaurant,
    this.settings,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final name = restaurant?.name ?? settings?.restaurantName ?? 'Restaurant';
    final address = restaurant?.address ?? settings?.address;
    final phone = restaurant?.mobile;
    final gst = restaurant?.gstNumber ?? settings?.gstin;
    final logo = restaurant?.logoUrl;
    final currency = restaurant?.currency ?? settings?.currency ?? 'INR';
    final when = _formatBillDateTime(
      order.billedAt ?? (order.updatedAt.isNotEmpty ? order.updatedAt : order.placedAt),
    );
    final totalQty = order.items.fold<int>(0, (s, i) => s + i.quantity);

    return Container(
      height: MediaQuery.of(context).size.height * 0.92,
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkSurface : const Color(0xFFF1F5F9),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
            decoration: BoxDecoration(
              color: isDark ? AppColors.darkCard : Colors.white,
              border: Border(bottom: BorderSide(color: isDark ? AppColors.darkLine : AppColors.line)),
            ),
            child: Row(
              children: [
                Text(S.of(ref).bill, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const Spacer(),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close_rounded),
                ),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppColors.line),
                ),
                child: DefaultTextStyle(
                  style: const TextStyle(
                    fontFamily: 'monospace',
                    fontSize: 12,
                    color: Color(0xFF111111),
                    height: 1.35,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (logo != null && logo.isNotEmpty)
                        Center(
                          child: Image.network(
                            logo,
                            height: 56,
                            errorBuilder: (_, __, ___) => const SizedBox.shrink(),
                          ),
                        ),
                      Text(
                        name.toUpperCase(),
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 0.5),
                      ),
                      if (address != null && address.isNotEmpty)
                        Text(address, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Color(0xFF444444))),
                      if (phone != null && phone.isNotEmpty)
                        Text('PH: $phone', textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Color(0xFF444444))),
                      if (gst != null && gst.isNotEmpty)
                        Text('GSTIN: $gst', textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Color(0xFF444444))),
                      const SizedBox(height: 4),
                      const Text('CASH / BILL', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 11)),
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: Divider(color: Color(0xFF333333), height: 1),
                      ),
                      _meta('Bill No', _displayBillNumber(order.billNumber)),
                      _meta('Order No', _displayOrderNumber(order.id)),
                      _meta('Waiter', order.waiterName ?? '—'),
                      _meta('Table', '${order.tableNumber}'),
                      _meta('Date / Time', when),
                      if (order.paymentMethod != null) _meta('Payment', order.paymentMethod!.toUpperCase()),
                      if (order.customerName != null) _meta('Customer', order.customerName!),
                      if (order.customerPhone != null) _meta('Phone', order.customerPhone!),
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: Divider(color: Color(0xFF333333), height: 1),
                      ),
                      const Row(
                        children: [
                          Expanded(flex: 4, child: Text('ITEM', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700))),
                          Expanded(child: Text('PRICE', textAlign: TextAlign.right, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700))),
                          Expanded(child: Text('QTY', textAlign: TextAlign.right, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700))),
                          Expanded(child: Text('TOTAL', textAlign: TextAlign.right, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700))),
                        ],
                      ),
                      const Divider(color: Color(0xFF333333), height: 12),
                      ...order.items.map((it) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                flex: 4,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(it.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                                    if (it.variant != null)
                                      Text(it.variant!, style: const TextStyle(fontSize: 10, color: Color(0xFF555555))),
                                    if (it.note != null)
                                      Text('Note: ${it.note}', style: const TextStyle(fontSize: 10, color: Color(0xFFB45309))),
                                  ],
                                ),
                              ),
                              Expanded(child: Text(it.price.toStringAsFixed(2), textAlign: TextAlign.right)),
                              Expanded(child: Text('${it.quantity}', textAlign: TextAlign.right)),
                              Expanded(
                                child: Text((it.price * it.quantity).toStringAsFixed(2), textAlign: TextAlign.right),
                              ),
                            ],
                          ),
                        );
                      }),
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: Divider(color: Color(0xFF333333), height: 1),
                      ),
                      _meta('Total Quantity', '$totalQty'),
                      _meta('Gross / Subtotal', order.subtotal.toStringAsFixed(2)),
                      if ((order.discountTotal ?? 0) > 0)
                        _meta(
                          (order.manualDiscountPercent ?? 0) > 0
                              ? 'Discount (${order.manualDiscountPercent}%)'
                              : 'Discount',
                          '-${order.discountTotal!.toStringAsFixed(2)}',
                        ),
                      if ((order.taxAmount ?? 0) > 0)
                        _meta(
                          'Tax / GST (${order.taxRatePercent ?? settings?.taxRatePercent ?? 0}%)',
                          order.taxAmount!.toStringAsFixed(2),
                        ),
                      const SizedBox(height: 6),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Net Amount ($currency)', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                          Text(order.total.toStringAsFixed(2), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                        ],
                      ),
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: Divider(color: Color(0xFF333333), height: 1),
                      ),
                      const Text(
                        'Thank you! Visit again.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 11, color: Color(0xFF555555)),
                      ),
                      Text(
                        'Order ${_displayOrderNumber(order.id)}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 10, color: Color(0xFF666666)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          _BillPdfActions(
            order: order,
            restaurant: restaurant,
            settings: settings,
            restaurantName: name,
          ),
        ],
      ),
    );
  }

  Widget _meta(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1.5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(k, style: const TextStyle(fontSize: 11)),
          Text(v, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}


class _BillPdfActions extends ConsumerStatefulWidget {
  final Order order;
  final RestaurantProfile? restaurant;
  final RestaurantSettings? settings;
  final String restaurantName;

  const _BillPdfActions({
    required this.order,
    this.restaurant,
    this.settings,
    required this.restaurantName,
  });

  @override
  ConsumerState<_BillPdfActions> createState() => _BillPdfActionsState();
}

class _BillPdfActionsState extends ConsumerState<_BillPdfActions> {
  bool _busy = false;

  Future<void> _run(Future<void> Function() job, String okMessage) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await job();
      if (mounted) {
        AppToast.success(context, okMessage);
      }
    } catch (e) {
      if (mounted) {
        AppToast.error(context, 'Failed: $e');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: EdgeInsets.fromLTRB(16, 12, 16, 12 + MediaQuery.of(context).padding.bottom),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkCard : Colors.white,
        border: Border(top: BorderSide(color: isDark ? AppColors.darkLine : AppColors.line)),
      ),
      child: Column(
        children: [
          if (_busy)
            const Padding(
              padding: EdgeInsets.only(bottom: 10),
              child: LinearProgressIndicator(minHeight: 3),
            ),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _busy
                      ? null
                      : () => _run(
                            () => bill_pdf.printBillPdf(
                              order: widget.order,
                              restaurant: widget.restaurant,
                              settings: widget.settings,
                            ),
                            'Print dialog opened',
                          ),
                  icon: const Icon(Icons.print_rounded, size: 18),
                  label: Text(S.of(ref).print),
                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.icon(
                  onPressed: _busy
                      ? null
                      : () => _run(
                            () => bill_pdf.shareBillPdf(
                              order: widget.order,
                              restaurant: widget.restaurant,
                              settings: widget.settings,
                            ),
                            'PDF shared',
                          ),
                  icon: const Icon(Icons.share_rounded, size: 18),
                  label: Text(S.of(ref).sharePdf),
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _busy
                  ? null
                  : () => _run(() async {
                        final file = await bill_pdf.saveBillPdf(
                          order: widget.order,
                          restaurant: widget.restaurant,
                          settings: widget.settings,
                        );
                        // Also open share sheet so user can save to Downloads / Drive / Files
                        await Share.shareXFiles(
                          [
                            XFile(
                              file.path,
                              mimeType: 'application/pdf',
                              name: bill_pdf.billFileName(widget.order),
                            ),
                          ],
                          subject: 'Bill ${bill_pdf.displayBillNumber(widget.order.billNumber)}',
                          text: 'Bill PDF',
                        );
                      }, 'PDF ready'),
              icon: const Icon(Icons.download_rounded, size: 18),
              label: Text(S.of(ref).downloadPdf),
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46)),
            ),
          ),
          const SizedBox(height: 4),
          SizedBox(
            width: double.infinity,
            child: TextButton.icon(
              onPressed: _busy
                  ? null
                  : () async {
                      final text = buildBillShareText(
                        order: widget.order,
                        restaurant: widget.restaurant,
                        settings: widget.settings,
                      );
                      await Clipboard.setData(ClipboardData(text: text));
                      if (context.mounted) {
                        AppToast.success(context, 'Bill text copied');
                      }
                    },
              icon: const Icon(Icons.copy_rounded, size: 16),
              label: Text(S.of(ref).copyBillText),
            ),
          ),
        ],
      ),
    );
  }
}
