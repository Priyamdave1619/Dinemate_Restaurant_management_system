import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import '../../data/models/models.dart';
import '../../core/network/api_client.dart';
import '../../core/config/app_config.dart';
import '../../core/errors/app_exception.dart';

const _kAccess = 'sevusal_waiter_access';
const _kRefresh = 'sevusal_waiter_refresh';
const _kUser = 'sevusal_waiter_user';
const _kRestaurant = 'sevusal_waiter_restaurant';

class AuthState {
  final SessionUser? user;
  final RestaurantSummary? restaurant;
  final String? accessToken;
  final String? refreshToken;
  final bool hydrated;
  final bool loading;

  const AuthState({
    this.user,
    this.restaurant,
    this.accessToken,
    this.refreshToken,
    this.hydrated = false,
    this.loading = false,
  });

  bool get isAuthenticated =>
      user != null && ((accessToken != null && accessToken!.isNotEmpty) || (refreshToken != null && refreshToken!.isNotEmpty));

  AuthState copyWith({
    SessionUser? user,
    RestaurantSummary? restaurant,
    String? accessToken,
    String? refreshToken,
    bool? hydrated,
    bool? loading,
    bool clearUser = false,
  }) =>
      AuthState(
        user: clearUser ? null : (user ?? this.user),
        restaurant: clearUser ? null : (restaurant ?? this.restaurant),
        accessToken: clearUser ? null : (accessToken ?? this.accessToken),
        refreshToken: clearUser ? null : (refreshToken ?? this.refreshToken),
        hydrated: hydrated ?? this.hydrated,
        loading: loading ?? this.loading,
      );
}

class AuthNotifier extends StateNotifier<AuthState> {
  final FlutterSecureStorage _secure;
  final ApiClient _api;

  AuthNotifier(this._secure, this._api) : super(const AuthState()) {
    _hydrate();
  }

  Future<void> _hydrate() async {
    try {
      final access = await _secure.read(key: _kAccess);
      final refresh = await _secure.read(key: _kRefresh);
      final prefs = await SharedPreferences.getInstance();
      final userJson = prefs.getString(_kUser);
      final restJson = prefs.getString(_kRestaurant);

      SessionUser? user;
      RestaurantSummary? restaurant;
      if (userJson != null) {
        user = SessionUser.fromJson(jsonDecode(userJson) as Map<String, dynamic>);
      }
      if (restJson != null) {
        restaurant = RestaurantSummary.fromJson(jsonDecode(restJson) as Map<String, dynamic>);
      }

      state = state.copyWith(
        accessToken: access,
        refreshToken: refresh,
        user: user,
        restaurant: restaurant,
        hydrated: true,
      );

      _api.configure(
        getAccessToken: () async => state.accessToken,
        refreshToken: refreshAccessToken,
      );
    } catch (_) {
      state = state.copyWith(hydrated: true);
    }
  }

  Future<void> setAuth({
    required SessionUser user,
    RestaurantSummary? restaurant,
    required String accessToken,
    required String refreshToken,
  }) async {
    await _secure.write(key: _kAccess, value: accessToken);
    await _secure.write(key: _kRefresh, value: refreshToken);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kUser, jsonEncode(user.toJson()));
    if (restaurant != null) {
      await prefs.setString(_kRestaurant, jsonEncode(restaurant.toJson()));
    } else {
      await prefs.remove(_kRestaurant);
    }
    state = state.copyWith(
      user: user,
      restaurant: restaurant,
      accessToken: accessToken,
      refreshToken: refreshToken,
    );
  }

  Future<void> setTokens(String access, String refresh) async {
    await _secure.write(key: _kAccess, value: access);
    await _secure.write(key: _kRefresh, value: refresh);
    state = state.copyWith(accessToken: access, refreshToken: refresh);
  }

  Future<void> clearAuth() async {
    await _secure.delete(key: _kAccess);
    await _secure.delete(key: _kRefresh);
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kUser);
    await prefs.remove(_kRestaurant);
    state = state.copyWith(clearUser: true);
  }

  Future<String?> refreshAccessToken() async {
    final refresh = state.refreshToken;
    if (refresh == null || refresh.isEmpty) return state.accessToken;

    try {
      final res = await _api.rawPost(
        '/api/auth/refresh',
        data: {'refreshToken': refresh},
        headers: {'Authorization': 'Bearer $refresh'},
      );
      final body = res.data;
      final d = body is Map ? (body['data'] ?? body) : null;
      if (d is Map && d['accessToken'] != null) {
        final newAccess = d['accessToken'].toString();
        final newRefresh = d['refreshToken']?.toString() ?? refresh;
        await setTokens(newAccess, newRefresh);
        return newAccess;
      }
      return state.accessToken;
    } catch (_) {
      // Keep existing session — never auto-logout on network/refresh failure
      return state.accessToken;
    }
  }

  Future<void> login(String username, String password) async {
    state = state.copyWith(loading: true);
    try {
      final data = await _api.post<Map<String, dynamic>>(
        '/api/auth/login',
        data: {'username': username, 'password': password},
        parser: (raw) {
          final m = raw as Map;
          final d = m['data'] ?? m;
          return Map<String, dynamic>.from(d as Map);
        },
      );
      final login = LoginResponse.fromJson(data);
      if (!['waiter', 'manager', 'owner'].contains(login.role)) {
        throw const ValidationException('This app is for restaurant staff only');
      }
      if (login.restaurantId == null || login.restaurantId!.isEmpty) {
        throw const ValidationException('No restaurant linked to this account');
      }
      final user = SessionUser(
        id: login.id,
        username: login.username,
        name: login.name,
        role: login.role,
        restaurantId: login.restaurantId,
      );
      await setAuth(
        user: user,
        restaurant: login.restaurant,
        accessToken: login.accessToken,
        refreshToken: login.refreshToken,
      );
    } finally {
      state = state.copyWith(loading: false);
    }
  }

  Future<void> logout() async {
    try {
      final rt = state.refreshToken;
      await _api.post('/api/auth/logout', data: rt != null ? {'refreshToken': rt} : null);
    } catch (_) {}
    await clearAuth();
  }
}

final apiClientProvider = Provider<ApiClient>((ref) => ApiClient());

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  final api = ref.watch(apiClientProvider);
  const secure = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  return AuthNotifier(secure, api);
});
