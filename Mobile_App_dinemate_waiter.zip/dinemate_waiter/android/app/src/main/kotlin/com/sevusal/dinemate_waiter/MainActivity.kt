package com.sevusal.dinemate_waiter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
