# Sevusal Waiter Portal (Flutter)

Production-ready Flutter migration of the Next.js **DineMate / Sevusal Waiter Portal**.

Mobile-first floor app for **waiters**, **managers**, and **owners**.

## Features (feature parity)

| Screen | What it does |
|--------|----------------|
| **Login** | Username/password, role check (waiter/manager/owner), restaurant binding |
| **Floor** | Live table grid (available / occupied / reserved / cleaning), seat/free, open order, auto-refresh ~12s |
| **Orders** | Active + all orders, search, status badges, navigate to detail |
| **Order detail** | Items, status flow (accept → prep → ready → served → completed), KOT, generate bill, cancel |
| **New order** | Pick table + menu items (categories), cart, place order |
| **Alerts** | Restaurant notifications, mark read / mark all read |
| **Me** | Profile, restaurant summary, logout (only explicit logout clears session) |

## Architecture

- **State**: Riverpod (`StateNotifier` + `FutureProvider`)
- **Routing**: GoRouter with auth redirects + shell (bottom nav)
- **Networking**: Dio + interceptors, token refresh (never auto-logout on network failure)
- **Storage**: `flutter_secure_storage` for tokens, `shared_preferences` for user/restaurant
- **Theme**: Full light + dark Material 3 design system
- **API base**: `https://backend-restaurants-or-ordering-sys.vercel.app` (override with `--dart-define=API_BASE_URL=...`)

## Project structure

```
lib/
├── core/           # theme, config, network, routing, utils, errors
├── data/           # models, services (WaiterApi)
├── features/       # auth state
├── presentation/   # screens, widgets, dialogs
└── main.dart
```

## Setup

```bash
flutter pub get
flutter run
# or web:
flutter run -d chrome
```

### Environment

```bash
flutter run --dart-define=API_BASE_URL=http://localhost:3000
```

Default production API is already configured.

## Auth behaviour (preserved from Next.js)

- Session kept until **explicit Logout** on Me screen
- Access token refresh every 10 minutes + on app resume
- Refresh failure does **not** clear the session
- Only waiter / manager / owner roles allowed
- Account must have a linked restaurant

## Platforms

Structured for **Android**, **iOS**, and **Web**. Desktop can be enabled via Flutter platforms.

## Notes

- No mock data — all screens call the real backend APIs
- Loading / empty / error / retry states on list screens
- Pull-to-refresh on Floor, Orders, Alerts
- Bottom navigation with 5 tabs matching the original app
- Modern dialogs for logout confirmation and bill preview (bottom sheet)
