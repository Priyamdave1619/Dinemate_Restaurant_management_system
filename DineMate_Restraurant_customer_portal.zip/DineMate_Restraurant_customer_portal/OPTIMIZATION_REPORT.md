# Frontend Optimization Report — DineMate Customer Portal

**Scope:** Customer-facing table ordering portal (Next.js 15 + React 19 + TanStack Query + Zustand + Framer Motion).  
This is **not** an admin dashboard; there are no large data tables, charts, auth login, or multi-tenant workspace switcher in this codebase.

---

## 1. Problems Found

| Priority | Issue |
|----------|--------|
| High | Every `MenuCard` re-rendered on any cart change (selector scanned all lines; card used `layout` + hover motion) |
| High | Page transitions used CSS `filter: blur()` — expensive on mobile GPUs |
| High | Menu/categories/settings/recommendations refetched too aggressively (short / inconsistent `staleTime`) |
| Medium | Search filtered the full menu on every keystroke (main-thread work during typing) |
| Medium | API errors could surface generic or internal-looking messages |
| Medium | No React error boundary — a single render error blanked the app |
| Medium | Heavy per-card Framer Motion (`layout`, `whileHover` on every card) |
| Low | Query client defaults not tuned for a dining session (stable menu data) |

---

## 2. Root Causes

1. **Cart → list coupling:** Each card subscribed to cart state in a way that still forced broad updates; combined with `layout` animations this made the menu feel janky when adjusting qty.
2. **Motion tokens:** `pageVariants` animated `filter: blur`, which forces expensive paint work.
3. **Fetch policy:** Multiple independent queries without aligned session-friendly cache times → extra network round-trips when navigating menu ↔ order.
4. **Search:** Controlled input drove filtering synchronously every character.
5. **Errors:** `getErrorMessage` trusted Axios message / body without status-based fallbacks or stack-trace filtering.
6. **Resilience:** No error boundary around the app tree.

---

## 3. Fixes Implemented

### API & errors (`src/lib/api/client.ts`)
- Status-aware user messages (400–504)
- Network / timeout handling
- Strips stack-trace-like body messages so internals never reach the diner

### React Query (`src/components/providers.tsx` + menu page)
- Default `staleTime` 60s, `gcTime` 10m, exponential retry delay
- Menu session queries: **2 min** `staleTime` for menu, categories, settings, recommendations
- `refetchOnWindowFocus: false` retained (correct for dining)

### Rendering (`src/components/menu-card.tsx`)
- `React.memo` on `MenuCard`
- Selector returns a **number** (qty for that `itemId` only) → re-render only when that qty changes
- Removed `layout` / hover motion wrappers from the card shell (lighter list scrolling)
- Images: `decoding="async"` + existing `loading="lazy"`

### Search (`table/.../page.tsx`)
- `useDeferredValue(search)` so typing stays responsive while filter work is deferred

### Motion (`src/lib/motion.ts`)
- Page variants: opacity + translate only (no blur filters)

### Stability
- New `ErrorBoundary` component
- Wired in root `layout.tsx`

### Prior feature (unchanged behavior)
- 15s place-order confirmation popup (responsive bottom-sheet / centered card)

---

## 4. Performance Improvements

| Area | Change |
|------|--------|
| Re-renders | Menu cards no longer re-render on unrelated cart line updates |
| Animations | Removed blur + per-card layout animations → smoother scroll on mobile |
| Network | Longer stale times → fewer duplicate menu/settings fetches during a session |
| Typing | Deferred search reduces main-thread pressure on large menus |
| Resilience | Render errors isolated; safer error toasts |

*(No production Lighthouse run in this environment — improvements are architectural and should show on real devices.)*

---

## 5. Security Improvements

- Stronger client-side error sanitization (no stack traces / internal paths in toasts)
- Existing sanitize helpers retained for free text and IDs
- Frontend still does not treat client checks as authorization (backend remains source of truth)

---

## 6. Files Changed

| File | Change |
|------|--------|
| `src/lib/api/client.ts` | Status-aware, safe error messages |
| `src/components/providers.tsx` | QueryClient defaults |
| `src/components/error-boundary.tsx` | **New** |
| `src/components/menu-card.tsx` | memo, lean selectors, lighter motion |
| `src/components/cart-sheet.tsx` | 15s confirm popup (earlier + responsive) |
| `src/lib/motion.ts` | No blur on page transitions |
| `src/app/layout.tsx` | ErrorBoundary |
| `src/app/[restaurantId]/table/[tableNumber]/page.tsx` | Deferred search, query cache options |

---

## 7. Remaining Issues / Out of Scope

- **Backend required:** Rate limiting, auth, tenant isolation, true server-side search/pagination (customer menu is intentionally full-list).
- **Menu images:** Still `<img>` not `next/image` — remote URLs are arbitrary tenant hosts; keep lazy/async unless image CDN domains are known.
- **QR scanner:** Large vendor scripts in `/public/vendor` — load only when scanner opens (already gated by open state; further dynamic import possible later).
- **No admin tables/charts** in this repo — large-table / virtualization items in the original brief do not apply.
- **Production metrics:** Run Lighthouse / Web Vitals on a real deployment after deploy.

---

## Acceptance checklist (this portal)

- [x] No intentional rewrite of business logic  
- [x] Place order + 15s cancel window preserved  
- [x] Cart / order session / bill lock preserved  
- [x] Safer errors + error boundary  
- [x] Fewer wasted re-renders and network refetches  
- [x] Smoother motion on mobile  
- [ ] Full device QA against live API (needs backend)  
- [ ] Production build verification in CI  
