"use client";

import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { X, Minus, Plus } from "lucide-react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { useCartStore, selectOrderingLocked } from "@/lib/stores/cart-store";
import { formatCurrency } from "@/lib/utils/format";
import { cn } from "@/lib/utils/cn";
import { overlayVariants, sheetVariants, sheetTransition, fadeFast } from "@/lib/motion";
import {
  FoodPlaceholderIcon,
  VegMark,
  NonVegMark,
  SpicyIcon,
  BestsellerIcon,
} from "@/components/icons";
import type { MenuItem, MenuAddOn } from "@/types";

const SPICE_LABELS: Record<string, string> = {
  none: "No spice",
  mild: "Mild",
  medium: "Medium",
  spicy: "Spicy",
  extra_spicy: "Extra spicy",
};

type Props = {
  item: MenuItem | null;
  open: boolean;
  onClose: () => void;
};

/**
 * Zomato-style customization bottom sheet:
 * variants, Jain/Regular, spice, add-ons, cooking request, qty → Add to cart.
 */
export function CustomizeSheet({ item, open, onClose }: Props) {
  const addItem = useCartStore((s) => s.addItem);
  const orderingLocked = useCartStore(selectOrderingLocked);

  const [variantId, setVariantId] = useState<string | undefined>();
  const [preparation, setPreparation] = useState<"regular" | "jain">("regular");
  const [spice, setSpice] = useState<string>("");
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [cookingRequest, setCookingRequest] = useState("");
  const [qty, setQty] = useState(1);
  const [mounted, setMounted] = useState(false);

  // Portal target isn't available during SSR/first render.
  useEffect(() => {
    setMounted(true);
  }, []);

  // Lock background scroll while the sheet is open, and restore it on close/unmount.
  useEffect(() => {
    if (!open) return;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [open]);

  useEffect(() => {
    if (!item || !open) return;
    setVariantId(item.variants?.[0]?.id);
    setPreparation(item.jainOnly ? "jain" : "regular");
    const opts = item.spiceOptions?.length
      ? item.spiceOptions
      : item.enableSpiceLevel
        ? ["mild", "medium", "spicy"]
        : [];
    setSpice(opts[0] || "");
    setSelectedAddOns([]);
    setCookingRequest("");
    setQty(1);
  }, [item, open]);

  const variant = useMemo(
    () => item?.variants?.find((v) => v.id === variantId),
    [item, variantId]
  );

  const addOnList: MenuAddOn[] = useMemo(
    () => (item?.addOns || []).filter((a) => a.available !== false),
    [item]
  );

  const unitPrice = useMemo(() => {
    if (!item) return 0;
    const base = item.price + (variant?.priceDelta || 0);
    const extras = addOnList
      .filter((a) => selectedAddOns.includes(a.id))
      .reduce((n, a) => n + (a.priceDelta || 0), 0);
    return base + extras;
  }, [item, variant, addOnList, selectedAddOns]);

  if (!item || !mounted) return null;

  // Jain/Regular: show when explicitly enabled, or by default for veg items
  // (Indian restaurant UX). Opt out with jainAvailable: false on the item.
  const isVegItem =
    item.isVeg === true || item.foodType === "veg" || item.foodType === "vegan";
  const showJain =
    !!item.jainOnly ||
    item.jainAvailable === true ||
    (item.jainAvailable !== false && isVegItem);
  const showSpice = !!item.enableSpiceLevel;
  const spiceOpts = item.spiceOptions?.length
    ? item.spiceOptions
    : ["mild", "medium", "spicy", "extra_spicy"];
  const showCooking = item.enableCookingRequest !== false; // default on for better UX unless disabled
  const maxCR = item.maxCookingRequestLength ?? 250;
  const showVariants = (item.variants?.length || 0) > 0;
  const showAddOns = addOnList.length > 0;

  function toggleAddOn(id: string) {
    setSelectedAddOns((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  }

  function handleAdd() {
    if (orderingLocked) {
      toast.error("Ordering is closed for this session");
      return;
    }
    const addOns = addOnList
      .filter((a) => selectedAddOns.includes(a.id))
      .map((a) => ({ id: a.id, label: a.label, priceDelta: a.priceDelta || 0 }));

    addItem(item!, {
      variantId: variant?.id,
      variantLabel: variant?.label,
      priceDelta: variant?.priceDelta || 0,
      preparation: showJain ? preparation : undefined,
      spiceLevelSelected: showSpice && spice ? SPICE_LABELS[spice] || spice : undefined,
      addOns,
      cookingRequest: showCooking ? cookingRequest.trim() : undefined,
      quantity: qty,
    });
    toast.success(`Added ${item!.name}`);
    onClose();
  }

  return createPortal(
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end" role="dialog" aria-modal="true">
          <motion.div
            className="absolute inset-0 bg-black/50"
            variants={overlayVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            transition={fadeFast}
            onClick={onClose}
            aria-hidden
          />
          <motion.div
            className="relative z-10 flex max-h-[92vh] flex-col rounded-t-3xl bg-white shadow-2xl dark:bg-brand-950"
            variants={sheetVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            transition={sheetTransition}
          >
        <div className="flex shrink-0 items-center justify-between border-b border-line px-4 py-3 dark:border-brand-800">
          <p className="text-sm font-semibold text-ink dark:text-brand-50">Customize</p>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-2 hover:bg-brand-50 dark:hover:bg-brand-900"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto px-4 pb-4 pt-3">
          {/* Header */}
          <div className="flex gap-3">
            <div className="h-20 w-20 shrink-0 overflow-hidden rounded-xl bg-brand-50 dark:bg-brand-900">
              {item.image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={item.image} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center">
                  <FoodPlaceholderIcon className="h-8 w-8" />
                </div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-1.5">
                {(item.isVeg === true ||
                  ["veg", "vegetarian", "vegan"].includes(String(item.foodType).toLowerCase())) && (
                  <VegMark size={14} />
                )}
                {(item.isVeg === false ||
                  ["non-veg", "nonveg", "non_veg", "egg"].includes(
                    String(item.foodType).toLowerCase()
                  )) && <NonVegMark size={14} />}
                {(item.spiceLevel === "hot" || item.tags?.includes("spicy")) && (
                  <span className="inline-flex items-center gap-0.5 text-[11px] font-semibold text-red-600">
                    <SpicyIcon className="h-3 w-3" /> Spicy
                  </span>
                )}
                {item.tags?.includes("bestseller") && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2 py-0.5 text-[10px] font-bold text-amber-800 dark:bg-amber-950/40 dark:text-amber-200">
                    <BestsellerIcon className="h-3 w-3 text-amber-600" /> Bestseller
                  </span>
                )}
              </div>
              <h2 className="mt-0.5 text-lg font-bold text-ink dark:text-brand-50">{item.name}</h2>
              {item.description && (
                <p className="mt-1 line-clamp-3 text-xs text-ink-secondary dark:text-brand-300">
                  {item.description}
                </p>
              )}
              <p className="mt-1.5 font-bold text-ink dark:text-brand-50">
                {formatCurrency(item.price)}
              </p>
            </div>
          </div>

          {/* Variants */}
          {showVariants && (
            <section className="rounded-2xl border border-line p-3 dark:border-brand-800">
              <h3 className="text-sm font-semibold text-ink dark:text-brand-50">Size / Variant</h3>
              <p className="mb-2 text-xs text-ink-muted">Select one option</p>
              <div className="space-y-2">
                {item.variants!.map((v) => (
                  <label
                    key={v.id}
                    className={cn(
                      "flex cursor-pointer items-center justify-between rounded-xl border px-3 py-2.5 text-sm transition",
                      variantId === v.id
                        ? "border-brand-500 bg-brand-50 dark:border-brand-400 dark:bg-brand-900"
                        : "border-line dark:border-brand-800"
                    )}
                  >
                    <span className="flex items-center gap-2 font-medium">
                      <input
                        type="radio"
                        name="variant"
                        checked={variantId === v.id}
                        onChange={() => setVariantId(v.id)}
                        className="accent-brand-600"
                      />
                      {v.label}
                    </span>
                    <span className="tabular-nums text-ink-secondary">
                      {v.priceDelta > 0
                        ? `+${formatCurrency(v.priceDelta)}`
                        : v.priceDelta < 0
                          ? formatCurrency(v.priceDelta)
                          : ""}
                    </span>
                  </label>
                ))}
              </div>
            </section>
          )}

          {/* Jain / Regular */}
          {showJain && (
            <section className="rounded-2xl border border-line p-3 dark:border-brand-800">
              <h3 className="text-sm font-semibold text-ink dark:text-brand-50">Preparation</h3>
              <p className="mb-2 text-xs text-ink-muted">Select up to 1 option</p>
              <div className="space-y-2">
                {!item.jainOnly && (
                  <label
                    className={cn(
                      "flex cursor-pointer items-center justify-between rounded-xl border px-3 py-2.5 text-sm",
                      preparation === "regular"
                        ? "border-brand-500 bg-brand-50 dark:border-brand-400 dark:bg-brand-900"
                        : "border-line dark:border-brand-800"
                    )}
                  >
                    <span className="flex items-center gap-2 font-medium">
                      <input
                        type="radio"
                        name="prep"
                        checked={preparation === "regular"}
                        onChange={() => setPreparation("regular")}
                        className="accent-brand-600"
                      />
                      Regular
                    </span>
                  </label>
                )}
                <label
                  className={cn(
                    "flex cursor-pointer items-center justify-between rounded-xl border px-3 py-2.5 text-sm",
                    preparation === "jain"
                      ? "border-emerald-500 bg-emerald-50 dark:border-emerald-400 dark:bg-emerald-950"
                      : "border-line dark:border-brand-800"
                  )}
                >
                  <span className="flex items-center gap-2 font-medium">
                    <input
                      type="radio"
                      name="prep"
                      checked={preparation === "jain"}
                      onChange={() => setPreparation("jain")}
                      className="accent-emerald-600"
                    />
                    Jain preparation
                  </span>
                </label>
              </div>
              {preparation === "jain" && (
                <p className="mt-2 text-[11px] text-ink-muted">
                  No onion, garlic, or root vegetables (as per restaurant Jain recipe).
                </p>
              )}
            </section>
          )}

          {/* Spice */}
          {showSpice && (
            <section className="rounded-2xl border border-line p-3 dark:border-brand-800">
              <h3 className="text-sm font-semibold text-ink dark:text-brand-50">Spice level</h3>
              <div className="mt-2 flex flex-wrap gap-2">
                {spiceOpts.map((s) => (
                  <motion.button
                    key={s}
                    type="button"
                    onClick={() => setSpice(s)}
                    whileTap={{ scale: 0.92 }}
                    className={cn(
                      "rounded-full px-3 py-1.5 text-xs font-semibold transition-colors",
                      spice === s
                        ? "bg-brand-600 text-white"
                        : "bg-brand-50 text-ink-secondary dark:bg-brand-900 dark:text-brand-200"
                    )}
                  >
                    {SPICE_LABELS[s] || s}
                  </motion.button>
                ))}
              </div>
            </section>
          )}

          {/* Add-ons */}
          {showAddOns && (
            <section className="rounded-2xl border border-line p-3 dark:border-brand-800">
              <h3 className="text-sm font-semibold text-ink dark:text-brand-50">Add extras</h3>
              <p className="mb-2 text-xs text-ink-muted">Optional</p>
              <div className="space-y-2">
                {addOnList.map((a) => (
                  <label
                    key={a.id}
                    className={cn(
                      "flex cursor-pointer items-center justify-between rounded-xl border px-3 py-2.5 text-sm",
                      selectedAddOns.includes(a.id)
                        ? "border-brand-500 bg-brand-50 dark:border-brand-400 dark:bg-brand-900"
                        : "border-line dark:border-brand-800"
                    )}
                  >
                    <span className="flex items-center gap-2 font-medium">
                      <input
                        type="checkbox"
                        checked={selectedAddOns.includes(a.id)}
                        onChange={() => toggleAddOn(a.id)}
                        className="accent-brand-600"
                      />
                      {a.label}
                    </span>
                    <span className="tabular-nums text-ink-secondary">
                      {a.priceDelta > 0 ? `+${formatCurrency(a.priceDelta)}` : "Free"}
                    </span>
                  </label>
                ))}
              </div>
            </section>
          )}

          {/* Cooking request */}
          {showCooking && (
            <section className="rounded-2xl border border-line p-3 dark:border-brand-800">
              <h3 className="text-sm font-semibold text-ink dark:text-brand-50">
                Add a cooking request{" "}
                <span className="font-normal text-ink-muted">(optional)</span>
              </h3>
              <p className="mb-2 text-[11px] text-ink-muted">
                The restaurant will try its best to fulfil your request.
              </p>
              <textarea
                value={cookingRequest}
                onChange={(e) => setCookingRequest(e.target.value.slice(0, maxCR))}
                rows={3}
                placeholder="e.g. Don't make it too spicy"
                className="w-full resize-none rounded-xl border border-line bg-surface-muted px-3 py-2 text-sm outline-none focus:border-brand-500 dark:border-brand-700 dark:bg-brand-900"
              />
              <p className="mt-1 text-right text-[10px] text-ink-muted">
                {cookingRequest.length}/{maxCR}
              </p>
            </section>
          )}
        </div>

        {/* Footer */}
        <div className="shrink-0 border-t border-line bg-white px-4 py-3 dark:border-brand-800 dark:bg-brand-950">
          <div className="mx-auto flex max-w-lg items-center gap-3">
            <div className="flex items-center gap-1 rounded-xl border border-line bg-surface-muted px-1 dark:border-brand-700 dark:bg-brand-900">
              <motion.button
                type="button"
                whileTap={{ scale: 0.85 }}
                className="rounded-lg p-2"
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                aria-label="Decrease quantity"
              >
                <Minus className="h-4 w-4" />
              </motion.button>
              <span className="min-w-[1.5rem] text-center text-sm font-bold" aria-live="polite">
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.span
                    key={qty}
                    initial={{ opacity: 0, y: -6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 6 }}
                    transition={fadeFast}
                    className="inline-block"
                  >
                    {qty}
                  </motion.span>
                </AnimatePresence>
              </span>
              <motion.button
                type="button"
                whileTap={{ scale: 0.85 }}
                className="rounded-lg p-2"
                onClick={() => setQty((q) => Math.min(99, q + 1))}
                aria-label="Increase quantity"
              >
                <Plus className="h-4 w-4" />
              </motion.button>
            </div>
            <motion.button
              type="button"
              onClick={handleAdd}
              whileTap={{ scale: 0.97 }}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-brand-600 py-3 text-sm font-bold text-white shadow-md transition-colors hover:bg-brand-700"
            >
              Add to cart · {formatCurrency(unitPrice * qty)}
            </motion.button>
          </div>
        </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  );
}
