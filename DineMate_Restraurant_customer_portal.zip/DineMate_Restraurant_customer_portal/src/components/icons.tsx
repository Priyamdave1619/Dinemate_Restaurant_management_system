"use client";

/**
 * Professional icon system for DineMate customer portal.
 * Lucide stroke icons + FSSAI-style diet marks (India restaurant standard).
 */

import {
  UtensilsCrossed,
  Leaf,
  Drumstick,
  Flame,
  Star,
  LayoutGrid,
  type LucideProps,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";

const DEFAULT = { size: 16, strokeWidth: 2 } as const;

/** Placeholder when a menu item has no photo */
export function FoodPlaceholderIcon({ className, ...props }: LucideProps) {
  return (
    <UtensilsCrossed
      {...DEFAULT}
      {...props}
      className={cn("h-8 w-8 text-brand-400 dark:text-brand-500", className)}
      aria-hidden
    />
  );
}

/** FSSAI-style vegetarian mark */
export function VegMark({
  className,
  size = 14,
  title = "Vegetarian",
}: {
  className?: string;
  size?: number;
  title?: string;
}) {
  return (
    <span
      role="img"
      aria-label={title}
      title={title}
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-[2px] border-[1.5px] border-emerald-600 bg-white dark:bg-transparent",
        className
      )}
      style={{ width: size, height: size }}
    >
      <span
        className="rounded-full bg-emerald-600"
        style={{ width: size * 0.45, height: size * 0.45 }}
      />
    </span>
  );
}

/** FSSAI-style non-vegetarian mark */
export function NonVegMark({
  className,
  size = 14,
  title = "Non-vegetarian",
}: {
  className?: string;
  size?: number;
  title?: string;
}) {
  return (
    <span
      role="img"
      aria-label={title}
      title={title}
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-[2px] border-[1.5px] border-red-600 bg-white dark:bg-transparent",
        className
      )}
      style={{ width: size, height: size }}
    >
      <span
        className="rounded-full bg-red-600"
        style={{ width: size * 0.45, height: size * 0.45 }}
      />
    </span>
  );
}

/** Jain indicator (amber mark) */
export function JainMark({
  className,
  size = 14,
}: {
  className?: string;
  size?: number;
}) {
  return (
    <span
      role="img"
      aria-label="Jain"
      title="Jain"
      className={cn(
        "inline-flex shrink-0 items-center justify-center rounded-[2px] border-[1.5px] border-amber-600 bg-white dark:bg-transparent",
        className
      )}
      style={{ width: size, height: size }}
    >
      <span
        className="rounded-full bg-amber-600"
        style={{ width: size * 0.45, height: size * 0.45 }}
      />
    </span>
  );
}

export function SpicyIcon({ className, ...props }: LucideProps) {
  return (
    <Flame
      {...DEFAULT}
      {...props}
      className={cn("h-3.5 w-3.5 shrink-0 text-red-500", className)}
      aria-label="Spicy"
    />
  );
}

export function BestsellerIcon({ className, ...props }: LucideProps) {
  return (
    <Star
      {...DEFAULT}
      {...props}
      className={cn("h-3.5 w-3.5 shrink-0 text-amber-500", className)}
      aria-hidden
    />
  );
}

export function LeafIcon({ className, ...props }: LucideProps) {
  return (
    <Leaf
      {...DEFAULT}
      {...props}
      className={cn("h-3.5 w-3.5 shrink-0 text-emerald-600", className)}
      aria-label="Vegetarian"
    />
  );
}

export function NonVegIcon({ className, ...props }: LucideProps) {
  return (
    <Drumstick
      {...DEFAULT}
      {...props}
      className={cn("h-3.5 w-3.5 shrink-0 text-red-500", className)}
      aria-label="Non-vegetarian"
    />
  );
}

export function AllItemsIcon({ className, ...props }: LucideProps) {
  return (
    <LayoutGrid
      {...DEFAULT}
      {...props}
      className={cn("h-3.5 w-3.5 shrink-0", className)}
      aria-hidden
    />
  );
}

export type DietFilterId = "all" | "veg" | "non-veg" | "jain" | "bestseller";

/** Chip icon for diet filters — unified render for Lucide + mark components */
export function DietFilterIcon({
  id,
  active,
}: {
  id: DietFilterId;
  active?: boolean;
}) {
  const tone = active ? "text-white" : undefined;
  switch (id) {
    case "all":
      return <AllItemsIcon className={cn("h-3.5 w-3.5", tone)} />;
    case "veg":
      return active ? <LeafIcon className="h-3.5 w-3.5 text-white" /> : <VegMark size={12} />;
    case "non-veg":
      return active ? <NonVegIcon className="h-3.5 w-3.5 text-white" /> : <NonVegMark size={12} />;
    case "jain":
      return active ? (
        <span
          className="inline-flex h-3 w-3 items-center justify-center rounded-[2px] border border-white"
          aria-hidden
        >
          <span className="h-1.5 w-1.5 rounded-full bg-white" />
        </span>
      ) : (
        <JainMark size={12} />
      );
    case "bestseller":
      return <BestsellerIcon className={cn("h-3.5 w-3.5", active ? "text-white" : "text-amber-500")} />;
    default:
      return null;
  }
}

export const DIET_FILTERS: Array<{ id: DietFilterId; label: string }> = [
  { id: "all", label: "All" },
  { id: "veg", label: "Veg" },
  { id: "non-veg", label: "Non-veg" },
  { id: "jain", label: "Jain" },
  { id: "bestseller", label: "Bestseller" },
];
