"use client";

import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import { useEffect, useState } from "react";

interface BrandLoaderProps {
  show?: boolean;
  message?: string;
}

export function BrandLoader({ show = true, message = "Loading…" }: BrandLoaderProps) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!mounted) return null;

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="brand-loader"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.35 }}
          role="status"
          aria-live="polite"
          aria-label={message}
        >
          <div className="flex flex-col items-center gap-5">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 260, damping: 24 }}
              className="relative"
            >
              <motion.div
                className="absolute -inset-4 rounded-3xl bg-brand-500/20 blur-xl"
                animate={{ opacity: [0.4, 0.7, 0.4], scale: [1, 1.05, 1] }}
                transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
              />
              <div className="relative flex h-20 w-20 items-center justify-center overflow-hidden rounded-2xl bg-white shadow-glow dark:bg-brand-900">
                <Image
                  src="/logos/logo-light.png"
                  alt="Logo"
                  width={64}
                  height={64}
                  className="object-contain dark:hidden"
                  priority
                />
                <Image
                  src="/logos/logo-dark.png"
                  alt="Logo"
                  width={64}
                  height={64}
                  className="hidden object-contain dark:block"
                  priority
                />
              </div>
            </motion.div>
            <motion.div
              className="h-1 w-24 overflow-hidden rounded-full bg-brand-100 dark:bg-brand-950"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <motion.div
                className="h-full w-1/2 rounded-full bg-brand-500"
                animate={{ x: ["-100%", "200%"] }}
                transition={{ duration: 1.1, repeat: Infinity, ease: "easeInOut" }}
              />
            </motion.div>
            <p className="text-sm font-medium text-ink-secondary dark:text-brand-300">{message}</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
