"use client";

import {
  useCartStore,
  selectCartCount,
  selectCartTotal,
  selectActiveOrderId,
  selectOrderingLocked,
} from "@/lib/stores/cart-store";
import { formatCurrency } from "@/lib/utils/format";
import { placeOrder, addOrderItems } from "@/lib/api/customer";
import { getErrorMessage } from "@/lib/api/client";
import { sanitizeText } from "@/lib/validation/sanitize";
import { Minus, Plus, ShoppingBag, X, Loader2, Clock } from "lucide-react";
import { useState, useEffect, useRef, useCallback } from "react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";

const CONFIRM_SECONDS = 15;

export function CartSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const lines = useCartStore((s) => s.lines);
  const setQty = useCartStore((s) => s.setQty);
  const remove = useCartStore((s) => s.remove);
  const clear = useCartStore((s) => s.clear);
  const updateLineCustomization = useCartStore((s) => s.updateLineCustomization);
  const setActiveOrder = useCartStore((s) => s.setActiveOrder);
  const restaurantId = useCartStore((s) => s.restaurantId);
  const tableNumber = useCartStore((s) => s.tableNumber);
  const itemCount = useCartStore(selectCartCount);
  const cartTotal = useCartStore(selectCartTotal);
  const activeOrderId = useCartStore(selectActiveOrderId);
  const orderingLocked = useCartStore(selectOrderingLocked);
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [countdown, setCountdown] = useState(CONFIRM_SECONDS);
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editPrep, setEditPrep] = useState<"regular" | "jain">("regular");
  const [editRequest, setEditRequest] = useState("");
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const placeOrderNowRef = useRef<() => Promise<void>>(() => Promise.resolve());
  const router = useRouter();

  const clearConfirmTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  const cancelConfirm = useCallback(() => {
    clearConfirmTimer();
    setConfirmOpen(false);
    setCountdown(CONFIRM_SECONDS);
  }, [clearConfirmTimer]);

  // Cleanup timer on unmount or when cart sheet closes
  useEffect(() => {
    if (!open) {
      cancelConfirm();
    }
    return () => clearConfirmTimer();
  }, [open, cancelConfirm, clearConfirmTimer]);

  async function placeOrderNow() {
    if (orderingLocked) {
      toast.error("Bill already requested — new items cannot be ordered");
      return;
    }
    if (!restaurantId || !tableNumber) {
      toast.error("Missing table context — scan the QR again");
      return;
    }
    if (lines.length === 0) return;
    setLoading(true);
    try {
      const payload = lines.map((l) => ({
        itemId: l.itemId,
        name: l.name,
        quantity: l.quantity,
        price: l.price,
        variant: l.variantLabel || l.variantId,
        note: l.note ? sanitizeText(l.note, 200) : undefined,
        preparation: l.preparation,
        spiceLevelSelected: l.spiceLevelSelected,
        addOnIds: l.addOns?.map((a) => a.id),
        cookingRequest: l.cookingRequest
          ? sanitizeText(l.cookingRequest, 250)
          : undefined,
      }));

      let orderId: string;

      if (activeOrderId) {
        // Append to existing open order (until bill is generated)
        const order = await addOrderItems(activeOrderId, payload);
        orderId = order.id;
        toast.success("Items added to your order");
      } else {
        // First order for this table session
        const order = await placeOrder({
          restaurantId,
          tableNumber,
          customerName: name ? sanitizeText(name, 80) : undefined,
          items: payload,
        });
        orderId = order.id;
        setActiveOrder(order.id);
        toast.success("Order placed!");
      }

      clear();
      onClose();
      router.push(`/${restaurantId}/table/${tableNumber}/order/${orderId}`);
    } catch (e) {
      toast.error(getErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  // Keep ref in sync so the interval always calls the latest placeOrderNow
  placeOrderNowRef.current = placeOrderNow;

  function startConfirm() {
    if (orderingLocked) {
      toast.error("Bill already requested — new items cannot be ordered");
      return;
    }
    if (!restaurantId || !tableNumber) {
      toast.error("Missing table context — scan the QR again");
      return;
    }
    if (lines.length === 0) return;

    setConfirmOpen(true);
    setCountdown(CONFIRM_SECONDS);

    clearConfirmTimer();
    timerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearConfirmTimer();
          setConfirmOpen(false);
          // Auto-place after countdown finishes
          void placeOrderNowRef.current();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-40 bg-brand-950/50 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => {
              if (!confirmOpen) onClose();
            }}
            aria-hidden
          />
          <motion.div
            className="fixed inset-x-0 bottom-0 z-50 mx-auto max-h-[85vh] max-w-lg overflow-hidden rounded-t-3xl bg-white shadow-2xl dark:bg-brand-900"
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 320 }}
            role="dialog"
            aria-modal="true"
            aria-labelledby="cart-title"
          >
            <div className="flex items-center justify-between border-b border-line px-5 py-4 dark:border-brand-800">
              <div className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5 text-brand-600" aria-hidden />
                <h2 id="cart-title" className="font-semibold text-ink dark:text-brand-50">
                  Your cart ({itemCount})
                </h2>
              </div>
              <button
                type="button"
                onClick={() => {
                  if (!confirmOpen) onClose();
                }}
                disabled={confirmOpen}
                className="rounded-full p-1.5 text-ink-muted transition hover:bg-brand-50 dark:hover:bg-brand-800 disabled:opacity-40"
                aria-label="Close cart"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {activeOrderId && !orderingLocked && (
              <div className="border-b border-amber-200/80 bg-amber-50 px-5 py-2 text-xs text-amber-900 dark:border-amber-900/40 dark:bg-amber-950/30 dark:text-amber-200">
                Adding to open order <span className="font-semibold">{activeOrderId}</span>. You can
                keep adding until the bill is requested.
              </div>
            )}

            {orderingLocked && (
              <div className="border-b border-red-200/80 bg-red-50 px-5 py-2 text-xs text-red-800 dark:border-red-900/40 dark:bg-red-950/30 dark:text-red-200">
                Bill has been requested — ordering is closed for this table.
              </div>
            )}

            <div className="max-h-[45vh] space-y-3 overflow-y-auto px-5 py-3">
              {lines.map((l) => (
                <div key={l.key} className="space-y-2 border-b border-line/60 pb-3 last:border-0 dark:border-brand-800/60">
                  <div className="flex items-start gap-3">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-ink dark:text-brand-50">{l.name}</p>
                      <div className="mt-0.5 space-y-0.5 text-[11px] leading-snug text-ink-muted">
                        {l.variantLabel && <p>Size: {l.variantLabel}</p>}
                        {l.preparation && (
                          <p>
                            Preference:{" "}
                            <span className="font-medium text-ink-secondary dark:text-brand-200">
                              {l.preparation === "jain" ? "Jain" : "Regular"}
                            </span>
                          </p>
                        )}
                        {l.spiceLevelSelected && <p>Spice: {l.spiceLevelSelected}</p>}
                        {l.addOns && l.addOns.length > 0 && (
                          <p>Add-ons: {l.addOns.map((a) => a.label).join(", ")}</p>
                        )}
                        {l.cookingRequest ? (
                          <p className="italic">Request: “{l.cookingRequest}”</p>
                        ) : null}
                      </div>
                      <p className="mt-1 text-sm font-semibold text-brand-600">
                        {formatCurrency(l.price * l.quantity)}
                        {l.quantity > 1 && (
                          <span className="ml-1 text-[10px] font-normal text-ink-muted">
                            ({formatCurrency(l.price)} each)
                          </span>
                        )}
                      </p>
                      {!orderingLocked && !confirmOpen && (
                        <button
                          type="button"
                          className="mt-1 text-[11px] font-semibold text-brand-600 underline-offset-2 hover:underline"
                          onClick={() => {
                            setEditingKey(editingKey === l.key ? null : l.key);
                            setEditPrep(l.preparation === "jain" ? "jain" : "regular");
                            setEditRequest(l.cookingRequest || "");
                          }}
                        >
                          {editingKey === l.key ? "Close edit" : "Edit customization"}
                        </button>
                      )}
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-2">
                      <div className="flex items-center gap-1 rounded-full border border-line bg-surface-muted px-1 dark:border-brand-700 dark:bg-brand-800">
                        <button
                          type="button"
                          className="rounded-full p-1.5 transition hover:bg-white dark:hover:bg-brand-700"
                          onClick={() => setQty(l.key, l.quantity - 1)}
                          disabled={orderingLocked || confirmOpen}
                          aria-label={`Decrease quantity of ${l.name}`}
                        >
                          <Minus className="h-3.5 w-3.5" />
                        </button>
                        <span className="w-5 text-center text-sm font-semibold" aria-live="polite">
                          {l.quantity}
                        </span>
                        <button
                          type="button"
                          className="rounded-full p-1.5 transition hover:bg-white dark:hover:bg-brand-700"
                          onClick={() => setQty(l.key, l.quantity + 1)}
                          disabled={orderingLocked || confirmOpen}
                          aria-label={`Increase quantity of ${l.name}`}
                        >
                          <Plus className="h-3.5 w-3.5" />
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => remove(l.key)}
                        disabled={orderingLocked || confirmOpen}
                        className="text-ink-muted transition hover:text-danger disabled:opacity-40"
                        aria-label={`Remove ${l.name}`}
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  {editingKey === l.key && !orderingLocked && (
                    <div className="rounded-xl border border-line bg-surface-muted/80 p-3 dark:border-brand-700 dark:bg-brand-800/50">
                      <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-ink-muted">
                        Food preference
                      </p>
                      <div className="mb-3 flex gap-2">
                        {(["regular", "jain"] as const).map((p) => (
                          <button
                            key={p}
                            type="button"
                            onClick={() => setEditPrep(p)}
                            className={
                              editPrep === p
                                ? "rounded-full bg-brand-500 px-3 py-1 text-[11px] font-semibold text-white"
                                : "rounded-full border border-line bg-white px-3 py-1 text-[11px] font-semibold text-ink-secondary dark:border-brand-600 dark:bg-brand-900 dark:text-brand-200"
                            }
                          >
                            {p === "jain" ? "Jain" : "Regular"}
                          </button>
                        ))}
                      </div>
                      <label className="mb-1 block text-[11px] font-semibold uppercase tracking-wide text-ink-muted">
                        Special cooking request
                      </label>
                      <input
                        type="text"
                        value={editRequest}
                        maxLength={250}
                        onChange={(e) => setEditRequest(e.target.value)}
                        placeholder="e.g. Less spicy, no garlic"
                        className="input-premium mb-2 py-2 text-sm"
                      />
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          className="rounded-full px-3 py-1.5 text-[11px] font-semibold text-ink-muted"
                          onClick={() => setEditingKey(null)}
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          className="rounded-full bg-brand-500 px-3 py-1.5 text-[11px] font-semibold text-white"
                          onClick={() => {
                            updateLineCustomization(l.key, {
                              preparation: editPrep,
                              cookingRequest: editRequest,
                            });
                            setEditingKey(null);
                            toast.success("Customization updated");
                          }}
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
              {lines.length === 0 && (
                <p className="py-8 text-center text-sm text-ink-muted">Cart is empty</p>
              )}
            </div>

            {lines.length > 0 && !orderingLocked && (
              <div className="space-y-3 border-t border-line px-5 py-4 dark:border-brand-800">
                {!activeOrderId && (
                  <>
                    <label className="sr-only" htmlFor="customer-name">
                      Your name (optional)
                    </label>
                    <input
                      id="customer-name"
                      type="text"
                      placeholder="Your name (optional)"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      maxLength={80}
                      className="input-premium"
                    />
                  </>
                )}
                <div className="flex items-center justify-between text-sm">
                  <span className="text-ink-secondary dark:text-brand-300">Subtotal</span>
                  <span className="text-lg font-bold text-ink dark:text-brand-50">
                    {formatCurrency(cartTotal)}
                  </span>
                </div>
                <button
                  type="button"
                  disabled={loading || confirmOpen}
                  onClick={startConfirm}
                  className="btn-primary w-full py-3.5"
                >
                  {loading && <Loader2 className="h-4 w-4 animate-spin" aria-hidden />}
                  {activeOrderId
                    ? `Add to order · ${formatCurrency(cartTotal)}`
                    : `Place order · ${formatCurrency(cartTotal)}`}
                </button>
              </div>
            )}
          </motion.div>

          {/* 15-second confirmation popup — responsive for all devices */}
          <AnimatePresence>
            {confirmOpen && (
              <motion.div
                className="fixed inset-0 z-[80] flex items-end justify-center sm:items-center p-0 sm:p-4"
                style={{
                  paddingBottom: "env(safe-area-inset-bottom, 0px)",
                  paddingTop: "env(safe-area-inset-top, 0px)",
                }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                role="dialog"
                aria-modal="true"
                aria-labelledby="confirm-order-title"
              >
                {/* Backdrop */}
                <motion.div
                  className="absolute inset-0 bg-brand-950/60 backdrop-blur-sm"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  aria-hidden
                />

                {/* Panel: bottom sheet on mobile, centered card on larger screens */}
                <motion.div
                  className="relative z-10 w-full max-w-[400px] rounded-t-3xl sm:rounded-3xl bg-white shadow-2xl dark:bg-brand-900 max-h-[min(90dvh,560px)] overflow-y-auto"
                  initial={{ y: "100%", opacity: 0.8 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: "100%", opacity: 0 }}
                  transition={{ type: "spring", damping: 28, stiffness: 320 }}
                >
                  <div className="flex flex-col items-center px-5 pt-5 pb-6 sm:px-6 sm:pt-6 sm:pb-7 text-center">
                    {/* Drag handle (mobile) */}
                    <div
                      className="mb-4 h-1 w-10 shrink-0 rounded-full bg-brand-200 dark:bg-brand-700 sm:hidden"
                      aria-hidden
                    />

                    <div className="mb-3 flex h-14 w-14 sm:h-16 sm:w-16 items-center justify-center rounded-full bg-brand-50 dark:bg-brand-800">
                      <Clock className="h-7 w-7 sm:h-8 sm:w-8 text-brand-600 dark:text-brand-300" aria-hidden />
                    </div>

                    <h3
                      id="confirm-order-title"
                      className="text-base sm:text-lg font-semibold text-ink dark:text-brand-50"
                    >
                      Confirming your order
                    </h3>
                    <p className="mt-1 text-sm text-ink-muted dark:text-brand-300">
                      Your order will be placed automatically in
                    </p>

                    {/* Countdown ring */}
                    <div className="relative my-4 sm:my-5 flex h-20 w-20 sm:h-24 sm:w-24 items-center justify-center">
                      <svg className="absolute inset-0 h-full w-full -rotate-90" viewBox="0 0 100 100">
                        <circle
                          cx="50"
                          cy="50"
                          r="42"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="6"
                          className="text-brand-100 dark:text-brand-800"
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="42"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="6"
                          strokeLinecap="round"
                          strokeDasharray={`${2 * Math.PI * 42}`}
                          strokeDashoffset={`${2 * Math.PI * 42 * (1 - countdown / CONFIRM_SECONDS)}`}
                          className="text-brand-500 transition-[stroke-dashoffset] duration-1000 linear"
                        />
                      </svg>
                      <span className="text-2xl sm:text-3xl font-bold tabular-nums text-brand-600 dark:text-brand-300">
                        {countdown}
                      </span>
                    </div>

                    <p className="mb-4 sm:mb-5 text-xs text-ink-muted dark:text-brand-400">
                      Tap Cancel if you change your mind
                    </p>

                    <button
                      type="button"
                      onClick={cancelConfirm}
                      disabled={loading}
                      className="w-full min-h-[48px] rounded-2xl border-2 border-danger/30 bg-danger/5 px-5 py-3.5 text-sm font-semibold text-danger transition hover:bg-danger/10 active:scale-[0.98] disabled:opacity-60"
                    >
                      Cancel order
                    </button>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </>
      )}
    </AnimatePresence>
  );
}
