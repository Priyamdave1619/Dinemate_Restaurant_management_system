"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Camera, X, SwitchCamera, AlertCircle } from "lucide-react";
import { sanitizeId, isValidRestaurantId, isValidTableNumber } from "@/lib/validation/sanitize";
import { decryptQrToken, resolveQrTokenViaApi } from "@/lib/crypto/qr-crypto";

type ParsedTable = { restaurantId: string; tableNumber: string };

/**
 * Extract restaurantId + tableNumber from a scanned QR value (URL or path).
 * Supports encrypted /q/{token}, canonical, legacy, query, and plain forms.
 */
export function parseTableQr(raw: string): ParsedTable | null {
  const value = (raw || "").trim();
  if (!value) return null;

  try {
    const url = value.startsWith("http")
      ? new URL(value)
      : new URL(value, "https://example.invalid");
    const parts = url.pathname.split("/").filter(Boolean);

    // Encrypted token path: /q/{token} — handled async via extractQrToken
    const qIdx = parts.findIndex((p) => p.toLowerCase() === "q");
    if (qIdx >= 0 && parts[qIdx + 1]) {
      return null;
    }

    // Canonical: /{restaurantId}/table/{tableNumber}
    const tableIdx = parts.findIndex((p) => p.toLowerCase() === "table");
    if (tableIdx >= 1 && parts[tableIdx + 1]) {
      const rid = sanitizeId(parts[tableIdx - 1]);
      const table = String(Number(parts[tableIdx + 1]));
      if (isValidRestaurantId(rid) && isValidTableNumber(table)) {
        return { restaurantId: rid, tableNumber: table };
      }
    }

    // Legacy: /table/{n}?restaurantId=...
    if (tableIdx === 0 && parts[1]) {
      const table = String(Number(parts[1]));
      const rid = sanitizeId(
        url.searchParams.get("restaurantId") || url.searchParams.get("r") || ""
      );
      if (rid && isValidRestaurantId(rid) && isValidTableNumber(table)) {
        return { restaurantId: rid, tableNumber: table };
      }
    }

    // Query params
    const rid =
      sanitizeId(url.searchParams.get("restaurantId") || url.searchParams.get("r") || "") ||
      "";
    const tableRaw =
      url.searchParams.get("table") ||
      url.searchParams.get("tableNumber") ||
      url.searchParams.get("t") ||
      "";
    if (rid && tableRaw && isValidRestaurantId(rid) && isValidTableNumber(tableRaw)) {
      return { restaurantId: rid, tableNumber: String(Number(tableRaw)) };
    }
  } catch {
    /* fall through */
  }

  const plain = /^([A-Za-z0-9][A-Za-z0-9\-_.]{1,62})[\/\-](\d{1,4})$/.exec(value);
  if (plain) {
    const rid = sanitizeId(plain[1]);
    const table = String(Number(plain[2]));
    if (isValidRestaurantId(rid) && isValidTableNumber(table)) {
      return { restaurantId: rid, tableNumber: table };
    }
  }

  return null;
}

/** Extract encrypted token from a scanned value, if present. */
export function extractQrToken(raw: string): string | null {
  const value = (raw || "").trim();
  if (!value) return null;
  try {
    const url = value.startsWith("http")
      ? new URL(value)
      : new URL(value, "https://example.invalid");
    const parts = url.pathname.split("/").filter(Boolean);
    const qIdx = parts.findIndex((p) => p.toLowerCase() === "q");
    if (qIdx >= 0 && parts[qIdx + 1]) {
      return parts[qIdx + 1];
    }
    const t = url.searchParams.get("token") || url.searchParams.get("d");
    if (t) return t;
  } catch {
    /* ignore */
  }
  if (/^[A-Za-z0-9_-]{40,}$/.test(value)) return value;
  return null;
}

type Props = {
  open: boolean;
  onClose: () => void;
  onScan: (result: ParsedTable) => void;
};

type Facing = "environment" | "user";

/** Pick best camera deviceId for requested facing direction. */
async function resolveCameraDeviceId(facing: Facing): Promise<string | undefined> {
  try {
    // Need permission first so labels are populated
    const temp = await navigator.mediaDevices.getUserMedia({ audio: false, video: true });
    temp.getTracks().forEach((t) => t.stop());

    const devices = await navigator.mediaDevices.enumerateDevices();
    const videos = devices.filter((d) => d.kind === "videoinput" && d.deviceId);

    if (videos.length === 0) return undefined;

    const wantBack = facing === "environment";
    const backHints = /back|rear|environment|world|facing back|camera2 0|camera0/i;
    const frontHints = /front|user|face|selfie|facing front|camera2 1|camera1/i;

    const scored = videos.map((d) => {
      const label = d.label || "";
      let score = 0;
      if (wantBack) {
        if (backHints.test(label)) score += 10;
        if (frontHints.test(label)) score -= 5;
      } else {
        if (frontHints.test(label)) score += 10;
        if (backHints.test(label)) score -= 5;
      }
      return { id: d.deviceId, label, score };
    });

    scored.sort((a, b) => b.score - a.score);
    if (scored[0].score > 0) return scored[0].id;

    // No label match: many phones list back camera first when facing environment
    if (wantBack) return videos[videos.length - 1]?.deviceId || videos[0]?.deviceId;
    return videos[0]?.deviceId;
  } catch {
    return undefined;
  }
}

/** Open camera with progressive constraint fallbacks (works across iOS/Android/desktop). */
async function openCameraStream(facing: Facing): Promise<MediaStream> {
  const deviceId = await resolveCameraDeviceId(facing);

  const attempts: MediaStreamConstraints[] = [];

  if (deviceId) {
    attempts.push({
      audio: false,
      video: {
        deviceId: { exact: deviceId },
        width: { ideal: 1280 },
        height: { ideal: 720 },
      },
    });
    attempts.push({
      audio: false,
      video: { deviceId: { ideal: deviceId } },
    });
  }

  // facingMode exact then ideal
  attempts.push({
    audio: false,
    video: {
      facingMode: { exact: facing },
      width: { ideal: 1280 },
      height: { ideal: 720 },
    },
  });
  attempts.push({
    audio: false,
    video: {
      facingMode: { ideal: facing },
      width: { ideal: 1280 },
      height: { ideal: 720 },
    },
  });
  attempts.push({
    audio: false,
    video: { facingMode: facing },
  });
  // Last resort: any camera
  attempts.push({ audio: false, video: true });

  let lastError: unknown;
  for (const constraints of attempts) {
    try {
      return await navigator.mediaDevices.getUserMedia(constraints);
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Could not open camera");
}

/** Load jsQR from vendor script if not already present. */
function loadJsQR(): Promise<
  (data: Uint8ClampedArray, w: number, h: number) => { data: string } | null
> {
  type JsQRFn = (data: Uint8ClampedArray, w: number, h: number) => { data: string } | null;
  const w = window as unknown as { jsQR?: JsQRFn };

  if (typeof w.jsQR === "function") {
    return Promise.resolve(w.jsQR);
  }

  return new Promise((resolve, reject) => {
    const existing = document.querySelector('script[data-jsqr="1"]');
    if (existing) {
      existing.addEventListener("load", () => {
        if (w.jsQR) resolve(w.jsQR);
        else reject(new Error("jsQR failed to load"));
      });
      return;
    }
    const script = document.createElement("script");
    script.src = "/vendor/jsQR.js";
    script.async = true;
    script.dataset.jsqr = "1";
    script.onload = () => {
      if (w.jsQR) resolve(w.jsQR);
      else reject(new Error("jsQR failed to load"));
    };
    script.onerror = () => reject(new Error("jsQR script error"));
    document.head.appendChild(script);
  });
}

export function QrScanner({ open, onClose, onScan }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number>(0);
  const detectorRef = useRef<BarcodeDetector | null>(null);
  const jsQRRef = useRef<
    ((data: Uint8ClampedArray, w: number, h: number) => { data: string } | null) | null
  >(null);
  const [error, setError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<Facing>("environment");
  const [ready, setReady] = useState(false);
  const scannedRef = useRef(false);
  const onScanRef = useRef(onScan);
  onScanRef.current = onScan;

  const stopCamera = useCallback(() => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = 0;
    }
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setReady(false);
  }, []);

  const handleRawValue = useCallback(async (raw: string) => {
    if (scannedRef.current) return;
    const parsed = parseTableQr(raw);
    if (parsed) {
      scannedRef.current = true;
      onScanRef.current(parsed);
      return;
    }
    const token = extractQrToken(raw);
    if (!token) return;
    scannedRef.current = true;
    try {
      const resolved =
        (await decryptQrToken(token)) || (await resolveQrTokenViaApi(token));
      if (
        resolved &&
        isValidRestaurantId(resolved.restaurantId) &&
        isValidTableNumber(resolved.tableNumber)
      ) {
        onScanRef.current({
          restaurantId: sanitizeId(resolved.restaurantId),
          tableNumber: String(Number(resolved.tableNumber)),
        });
        return;
      }
    } catch {
      /* ignore */
    }
    scannedRef.current = false;
  }, []);

  const startCamera = useCallback(async () => {
    stopCamera();
    setError(null);
    scannedRef.current = false;
    detectorRef.current = null;
    jsQRRef.current = null;

    if (typeof window === "undefined" || !navigator.mediaDevices?.getUserMedia) {
      setError("Camera is not supported on this device or browser. Use HTTPS and a modern browser.");
      return;
    }

    // Secure context required (HTTPS or localhost)
    if (!window.isSecureContext) {
      setError("Camera requires a secure connection (HTTPS). Open this site over HTTPS.");
      return;
    }

    // Try native BarcodeDetector first
    if ("BarcodeDetector" in window) {
      try {
        const formats =
          typeof (window as unknown as { BarcodeDetector: { getSupportedFormats?: () => Promise<string[]> } })
            .BarcodeDetector.getSupportedFormats === "function"
            ? await (
                window as unknown as {
                  BarcodeDetector: { getSupportedFormats: () => Promise<string[]> };
                }
              ).BarcodeDetector.getSupportedFormats()
            : ["qr_code"];
        if (formats.includes("qr_code") || formats.length === 0) {
          detectorRef.current = new BarcodeDetector({ formats: ["qr_code"] });
        }
      } catch {
        detectorRef.current = null;
      }
    }

    // Always try to load jsQR as fallback (or primary)
    try {
      jsQRRef.current = await loadJsQR();
    } catch {
      jsQRRef.current = null;
    }

    if (!detectorRef.current && !jsQRRef.current) {
      setError(
        "QR scanning is not available in this browser. Please use Chrome, Edge, Safari, or Samsung Internet, or enter table details manually."
      );
      return;
    }

    try {
      const stream = await openCameraStream(facingMode);
      streamRef.current = stream;
      const video = videoRef.current;
      if (!video) return;

      video.setAttribute("playsinline", "true");
      video.setAttribute("webkit-playsinline", "true");
      video.muted = true;
      video.playsInline = true;
      video.srcObject = stream;

      // Wait for video to have data
      await new Promise<void>((resolve, reject) => {
        const onReady = () => {
          video.removeEventListener("loadeddata", onReady);
          resolve();
        };
        video.addEventListener("loadeddata", onReady);
        video.play().catch(reject);
        // Safety timeout
        setTimeout(() => resolve(), 2000);
      });

      setReady(true);

      if (!canvasRef.current) {
        canvasRef.current = document.createElement("canvas");
      }

      const detect = async () => {
        if (!videoRef.current || scannedRef.current) return;
        const v = videoRef.current;
        if (v.readyState < 2) {
          rafRef.current = requestAnimationFrame(detect);
          return;
        }

        try {
          // Native detector
          if (detectorRef.current) {
            const codes = await detectorRef.current.detect(v);
            if (codes?.length) {
              const raw = codes[0].rawValue || "";
              if (raw) {
                await handleRawValue(raw);
                if (scannedRef.current) return;
              }
            }
          }

          // jsQR canvas fallback
          if (jsQRRef.current && canvasRef.current) {
            const canvas = canvasRef.current;
            const w = v.videoWidth;
            const h = v.videoHeight;
            if (w > 0 && h > 0) {
              // Downscale large frames for performance
              const maxSide = 640;
              const scale = Math.min(1, maxSide / Math.max(w, h));
              const cw = Math.floor(w * scale);
              const ch = Math.floor(h * scale);
              canvas.width = cw;
              canvas.height = ch;
              const ctx = canvas.getContext("2d", { willReadFrequently: true });
              if (ctx) {
                ctx.drawImage(v, 0, 0, cw, ch);
                const imageData = ctx.getImageData(0, 0, cw, ch);
                const code = jsQRRef.current(imageData.data, cw, ch);
                if (code?.data) {
                  await handleRawValue(code.data);
                  if (scannedRef.current) return;
                }
              }
            }
          }
        } catch {
          /* frame skip */
        }
        rafRef.current = requestAnimationFrame(detect);
      };
      rafRef.current = requestAnimationFrame(detect);
    } catch (e) {
      const msg =
        e instanceof DOMException && e.name === "NotAllowedError"
          ? "Camera permission denied. Allow camera access in browser settings and try again."
          : e instanceof DOMException && e.name === "NotFoundError"
            ? "No camera found on this device."
            : e instanceof DOMException && e.name === "NotReadableError"
              ? "Camera is in use by another app. Close it and retry."
              : e instanceof DOMException && e.name === "OverconstrainedError"
                ? "Could not switch to the requested camera. Try Flip or Retry."
                : "Could not open the camera. Try Flip, Retry, or enter details manually.";
      setError(msg);
    }
  }, [facingMode, stopCamera, handleRawValue]);

  useEffect(() => {
    if (open) {
      void startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [open, facingMode, startCamera, stopCamera]);

  function flipCamera() {
    setFacingMode((m) => (m === "environment" ? "user" : "environment"));
  }

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col bg-black/95"
      role="dialog"
      aria-modal="true"
      aria-label="Scan table QR code"
    >
      <div className="flex items-center justify-between px-4 py-3 text-white">
        <p className="text-sm font-semibold">Scan table QR</p>
        <button
          type="button"
          onClick={onClose}
          className="rounded-full p-2 hover:bg-white/10"
          aria-label="Close scanner"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="relative mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center px-4 pb-8">
        <div className="relative aspect-square w-full max-w-sm overflow-hidden rounded-2xl bg-black ring-2 ring-white/20">
          <video
            ref={videoRef}
            playsInline
            muted
            autoPlay
            className="h-full w-full object-cover"
            // Mirror only front camera for natural selfie view
            style={facingMode === "user" ? { transform: "scaleX(-1)" } : undefined}
          />
          <div className="pointer-events-none absolute inset-0">
            <div className="absolute inset-[12%] rounded-xl border-2 border-white/80 shadow-[0_0_0_9999px_rgba(0,0,0,0.45)]" />
            <div className="absolute left-[12%] right-[12%] top-1/2 h-0.5 -translate-y-1/2 bg-brand-400/80 animate-pulse" />
          </div>
          {!ready && !error && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/60 text-sm text-white">
              Starting camera…
            </div>
          )}
        </div>

        {error ? (
          <div className="mt-4 flex max-w-sm items-start gap-2 rounded-xl bg-red-950/80 px-4 py-3 text-left text-sm text-red-100">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        ) : (
          <p className="mt-4 text-center text-sm text-white/70">
            Point the back camera at the QR code on your table
            {facingMode === "user" ? " (front camera active — tap Flip)" : ""}
          </p>
        )}

        <div className="mt-6 flex gap-3">
          <button
            type="button"
            onClick={flipCamera}
            className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-2.5 text-sm font-medium text-white backdrop-blur hover:bg-white/20"
          >
            <SwitchCamera className="h-4 w-4" />
            Flip
          </button>
          <button
            type="button"
            onClick={() => void startCamera()}
            className="inline-flex items-center gap-2 rounded-xl bg-brand-500 px-4 py-2.5 text-sm font-semibold text-white hover:bg-brand-600"
          >
            <Camera className="h-4 w-4" />
            Retry
          </button>
        </div>
      </div>
    </div>
  );
}
