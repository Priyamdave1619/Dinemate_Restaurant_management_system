"use client";

import { Component, type ErrorInfo, type ReactNode } from "react";

type Props = {
  children: ReactNode;
  fallbackTitle?: string;
};

type State = {
  hasError: boolean;
};

/**
 * Lightweight error boundary — catches render errors so a single broken
 * subtree cannot blank the entire customer experience.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Keep console for ops; never surface internals to the diner
    if (process.env.NODE_ENV !== "production") {
      console.error("[ErrorBoundary]", error, info.componentStack);
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          role="alert"
          className="mx-auto flex min-h-[40vh] max-w-md flex-col items-center justify-center gap-3 px-6 py-12 text-center"
        >
          <p className="text-base font-semibold text-ink dark:text-brand-50">
            {this.props.fallbackTitle || "Something went wrong"}
          </p>
          <p className="text-sm text-ink-muted dark:text-brand-300">
            Please refresh the page or scan the table QR again.
          </p>
          <button
            type="button"
            onClick={() => {
              this.setState({ hasError: false });
              if (typeof window !== "undefined") window.location.reload();
            }}
            className="btn-primary mt-2 px-5 py-2.5 text-sm"
          >
            Refresh
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
