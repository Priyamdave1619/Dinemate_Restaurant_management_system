"use client";

import { memo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Minus, SlidersHorizontal } from "lucide-react";
import type { MenuItem } from "@/types";
import { formatCurrency } from "@/lib/utils/format";
import { useCartStore, selectOrderingLocked } from "@/lib/stores/cart-store";
import { toast } from "sonner";
import { CustomizeSheet } from "@/components/customize-sheet";
import { FoodPlaceholderIcon, VegMark, NonVegMark, SpicyIcon } from "@/components/icons";

type Props = {
  item: MenuItem;
};

/** Default options for one-tap Add (no sheet). */
function defaultAddOpts(item: MenuItem) {
  const firstVariant = item.variants?.[0];
  const isVeg =
    item.isVeg === true ||
    ["veg", "vegetarian", "vegan"].includes(String(item.foodType).toLowerCase());
  const prep: "regular" | "jain" | undefined = item.jainOnly
    ? "jain"
    : item.jainAvailable === true || (item.jainAvailable !== false && isVeg)
      ? "regular"
      : undefined;

  return {
    variantId: firstVariant?.id,
    variantLabel: firstVariant?.label,
    priceDelta: firstVariant?.priceDelta || 0,
    preparation: prep,
    quantity: 1 as const,
  };
}

function MenuCardInner({ item }: Props) {
  const lineQty = useCartStore((s) =>
    s.lines.reduce((n, l) => (l.itemId === item.id ? n + l.quantity : n), 0)
  );
  const orderingLocked = useCartStore(selectOrderingLocked);
  const addItem = useCartStore((s) => s.addItem);
  const adjustItemQty = useCartStore((s) => s.adjustItemQty);
  const [customizeOpen, setCustomizeOpen] = useState(false);

  if (item.available === false) return null;
  if (item.availableNow === false) return null;

  function openCustomize() {
    if (orderingLocked) {
      toast.error("Bill already requested — ordering is closed");
      return;
    }
    setCustomizeOpen(true);
  }

  function handleQuickAdd() {
    if (orderingLocked) {
      toast.error("Bill already requested — ordering is closed");
      return;
    }
    // Items that require a choice (variants / add-ons) open customize instead
    const needsChoice =
      (item.variants?.length || 0) > 1 || (item.addOns?.filter((a) => a.available !== false).length || 0) > 0;
    if (needsChoice) {
      setCustomizeOpen(true);
      return;
    }
    addItem(item, defaultAddOpts(item));
  }

  function handlePlus() {
    if (orderingLocked) return;
    if (lineQty === 0) {
      handleQuickAdd();
      return;
    }
    // If multiple customization lines exist, + adds another default unit via adjust
    adjustItemQty(item.id, 1);
  }

  function handleMinus() {
    if (orderingLocked) return;
    adjustItemQty(item.id, -1);
  }

  return (
    <>
      <article className="card-premium flex gap-3 p-3 transition-shadow hover:shadow-soft">
        <button
          type="button"
          onClick={openCustomize}
          className="relative h-24 w-24 shrink-0 overflow-hidden rounded-xl bg-brand-50 dark:bg-brand-800"
          aria-label={`View ${item.name}`}
        >
          {item.image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={item.image}
              alt={item.name}
              className="h-full w-full object-cover"
              loading="lazy"
              decoding="async"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center" aria-hidden>
              <FoodPlaceholderIcon className="h-8 w-8" />
            </div>
          )}
          <AnimatePresence>
            {lineQty > 0 && (
              <motion.span
                key="qty-badge"
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.5 }}
                transition={{ type: "spring", stiffness: 500, damping: 22 }}
                className="absolute right-1 top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-brand-500 px-1 text-[10px] font-bold text-white"
              >
                {lineQty}
              </motion.span>
            )}
          </AnimatePresence>
        </button>

        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex items-start gap-1.5">
            {(item.isVeg === true ||
              ["veg", "vegetarian", "vegan"].includes(String(item.foodType).toLowerCase())) && (
              <VegMark className="mt-1" size={13} />
            )}
            {(item.isVeg === false ||
              ["non-veg", "nonveg", "non_veg", "egg"].includes(
                String(item.foodType).toLowerCase()
              )) && <NonVegMark className="mt-1" size={13} />}
            {(item.spiceLevel === "hot" || item.tags?.includes("spicy")) && (
              <SpicyIcon className="mt-0.5" />
            )}
            <h3 className="font-semibold leading-snug text-ink dark:text-brand-50">{item.name}</h3>
          </div>

          {item.tags && item.tags.length > 0 && (
            <div className="mt-1 flex flex-wrap gap-1">
              {item.tags.slice(0, 3).map((tag) => (
                <span
                  key={tag}
                  className="rounded-full bg-brand-50 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-brand-700 dark:bg-brand-900 dark:text-brand-200"
                >
                  {tag.replace(/_/g, " ")}
                </span>
              ))}
            </div>
          )}

          {item.description && (
            <p className="mt-0.5 line-clamp-2 text-xs text-ink-secondary dark:text-brand-300">
              {item.description}
            </p>
          )}

          {(item.jainOnly ||
            item.jainAvailable === true ||
            (item.jainAvailable !== false &&
              (item.isVeg || item.foodType === "veg" || item.foodType === "vegan"))) && (
            <p className="mt-1 text-[10px] font-medium text-emerald-700 dark:text-emerald-400">
              Jain available
            </p>
          )}

          <div className="mt-auto flex items-center justify-between gap-2 pt-2">
            <span className="font-bold text-ink dark:text-brand-50">
              {formatCurrency(item.price)}
              {(item.variants?.length || 0) > 0 || (item.addOns?.length || 0) > 0 ? (
                <span className="text-[10px] font-normal text-ink-muted"> onwards</span>
              ) : null}
            </span>

            {orderingLocked ? (
              <span className="rounded-full bg-brand-50 px-3 py-1.5 text-[10px] font-semibold text-ink-muted dark:bg-brand-800">
                Closed
              </span>
            ) : (
              <div className="flex items-center gap-1.5">
                {/* Customize — always available */}
                <button
                  type="button"
                  onClick={openCustomize}
                  className="inline-flex items-center gap-1 rounded-full border border-line bg-white px-2.5 py-1.5 text-[11px] font-semibold text-ink-secondary transition hover:bg-brand-50 dark:border-brand-700 dark:bg-brand-900 dark:text-brand-200 dark:hover:bg-brand-800"
                  aria-label={`Customize ${item.name}`}
                >
                  <SlidersHorizontal className="h-3 w-3" />
                  Customize
                </button>

                {/* Add  OR  − qty + */}
                {lineQty === 0 ? (
                  <button
                    type="button"
                    onClick={handleQuickAdd}
                    className="inline-flex items-center gap-1 rounded-full bg-brand-500 px-3 py-1.5 text-xs font-semibold text-white shadow-sm transition-transform hover:bg-brand-600 active:scale-95 focus-visible:ring-2 focus-visible:ring-brand-500 focus-visible:ring-offset-2"
                    aria-label={`Add ${item.name}`}
                  >
                    <Plus className="h-3.5 w-3.5" /> Add
                  </button>
                ) : (
                  <div
                    className="inline-flex items-center gap-0.5 rounded-full border border-brand-500 bg-brand-500 text-white shadow-sm"
                    role="group"
                    aria-label={`Quantity of ${item.name}`}
                  >
                    <button
                      type="button"
                      onClick={handleMinus}
                      className="flex h-8 w-8 items-center justify-center rounded-full transition hover:bg-brand-600 active:scale-95"
                      aria-label={`Decrease ${item.name}`}
                    >
                      <Minus className="h-3.5 w-3.5" />
                    </button>
                    <span className="min-w-[1.25rem] text-center text-xs font-bold tabular-nums" aria-live="polite">
                      {lineQty}
                    </span>
                    <button
                      type="button"
                      onClick={handlePlus}
                      className="flex h-8 w-8 items-center justify-center rounded-full transition hover:bg-brand-600 active:scale-95"
                      aria-label={`Increase ${item.name}`}
                    >
                      <Plus className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </article>

      <CustomizeSheet item={item} open={customizeOpen} onClose={() => setCustomizeOpen(false)} />
    </>
  );
}

export const MenuCard = memo(MenuCardInner);
