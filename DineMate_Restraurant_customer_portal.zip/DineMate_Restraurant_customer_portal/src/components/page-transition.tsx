"use client";

import { motion } from "framer-motion";
import { pageTransition, pageVariants } from "@/lib/motion";

/** Soft fade + rise + blur on route/content mount */
export function PageTransition({
  children,
  className,
  as = "div",
}: {
  children: React.ReactNode;
  className?: string;
  /** Semantic element to render — defaults to a plain div. */
  as?: "div" | "main" | "section";
}) {
  const MotionTag = as === "main" ? motion.main : as === "section" ? motion.section : motion.div;
  return (
    <MotionTag
      className={className}
      initial="initial"
      animate="animate"
      exit="exit"
      variants={pageVariants}
      transition={pageTransition}
      style={{ willChange: "opacity, transform, filter" }}
    >
      {children}
    </MotionTag>
  );
}
