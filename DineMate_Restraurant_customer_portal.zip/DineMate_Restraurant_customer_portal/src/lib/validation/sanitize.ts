/**
 * Client-side input sanitization aligned with enterprise security standards.
 * Backend remains the source of truth; this reduces XSS surface and normalizes data.
 */

const CONTROL_CHARS = /[\u0000-\u001F\u007F-\u009F]/g;
const HTML_TAGS = /<\/?[^>]+(>|$)/g;
const MULTI_SPACE = /\s{2,}/g;

export function normalizeWhitespace(value: string): string {
  return value.replace(MULTI_SPACE, " ").trim();
}

export function stripHtml(value: string): string {
  return value.replace(HTML_TAGS, "");
}

export function stripControlChars(value: string): string {
  return value.replace(CONTROL_CHARS, "");
}

/** Sanitize free-text fields (name, notes, search). */
export function sanitizeText(value: string, maxLength = 200): string {
  if (typeof value !== "string") return "";
  let v = stripControlChars(value);
  v = stripHtml(v);
  v = normalizeWhitespace(v);
  if (v.length > maxLength) v = v.slice(0, maxLength);
  return v;
}

/** Sanitize restaurant / table identifiers (alphanumeric + limited punctuation). */
export function sanitizeId(value: string, maxLength = 64): string {
  if (typeof value !== "string") return "";
  let v = stripControlChars(value).trim();
  v = v.replace(/[^a-zA-Z0-9\-_.]/g, "");
  if (v.length > maxLength) v = v.slice(0, maxLength);
  return v;
}

export function isValidTableNumber(value: string | number): boolean {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isInteger(n) && n >= 1 && n <= 9999;
}

export function isValidRestaurantId(value: string): boolean {
  return /^[A-Za-z0-9][A-Za-z0-9\-_.]{1,62}$/.test(value);
}
