import axios, { type AxiosError } from "axios";

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000";

export const api = axios.create({
  baseURL: API_URL,
  headers: { "Content-Type": "application/json" },
  timeout: 25000,
});

/** User-facing messages keyed by HTTP status — never leak stack traces or internals. */
const STATUS_MESSAGES: Record<number, string> = {
  400: "Invalid request. Please check your input and try again.",
  401: "Session expired. Please scan the table QR again.",
  403: "You don’t have permission to do that.",
  404: "Not found. The item or order may no longer be available.",
  409: "This action conflicts with the current state. Please refresh and try again.",
  422: "Some details look invalid. Please review and try again.",
  429: "Too many requests. Please wait a moment and try again.",
  500: "Something went wrong on our side. Please try again shortly.",
  502: "Service temporarily unavailable. Please try again.",
  503: "Service temporarily unavailable. Please try again.",
  504: "Request timed out. Please try again.",
};

function messageFromBody(error: AxiosError): string | undefined {
  const data = error.response?.data;
  if (!data || typeof data !== "object") return undefined;
  const rec = data as Record<string, unknown>;
  // Common API shapes
  if (typeof rec.message === "string" && rec.message.trim()) {
    const msg = rec.message.trim();
    // Never surface stack traces or internal paths
    if (/at\s+\S+\s+\(|node_modules|Error:|TypeError|ReferenceError/i.test(msg)) {
      return undefined;
    }
    return msg.slice(0, 200);
  }
  if (typeof rec.error === "string" && rec.error.trim()) {
    return rec.error.trim().slice(0, 200);
  }
  return undefined;
}

export function getErrorMessage(error: unknown): string {
  if (axios.isAxiosError(error)) {
    if (error.code === "ECONNABORTED") {
      return "Request timed out. Please try again.";
    }
    if (!error.response) {
      return "Network error. Check your connection and try again.";
    }
    const status = error.response.status;
    const fromBody = messageFromBody(error);
    if (fromBody) return fromBody;
    if (STATUS_MESSAGES[status]) return STATUS_MESSAGES[status];
    if (status >= 500) return STATUS_MESSAGES[500];
    return error.message || "Something went wrong";
  }
  if (error instanceof Error) {
    // Avoid leaking internal Error messages that look like stack traces
    if (/at\s+\S+\s+\(|node_modules/i.test(error.message)) {
      return "Something went wrong";
    }
    return error.message || "Something went wrong";
  }
  return "Something went wrong";
}
