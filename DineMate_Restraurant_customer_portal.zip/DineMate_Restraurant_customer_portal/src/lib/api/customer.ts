import { api } from "./client";
import type {
  ApiSuccess,
  MenuCategory,
  MenuItem,
  Offer,
  Order,
  RestaurantSettings,
} from "@/types";

/**
 * Public customer routes resolve tenant via `?restaurantId=` only
 * (see backend tenant-context.ts). Do NOT send custom headers like
 * X-Restaurant-Id — they trigger a CORS preflight that fails unless
 * the backend Allow-Headers list includes them.
 */
function tenantParams(restaurantId: string) {
  return { params: { restaurantId } };
}

/** GET /api/menu?restaurantId= — full menu (no pagination for customer view). */
export async function getMenu(restaurantId: string): Promise<MenuItem[]> {
  const { data } = await api.get<ApiSuccess<{ items: MenuItem[] }>>(
    "/api/menu",
    tenantParams(restaurantId)
  );
  return data.data.items ?? [];
}

/** GET /api/categories?restaurantId= */
export async function getCategories(restaurantId: string): Promise<MenuCategory[]> {
  const { data } = await api.get<ApiSuccess<{ categories: MenuCategory[] }>>(
    "/api/categories",
    tenantParams(restaurantId)
  );
  return data.data.categories ?? [];
}

/** GET /api/settings?restaurantId= — tax, currency, restaurant name */
export async function getSettings(restaurantId: string): Promise<RestaurantSettings> {
  const { data } = await api.get<ApiSuccess<{ settings: RestaurantSettings }>>(
    "/api/settings",
    tenantParams(restaurantId)
  );
  return data.data.settings;
}

export type RankedMenuItem = {
  item: MenuItem;
  score: number;
  reason: string;
};

export type MenuRecommendations = {
  bestsellers: RankedMenuItem[];
  recommended: RankedMenuItem[];
  pairs: Record<string, Array<{ itemId: string; score: number }>>;
};

/** GET /api/menu/recommendations?restaurantId= — bestsellers + non-AI recommendations */
export async function getRecommendations(restaurantId: string): Promise<MenuRecommendations> {
  const { data } = await api.get<ApiSuccess<MenuRecommendations>>(
    "/api/menu/recommendations",
    tenantParams(restaurantId)
  );
  return data.data;
}

/** GET /api/offers?restaurantId=&live=1 — currently live offers */
export async function getOffers(restaurantId: string, liveOnly = true): Promise<Offer[]> {
  const { data } = await api.get<ApiSuccess<{ offers: Offer[] }>>("/api/offers", {
    params: { restaurantId, ...(liveOnly ? { live: "1" } : {}) },
  });
  return data.data.offers ?? [];
}

/**
 * POST /api/orders?restaurantId=
 * Backend requires each item to include itemId + name (price/qty optional).
 * Variant field is `variant` (label string), not variantId.
 */
type OrderItemPayload = {
  itemId: string;
  name: string;
  quantity: number;
  price?: number;
  variant?: string;
  note?: string;
  preparation?: "regular" | "jain";
  spiceLevelSelected?: string;
  addOnIds?: string[];
  cookingRequest?: string;
};

export async function placeOrder(body: {
  restaurantId: string;
  tableNumber: number;
  items: OrderItemPayload[];
  customerName?: string;
  note?: string;
}): Promise<Order> {
  const { restaurantId, ...payload } = body;
  const { data } = await api.post<ApiSuccess<{ order: Order }>>(
    "/api/orders",
    {
      tableNumber: payload.tableNumber,
      items: payload.items.map((i) => ({
        itemId: i.itemId,
        name: i.name,
        quantity: i.quantity,
        price: i.price,
        variant: i.variant,
        note: i.note,
        preparation: i.preparation,
        spiceLevelSelected: i.spiceLevelSelected,
        addOnIds: i.addOnIds,
        cookingRequest: i.cookingRequest,
      })),
      customerName: payload.customerName,
      note: payload.note,
    },
    tenantParams(restaurantId)
  );
  return data.data.order;
}

/** GET /api/orders/[id] — tenant is encoded in the order id */
export async function getOrderStatus(orderId: string, _restaurantId?: string): Promise<Order> {
  const { data } = await api.get<ApiSuccess<{ order: Order }>>(`/api/orders/${orderId}`);
  return data.data.order;
}

/** POST /api/orders/[id]/items — add items to an in-progress order */
export async function addOrderItems(
  orderId: string,
  items: OrderItemPayload[]
): Promise<Order> {
  const { data } = await api.post<ApiSuccess<{ order: Order }>>(`/api/orders/${orderId}/items`, {
    items,
  });
  return data.data.order;
}

/** GET /api/orders/[id]/bill — finalize (first call) or read archived bill + settings */
export async function getOrderBill(
  orderId: string
): Promise<{ order: Order; settings?: RestaurantSettings }> {
  const { data } = await api.get<ApiSuccess<{ order: Order; settings?: RestaurantSettings }>>(
    `/api/orders/${orderId}/bill`
  );
  return { order: data.data.order, settings: data.data.settings };
}

/** GET /api/orders/[id]/kot — pending kitchen items */
export async function getOrderKot(orderId: string) {
  const { data } = await api.get<ApiSuccess<{ items: unknown[]; order?: Order }>>(
    `/api/orders/${orderId}/kot`
  );
  return data.data;
}

/** GET /api/tables?restaurantId= — optional table validation */
export async function getTables(restaurantId: string) {
  const { data } = await api.get<
    ApiSuccess<{ tables: Array<{ id: string; number: number; status: string }> }>
  >("/api/tables", tenantParams(restaurantId));
  return data.data.tables ?? [];
}

/** GET /api/health — connectivity check */
export async function healthCheck() {
  const { data } = await api.get<ApiSuccess<Record<string, unknown>>>("/api/health");
  return data;
}
