import type { Order, RestaurantSettings } from "@/types";

function esc(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function money(n: number) {
  return Number(n || 0).toFixed(2);
}

/** Hide tenant id (RESTxxxxxx) from anything shown on the customer bill. */
function publicRef(value?: string | null): string {
  if (!value) return "—";
  const ord = /^ord-REST\d+-(\d+)$/i.exec(value);
  if (ord) return ord[1];
  const bill = /^REST\d+-(.+)$/i.exec(value);
  if (bill) return bill[1];
  return value.replace(/REST\d+/gi, "").replace(/^-+|-+$/g, "") || value;
}

function restaurantDisplayName(order: Order, settings?: RestaurantSettings | null) {
  const name = settings?.restaurantName?.trim();
  if (name && !/^REST\d+$/i.test(name)) return name;
  return "Restaurant";
}

function formatDateParts(iso?: string) {
  if (!iso) return { date: "—", time: "—" };
  try {
    const d = new Date(iso);
    const date = d.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
    const time = d.toLocaleTimeString("en-IN", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });
    return { date, time };
  } catch {
    return { date: iso, time: "" };
  }
}

/** Wrap a long string into chunks of at most `max` characters (word-aware). */
function wrapText(text: string, max: number): string[] {
  if (text.length <= max) return [text];
  const out: string[] = [];
  let remaining = text;
  while (remaining.length > max) {
    let breakAt = remaining.lastIndexOf(" ", max);
    if (breakAt < Math.floor(max * 0.4)) breakAt = max;
    out.push(remaining.slice(0, breakAt).trimEnd());
    remaining = remaining.slice(breakAt).trimStart();
  }
  if (remaining) out.push(remaining);
  return out;
}

function buildReceiptLines(order: Order, settings?: RestaurantSettings | null): string[] {
  const name = restaurantDisplayName(order, settings);
  const { date, time } = formatDateParts(order.billedAt || order.placedAt);
  const qtyTotal = (order.items || []).reduce((n, i) => n + i.quantity, 0);
  const taxRate = order.taxRatePercent ?? settings?.taxRatePercent ?? 0;
  const billNo = publicRef(order.billNumber);
  const lines: string[] = [];

  // Wider than before so amounts/dates are not clipped on PDF
  const W = 48;
  const center = (s: string) => {
    const t = s.slice(0, W);
    const pad = Math.max(0, Math.floor((W - t.length) / 2));
    return " ".repeat(pad) + t;
  };
  const row = (left: string, right: string) => {
    const r = right.slice(0, 14);
    const l = left.slice(0, W - r.length - 1);
    return l + " ".repeat(Math.max(1, W - l.length - r.length)) + r;
  };
  const dash = "-".repeat(W);

  for (const part of wrapText(name.toUpperCase(), W)) lines.push(center(part));
  if (settings?.address) {
    for (const part of wrapText(settings.address, W)) lines.push(center(part));
  }
  if (settings?.phone?.trim()) {
    lines.push(center(`Ph: ${settings.phone.trim()}`.slice(0, W)));
  }
  if (settings?.foodLicence?.trim()) {
    lines.push(center(`Food Lic: ${settings.foodLicence.trim()}`.slice(0, W)));
  }
  if (settings?.gstin) lines.push(center(`GSTIN: ${settings.gstin}`.slice(0, W)));
  lines.push(center("CASH / BILL"));
  lines.push(dash);
  lines.push(row("Bill No", billNo));
  lines.push(row("Table", String(order.tableNumber)));
  if (order.customerName) lines.push(row("Guest", order.customerName.slice(0, 24)));
  lines.push(row("Date", `${date} ${time}`.trim()));
  lines.push(dash);
  lines.push(row("Item", "Amt"));
  lines.push(dash);

  for (const it of order.items || []) {
    const title = it.name + (it.variant ? ` (${it.variant})` : "");
    for (const part of wrapText(title, W)) lines.push(part);
    lines.push(row(`  ${money(it.price)} x ${it.quantity}`, money(it.price * it.quantity)));
  }

  lines.push(dash);
  lines.push(row("Total Quantity", String(qtyTotal)));
  lines.push(row("Gross Total", money(order.subtotal)));
  if (typeof order.discountTotal === "number" && order.discountTotal > 0) {
    lines.push(row("Discount", `-${money(order.discountTotal)}`));
  }
  if (typeof order.taxAmount === "number" && order.taxAmount > 0) {
    lines.push(row(`Tax${taxRate ? ` ${taxRate}%` : ""}`, money(order.taxAmount)));
  }
  lines.push("=".repeat(W));
  lines.push(row("NET AMOUNT", `Rs ${money(order.total)}`));
  lines.push("=".repeat(W));
  lines.push("");
  lines.push(center("Thank you! Visit again"));
  lines.push(center("Powered by DineMate"));
  return lines;
}

/**
 * Responsive HTML receipt for print:
 * - Screen: fluid, readable on phones
 * - Print thermal (58/80mm): compact columns, no overflow
 * - Print A4 / letter: centered receipt card, no cut-off
 */
export function buildBillHtml(order: Order, settings?: RestaurantSettings | null): string {
  const name = restaurantDisplayName(order, settings);
  const { date, time } = formatDateParts(order.billedAt || order.placedAt);
  const qtyTotal = (order.items || []).reduce((n, i) => n + i.quantity, 0);
  const taxRate = order.taxRatePercent ?? settings?.taxRatePercent ?? 0;
  const billNo = publicRef(order.billNumber);
  const phone = (settings?.phone || "").trim();
  const address = (settings?.address || "").trim();
  const foodLicence = (settings?.foodLicence || "").trim();
  const gstin = (settings?.gstin || "").trim();

  const itemRows = (order.items || [])
    .map((it) => {
      const title = esc(it.name) + (it.variant ? ` (${esc(it.variant)})` : "");
      return `
      <tr class="item-row">
        <td colspan="3" class="item-name">${title}</td>
        <td class="num amt">${money(it.price * it.quantity)}</td>
      </tr>
      <tr class="item-detail">
        <td colspan="4" class="detail">
          <span>${money(it.price)}</span>
          <span class="sep">×</span>
          <span>${it.quantity}</span>
        </td>
      </tr>`;
    })
    .join("");

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover" />
  <title>Bill ${esc(billNo)}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    html {
      -webkit-text-size-adjust: 100%;
      text-size-adjust: 100%;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      font-size: 14px;
      line-height: 1.45;
      color: #111;
      background: #f3f4f6;
      margin: 0;
      padding: 16px 12px 28px;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .receipt {
      width: 100%;
      max-width: 420px;
      margin: 0 auto;
      background: #fff;
      border-radius: 12px;
      padding: 18px 16px 22px;
      box-shadow: 0 1px 3px rgba(0,0,0,.08);
    }
    .center { text-align: center; }
    .bold { font-weight: 700; }
    .name {
      font-size: 1.15rem;
      font-weight: 800;
      text-transform: uppercase;
      letter-spacing: 0.03em;
      word-break: break-word;
      line-height: 1.25;
    }
    .muted {
      font-size: 0.8rem;
      color: #444;
      word-break: break-word;
      margin-top: 2px;
    }
    .tag {
      display: inline-block;
      margin-top: 8px;
      font-size: 0.75rem;
      font-weight: 700;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: #111;
    }
    .dash {
      border: none;
      border-top: 1px dashed #999;
      margin: 12px 0;
    }
    .solid {
      border: none;
      border-top: 2px solid #111;
      margin: 10px 0;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
    }
    .meta td {
      padding: 4px 0;
      font-size: 0.9rem;
      vertical-align: top;
    }
    .meta td:first-child {
      width: 38%;
      color: #555;
      padding-right: 8px;
    }
    .meta td.num {
      width: 62%;
      text-align: right;
      font-weight: 600;
      word-break: break-word;
    }
    .items thead th {
      font-size: 0.7rem;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      color: #666;
      text-align: left;
      padding: 0 4px 6px 0;
      border-bottom: 1px dashed #bbb;
      font-weight: 700;
    }
    .items thead th.num { text-align: right; padding-right: 0; }
    .items thead th.amt { width: 28%; }
    .item-name {
      padding: 8px 8px 0 0;
      font-weight: 600;
      font-size: 0.95rem;
      word-break: break-word;
      overflow-wrap: anywhere;
      line-height: 1.3;
    }
    .item-row td.amt {
      padding: 8px 0 0 0;
      text-align: right;
      font-weight: 700;
      white-space: nowrap;
      font-variant-numeric: tabular-nums;
      vertical-align: top;
    }
    .item-detail td.detail {
      padding: 2px 0 8px 0;
      font-size: 0.8rem;
      color: #555;
      font-variant-numeric: tabular-nums;
    }
    .item-detail .sep { margin: 0 4px; color: #999; }
    .totals td {
      padding: 5px 0;
      font-size: 0.9rem;
    }
    .totals td:first-child {
      width: 58%;
      color: #444;
      padding-right: 8px;
      word-break: break-word;
    }
    .totals td.num {
      width: 42%;
      text-align: right;
      font-weight: 600;
      white-space: nowrap;
      font-variant-numeric: tabular-nums;
    }
    .net td {
      font-size: 1.05rem !important;
      font-weight: 800 !important;
      color: #111 !important;
      padding-top: 8px !important;
    }
    .footer {
      margin-top: 16px;
      text-align: center;
      font-size: 0.8rem;
    }
    .footer .bold { margin-bottom: 4px; }

    /* Phones */
    @media screen and (max-width: 400px) {
      body { padding: 10px 8px 20px; font-size: 13px; }
      .receipt { padding: 14px 12px 18px; border-radius: 10px; max-width: 100%; }
      .name { font-size: 1.05rem; }
      .item-name { font-size: 0.9rem; }
    }

    /* Print — works for mobile share/print, thermal, and A4 */
    @media print {
      html, body {
        background: #fff !important;
        padding: 0 !important;
        margin: 0 !important;
        width: 100% !important;
        font-size: 11pt !important;
      }
      .receipt {
        max-width: 100% !important;
        width: 100% !important;
        margin: 0 auto !important;
        padding: 4mm 5mm !important;
        box-shadow: none !important;
        border-radius: 0 !important;
      }
      .dash { border-top-color: #000 !important; }
      .solid { border-top-color: #000 !important; }
      .muted, .meta td:first-child, .totals td:first-child,
      .item-detail td.detail, .items thead th {
        color: #000 !important;
      }
      .no-print { display: none !important; }

      /* Prefer continuous receipt height; fall back gracefully on A4 */
      @page {
        size: auto;
        margin: 8mm;
      }
    }

    /* Narrow thermal-ish paper when browser supports it */
    @media print and (max-width: 90mm) {
      body { font-size: 10px !important; }
      .receipt { padding: 2mm 3mm !important; }
      .name { font-size: 12px !important; }
      .net td { font-size: 12px !important; }
      @page { margin: 2mm; }
    }
  </style>
</head>
<body>
  <div class="receipt">
    <div class="center">
      <div class="name">${esc(name)}</div>
      ${address ? `<div class="muted">${esc(address)}</div>` : ""}
      ${phone ? `<div class="muted">Ph: ${esc(phone)}</div>` : ""}
      ${foodLicence ? `<div class="muted">Food Lic: ${esc(foodLicence)}</div>` : ""}
      ${gstin ? `<div class="muted">GSTIN: ${esc(gstin)}</div>` : ""}
      <div class="tag">Cash / Bill</div>
    </div>

    <hr class="dash" />

    <table class="meta">
      <tr>
        <td>Bill No</td>
        <td class="num bold">${esc(billNo)}</td>
      </tr>
      <tr>
        <td>Table</td>
        <td class="num">${order.tableNumber}</td>
      </tr>
      ${
        order.customerName
          ? `<tr><td>Guest</td><td class="num">${esc(order.customerName)}</td></tr>`
          : ""
      }
      <tr>
        <td>Date</td>
        <td class="num">${esc(date)}&nbsp;${esc(time)}</td>
      </tr>
    </table>

    <hr class="dash" />

    <table class="items">
      <thead>
        <tr>
          <th colspan="3">Item</th>
          <th class="num amt">Amt</th>
        </tr>
      </thead>
      <tbody>
        ${itemRows}
      </tbody>
    </table>

    <hr class="dash" />

    <table class="totals">
      <tr>
        <td>Total Quantity</td>
        <td class="num">${qtyTotal}</td>
      </tr>
      <tr>
        <td>Gross Total</td>
        <td class="num">${money(order.subtotal)}</td>
      </tr>
      ${
        typeof order.discountTotal === "number" && order.discountTotal > 0
          ? `<tr><td>Discount</td><td class="num">-${money(order.discountTotal)}</td></tr>`
          : ""
      }
      ${
        typeof order.taxAmount === "number" && order.taxAmount > 0
          ? `<tr><td>Tax${taxRate ? ` ${taxRate}%` : ""}</td><td class="num">${money(order.taxAmount)}</td></tr>`
          : ""
      }
    </table>

    <hr class="solid" />

    <table class="totals">
      <tr class="net">
        <td>Net Amount</td>
        <td class="num">Rs ${money(order.total)}</td>
      </tr>
    </table>

    <hr class="dash" />

    <div class="footer">
      <div class="bold">Thank you! Visit again</div>
      <div class="muted">Powered by DineMate</div>
    </div>
  </div>
</body>
</html>`;
}

/** Escape for PDF literal strings (WinAnsi-ish safe subset). */
function pdfEsc(s: string): string {
  return s
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)")
    .replace(/[^\x20-\x7E]/g, (ch) => {
      if (ch === "₹") return "Rs ";
      if (ch === "–" || ch === "—") return "-";
      if (ch === "’" || ch === "‘") return "'";
      if (ch === "“" || ch === "”") return '"';
      return "";
    });
}

/**
 * Build a simple single-page PDF (Courier monospace thermal receipt).
 * Wider page + margins so text is not clipped on mobile PDF viewers.
 */
export function buildBillPdf(order: Order, settings?: RestaurantSettings | null): Blob {
  const receiptLines = buildReceiptLines(order, settings);
  const fontSize = 10;
  const leading = 13;
  // ~80mm-ish width in points with padding so nothing clips
  const pageWidth = 280;
  const marginX = 18;
  const marginTop = 24;
  const contentHeight = marginTop + receiptLines.length * leading + 24;
  const pageHeight = Math.max(400, contentHeight);

  const contentLines: string[] = [];
  // Start text object
  contentLines.push("BT");
  contentLines.push(`/F1 ${fontSize} Tf`);
  contentLines.push(`${leading} TL`);
  contentLines.push(`${marginX} ${pageHeight - marginTop} Td`);

  for (let i = 0; i < receiptLines.length; i++) {
    const line = pdfEsc(receiptLines[i]);
    if (i === 0) {
      contentLines.push(`(${line}) Tj`);
    } else {
      contentLines.push(`T* (${line}) Tj`);
    }
  }
  contentLines.push("ET");
  const stream = contentLines.join("\n");
  const streamLen = new TextEncoder().encode(stream).length;

  const objects: string[] = [];
  // 1: Catalog
  objects.push("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
  // 2: Pages
  objects.push("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n");
  // 3: Page
  objects.push(
    `3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>\nendobj\n`
  );
  // 4: Content stream
  objects.push(`4 0 obj\n<< /Length ${streamLen} >>\nstream\n${stream}\nendstream\nendobj\n`);
  // 5: Font
  objects.push("5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>\nendobj\n");

  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [0];
  for (const obj of objects) {
    offsets.push(new TextEncoder().encode(pdf).length);
    pdf += obj;
  }
  const xrefPos = new TextEncoder().encode(pdf).length;
  pdf += `xref\n0 ${objects.length + 1}\n`;
  pdf += "0000000000 65535 f \n";
  for (let i = 1; i <= objects.length; i++) {
    pdf += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\n`;
  pdf += `startxref\n${xrefPos}\n%%EOF`;

  return new Blob([pdf], { type: "application/pdf" });
}

/** Download bill as a real PDF file (no restaurant id in content). */
export function downloadBillPdf(order: Order, settings?: RestaurantSettings | null) {
  const blob = buildBillPdf(order, settings);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  const name = publicRef(order.billNumber || order.id);
  a.download = `bill-${name}.pdf`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/** @deprecated use downloadBillPdf */
export function downloadBillHtml(order: Order, settings?: RestaurantSettings | null) {
  downloadBillPdf(order, settings);
}

/**
 * Print via hidden iframe — responsive receipt for phone / thermal / A4.
 */
export function printBill(order: Order, settings?: RestaurantSettings | null): boolean {
  if (typeof document === "undefined") return false;
  const html = buildBillHtml(order, settings);

  const existing = document.getElementById("dinemate-print-frame");
  if (existing) existing.remove();

  const iframe = document.createElement("iframe");
  iframe.id = "dinemate-print-frame";
  iframe.setAttribute("aria-hidden", "true");
  iframe.style.cssText =
    "position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0;pointer-events:none;";
  document.body.appendChild(iframe);

  const doc = iframe.contentDocument || iframe.contentWindow?.document;
  if (!doc) {
    iframe.remove();
    return false;
  }

  doc.open();
  doc.write(html);
  doc.close();

  const runPrint = () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch {
      /* ignore */
    }
    setTimeout(() => {
      try {
        iframe.remove();
      } catch {
        /* ignore */
      }
    }, 60_000);
  };

  // Give layout/fonts a moment on mobile browsers
  if (iframe.contentWindow?.document.readyState === "complete") {
    setTimeout(runPrint, 250);
  } else {
    iframe.onload = () => setTimeout(runPrint, 250);
  }
  return true;
}

export { publicRef, restaurantDisplayName };
