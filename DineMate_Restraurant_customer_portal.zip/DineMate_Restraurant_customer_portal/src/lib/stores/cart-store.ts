"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartLine, MenuItem } from "@/types";

interface CartState {
  restaurantId: string | null;
  tableNumber: number | null;
  /** Active open order for this table — items can be added until bill is generated. */
  activeOrderId: string | null;
  /** True after bill is requested/printed — no more ordering for this session. */
  orderingLocked: boolean;
  /** ISO timestamp when bill was finalized (for auto-close countdown). */
  billCompletedAt: string | null;
  lines: CartLine[];
  setContext: (restaurantId: string, tableNumber: number) => void;
  setActiveOrder: (orderId: string | null) => void;
  lockOrdering: () => void;
  unlockOrdering: () => void;
  /** Clear cart + lock so a new guest can start a fresh session on this device. */
  resetSession: () => void;
  addItem: (
    item: MenuItem,
    opts?: {
      variantId?: string;
      variantLabel?: string;
      priceDelta?: number;
      preparation?: "regular" | "jain";
      spiceLevelSelected?: string;
      addOns?: Array<{ id: string; label: string; priceDelta: number }>;
      cookingRequest?: string;
      note?: string;
      quantity?: number;
    }
  ) => void;
  /**
   * Adjust quantity for a menu item from the menu card.
   * − decreases the last matching line; + increases a single shared line or the last one.
   * Returns the new total qty for that itemId (0 if removed).
   */
  adjustItemQty: (itemId: string, delta: number) => number;
  /** Replace a cart line (used when editing customization — key may change). */
  replaceLine: (
    oldKey: string,
    item: MenuItem,
    opts?: {
      variantId?: string;
      variantLabel?: string;
      priceDelta?: number;
      preparation?: "regular" | "jain";
      spiceLevelSelected?: string;
      addOns?: Array<{ id: string; label: string; priceDelta: number }>;
      cookingRequest?: string;
      note?: string;
      quantity?: number;
    }
  ) => void;
  setQty: (key: string, quantity: number) => void;
  /**
   * Update customization fields on an existing line (rebuilds identity key).
   * Merges into an existing line if the new key already exists.
   */
  updateLineCustomization: (
    key: string,
    meta: {
      preparation?: "regular" | "jain";
      spiceLevelSelected?: string;
      cookingRequest?: string;
    }
  ) => void;
  remove: (key: string) => void;
  clear: () => void;
  total: () => number;
  count: () => number;
}

/** Build the stable cart-line key (product + customization identity). */
export function buildCartLineKey(
  itemId: string,
  opts?: {
    variantId?: string;
    preparation?: "regular" | "jain";
    spiceLevelSelected?: string;
    addOns?: Array<{ id: string }>;
    cookingRequest?: string;
  }
): string {
  const addOnKey = (opts?.addOns || [])
    .map((a) => a.id)
    .sort()
    .join("+");
  const prep = opts?.preparation || "regular";
  const spice = opts?.spiceLevelSelected || "";
  const req = (opts?.cookingRequest || "").trim();
  return [
    itemId,
    opts?.variantId || "base",
    prep,
    spice || "-",
    addOnKey || "-",
    req ? req.slice(0, 24) : "-",
  ].join(":");
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      restaurantId: null,
      tableNumber: null,
      activeOrderId: null,
      orderingLocked: false,
      billCompletedAt: null,
      lines: [],
      setContext: (restaurantId, tableNumber) => {
        const cur = get();
        // Switching restaurant or table always starts a fresh session
        if (
          (cur.restaurantId && cur.restaurantId !== restaurantId) ||
          (cur.tableNumber != null && cur.tableNumber !== tableNumber)
        ) {
          set({
            restaurantId,
            tableNumber,
            lines: [],
            activeOrderId: null,
            orderingLocked: false,
            billCompletedAt: null,
          });
          return;
        }
        // Same table: after bill, keep lock briefly (same session), then free
        // the device so the next guest scanning this QR can order.
        if (cur.orderingLocked && cur.billCompletedAt) {
          const ageMs = Date.now() - new Date(cur.billCompletedAt).getTime();
          if (ageMs >= 30_000 || Number.isNaN(ageMs)) {
            set({
              restaurantId,
              tableNumber,
              lines: [],
              activeOrderId: null,
              orderingLocked: false,
              billCompletedAt: null,
            });
            return;
          }
        }
        set({ restaurantId, tableNumber });
      },
      setActiveOrder: (orderId) =>
        set({ activeOrderId: orderId, orderingLocked: false, billCompletedAt: null }),
      lockOrdering: () =>
        set({
          orderingLocked: true,
          activeOrderId: null,
          lines: [],
          billCompletedAt: new Date().toISOString(),
        }),
      unlockOrdering: () => set({ orderingLocked: false, billCompletedAt: null }),
      resetSession: () =>
        set({
          lines: [],
          activeOrderId: null,
          orderingLocked: false,
          billCompletedAt: null,
        }),
      addItem: (item, opts) => {
        if (get().orderingLocked) return;
        const addOns = opts?.addOns || [];
        const req = (opts?.cookingRequest || "").trim();
        const key = buildCartLineKey(item.id, {
          variantId: opts?.variantId,
          preparation: opts?.preparation,
          spiceLevelSelected: opts?.spiceLevelSelected,
          addOns,
          cookingRequest: req,
        });
        const addOnTotal = addOns.reduce((n, a) => n + (a.priceDelta || 0), 0);
        const price = item.price + (opts?.priceDelta || 0) + addOnTotal;
        const qty = Math.max(1, opts?.quantity || 1);
        set((s) => {
          const existing = s.lines.find((l) => l.key === key);
          if (existing) {
            return {
              lines: s.lines.map((l) =>
                l.key === key ? { ...l, quantity: l.quantity + qty } : l
              ),
            };
          }
          return {
            lines: [
              ...s.lines,
              {
                key,
                itemId: item.id,
                name: item.name,
                price,
                quantity: qty,
                variantId: opts?.variantId,
                variantLabel: opts?.variantLabel,
                preparation: opts?.preparation,
                spiceLevelSelected: opts?.spiceLevelSelected,
                addOns: addOns.length ? addOns : undefined,
                cookingRequest: req || undefined,
                note: opts?.note,
                image: item.image,
              },
            ],
          };
        });
      },
      adjustItemQty: (itemId, delta) => {
        if (get().orderingLocked) return 0;
        const lines = get().lines.filter((l) => l.itemId === itemId);
        if (lines.length === 0) return 0;

        if (delta > 0) {
          // Prefer a single shared line; otherwise bump the last matching line
          const target = lines.length === 1 ? lines[0] : lines[lines.length - 1];
          set((s) => ({
            lines: s.lines.map((l) =>
              l.key === target.key ? { ...l, quantity: l.quantity + delta } : l
            ),
          }));
        } else if (delta < 0) {
          // Decrease from the last line first (LIFO) so mixed customizations unwind cleanly
          const target = lines[lines.length - 1];
          const nextQty = target.quantity + delta;
          if (nextQty <= 0) {
            set((s) => ({ lines: s.lines.filter((l) => l.key !== target.key) }));
          } else {
            set((s) => ({
              lines: s.lines.map((l) =>
                l.key === target.key ? { ...l, quantity: nextQty } : l
              ),
            }));
          }
        }

        return get().lines
          .filter((l) => l.itemId === itemId)
          .reduce((n, l) => n + l.quantity, 0);
      },
      replaceLine: (oldKey, item, opts) => {
        if (get().orderingLocked) return;
        const existing = get().lines.find((l) => l.key === oldKey);
        const qty = Math.max(1, opts?.quantity ?? existing?.quantity ?? 1);
        // Remove old line first so a key collision with the new customization merges cleanly
        set((s) => ({ lines: s.lines.filter((l) => l.key !== oldKey) }));
        get().addItem(item, { ...opts, quantity: qty });
      },
      setQty: (key, quantity) => {
        if (get().orderingLocked) return;
        if (quantity <= 0) {
          set((s) => ({ lines: s.lines.filter((l) => l.key !== key) }));
          return;
        }
        set((s) => ({
          lines: s.lines.map((l) => (l.key === key ? { ...l, quantity } : l)),
        }));
      },
      updateLineCustomization: (key, meta) => {
        if (get().orderingLocked) return;
        const line = get().lines.find((l) => l.key === key);
        if (!line) return;

        const preparation =
          meta.preparation !== undefined ? meta.preparation : line.preparation;
        const spiceLevelSelected =
          meta.spiceLevelSelected !== undefined
            ? meta.spiceLevelSelected
            : line.spiceLevelSelected;
        const cookingRequest =
          meta.cookingRequest !== undefined
            ? meta.cookingRequest.trim()
            : line.cookingRequest;

        const newKey = buildCartLineKey(line.itemId, {
          variantId: line.variantId,
          preparation,
          spiceLevelSelected,
          addOns: line.addOns,
          cookingRequest,
        });

        if (newKey === key) {
          set((s) => ({
            lines: s.lines.map((l) =>
              l.key === key
                ? {
                    ...l,
                    preparation,
                    spiceLevelSelected: spiceLevelSelected || undefined,
                    cookingRequest: cookingRequest || undefined,
                  }
                : l
            ),
          }));
          return;
        }

        // Key changed — merge into existing target or retarget this line
        const target = get().lines.find((l) => l.key === newKey);
        set((s) => {
          const without = s.lines.filter((l) => l.key !== key);
          if (target) {
            return {
              lines: without.map((l) =>
                l.key === newKey
                  ? { ...l, quantity: l.quantity + line.quantity }
                  : l
              ),
            };
          }
          return {
            lines: [
              ...without,
              {
                ...line,
                key: newKey,
                preparation,
                spiceLevelSelected: spiceLevelSelected || undefined,
                cookingRequest: cookingRequest || undefined,
              },
            ],
          };
        });
      },
      remove: (key) => {
        if (get().orderingLocked) return;
        set((s) => ({ lines: s.lines.filter((l) => l.key !== key) }));
      },
      clear: () => set({ lines: [] }),
      total: () => get().lines.reduce((s, l) => s + l.price * l.quantity, 0),
      count: () => get().lines.reduce((s, l) => s + l.quantity, 0),
    }),
    {
      name: "dinemate-customer-cart",
      partialize: (s) => ({
        restaurantId: s.restaurantId,
        tableNumber: s.tableNumber,
        activeOrderId: s.activeOrderId,
        orderingLocked: s.orderingLocked,
        billCompletedAt: s.billCompletedAt,
        lines: s.lines,
      }),
    }
  )
);

export const selectCartCount = (s: CartState) => s.lines.reduce((n, l) => n + l.quantity, 0);
export const selectCartTotal = (s: CartState) =>
  s.lines.reduce((n, l) => n + l.price * l.quantity, 0);
export const selectActiveOrderId = (s: CartState) => s.activeOrderId;
export const selectOrderingLocked = (s: CartState) => s.orderingLocked;
