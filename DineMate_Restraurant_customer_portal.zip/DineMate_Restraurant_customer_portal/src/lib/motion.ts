/** Shared motion tokens — smooth, premium, Zomato-like */

export const easeOutExpo = [0.16, 1, 0.3, 1] as const;
export const easeOutQuart = [0.25, 1, 0.5, 1] as const;
export const easeInOut = [0.4, 0, 0.2, 1] as const;

/** Soft spring for bottom sheets — less bounce, longer settle */
export const sheetTransition = {
  type: "spring" as const,
  damping: 34,
  stiffness: 380,
  mass: 0.9,
};

/** Slightly softer for closing feel */
export const sheetExitTransition = {
  type: "spring" as const,
  damping: 40,
  stiffness: 420,
  mass: 0.8,
};

export const fadeTransition = {
  duration: 0.32,
  ease: easeOutExpo,
};

export const fadeFast = {
  duration: 0.2,
  ease: easeOutQuart,
};

/** Opacity + translate only — avoid CSS filter:blur (expensive on mobile GPUs). */
export const pageVariants = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -8 },
};

export const pageTransition = {
  duration: 0.42,
  ease: easeOutExpo,
};

export const listContainer = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.055, delayChildren: 0.06 },
  },
};

export const listItem = {
  hidden: { opacity: 0, y: 14, scale: 0.98 },
  show: {
    opacity: 1,
    y: 0,
    scale: 1,
    transition: { duration: 0.38, ease: easeOutExpo },
  },
  exit: {
    opacity: 0,
    y: -6,
    transition: { duration: 0.2, ease: easeOutQuart },
  },
};

export const overlayVariants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 },
  exit: { opacity: 0 },
};

export const sheetVariants = {
  hidden: { y: "105%" },
  visible: { y: 0 },
  exit: { y: "105%" },
};
