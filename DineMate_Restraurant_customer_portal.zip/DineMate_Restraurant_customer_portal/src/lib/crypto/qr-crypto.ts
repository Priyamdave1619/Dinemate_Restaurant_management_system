/**
 * Client-side QR token decrypt (AES-256-GCM).
 * Must use the same secret as backend QR_SECRET / NEXT_PUBLIC_QR_SECRET.
 *
 * Token: base64url( iv(12) || ciphertext || tag(16) )
 * Plaintext: { r: restaurantId, t: tableNumber, v: 1 }
 */

export type QrPayloadResolved = {
  restaurantId: string;
  tableNumber: string;
};

function getSecret(): string {
  const secret =
    (typeof process !== "undefined" &&
      (process.env.NEXT_PUBLIC_QR_SECRET || process.env.QR_SECRET)) ||
    "";
  if (!secret || secret.length < 16) {
    return "dinemate-dev-qr-secret-change-me";
  }
  return secret;
}

function fromBase64Url(s: string): Uint8Array {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  const b64 = s.replace(/-/g, "+").replace(/_/g, "/") + pad;
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function deriveKey(secret: string): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const hash = await crypto.subtle.digest("SHA-256", enc.encode(secret));
  return crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, ["decrypt"]);
}

/** Decrypt an opaque QR token. Returns null if invalid. */
export async function decryptQrToken(token: string): Promise<QrPayloadResolved | null> {
  try {
    const raw = (token || "").trim();
    if (!raw || raw.length < 40) return null;
    if (typeof crypto === "undefined" || !crypto.subtle) return null;

    const buf = fromBase64Url(raw);
    if (buf.length < 12 + 16 + 1) return null;
    const iv = buf.slice(0, 12);
    const tag = buf.slice(buf.length - 16);
    const data = buf.slice(12, buf.length - 16);
    // WebCrypto expects ciphertext || tag together for AES-GCM
    const cipherWithTag = new Uint8Array(data.length + tag.length);
    cipherWithTag.set(data, 0);
    cipherWithTag.set(tag, data.length);

    const key = await deriveKey(getSecret());
    const plainBuf = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv, tagLength: 128 },
      key,
      cipherWithTag
    );
    const plain = new TextDecoder().decode(plainBuf);
    const parsed = JSON.parse(plain) as { r?: string; t?: number; v?: number };
    if (parsed?.v !== 1 || typeof parsed.r !== "string" || typeof parsed.t !== "number") {
      return null;
    }
    const restaurantId = parsed.r.trim();
    const tableNumber = String(Math.floor(parsed.t));
    if (!restaurantId || !/^\d+$/.test(tableNumber) || Number(tableNumber) < 1) return null;
    return { restaurantId, tableNumber };
  } catch {
    return null;
  }
}

/**
 * Resolve token via backend API (fallback when client decrypt fails or
 * secret is not embedded in the client bundle).
 */
export async function resolveQrTokenViaApi(
  token: string,
  apiBase?: string
): Promise<QrPayloadResolved | null> {
  try {
    const base = (apiBase || process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000").replace(
      /\/$/,
      ""
    );
    const res = await fetch(
      `${base}/api/qr/resolve?token=${encodeURIComponent(token)}`,
      { method: "GET", credentials: "omit" }
    );
    if (!res.ok) return null;
    const json = await res.json();
    const data = json?.data ?? json;
    if (data?.restaurantId && data?.tableNumber != null) {
      return {
        restaurantId: String(data.restaurantId),
        tableNumber: String(Number(data.tableNumber)),
      };
    }
    return null;
  } catch {
    return null;
  }
}
