import { createDecipheriv, createHash } from "crypto";

export type QrResolved = { restaurantId: string; tableNumber: number };

const IV_LEN = 12;
const TAG_LEN = 16;

function getSecret(): string {
  const secret =
    process.env.QR_SECRET ||
    process.env.NEXT_PUBLIC_QR_SECRET ||
    "";
  if (!secret || secret.length < 16) {
    return "dinemate-dev-qr-secret-change-me";
  }
  return secret;
}

function deriveKey(secret: string): Buffer {
  return createHash("sha256").update(secret, "utf8").digest();
}

function fromBase64Url(s: string): Buffer {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  const b64 = s.replace(/-/g, "+").replace(/_/g, "/") + pad;
  return Buffer.from(b64, "base64");
}

/** Decrypt QR token with Node crypto (server components / route handlers). */
export function decryptQrTokenServer(token: string): QrResolved | null {
  try {
    const raw = (token || "").trim();
    if (!raw || raw.length < 40) return null;
    const buf = fromBase64Url(raw);
    if (buf.length < IV_LEN + TAG_LEN + 1) return null;
    const iv = buf.subarray(0, IV_LEN);
    const tag = buf.subarray(buf.length - TAG_LEN);
    const data = buf.subarray(IV_LEN, buf.length - TAG_LEN);
    const key = deriveKey(getSecret());
    const decipher = createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(tag);
    const plain = Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8");
    const parsed = JSON.parse(plain) as { r?: string; t?: number; v?: number };
    if (parsed?.v !== 1 || typeof parsed.r !== "string" || typeof parsed.t !== "number") {
      return null;
    }
    const restaurantId = parsed.r.trim();
    const tableNumber = Math.floor(parsed.t);
    if (!restaurantId || tableNumber < 1 || tableNumber > 9999) return null;
    return { restaurantId, tableNumber };
  } catch {
    return null;
  }
}

/** Resolve via backend API when local decrypt fails (secret mismatch / rotation). */
export async function resolveQrTokenServer(token: string): Promise<QrResolved | null> {
  try {
    const base = (process.env.NEXT_PUBLIC_API_URL || "http://localhost:3000").replace(/\/$/, "");
    const res = await fetch(`${base}/api/qr/resolve?token=${encodeURIComponent(token)}`, {
      method: "GET",
      cache: "no-store",
    });
    if (!res.ok) return null;
    const json = (await res.json()) as {
      data?: { restaurantId?: string; tableNumber?: number };
      restaurantId?: string;
      tableNumber?: number;
    };
    const data = json?.data ?? json;
    if (data?.restaurantId != null && data?.tableNumber != null) {
      return {
        restaurantId: String(data.restaurantId),
        tableNumber: Number(data.tableNumber),
      };
    }
    return null;
  } catch {
    return null;
  }
}
