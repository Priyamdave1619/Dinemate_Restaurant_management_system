export interface MenuCategory {
  id: string;
  name: string;
  icon?: string;
  restaurantId?: string;
  scheduleEnabled?: boolean;
  availableFrom?: string;
  availableTo?: string;
  /** Set by backend withCategoryAvailabilityFlags */
  availableNow?: boolean;
  outsideSchedule?: boolean;
}

export interface MenuAddOn {
  id: string;
  label: string;
  priceDelta: number;
  available?: boolean;
}

export interface MenuItem {
  id: string;
  name: string;
  description?: string;
  categoryId: string;
  price: number;
  image?: string;
  available: boolean;
  foodType?: string;
  spiceLevel?: string;
  isVeg?: boolean;
  prepTimeMinutes?: number;
  variants?: Array<{ id: string; label: string; priceDelta: number }>;
  jainAvailable?: boolean;
  jainOnly?: boolean;
  enableSpiceLevel?: boolean;
  spiceOptions?: string[];
  enableCookingRequest?: boolean;
  maxCookingRequestLength?: number;
  addOns?: MenuAddOn[];
  tags?: string[];
  ingredients?: string[];
  allergens?: string[];
  scheduleEnabled?: boolean;
  availableFrom?: string;
  availableTo?: string;
  /** Set by backend withAvailabilityFlags */
  availableNow?: boolean;
  outsideSchedule?: boolean;
}

export interface CartLine {
  key: string;
  itemId: string;
  name: string;
  price: number;
  quantity: number;
  variantId?: string;
  variantLabel?: string;
  preparation?: "regular" | "jain";
  spiceLevelSelected?: string;
  addOns?: Array<{ id: string; label: string; priceDelta: number }>;
  cookingRequest?: string;
  note?: string;
  image?: string;
}

export interface OrderItem {
  id: string;
  itemId: string;
  name: string;
  quantity: number;
  price: number;
  variant?: string;
  note?: string;
  preparation?: string;
  spiceLevelSelected?: string;
  addOns?: Array<{ id: string; label: string; priceDelta: number }>;
  cookingRequest?: string;
}

export interface AppliedOffer {
  offerId: string;
  name: string;
  amount: number;
}

export interface Order {
  id: string;
  restaurantId?: string;
  tableNumber: number;
  items: OrderItem[];
  status: string;
  total: number;
  subtotal: number;
  taxAmount?: number;
  taxRatePercent?: number;
  discountTotal?: number;
  appliedOffers?: AppliedOffer[];
  placedAt: string;
  updatedAt?: string;
  billedAt?: string;
  customerName?: string;
  note?: string;
  billGenerated?: boolean;
  billNumber?: string;
  estimatedMinutes?: number;
  paymentMethod?: string;
}

export interface Offer {
  id: string;
  name: string;
  type?: string;
  active?: boolean;
  live?: boolean;
  status?: string;
  description?: string;
  discountPercent?: number;
  discountAmount?: number;
}

export interface RestaurantSettings {
  restaurantId: string;
  taxRatePercent: number;
  restaurantName: string;
  address?: string;
  phone?: string;
  foodLicence?: string;
  gstin?: string;
  baseUrl?: string;
  currency?: string;
  openingTime?: string;
  closingTime?: string;
  billPrefix?: string;
}

export interface RestaurantPublic {
  id: string;
  name: string;
  status?: string;
}

export interface ApiSuccess<T> {
  success: true;
  message: string;
  data: T;
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
  };
}
