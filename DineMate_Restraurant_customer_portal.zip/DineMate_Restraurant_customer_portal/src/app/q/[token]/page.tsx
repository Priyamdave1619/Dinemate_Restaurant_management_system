import { redirect } from "next/navigation";
import Link from "next/link";
import { decryptQrTokenServer, resolveQrTokenServer } from "@/lib/crypto/qr-crypto-server";

/**
 * Encrypted QR landing page.
 * URL in QR:  /q/{token}
 * After decrypt → 302/redirect to /{restaurantId}/table/{tableNumber}
 * so the browser address bar shows the clean menu URL.
 */
export default async function EncryptedQrPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token: rawToken } = await params;
  // Next may decode path segments; restore base64url if needed
  const token = decodeURIComponent(rawToken || "").trim();

  if (token) {
    const resolved =
      decryptQrTokenServer(token) || (await resolveQrTokenServer(token));

    if (resolved) {
      const rid = encodeURIComponent(resolved.restaurantId);
      const tn = String(Math.floor(resolved.tableNumber));
      // Server redirect → address bar becomes plain menu URL
      redirect(`/${rid}/table/${tn}`);
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-surface-muted px-6 text-center">
      <p className="max-w-sm text-sm text-ink-muted">
        This QR code is invalid or could not be read. Please ask staff for a new one, or open the menu
        manually.
      </p>
      <Link
        href="/"
        className="mt-2 rounded-xl bg-brand-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-brand-700"
      >
        Go to home
      </Link>
    </div>
  );
}
