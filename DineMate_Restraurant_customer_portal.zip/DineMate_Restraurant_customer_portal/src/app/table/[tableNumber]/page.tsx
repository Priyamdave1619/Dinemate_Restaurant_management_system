"use client";

import { use, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { isValidRestaurantId, isValidTableNumber, sanitizeId } from "@/lib/validation/sanitize";
import { Loader2 } from "lucide-react";
import { Suspense } from "react";

/**
 * Legacy QR URL support:
 *   /table/{n}?restaurantId={id}
 * Redirects to the canonical route /{restaurantId}/table/{n}
 */
function LegacyTableRedirect({ tableNumber }: { tableNumber: string }) {
  const router = useRouter();
  const search = useSearchParams();

  useEffect(() => {
    const rid = sanitizeId(
      search.get("restaurantId") || search.get("r") || ""
    );
    const tn = String(Number(tableNumber));
    if (rid && isValidRestaurantId(rid) && isValidTableNumber(tn)) {
      router.replace(`/${rid}/table/${tn}`);
    } else {
      router.replace("/");
    }
  }, [tableNumber, search, router]);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-3">
      <Loader2 className="h-8 w-8 animate-spin text-brand-600" />
      <p className="text-sm text-ink-muted">Opening menu…</p>
    </div>
  );
}

export default function LegacyTablePage({
  params,
}: {
  params: Promise<{ tableNumber: string }>;
}) {
  const { tableNumber } = use(params);
  return (
    <Suspense
      fallback={
        <div className="flex min-h-screen items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-brand-600" />
        </div>
      }
    >
      <LegacyTableRedirect tableNumber={tableNumber} />
    </Suspense>
  );
}
