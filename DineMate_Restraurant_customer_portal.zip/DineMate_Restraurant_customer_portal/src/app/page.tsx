"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { QrCode } from "lucide-react";
import Image from "next/image";
import { ThemeToggle } from "@/components/theme-toggle";
import { QrScanner } from "@/components/qr-scanner";
import { toast } from "sonner";

export default function HomePage() {
  const router = useRouter();
  const [scannerOpen, setScannerOpen] = useState(false);

  function handleScan(result: { restaurantId: string; tableNumber: string }) {
    setScannerOpen(false);
    toast.success(`Table ${result.tableNumber} — opening menu`);
    router.push(`/${result.restaurantId}/table/${result.tableNumber}`);
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-b from-brand-50 via-surface-muted to-white dark:from-brand-950 dark:via-brand-950 dark:to-brand-900">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-32 -right-32 h-96 w-96 rounded-full bg-brand-400/10 blur-3xl dark:bg-brand-600/10" />
        <div className="absolute bottom-0 left-0 h-72 w-72 rounded-full bg-brand-300/10 blur-3xl dark:bg-brand-700/10" />
      </div>

      <div className="absolute right-4 top-4 z-10">
        <ThemeToggle />
      </div>

      <div className="relative mx-auto flex min-h-screen max-w-md flex-col items-center justify-center px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
          className="w-full text-center"
        >
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center overflow-hidden rounded-2xl bg-white shadow-glow dark:bg-brand-900">
            <Image
              src="/logos/logo-light.png"
              alt="DineMate"
              width={56}
              height={56}
              className="object-contain dark:hidden"
              priority
            />
            <Image
              src="/logos/logo-dark.png"
              alt="DineMate"
              width={56}
              height={56}
              className="hidden object-contain dark:block"
              priority
            />
          </div>

          <h1 className="text-2xl font-bold tracking-tight text-ink dark:text-brand-50 sm:text-3xl">
            Table ordering
          </h1>
          <p className="mt-2 text-sm text-ink-secondary dark:text-brand-300">
            Scan the QR code on your table to view the menu
          </p>

          <button
            type="button"
            onClick={() => setScannerOpen(true)}
            className="btn-primary mt-8 w-full py-3.5 text-sm"
          >
            <QrCode className="h-4 w-4" />
            Scan table QR code
          </button>

          <p className="mt-8 text-xs text-ink-muted dark:text-brand-400">
            Tip: You can also open the camera app and scan the table QR — it opens the menu
            directly.
          </p>
        </motion.div>
      </div>

      <QrScanner
        open={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onScan={handleScan}
      />
    </div>
  );
}
