"use client";

import { use, useEffect, useMemo, useState, useDeferredValue } from "react";
import { useQuery } from "@tanstack/react-query";
import { getMenu, getCategories, getSettings, getOffers, getRecommendations } from "@/lib/api/customer";
import { useCartStore, selectCartCount, selectCartTotal, selectActiveOrderId, selectOrderingLocked } from "@/lib/stores/cart-store";
import { MenuCard } from "@/components/menu-card";
import { CartSheet } from "@/components/cart-sheet";
import { ThemeToggle } from "@/components/theme-toggle";
import { ShoppingBag, Search, Tag, Flame, Sparkles } from "lucide-react";
import { formatCurrency } from "@/lib/utils/format";
import { sanitizeText } from "@/lib/validation/sanitize";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils/cn";
import { PageTransition } from "@/components/page-transition";
import { listContainer, listItem, fadeTransition, sheetTransition } from "@/lib/motion";
import { DIET_FILTERS, DietFilterIcon } from "@/components/icons";
import type { MenuCategory, MenuItem } from "@/types";

/** Shared query options for menu-session data (rarely changes while dining). */
const MENU_QUERY = {
  staleTime: 2 * 60_000,
  gcTime: 15 * 60_000,
} as const;

export default function TableMenuPage({
  params,
}: {
  params: Promise<{ restaurantId: string; tableNumber: string }>;
}) {
  const { restaurantId, tableNumber } = use(params);
  const tableNum = Number(tableNumber);
  const setContext = useCartStore((s) => s.setContext);
  const resetSession = useCartStore((s) => s.resetSession);
  const unlockOrdering = useCartStore((s) => s.unlockOrdering);
  // Select derived numbers so the bar re-renders when lines change
  const itemCount = useCartStore(selectCartCount);
  const cartTotal = useCartStore(selectCartTotal);
  const activeOrderId = useCartStore(selectActiveOrderId);
  const orderingLocked = useCartStore(selectOrderingLocked);
  const [cartOpen, setCartOpen] = useState(false);
  const [search, setSearch] = useState("");
  /** Deferred search keeps typing responsive while filtering stays off the critical path */
  const deferredSearch = useDeferredValue(search);
  const [activeCat, setActiveCat] = useState<string>("all");
  const [sessionEnded, setSessionEnded] = useState(false);
  const [dietFilter, setDietFilter] = useState<"all" | "veg" | "non-veg" | "jain" | "bestseller">("all");

  useEffect(() => {
    if (restaurantId && tableNum) setContext(restaurantId, tableNum);
  }, [restaurantId, tableNum, setContext]);

  // After bill auto-close fallback lands here — free table for next guest
  useEffect(() => {
    if (typeof window === "undefined") return;
    const url = new URL(window.location.href);
    if (url.searchParams.get("session") === "ended") {
      resetSession();
      setSessionEnded(true);
      url.searchParams.delete("session");
      window.history.replaceState({}, "", url.pathname);
    }
  }, [resetSession]);

  const {
    data: items,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["menu", restaurantId],
    queryFn: () => getMenu(restaurantId),
    enabled: !!restaurantId,
    ...MENU_QUERY,
  });

  const { data: categories } = useQuery({
    queryKey: ["categories", restaurantId],
    queryFn: () => getCategories(restaurantId),
    enabled: !!restaurantId,
    ...MENU_QUERY,
  });

  const {
    data: settings,
    isLoading: settingsLoading,
    isFetching: settingsFetching,
  } = useQuery({
    queryKey: ["settings", restaurantId],
    queryFn: () => getSettings(restaurantId),
    enabled: !!restaurantId,
    ...MENU_QUERY,
  });
  const settingsPending = settingsLoading || (settingsFetching && !settings);

  const { data: offers } = useQuery({
    queryKey: ["offers", restaurantId],
    queryFn: () => getOffers(restaurantId, true),
    enabled: !!restaurantId,
    staleTime: 60_000,
  });

  const { data: recommendations } = useQuery({
    queryKey: ["recommendations", restaurantId],
    queryFn: () => getRecommendations(restaurantId),
    enabled: !!restaurantId,
    ...MENU_QUERY,
  });

  useEffect(() => {
    const name = (settings?.restaurantName || "").trim();
    if (name) {
      document.title = `${name} · Table ${tableNum}`;
    } else if (restaurantId) {
      document.title = `${restaurantId} · Table ${tableNum}`;
    }
  }, [settings?.restaurantName, restaurantId, tableNum]);

  /** Item ids the recommendations engine actually ranks as bestsellers —
   *  the source of truth, since most items never carry a "bestseller" tag. */
  const bestsellerIds = useMemo(() => {
    const ids = new Set<string>();
    for (const r of recommendations?.bestsellers || []) ids.add(r.item.id);
    return ids;
  }, [recommendations]);

  /** Shared predicate so the diet filter behaves identically everywhere it's
   *  applied — the category list AND the Bestsellers/Recommended sections. */
  function matchesDiet(i: MenuItem, filter: typeof dietFilter): boolean {
    if (filter === "veg") {
      return (
        i.isVeg === true ||
        ["veg", "vegetarian", "vegan"].includes(String(i.foodType).toLowerCase())
      );
    }
    if (filter === "non-veg") {
      return (
        i.isVeg === false ||
        ["non-veg", "nonveg", "non_veg", "egg"].includes(String(i.foodType).toLowerCase())
      );
    }
    if (filter === "jain") {
      return (
        i.jainAvailable === true ||
        i.jainOnly === true ||
        (i.jainAvailable !== false &&
          (i.isVeg === true || ["veg", "vegetarian", "vegan"].includes(String(i.foodType).toLowerCase())))
      );
    }
    if (filter === "bestseller") {
      return (
        bestsellerIds.has(i.id) ||
        (i.tags || []).some((t) =>
          ["bestseller", "popular", "recommended"].includes(String(t).toLowerCase())
        )
      );
    }
    return true;
  }

  /** Only categories that currently have at least one available item. */
  const visibleCategories = useMemo(() => {
    const cats = categories || [];
    const list = items || [];
    return cats.filter((c) => {
      if (c.availableNow === false) return false;
      return list.some((i) => i.categoryId === c.id && i.available !== false);
    });
  }, [categories, items]);

  /** Items filtered by tab + search; respect availableNow when present. */
  const filtered = useMemo(() => {
    let list = (items || []).filter((i) => {
      if (i.available === false) return false;
      if (i.availableNow === false) return false;
      return true;
    });
    if (activeCat !== "all" && !deferredSearch.trim()) list = list.filter((i) => i.categoryId === activeCat);
    if (dietFilter !== "all") list = list.filter((i) => matchesDiet(i, dietFilter));
    if (deferredSearch.trim()) {
      const q = sanitizeText(deferredSearch, 100).toLowerCase();
      list = list.filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          i.description?.toLowerCase().includes(q) ||
          (i.tags || []).some((t) => String(t).toLowerCase().includes(q)) ||
          (i.ingredients || []).some((ing) => String(ing).toLowerCase().includes(q))
      );
    }
    return list;
  }, [items, activeCat, deferredSearch, dietFilter, bestsellerIds]);

  /**
   * Group filtered items by category for sectioned ("category-wise") layout.
   * When "All", preserve backend category order with section headings.
   */
  const grouped = useMemo(() => {
    const catMap = new Map<string, MenuCategory>();
    for (const c of categories || []) catMap.set(c.id, c);

    const order =
      activeCat === "all"
        ? (categories || []).map((c) => c.id)
        : [activeCat];

    const buckets = new Map<string, MenuItem[]>();
    for (const item of filtered) {
      const key = item.categoryId || "uncategorized";
      if (!buckets.has(key)) buckets.set(key, []);
      buckets.get(key)!.push(item);
    }

    const sections: Array<{ category: MenuCategory | null; items: MenuItem[] }> = [];
    const seen = new Set<string>();

    for (const id of order) {
      const sectionItems = buckets.get(id);
      if (!sectionItems?.length) continue;
      sections.push({ category: catMap.get(id) || null, items: sectionItems });
      seen.add(id);
    }
    for (const [id, sectionItems] of buckets) {
      if (seen.has(id) || !sectionItems.length) continue;
      sections.push({
        category: catMap.get(id) || { id, name: "Other" },
        items: sectionItems,
      });
    }
    return sections;
  }, [filtered, categories, activeCat]);

  const restaurantTitle = (settings?.restaurantName || "").trim();

  return (
    <div className="mx-auto min-h-screen max-w-lg bg-surface-muted pb-28 dark:bg-brand-950">
      <header className="sticky top-0 z-30 border-b border-line/80 bg-white/90 backdrop-blur-xl dark:border-brand-800 dark:bg-brand-950/90">
        <div className="px-4 pb-3 pt-4">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0 flex-1">
              {settingsPending ? (
                <div className="space-y-2" aria-busy="true" aria-label="Loading restaurant">
                  <div className="h-3 w-16 animate-pulse rounded bg-brand-100 dark:bg-brand-800" />
                  <div className="h-5 w-44 max-w-full animate-pulse rounded bg-brand-100 dark:bg-brand-800" />
                </div>
              ) : (
                <>
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-brand-600 dark:text-brand-400">
                    Table {tableNum}
                  </p>
                  <h1 className="truncate text-lg font-bold leading-tight text-ink dark:text-brand-50">
                    {restaurantTitle || "Restaurant"}
                  </h1>
                </>
              )}
            </div>
            <ThemeToggle />
          </div>
          <div className="relative mt-3">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-muted" aria-hidden />
            <label htmlFor="menu-search" className="sr-only">
              Search menu
            </label>
            <input
              id="menu-search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search menu…"
              className="input-premium py-2.5 pl-9 pr-3"
            />
          </div>
        </div>
        <div className="scrollbar-none flex gap-2 overflow-x-auto px-4 pb-3" role="tablist" aria-label="Categories">
          <motion.button
            type="button"
            role="tab"
            aria-selected={activeCat === "all"}
            onClick={() => setActiveCat("all")}
            whileTap={{ scale: 0.94 }}
            className={cn(
              "relative shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold",
              activeCat === "all"
                ? "text-white"
                : "text-ink-secondary dark:text-brand-200"
            )}
          >
            {activeCat === "all" && (
              <motion.span
                layoutId="active-category-pill"
                className="absolute inset-0 rounded-full bg-brand-500 shadow-sm"
                transition={sheetTransition}
              />
            )}
            {activeCat !== "all" && (
              <span className="absolute inset-0 rounded-full bg-brand-50 dark:bg-brand-800" />
            )}
            <span className="relative">All</span>
          </motion.button>
          {visibleCategories.map((c) => (
            <motion.button
              key={c.id}
              type="button"
              role="tab"
              aria-selected={activeCat === c.id}
              onClick={() => setActiveCat(c.id)}
              whileTap={{ scale: 0.94 }}
              className={cn(
                "relative shrink-0 rounded-full px-3.5 py-1.5 text-xs font-semibold",
                activeCat === c.id
                  ? "text-white"
                  : "text-ink-secondary dark:text-brand-200"
              )}
            >
              {activeCat === c.id ? (
                <motion.span
                  layoutId="active-category-pill"
                  className="absolute inset-0 rounded-full bg-brand-500 shadow-sm"
                  transition={sheetTransition}
                />
              ) : (
                <span className="absolute inset-0 rounded-full bg-brand-50 dark:bg-brand-800" />
              )}
              <span className="relative">
                {c.icon ? `${c.icon} ` : ""}
                {c.name}
              </span>
            </motion.button>
          ))}
        </div>

        <div className="scrollbar-none flex gap-2 overflow-x-auto px-4 pb-3" role="group" aria-label="Dietary filters">
          {DIET_FILTERS.map((f) => {
            const active = dietFilter === f.id;
            return (
              <motion.button
                key={f.id}
                type="button"
                onClick={() => setDietFilter(f.id)}
                whileTap={{ scale: 0.92 }}
                className={cn(
                  "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11px] font-semibold transition-colors",
                  active
                    ? "border-brand-500 bg-brand-500 text-white shadow-sm"
                    : "border-line bg-white text-ink-secondary dark:border-brand-700 dark:bg-brand-900 dark:text-brand-200"
                )}
              >
                <DietFilterIcon id={f.id} active={active} />
                {f.label}
              </motion.button>
            );
          })}
        </div>
      </header>

      {(offers || []).length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={fadeTransition}
          className="space-y-2 px-4 pt-3"
        >
          {(offers || []).slice(0, 3).map((o) => (
            <div
              key={o.id}
              className="flex items-start gap-2 rounded-xl border border-amber-200/80 bg-amber-50 px-3 py-2 text-xs text-amber-900 dark:border-amber-900/40 dark:bg-amber-950/30 dark:text-amber-200"
            >
              <Tag className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
              <div>
                <p className="font-semibold">{o.name}</p>
                {o.description && <p className="opacity-80">{o.description}</p>}
              </div>
            </div>
          ))}
        </motion.div>
      )}

      <AnimatePresence>
        {sessionEnded && !orderingLocked && (
          <motion.div
            initial={{ opacity: 0, y: -6, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={fadeTransition}
            className="mx-4 mt-3 overflow-hidden rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2.5 text-xs text-emerald-900 dark:border-emerald-900/40 dark:bg-emerald-950/30 dark:text-emerald-200"
          >
            <p className="font-semibold">Thank you — table is ready for the next guest</p>
            <p className="opacity-90">You can start a new order from this menu whenever you like.</p>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {orderingLocked && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={fadeTransition}
            className="mx-4 mt-3 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-xs text-red-800 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-200"
          >
            <p className="font-semibold">Ordering closed for this session</p>
            <p className="opacity-90">
              Bill has been requested. This session will end shortly so the next guest can order.
            </p>
            <motion.button
              type="button"
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                resetSession();
                unlockOrdering();
                setSessionEnded(true);
              }}
              className="mt-2 rounded-full bg-red-600 px-3 py-1 text-[11px] font-semibold text-white"
            >
              Start new order
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {activeOrderId && !orderingLocked && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={fadeTransition}
            className="mx-4 mt-3 flex items-start justify-between gap-2 rounded-xl border border-brand-200 bg-brand-50 px-3 py-2.5 text-xs text-brand-900 dark:border-brand-900/40 dark:bg-brand-950/30 dark:text-brand-200"
          >
            <div>
              <p className="font-semibold">Open order</p>
              <p className="opacity-90">You can keep adding items until the bill is requested.</p>
            </div>
            <a
              href={`/${restaurantId}/table/${tableNum}/order/${activeOrderId}`}
              className="shrink-0 rounded-full bg-brand-500 px-3 py-1 text-[11px] font-semibold text-white transition hover:bg-brand-600 active:scale-95"
            >
              View order
            </a>
          </motion.div>
        )}
      </AnimatePresence>

      <PageTransition className="space-y-6 px-4 py-4" as="main">
        {isLoading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading menu">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="skeleton h-28 rounded-2xl" />
            ))}
          </div>
        )}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={fadeTransition}
            className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/40 dark:text-amber-200"
            role="alert"
          >
            Could not load menu. Check that the restaurant ID is correct and the backend allows
            customer access for this tenant.
          </motion.div>
        )}

        {!isLoading && !error && (recommendations?.bestsellers?.length ?? 0) > 0 && activeCat === "all" && !search.trim() && (() => {
          const bestsellers = recommendations!.bestsellers.filter((r) => matchesDiet(r.item, dietFilter));
          if (bestsellers.length === 0) return null;
          return (
          <motion.section
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={fadeTransition}
            aria-labelledby="bestsellers-heading"
          >
            <h2
              id="bestsellers-heading"
              className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-ink-secondary dark:text-brand-300"
            >
              <Flame className="h-4 w-4 text-orange-500" aria-hidden />
              Bestsellers
            </h2>
            <motion.div variants={listContainer} initial="hidden" animate="show" className="space-y-3">
              {bestsellers.map((r) => (
                <motion.div key={r.item.id} variants={listItem} className="relative">
                  <span className="absolute left-2 top-2 z-10 rounded-full bg-orange-500 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white shadow-sm">
                    {r.reason || "Bestseller"}
                  </span>
                  <MenuCard item={r.item} />
                </motion.div>
              ))}
            </motion.div>
          </motion.section>
          );
        })()}

        {!isLoading && !error && (recommendations?.recommended?.length ?? 0) > 0 && activeCat === "all" && !search.trim() && (() => {
          const recommended = recommendations!.recommended.filter((r) => matchesDiet(r.item, dietFilter));
          if (recommended.length === 0) return null;
          return (
          <motion.section
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...fadeTransition, delay: 0.05 }}
            aria-labelledby="recommended-heading"
          >
            <h2
              id="recommended-heading"
              className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-ink-secondary dark:text-brand-300"
            >
              <Sparkles className="h-4 w-4 text-amber-500" aria-hidden />
              Recommended for you
            </h2>
            <motion.div variants={listContainer} initial="hidden" animate="show" className="space-y-3">
              {recommended.map((r) => (
                <motion.div key={r.item.id} variants={listItem} className="relative">
                  <span className="absolute left-2 top-2 z-10 rounded-full bg-amber-500 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white shadow-sm">
                    {r.reason || "Recommended"}
                  </span>
                  <MenuCard item={r.item} />
                </motion.div>
              ))}
            </motion.div>
          </motion.section>
          );
        })()}

        <AnimatePresence mode="popLayout">
          {!isLoading &&
            !error &&
            grouped.map((section) => (
              <motion.section
                key={section.category?.id || "other"}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6, transition: { duration: 0.15 } }}
                transition={fadeTransition}
                aria-labelledby={`cat-${section.category?.id || "other"}`}
              >
                {section.category && (
                  <h2
                    id={`cat-${section.category.id}`}
                    className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wide text-ink-secondary dark:text-brand-300"
                  >
                    {section.category.icon && (
                      <span className="text-base" aria-hidden>
                        {section.category.icon}
                      </span>
                    )}
                    {section.category.name}
                    <span className="ml-1 rounded-full bg-brand-100/80 px-2 py-0.5 text-[10px] font-semibold normal-case text-ink-muted dark:bg-brand-800">
                      {section.items.length}
                    </span>
                  </h2>
                )}
                <motion.div
                  variants={listContainer}
                  initial="hidden"
                  animate="show"
                  className="space-y-3"
                >
                  <AnimatePresence mode="popLayout">
                    {section.items.map((item) => (
                      <motion.div key={item.id} layout variants={listItem} initial="hidden" animate="show" exit="exit">
                        <MenuCard item={item} />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </motion.div>
              </motion.section>
            ))}
        </AnimatePresence>

        <AnimatePresence>
          {!isLoading && filtered.length === 0 && !error && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={fadeTransition}
              className="py-16 text-center text-sm text-ink-muted"
            >
              No items found
            </motion.p>
          )}
        </AnimatePresence>
      </PageTransition>

      <AnimatePresence>
        {itemCount > 0 && (
          <motion.div
            initial={{ y: 80, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 80, opacity: 0 }}
            transition={sheetTransition}
            className="fixed inset-x-0 bottom-0 z-20 mx-auto max-w-lg p-4"
          >
            <motion.button
              type="button"
              onClick={() => setCartOpen(true)}
              whileTap={{ scale: 0.98 }}
              className="flex w-full items-center justify-between rounded-2xl bg-brand-800 px-5 py-4 text-white shadow-elevated transition-colors hover:bg-brand-700 dark:bg-brand-600 dark:hover:bg-brand-500"
            >
              <div className="flex items-center gap-3">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white/15">
                  <ShoppingBag className="h-4 w-4" />
                </span>
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.span
                    key={itemCount}
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 8 }}
                    transition={fadeTransition}
                    className="inline-block text-sm font-semibold"
                  >
                    {itemCount} items
                  </motion.span>
                </AnimatePresence>
              </div>
              <span className="font-bold">{formatCurrency(cartTotal)} · View cart</span>
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      <CartSheet open={cartOpen} onClose={() => setCartOpen(false)} />
    </div>
  );
}
