"use client";

import { use, useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getOrderStatus, getOrderBill } from "@/lib/api/customer";
import { formatCurrency } from "@/lib/utils/format";
import { downloadBillPdf, printBill, publicRef, restaurantDisplayName } from "@/lib/utils/bill-receipt";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  CheckCircle2,
  Clock,
  ChefHat,
  Bell,
  ArrowLeft,
  Receipt,
  Download,
  Printer,
  Loader2,
} from "lucide-react";
import { motion } from "framer-motion";
import { ThemeToggle } from "@/components/theme-toggle";
import { cn } from "@/lib/utils/cn";
import { toast } from "sonner";
import { getErrorMessage } from "@/lib/api/client";
import { useCartStore } from "@/lib/stores/cart-store";
import type { Order, RestaurantSettings } from "@/types";

const STATUS_STEPS = [
  { key: "accepted", label: "Received", icon: CheckCircle2 },
  { key: "preparing", label: "Cooking", icon: ChefHat },
  { key: "ready", label: "Ready", icon: Bell },
  { key: "served", label: "Served", icon: CheckCircle2 },
];

function stepIndex(status: string) {
  const map: Record<string, number> = {
    pending: 0,
    accepted: 0,
    preparing: 1,
    ready: 2,
    served: 3,
    completed: 3,
    cancelled: -1,
  };
  return map[status] ?? 0;
}

function formatDate(iso?: string) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

export default function OrderStatusPage({
  params,
}: {
  params: Promise<{ restaurantId: string; tableNumber: string; orderId: string }>;
}) {
  const { restaurantId, tableNumber, orderId } = use(params);
  const router = useRouter();
  const setActiveOrder = useCartStore((s) => s.setActiveOrder);
  const lockOrdering = useCartStore((s) => s.lockOrdering);
  const resetSession = useCartStore((s) => s.resetSession);
  const [billLoading, setBillLoading] = useState(false);
  const [billOrder, setBillOrder] = useState<Order | null>(null);
  const [billSettings, setBillSettings] = useState<RestaurantSettings | null>(null);
  const autoFetched = useRef(false);
  /** Seconds left before tab closes after bill success (null = not counting). */
  const [closeIn, setCloseIn] = useState<number | null>(null);
  const closeStarted = useRef(false);

  const isDone = (o?: Order | null) =>
    !!o && (o.status === "completed" || o.billGenerated === true);

  const { data: order, isLoading, refetch } = useQuery({
    queryKey: ["order", orderId],
    queryFn: () => getOrderStatus(orderId),
    // Stop polling once completed / billed — bill view takes over
    refetchInterval: (q) => (isDone(q.state.data) ? false : 8000),
  });

  const idx = order ? stepIndex(order.status) : 0;

  async function loadBill(opts?: { finalize?: boolean }) {
    setBillLoading(true);
    try {
      const { order: o, settings } = await getOrderBill(orderId);
      setBillOrder(o);
      setBillSettings(settings ?? null);
      if (o.billGenerated || o.status === "completed") {
        lockOrdering();
      } else {
        setActiveOrder(o.id);
      }
      if (opts?.finalize) {
        toast.success(o.billNumber ? `Bill ${o.billNumber} ready` : "Bill ready");
        await refetch();
      }
      return o;
    } catch (e) {
      toast.error(getErrorMessage(e));
      return null;
    } finally {
      setBillLoading(false);
    }
  }

  // When staff completes the order or generates a bill, auto-load & show it
  useEffect(() => {
    if (!order) return;
    if (!isDone(order)) return;
    if (autoFetched.current) return;
    autoFetched.current = true;
    void loadBill();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order?.status, order?.billGenerated, order?.id]);


  // Keep session order id while still open; lock when already billed
  useEffect(() => {
    if (!order) return;
    if (order.billGenerated || order.status === "completed") {
      lockOrdering();
    } else if (order.status !== "cancelled") {
      setActiveOrder(order.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order?.id, order?.status, order?.billGenerated]);

  // After bill is successfully generated: 30s countdown → clear session → close tab
  // so the next guest can order freely on this device / table QR.
  useEffect(() => {
    const billed =
      !!(billOrder?.billGenerated || billOrder?.status === "completed") ||
      !!(order?.billGenerated || order?.status === "completed");
    if (!billed || closeStarted.current) return;
    closeStarted.current = true;
    setCloseIn(30);

    const interval = window.setInterval(() => {
      setCloseIn((prev) => {
        if (prev == null) return null;
        if (prev <= 1) {
          window.clearInterval(interval);
          // Free the device for the next customer
          resetSession();
          try {
            window.close();
          } catch {
            /* browsers often block window.close for non-script-opened tabs */
          }
          // Fallback: leave order page so a new scan can start clean
          router.replace(`/${restaurantId}/table/${tableNumber}?session=ended`);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => window.clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [billOrder?.billGenerated, billOrder?.status, order?.billGenerated, order?.status]);

  const display = billOrder || order;
  const showBillView = isDone(order) || !!billOrder;

  function handleDownload() {
    const o = billOrder || order;
    if (!o) return;
    downloadBillPdf(o, billSettings);
    toast.success("Bill PDF downloaded");
  }

  function handlePrint() {
    const o = billOrder || order;
    if (!o) return;
    const ok = printBill(o, billSettings);
    if (!ok) toast.error("Could not open print dialog — try Download instead");
  }

  return (
    <div className="mx-auto min-h-screen max-w-lg bg-surface-muted dark:bg-brand-950">
      <header className="border-b border-line bg-white px-4 py-4 dark:border-brand-800 dark:bg-brand-950">
        <div className="flex items-start justify-between">
          <div>
            <Link
              href={`/${restaurantId}/table/${tableNumber}`}
              className="inline-flex items-center gap-1.5 text-sm text-ink-secondary transition hover:text-ink dark:text-brand-300 dark:hover:text-white"
            >
              <ArrowLeft className="h-4 w-4" /> Back to menu
            </Link>
            <h1 className="mt-2 text-xl font-bold text-ink dark:text-brand-50">
              {showBillView ? "Your bill" : "Order status"}
            </h1>
            <p className="text-xs text-ink-muted">
              Table {tableNumber}
              {display?.billNumber ? ` · Bill ${publicRef(display.billNumber)}` : ""}
            </p>
          </div>
          <ThemeToggle />
        </div>
      </header>

      <main className="space-y-6 px-4 py-6">
        {isLoading && !display && (
          <div className="skeleton h-40 rounded-2xl" aria-busy="true" aria-label="Loading order" />
        )}

        {order && order.status === "cancelled" && (
          <div className="rounded-2xl border border-red-200 bg-red-50 p-5 text-center dark:border-red-900/50 dark:bg-red-950/40">
            <p className="font-semibold text-red-700 dark:text-red-300">Order cancelled</p>
          </div>
        )}

        {/* Progress — hide once completed/billed */}
        {order && order.status !== "cancelled" && !showBillView && (
          <div className="card-premium p-5">
            <div className="flex justify-between" role="list" aria-label="Order progress">
              {STATUS_STEPS.map((s, i) => {
                const Icon = s.icon;
                const done = i <= idx;
                return (
                  <div key={s.key} className="flex flex-1 flex-col items-center" role="listitem">
                    <div
                      className={cn(
                        "flex h-10 w-10 items-center justify-center rounded-full transition-colors",
                        done
                          ? "bg-brand-500 text-white shadow-sm"
                          : "bg-brand-50 text-ink-muted dark:bg-brand-800 dark:text-brand-400"
                      )}
                    >
                      <Icon className="h-5 w-5" aria-hidden />
                    </div>
                    <p
                      className={cn(
                        "mt-2 text-[11px] font-medium",
                        done ? "text-ink dark:text-brand-50" : "text-ink-muted"
                      )}
                    >
                      {s.label}
                    </p>
                  </div>
                );
              })}
            </div>
            <p className="mt-4 text-center text-sm text-ink-secondary dark:text-brand-300 capitalize">
              Current:{" "}
              <span className="font-semibold text-ink dark:text-brand-50">{order.status}</span>
            </p>
          </div>
        )}

        {/* Completed banner */}
        {showBillView && order?.status !== "cancelled" && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-center dark:border-emerald-900/50 dark:bg-emerald-950/40"
          >
            <CheckCircle2 className="mx-auto h-8 w-8 text-emerald-600 dark:text-emerald-400" />
            <p className="mt-2 font-semibold text-emerald-800 dark:text-emerald-200">
              Order completed
            </p>
            <p className="text-xs text-emerald-700/80 dark:text-emerald-300/80">
              Your bill is ready below
            </p>
          </motion.div>
        )}

        {/* Full bill card */}
        {display && order?.status !== "cancelled" && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="card-premium space-y-4 p-5"
            id="customer-bill"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <h2 className="flex items-center gap-2 font-semibold text-ink dark:text-brand-50">
                  <Receipt className="h-4 w-4 text-brand-600" />
                  {showBillView ? "Bill" : "Items"}
                  {display.billNumber ? (
                    <span className="rounded-full bg-brand-50 px-2 py-0.5 text-[11px] font-bold text-brand-700 dark:bg-brand-950 dark:text-brand-300">
                      {publicRef(display.billNumber)}
                    </span>
                  ) : null}
                </h2>
                {(billSettings || display) && (
                  <div className="mt-0.5 space-y-0.5">
                    <p className="text-sm text-ink-secondary dark:text-brand-300">
                      {restaurantDisplayName(display, billSettings)}
                    </p>
                    {billSettings?.address ? (
                      <p className="text-[11px] leading-snug text-ink-muted break-words">
                        {billSettings.address}
                      </p>
                    ) : null}
                    {billSettings?.phone ? (
                      <p className="text-[11px] text-ink-muted">Ph: {billSettings.phone}</p>
                    ) : null}
                    {billSettings?.foodLicence ? (
                      <p className="text-[11px] text-ink-muted">
                        Food Lic: {billSettings.foodLicence}
                      </p>
                    ) : null}
                  </div>
                )}
                {showBillView && (
                  <p className="mt-1 text-[11px] text-ink-muted">
                    {display.billedAt
                      ? `Billed ${formatDate(display.billedAt)}`
                      : `Placed ${formatDate(display.placedAt)}`}
                    {display.customerName ? ` · ${display.customerName}` : ""}
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-3">
              {display.items?.map((it) => (
                <div key={it.id} className="flex items-start justify-between gap-3 text-sm">
                  <div className="min-w-0 flex-1">
                    <p className="break-words font-medium text-ink dark:text-brand-100">
                      {it.name}
                      {it.variant ? (
                        <span className="font-normal text-ink-muted"> ({it.variant})</span>
                      ) : null}
                    </p>
                    {(it.preparation === "jain" ||
                      it.spiceLevelSelected ||
                      (it.addOns && it.addOns.length > 0) ||
                      it.cookingRequest ||
                      it.note) && (
                      <p className="mt-0.5 text-[11px] leading-snug text-ink-muted">
                        {[
                          it.preparation === "jain" ? "Jain" : null,
                          it.spiceLevelSelected,
                          it.addOns?.map((a) => a.label).join(", "),
                          it.cookingRequest ? `“${it.cookingRequest}”` : null,
                          !it.cookingRequest && it.note ? it.note : null,
                        ]
                          .filter(Boolean)
                          .join(" · ")}
                      </p>
                    )}
                    <p className="mt-0.5 text-xs text-ink-muted">
                      {formatCurrency(it.price)} × {it.quantity}
                    </p>
                  </div>
                  <span className="shrink-0 font-semibold tabular-nums text-ink dark:text-brand-50">
                    {formatCurrency(it.price * it.quantity)}
                  </span>
                </div>
              ))}
            </div>

            <div className="space-y-1.5 border-t border-line pt-3 dark:border-brand-800">
              <div className="flex justify-between text-sm text-ink-secondary">
                <span>Subtotal</span>
                <span>{formatCurrency(display.subtotal)}</span>
              </div>
              {typeof display.discountTotal === "number" && display.discountTotal > 0 && (
                <div className="flex justify-between text-sm text-emerald-600">
                  <span>Discount</span>
                  <span>−{formatCurrency(display.discountTotal)}</span>
                </div>
              )}
              {typeof display.taxAmount === "number" && display.taxAmount > 0 && (
                <div className="flex justify-between text-sm text-ink-secondary">
                  <span>
                    Tax{display.taxRatePercent ? ` (${display.taxRatePercent}%)` : ""}
                  </span>
                  <span>{formatCurrency(display.taxAmount)}</span>
                </div>
              )}
              <div className="flex justify-between pt-1 text-base font-bold">
                <span className="text-ink dark:text-brand-50">
                  {showBillView ? "Payable" : "Total"}
                </span>
                <span className="text-brand-600">{formatCurrency(display.total)}</span>
              </div>
            </div>

            {/* Download / Print — shown once bill is available */}
            {showBillView && (
              <div className="grid grid-cols-1 gap-2 pt-1 min-[380px]:grid-cols-2">
                <button
                  type="button"
                  onClick={handleDownload}
                  className="btn-primary flex items-center justify-center gap-2 py-3 text-sm"
                >
                  <Download className="h-4 w-4 shrink-0" />
                  Download PDF
                </button>
                <button
                  type="button"
                  onClick={handlePrint}
                  className="flex items-center justify-center gap-2 rounded-xl border border-line bg-white px-4 py-3 text-sm font-semibold text-ink transition hover:bg-brand-50 dark:border-brand-700 dark:bg-brand-900 dark:text-white dark:hover:bg-brand-800"
                >
                  <Printer className="h-4 w-4 shrink-0" />
                  Print bill
                </button>
              </div>
            )}
          </motion.div>
        )}

        

        {closeIn != null && closeIn > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="rounded-2xl border border-brand-200 bg-brand-50 px-4 py-3 text-center dark:border-brand-700 dark:bg-brand-900/40"
          >
            <p className="text-sm font-semibold text-brand-800 dark:text-brand-100">
              Thank you! This session will close in {closeIn}s
            </p>
            <p className="mt-1 text-xs text-brand-700/80 dark:text-brand-200/80">
              The table will be free for the next guest. You can close this tab now.
            </p>
            <button
              type="button"
              onClick={() => {
                resetSession();
                try {
                  window.close();
                } catch {
                  /* ignore */
                }
                router.replace(`/${restaurantId}/table/${tableNumber}?session=ended`);
              }}
              className="mt-3 inline-flex rounded-xl bg-brand-600 px-4 py-2 text-xs font-semibold text-white hover:bg-brand-700"
            >
              Close now
            </button>
          </motion.div>
        )}

            {order && !showBillView && order.status !== "cancelled" && (
              <Link
                href={`/${restaurantId}/table/${tableNumber}`}
                className="btn-primary flex w-full items-center justify-center gap-2 py-3"
              >
                Add more items
              </Link>
            )}

            {/* Request bill while order is still active (not completed yet) */}
        {order &&
          order.status !== "cancelled" &&
          !isDone(order) &&
          !billOrder && (
            <button
              type="button"
              disabled={billLoading}
              onClick={() => loadBill({ finalize: true })}
              className="btn-primary flex w-full items-center justify-center gap-2 py-3"
            >
              {billLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Preparing bill…
                </>
              ) : (
                <>
                  <Receipt className="h-4 w-4" /> Request bill
                </>
              )}
            </button>
          )}

        {billLoading && showBillView && !billOrder && (
          <div className="flex items-center justify-center gap-2 text-sm text-ink-muted">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading bill…
          </div>
        )}

        {!showBillView && order?.status !== "cancelled" && (
          <p className="flex items-center justify-center gap-1.5 text-xs text-ink-muted">
            <Clock className="h-3.5 w-3.5" aria-hidden /> Updates automatically — bill appears when
            order is completed
          </p>
        )}
      </main>
    </div>
  );
}
