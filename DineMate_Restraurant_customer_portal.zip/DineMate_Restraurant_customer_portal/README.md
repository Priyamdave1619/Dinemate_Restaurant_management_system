# DineMate Customer Portal

Premium table ordering experience for diners (QR → menu → cart → live order status).

Built with Next.js 15, Tailwind, Framer Motion, TanStack Query, and Zustand.  
Design system: **Royal Blue** enterprise palette with full light/dark support.

## Features

- **Table menu** — `/[restaurantId]/table/[tableNumber]`
- Category chips + search with client-side sanitization
- Cart (bottom sheet) with variants, quantity, optional name
- Place order → live status polling
- Landing page with validated manual entry
- Theme toggle (system preference + persistent choice)
- Branded loader, accessibility (ARIA, focus rings, keyboard)
- Favicons & logos from brand kit

## Setup

```bash
cp .env.example .env.local   # or create with NEXT_PUBLIC_API_URL=http://localhost:3000
npm install
npm run dev                 # http://localhost:3003
```

### QR URL shape

Encrypted (canonical — what the backend encodes into QR images):

```
http://localhost:3003/q/{encryptedToken}
```

The token is AES-256-GCM encrypted `{ restaurantId, tableNumber }`. On open,
`/q/[token]` decrypts and redirects to the menu.

Plain / legacy forms still work:

```
http://localhost:3003/{restaurantId}/table/{tableNumber}
http://localhost:3003/table/{tableNumber}?restaurantId={id}
```

Set backend `NEXT_PUBLIC_BASE_URL` to this origin and add it to `ALLOWED_ORIGINS`.
Set the same `NEXT_PUBLIC_QR_SECRET` / `QR_SECRET` on backend and customer portal.

### Security notes

- Client sanitizes free text and IDs before API calls
- Backend remains the source of truth for auth, rate limits, and validation
- CORS + CSRF protections live in the DineMate API (`proxy.ts`)
