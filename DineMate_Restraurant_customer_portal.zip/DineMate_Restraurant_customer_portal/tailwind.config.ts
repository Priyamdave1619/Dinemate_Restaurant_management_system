import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#EEF3FB",
          100: "#D6E4F7",
          200: "#B0CAF0",
          300: "#7FA6E3",
          400: "#4D7FD1",
          500: "#1E4A9C",
          600: "#183D82",
          700: "#14326B",
          800: "#102855",
          900: "#0C1F42",
          950: "#0A1628",
        },
        surface: {
          DEFAULT: "#FFFFFF",
          muted: "#F4F7FC",
          elevated: "#FFFFFF",
        },
        ink: {
          DEFAULT: "#0B1F3A",
          secondary: "#3D5A80",
          muted: "#7A93B0",
        },
        line: {
          DEFAULT: "#D6E0EF",
          strong: "#B8C7DC",
        },
        success: "#22C55E",
        warning: "#F59E0B",
        danger: "#EF4444",
        info: "#3B82F6",
      },
      fontFamily: {
        sans: ["var(--font-geist)", "Inter", "system-ui", "sans-serif"],
      },
      borderRadius: {
        xl: "12px",
        "2xl": "16px",
        "3xl": "20px",
      },
      boxShadow: {
        soft: "0 4px 24px -4px rgba(11, 31, 58, 0.08)",
        card: "0 2px 12px -2px rgba(11, 31, 58, 0.06)",
        elevated: "0 8px 32px -8px rgba(11, 31, 58, 0.14)",
        glow: "0 0 0 1px rgba(30, 74, 156, 0.15), 0 4px 16px -2px rgba(30, 74, 156, 0.22)",
        "glow-lg": "0 0 0 1px rgba(30, 74, 156, 0.2), 0 8px 32px -4px rgba(30, 74, 156, 0.28)",
      },
      animation: {
        "fade-in": "fadeIn 0.3s ease-out",
        "slide-up": "slideUp 0.35s cubic-bezier(0.16, 1, 0.3, 1)",
        "scale-in": "scaleIn 0.25s ease-out",
        "pulse-soft": "pulseSoft 2s ease-in-out infinite",
        shimmer: "shimmer 1.5s infinite",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideUp: {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        scaleIn: {
          "0%": { opacity: "0", transform: "scale(0.96)" },
          "100%": { opacity: "1", transform: "scale(1)" },
        },
        pulseSoft: {
          "0%, 100%": { opacity: "1" },
          "50%": { opacity: "0.7" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};

export default config;
