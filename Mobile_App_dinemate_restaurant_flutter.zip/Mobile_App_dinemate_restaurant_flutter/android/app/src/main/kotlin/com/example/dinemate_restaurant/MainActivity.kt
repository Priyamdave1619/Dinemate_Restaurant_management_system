package com.example.dinemate_restaurant

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
