# Dinemate — Ultra-Premium Restaurant Portal

Luxury Flutter app for **Owner / Manager / Waiter**.

**Brand:** Dinemate  
**Primary:** Royal Navy (`#0B2A4A`) · Deep Navy (`#071A2F`)  
**Design:** Ultra-premium hospitality + FinTech polish

## Highlights

- Cinematic splash with refined motion
- Custom Dinemate bottom navigation
- Premium metric cards & order tiles
- Design system: colors, tokens, buttons, cards, skeletons, empty states
- Full feature parity with Next.js portal
- Riverpod · Dio · Secure storage · Light/Dark

## Modules

Auth · Dashboard · Orders · Menu · Tables & QR · Staff · Finance · Offers · Reports · Notifications · Activity · Settings · Subscription · Profile

## Setup

```bash
cd dinemate_restaurant_flutter
flutter pub get
flutter run
# optional: --dart-define=API_BASE_URL=https://your-api.com
```

**Login:** Restaurant ID (owner) or staff username + password.

## Structure

```
lib/
  core/theme/     app_theme, dinemate_tokens
  widgets/
    dinemate/     DinemateButton, DinemateCard, MetricCard
    common/       brand, empty, loading, status
  screens/        splash + all features
  providers/ services/ models/
```
