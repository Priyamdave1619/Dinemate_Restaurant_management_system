import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/core/responsive/dinemate_breakpoints.dart';

/// Rebuilds when layout category changes (compact / medium / expanded / large).
class DinemateResponsiveBuilder extends StatelessWidget {
  final Widget Function(BuildContext context, DinemateLayout layout, BoxConstraints constraints)
      builder;

  const DinemateResponsiveBuilder({super.key, required this.builder});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final w = constraints.maxWidth.isFinite
            ? constraints.maxWidth
            : MediaQuery.sizeOf(context).width;
        final layout = DinemateBreakpoints.ofWidth(w);
        return builder(context, layout, constraints);
      },
    );
  }
}

/// Centers content and caps max width on large screens.
class DinemateConstrainedContent extends StatelessWidget {
  final Widget child;
  final double maxWidth;
  final EdgeInsetsGeometry? padding;

  const DinemateConstrainedContent({
    super.key,
    required this.child,
    this.maxWidth = DinemateBreakpoints.maxContentWidth,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: maxWidth),
        child: padding != null ? Padding(padding: padding!, child: child) : child,
      ),
    );
  }
}

/// Responsive page padding based on width.
class DinematePagePadding extends StatelessWidget {
  final Widget child;

  const DinematePagePadding({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final layout = DinemateBreakpoints.of(context);
    return Padding(
      padding: DinemateBreakpoints.pagePadding(layout),
      child: child,
    );
  }
}

/// Simple responsive value picker.
T dinemateValue<T>(
  BuildContext context, {
  required T compact,
  T? medium,
  T? expanded,
  T? large,
}) {
  switch (DinemateBreakpoints.of(context)) {
    case DinemateLayout.compact:
      return compact;
    case DinemateLayout.medium:
      return medium ?? compact;
    case DinemateLayout.expanded:
      return expanded ?? medium ?? compact;
    case DinemateLayout.large:
      return large ?? expanded ?? medium ?? compact;
  }
}
