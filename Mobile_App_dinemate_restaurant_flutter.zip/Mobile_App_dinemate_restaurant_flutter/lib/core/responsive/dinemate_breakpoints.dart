import 'package:flutter/material.dart';

/// Centralized layout width categories for Dinemate.
enum DinemateLayout { compact, medium, expanded, large }

class DinemateBreakpoints {
  DinemateBreakpoints._();

  static const double compactMax = 599; // phones
  static const double mediumMax = 1023; // tablets / large phones landscape
  static const double expandedMax = 1439; // small desktop
  // large = 1440+

  static const double maxContentWidth = 1280;
  static const double maxFormWidth = 560;
  static const double maxDialogWidth = 480;

  static DinemateLayout ofWidth(double width) {
    if (width <= compactMax) return DinemateLayout.compact;
    if (width <= mediumMax) return DinemateLayout.medium;
    if (width <= expandedMax) return DinemateLayout.expanded;
    return DinemateLayout.large;
  }

  static DinemateLayout of(BuildContext context) {
    return ofWidth(MediaQuery.sizeOf(context).width);
  }

  static bool isCompact(BuildContext context) =>
      of(context) == DinemateLayout.compact;

  static bool isMedium(BuildContext context) =>
      of(context) == DinemateLayout.medium;

  static bool isExpanded(BuildContext context) {
    final l = of(context);
    return l == DinemateLayout.expanded || l == DinemateLayout.large;
  }

  /// Grid columns for card grids (menu, tables, offers).
  static int gridColumns(double width, {int min = 1, int max = 4}) {
    int cols;
    if (width < 360) {
      cols = 1;
    } else if (width < 600) {
      cols = 2;
    } else if (width < 900) {
      cols = 3;
    } else if (width < 1200) {
      cols = 4;
    } else {
      cols = 5;
    }
    return cols.clamp(min, max);
  }

  /// Metric / KPI columns on dashboard.
  static int metricColumns(double width) {
    if (width < 480) return 2;
    if (width < 900) return 2;
    if (width < 1200) return 4;
    return 4;
  }

  static EdgeInsets pagePadding(DinemateLayout layout) {
    switch (layout) {
      case DinemateLayout.compact:
        return const EdgeInsets.symmetric(horizontal: 16, vertical: 12);
      case DinemateLayout.medium:
        return const EdgeInsets.symmetric(horizontal: 24, vertical: 16);
      case DinemateLayout.expanded:
      case DinemateLayout.large:
        return const EdgeInsets.symmetric(horizontal: 32, vertical: 20);
    }
  }

  static double gutter(DinemateLayout layout) {
    switch (layout) {
      case DinemateLayout.compact:
        return 12;
      case DinemateLayout.medium:
        return 16;
      case DinemateLayout.expanded:
      case DinemateLayout.large:
        return 20;
    }
  }
}
