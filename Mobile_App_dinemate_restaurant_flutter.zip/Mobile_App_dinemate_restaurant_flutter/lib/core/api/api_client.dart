import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dinemate_restaurant/core/constants/app_constants.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';

/// Persists session so force-killing the app does not log the user out.
///
/// Strategy:
/// 1. Write tokens + user to both FlutterSecureStorage AND SharedPreferences
/// 2. On read, try secure storage first, then fall back to prefs
/// 3. Never clear the session on network/timeout errors — only on explicit
///    logout or a hard 401/403 from the refresh endpoint
class ApiClient {
  late final Dio dio;

  static const FlutterSecureStorage _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
    // first_unlock keeps values after background kill; unlocked device required once
    iOptions: IOSOptions(accessibility: KeychainAccessibility.first_unlock),
  );

  Future<bool>? _refreshInFlight;
  void Function()? onSessionInvalid;

  ApiClient() {
    dio = Dio(
      BaseOptions(
        baseUrl: AppConstants.apiBaseUrl,
        connectTimeout: AppConstants.connectTimeout,
        receiveTimeout: AppConstants.receiveTimeout,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
      ),
    );

    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await getAccessToken();
          if (token != null && token.isNotEmpty) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          return handler.next(options);
        },
        onError: (error, handler) async {
          final status = error.response?.statusCode;
          final path = error.requestOptions.path;

          final isAuthEndpoint = path.contains('/auth/login') ||
              path.contains('/auth/refresh') ||
              path.contains('/auth/logout');

          if (status == 401 && !isAuthEndpoint) {
            final refreshed = await _tryRefreshToken();
            if (refreshed) {
              final opts = error.requestOptions;
              final token = await getAccessToken();
              if (token != null) {
                opts.headers['Authorization'] = 'Bearer $token';
              }
              try {
                final response = await dio.fetch(opts);
                return handler.resolve(response);
              } catch (_) {
                return handler.next(error);
              }
            }
          }

          return handler.next(error);
        },
      ),
    );

    if (kDebugMode) {
      dio.interceptors.add(
        PrettyDioLogger(
          requestHeader: false,
          requestBody: false,
          responseBody: false,
          responseHeader: false,
          error: true,
          compact: true,
        ),
      );
    }
  }

  // ── Dual-write helpers ────────────────────────────────────

  Future<void> _write(String key, String value) async {
    try {
      await _storage.write(key: key, value: value);
    } catch (e) {
      debugPrint('SecureStorage write failed ($key): $e');
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('dm_$key', value);
    } catch (e) {
      debugPrint('Prefs write failed ($key): $e');
    }
  }

  Future<String?> _read(String key) async {
    try {
      final v = await _storage.read(key: key);
      if (v != null && v.isNotEmpty) return v;
    } catch (e) {
      debugPrint('SecureStorage read failed ($key): $e');
    }
    try {
      final prefs = await SharedPreferences.getInstance();
      final v = prefs.getString('dm_$key');
      if (v != null && v.isNotEmpty) {
        // Re-hydrate secure storage when possible
        try {
          await _storage.write(key: key, value: v);
        } catch (_) {}
        return v;
      }
    } catch (e) {
      debugPrint('Prefs read failed ($key): $e');
    }
    return null;
  }

  Future<void> _delete(String key) async {
    try {
      await _storage.delete(key: key);
    } catch (_) {}
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('dm_$key');
    } catch (_) {}
  }

  Future<bool> _tryRefreshToken() async {
    if (_refreshInFlight != null) return _refreshInFlight!;
    _refreshInFlight = _doRefresh();
    try {
      return await _refreshInFlight!;
    } finally {
      _refreshInFlight = null;
    }
  }

  Future<bool> _doRefresh() async {
    try {
      final refreshToken = await _read(AppConstants.keyRefreshToken);
      if (refreshToken == null || refreshToken.isEmpty) {
        debugPrint('Auth: no refresh token');
        return false;
      }

      final bare = Dio(
        BaseOptions(
          baseUrl: AppConstants.apiBaseUrl,
          connectTimeout: AppConstants.connectTimeout,
          receiveTimeout: AppConstants.receiveTimeout,
          headers: {
            'Accept': 'application/json',
            'Authorization': 'Bearer $refreshToken',
          },
        ),
      );

      final response = await bare.post('/api/auth/refresh');
      final data = response.data is Map ? response.data['data'] : null;
      final access = data is Map ? data['accessToken']?.toString() : null;
      if (access == null || access.isEmpty) {
        debugPrint('Auth: refresh response missing accessToken');
        return false;
      }

      await _write(AppConstants.keyAccessToken, access);
      final newRefresh = data is Map ? data['refreshToken']?.toString() : null;
      if (newRefresh != null && newRefresh.isNotEmpty) {
        await _write(AppConstants.keyRefreshToken, newRefresh);
      }
      debugPrint('Auth: token refreshed');
      return true;
    } on DioException catch (e) {
      final status = e.response?.statusCode;
      if (status == 401 || status == 403) {
        debugPrint('Auth: refresh rejected ($status) — clearing session');
        await clearTokens();
        onSessionInvalid?.call();
      } else {
        debugPrint(
          'Auth: refresh failed ($status / ${e.type}) — keeping session',
        );
      }
      return false;
    } catch (e) {
      debugPrint('Auth: refresh error — keeping session: $e');
      return false;
    }
  }

  Future<void> saveTokens(String accessToken, String refreshToken) async {
    await Future.wait([
      _write(AppConstants.keyAccessToken, accessToken),
      _write(AppConstants.keyRefreshToken, refreshToken),
    ]);
  }

  Future<void> clearTokens() async {
    await Future.wait([
      _delete(AppConstants.keyAccessToken),
      _delete(AppConstants.keyRefreshToken),
      _delete(AppConstants.keyUser),
      _delete(AppConstants.keyRestaurantId),
    ]);
  }

  Future<String?> getAccessToken() => _read(AppConstants.keyAccessToken);

  Future<String?> getRefreshToken() => _read(AppConstants.keyRefreshToken);

  Future<bool> hasStoredSession() async {
    final token = await getAccessToken();
    return token != null && token.isNotEmpty;
  }

  /// Exposed for user profile cache (same dual-write path).
  Future<void> writeKey(String key, String value) => _write(key, value);
  Future<String?> readKey(String key) => _read(key);
  Future<void> deleteKey(String key) => _delete(key);

  /// Legacy accessor — prefer [readKey]/[writeKey] so prefs backup is used.
  FlutterSecureStorage get storage => _storage;
}

final apiClient = ApiClient();
