import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

/// Premium Dinemate palette — Royal Navy + soft gold accents.
/// Prefer Theme.of(context).colorScheme / textTheme over these constants
/// for any color that should flip with light/dark mode.
class AppColors {
  AppColors._();

  // Brand
  static const deepNavy = Color(0xFF071A2F);
  static const primary = Color(0xFF0B2A4A);
  static const premiumNavy = Color(0xFF123B63);
  static const softNavy = Color(0xFF1C4B73);
  static const primaryLight = Color(0xFF5B8FC7);
  static const navyTint = Color(0xFFEAF1F7);
  static const primarySoft = Color(0xFFE8F0F7);
  static const secondary = Color(0xFFD97706);
  static const gold = Color(0xFFC9A227);

  // Light surfaces
  static const background = Color(0xFFF5F7FA);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceElevated = Color(0xFFF4F7FA);
  static const surfaceMuted = Color(0xFFEEF2F6);

  // Light text
  static const textPrimary = Color(0xFF0B1726);
  static const textSecondary = Color(0xFF5B6B7C);
  static const textMuted = Color(0xFF8B9AAB);
  static const textOnPrimary = Color(0xFFFFFFFF);

  // Light borders
  static const border = Color(0xFFE2E8F0);
  static const borderStrong = Color(0xFFCBD5E1);
  static const borderSubtle = Color(0xFFF1F5F9);

  // Semantic (shared)
  static const success = Color(0xFF0D9488);
  static const successSoft = Color(0xFFCCFBF1);
  static const warning = Color(0xFFD97706);
  static const warningSoft = Color(0xFFFEF3C7);
  static const error = Color(0xFFEF4444);
  static const errorSoft = Color(0xFFFEE2E2);
  static const info = Color(0xFF3B82F6);
  static const infoSoft = Color(0xFFDBEAFE);

  // Order status
  static const pending = Color(0xFFD97706);
  static const confirmed = Color(0xFF3B82F6);
  static const preparing = Color(0xFF8B5CF6);
  static const ready = Color(0xFF14B8A6);
  static const served = Color(0xFF06B6D4);
  static const completed = Color(0xFF64748B);
  static const cancelled = Color(0xFFEF4444);

  // Dark surfaces (layered hierarchy)
  static const darkBackground = Color(0xFF070D16);
  static const darkSurface = Color(0xFF0C1522);
  static const darkCard = Color(0xFF121C2C);
  static const darkElevated = Color(0xFF1A2538);
  static const darkInput = Color(0xFF152032);
  static const darkBorder = Color(0xFF243247);
  static const darkBorderStrong = Color(0xFF334155);

  // Dark text (high contrast)
  static const darkTextPrimary = Color(0xFFF1F5F9);
  static const darkTextSecondary = Color(0xFFA8B8CC);
  static const darkTextMuted = Color(0xFF7A8BA3);
  static const darkTextOnPrimary = Color(0xFFFFFFFF);
}

/// Theme-aware semantic helpers so widgets avoid `if (isDark)`.
extension DinemateThemeX on BuildContext {
  ColorScheme get cs => Theme.of(this).colorScheme;
  TextTheme get tt => Theme.of(this).textTheme;
  bool get isDark => Theme.of(this).brightness == Brightness.dark;

  Color get appBackground =>
      isDark ? AppColors.darkBackground : AppColors.background;
  Color get appSurface => isDark ? AppColors.darkCard : AppColors.surface;
  Color get appElevated =>
      isDark ? AppColors.darkElevated : AppColors.surfaceElevated;
  Color get appBorder => isDark ? AppColors.darkBorder : AppColors.border;
  Color get appText =>
      isDark ? AppColors.darkTextPrimary : AppColors.textPrimary;
  Color get appTextSecondary =>
      isDark ? AppColors.darkTextSecondary : AppColors.textSecondary;
  Color get appTextMuted =>
      isDark ? AppColors.darkTextMuted : AppColors.textMuted;
  Color get appPrimary =>
      isDark ? AppColors.primaryLight : AppColors.primary;
}

class AppTheme {
  AppTheme._();

  static final ThemeData light = _build(Brightness.light);
  static final ThemeData dark = _build(Brightness.dark);

  static ThemeData _build(Brightness brightness) {
    final isDark = brightness == Brightness.dark;

    final primary = isDark ? AppColors.primaryLight : AppColors.primary;
    final onPrimary =
        isDark ? AppColors.darkTextOnPrimary : AppColors.textOnPrimary;
    final surface = isDark ? AppColors.darkCard : AppColors.surface;
    final onSurface =
        isDark ? AppColors.darkTextPrimary : AppColors.textPrimary;
    final scaffold =
        isDark ? AppColors.darkBackground : AppColors.background;
    final border = isDark ? AppColors.darkBorder : AppColors.border;
    final secondaryText =
        isDark ? AppColors.darkTextSecondary : AppColors.textSecondary;
    final mutedText =
        isDark ? AppColors.darkTextMuted : AppColors.textMuted;
    final inputFill = isDark ? AppColors.darkInput : AppColors.surface;
    final card = isDark ? AppColors.darkCard : AppColors.surface;
    final elevated =
        isDark ? AppColors.darkElevated : AppColors.surfaceElevated;
    final appBarBg = isDark ? AppColors.darkSurface : AppColors.surface;
    final navBg = isDark ? AppColors.darkSurface : AppColors.surface;
    final indicator =
        isDark ? primary.withValues(alpha: 0.22) : AppColors.navyTint;

    final colorScheme = ColorScheme(
      brightness: brightness,
      primary: primary,
      onPrimary: onPrimary,
      secondary: isDark ? AppColors.gold : AppColors.softNavy,
      onSecondary: onPrimary,
      error: AppColors.error,
      onError: Colors.white,
      surface: surface,
      onSurface: onSurface,
      surfaceContainerHighest: elevated,
      surfaceContainerHigh: isDark ? AppColors.darkElevated : AppColors.surfaceMuted,
      surfaceContainer: isDark ? AppColors.darkSurface : AppColors.surfaceElevated,
      surfaceContainerLow: isDark ? AppColors.darkBackground : AppColors.background,
      outline: border,
      outlineVariant: isDark ? AppColors.darkBorderStrong : AppColors.borderSubtle,
      onSurfaceVariant: secondaryText,
      primaryContainer: isDark
          ? AppColors.primary.withValues(alpha: 0.35)
          : AppColors.navyTint,
      onPrimaryContainer: isDark ? AppColors.darkTextPrimary : AppColors.primary,
      tertiary: AppColors.success,
      onTertiary: Colors.white,
      inverseSurface: isDark ? AppColors.surface : AppColors.deepNavy,
      onInverseSurface: isDark ? AppColors.textPrimary : Colors.white,
      shadow: Colors.black,
      scrim: Colors.black,
    );

    final base = ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: colorScheme,
    );

    final textTheme = GoogleFonts.interTextTheme(base.textTheme).apply(
      bodyColor: onSurface,
      displayColor: onSurface,
    );

    final radius12 = BorderRadius.circular(12);
    final radius16 = BorderRadius.circular(16);

    return base.copyWith(
      scaffoldBackgroundColor: scaffold,
      canvasColor: scaffold,
      textTheme: textTheme,
      primaryTextTheme: textTheme,
      iconTheme: IconThemeData(color: primary, size: 22),
      primaryIconTheme: IconThemeData(color: primary, size: 22),
      dividerColor: border,
      disabledColor: mutedText,
      hintColor: mutedText,
      unselectedWidgetColor: mutedText,

      appBarTheme: AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0.5,
        centerTitle: false,
        backgroundColor: appBarBg,
        foregroundColor: onSurface,
        surfaceTintColor: Colors.transparent,
        systemOverlayStyle:
            isDark ? SystemUiOverlayStyle.light : SystemUiOverlayStyle.dark,
        titleTextStyle: GoogleFonts.inter(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: onSurface,
          letterSpacing: -0.2,
        ),
        iconTheme: IconThemeData(color: primary, size: 22),
        actionsIconTheme: IconThemeData(color: primary, size: 22),
      ),

      cardTheme: CardThemeData(
        elevation: 0,
        color: card,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: radius16,
          side: BorderSide(color: border, width: 1),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: onPrimary,
          disabledBackgroundColor: primary.withValues(alpha: 0.35),
          disabledForegroundColor: onPrimary.withValues(alpha: 0.7),
          elevation: 0,
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: radius12),
          textStyle: GoogleFonts.inter(
            fontWeight: FontWeight.w600,
            fontSize: 15,
            letterSpacing: 0.1,
          ),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: onPrimary,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: radius12),
          textStyle: GoogleFonts.inter(fontWeight: FontWeight.w600, fontSize: 15),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primary,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: radius12),
          side: BorderSide(color: primary, width: 1.5),
          textStyle: GoogleFonts.inter(fontWeight: FontWeight.w600, fontSize: 15),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: primary,
          textStyle: GoogleFonts.inter(fontWeight: FontWeight.w600, fontSize: 14),
        ),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: primary,
        foregroundColor: onPrimary,
        elevation: 3,
        shape: RoundedRectangleBorder(borderRadius: radius16),
      ),
      iconButtonTheme: IconButtonThemeData(
        style: IconButton.styleFrom(
          foregroundColor: primary,
          disabledForegroundColor: mutedText,
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: inputFill,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: radius12,
          borderSide: BorderSide(color: border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: radius12,
          borderSide: BorderSide(color: border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: radius12,
          borderSide: BorderSide(color: primary, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: radius12,
          borderSide: const BorderSide(color: AppColors.error),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: radius12,
          borderSide: const BorderSide(color: AppColors.error, width: 1.5),
        ),
        disabledBorder: OutlineInputBorder(
          borderRadius: radius12,
          borderSide: BorderSide(color: border.withValues(alpha: 0.5)),
        ),
        labelStyle: GoogleFonts.inter(color: secondaryText, fontSize: 14),
        floatingLabelStyle: GoogleFonts.inter(color: primary, fontSize: 14),
        hintStyle: GoogleFonts.inter(color: mutedText, fontSize: 14),
        helperStyle: GoogleFonts.inter(color: mutedText, fontSize: 12),
        errorStyle: GoogleFonts.inter(color: AppColors.error, fontSize: 12),
        prefixIconColor: secondaryText,
        suffixIconColor: secondaryText,
      ),

      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: navBg,
        indicatorColor: indicator,
        elevation: 0,
        height: 68,
        surfaceTintColor: Colors.transparent,
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return GoogleFonts.inter(
            fontSize: 11,
            fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
            color: selected ? primary : mutedText,
            letterSpacing: 0.1,
          );
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return IconThemeData(
            color: selected ? primary : mutedText,
            size: 24,
          );
        }),
      ),
      navigationRailTheme: NavigationRailThemeData(
        backgroundColor: navBg,
        indicatorColor: indicator,
        selectedIconTheme: IconThemeData(color: primary, size: 24),
        unselectedIconTheme: IconThemeData(color: mutedText, size: 24),
        selectedLabelTextStyle: GoogleFonts.inter(
          color: primary,
          fontWeight: FontWeight.w600,
          fontSize: 12,
        ),
        unselectedLabelTextStyle: GoogleFonts.inter(
          color: mutedText,
          fontWeight: FontWeight.w500,
          fontSize: 12,
        ),
      ),
      drawerTheme: DrawerThemeData(
        backgroundColor: isDark ? AppColors.darkSurface : AppColors.surface,
        surfaceTintColor: Colors.transparent,
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: navBg,
        selectedItemColor: primary,
        unselectedItemColor: mutedText,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),

      chipTheme: ChipThemeData(
        backgroundColor: elevated,
        selectedColor: indicator,
        disabledColor: elevated.withValues(alpha: 0.5),
        labelStyle: GoogleFonts.inter(fontSize: 13, color: onSurface),
        secondaryLabelStyle: GoogleFonts.inter(fontSize: 13, color: primary),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        side: BorderSide(color: border),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        checkmarkColor: primary,
      ),

      dialogTheme: DialogThemeData(
        backgroundColor: card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        titleTextStyle: GoogleFonts.inter(
          fontSize: 18,
          fontWeight: FontWeight.w600,
          color: onSurface,
        ),
        contentTextStyle: GoogleFonts.inter(
          fontSize: 14,
          color: secondaryText,
        ),
        iconColor: primary,
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: card,
        surfaceTintColor: Colors.transparent,
        modalBackgroundColor: card,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        showDragHandle: true,
        dragHandleColor: isDark ? AppColors.darkBorderStrong : AppColors.borderStrong,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: radius12),
        backgroundColor: isDark ? AppColors.darkElevated : AppColors.deepNavy,
        contentTextStyle: GoogleFonts.inter(color: Colors.white, fontSize: 14),
        actionTextColor: AppColors.gold,
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: card,
        surfaceTintColor: Colors.transparent,
        textStyle: GoogleFonts.inter(color: onSurface, fontSize: 14),
        shape: RoundedRectangleBorder(
          borderRadius: radius12,
          side: BorderSide(color: border),
        ),
      ),
      tooltipTheme: TooltipThemeData(
        decoration: BoxDecoration(
          color: isDark ? AppColors.darkElevated : AppColors.deepNavy,
          borderRadius: BorderRadius.circular(8),
        ),
        textStyle: GoogleFonts.inter(color: Colors.white, fontSize: 12),
      ),
      menuTheme: MenuThemeData(
        style: MenuStyle(
          backgroundColor: WidgetStatePropertyAll(card),
          surfaceTintColor: const WidgetStatePropertyAll(Colors.transparent),
        ),
      ),

      dividerTheme: DividerThemeData(color: border, thickness: 1, space: 1),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: primary,
        linearTrackColor: border,
        circularTrackColor: border.withValues(alpha: 0.4),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return primary;
          return isDark ? AppColors.darkTextMuted : Colors.white;
        }),
        trackColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) {
            return primary.withValues(alpha: 0.4);
          }
          return isDark ? AppColors.darkBorderStrong : AppColors.borderStrong;
        }),
        trackOutlineColor: WidgetStatePropertyAll(border),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return primary;
          return Colors.transparent;
        }),
        checkColor: WidgetStatePropertyAll(onPrimary),
        side: BorderSide(color: secondaryText, width: 1.5),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      ),
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.resolveWith((s) {
          if (s.contains(WidgetState.selected)) return primary;
          return secondaryText;
        }),
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: primary,
        inactiveTrackColor: border,
        thumbColor: primary,
        overlayColor: primary.withValues(alpha: 0.12),
        valueIndicatorColor: primary,
        valueIndicatorTextStyle: GoogleFonts.inter(color: onPrimary, fontSize: 12),
      ),

      tabBarTheme: TabBarThemeData(
        labelColor: primary,
        unselectedLabelColor: secondaryText,
        indicatorColor: primary,
        indicatorSize: TabBarIndicatorSize.label,
        labelStyle: GoogleFonts.inter(fontWeight: FontWeight.w600, fontSize: 14),
        unselectedLabelStyle:
            GoogleFonts.inter(fontWeight: FontWeight.w500, fontSize: 14),
        dividerColor: border,
      ),
      listTileTheme: ListTileThemeData(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        shape: RoundedRectangleBorder(borderRadius: radius12),
        iconColor: primary,
        textColor: onSurface,
        subtitleTextStyle: GoogleFonts.inter(color: secondaryText, fontSize: 13),
        tileColor: Colors.transparent,
      ),
      expansionTileTheme: ExpansionTileThemeData(
        textColor: onSurface,
        iconColor: primary,
        collapsedTextColor: onSurface,
        collapsedIconColor: secondaryText,
        backgroundColor: Colors.transparent,
        collapsedBackgroundColor: Colors.transparent,
      ),
      dataTableTheme: DataTableThemeData(
        headingTextStyle: GoogleFonts.inter(
          fontWeight: FontWeight.w600,
          color: onSurface,
          fontSize: 13,
        ),
        dataTextStyle: GoogleFonts.inter(color: onSurface, fontSize: 13),
        dividerThickness: 1,
        headingRowColor: WidgetStatePropertyAll(elevated),
      ),
      badgeTheme: BadgeThemeData(
        backgroundColor: AppColors.error,
        textColor: Colors.white,
      ),
      bannerTheme: MaterialBannerThemeData(
        backgroundColor: elevated,
        contentTextStyle: GoogleFonts.inter(color: onSurface, fontSize: 14),
      ),
    );
  }
}
