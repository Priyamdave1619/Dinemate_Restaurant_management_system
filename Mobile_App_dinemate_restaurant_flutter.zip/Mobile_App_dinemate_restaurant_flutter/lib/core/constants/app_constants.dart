class AppConstants {
  AppConstants._();

  static const String appName = 'Dinemate';
  static const String appVersion = '1.0.0';

  /// Change this to your backend URL
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'your_api_url',
  );

  static const Duration connectTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);

  // Secure storage keys
  static const String keyAccessToken = 'access_token';
  static const String keyRefreshToken = 'refresh_token';
  static const String keyUser = 'user_data';
  static const String keyRestaurantId = 'restaurant_id';

  // Roles
  static const String roleOwner = 'owner';
  static const String roleManager = 'manager';
  static const String roleWaiter = 'waiter';
  static const String roleSuperAdmin = 'super_admin';
}