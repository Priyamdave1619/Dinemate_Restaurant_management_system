import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Keeps an `autoDispose` provider's last value alive for [duration] after
/// its last listener unsubscribes, instead of disposing (and refetching)
/// immediately on every screen navigation.
///
/// Without this, every `FutureProvider.autoDispose` re-runs its network
/// call from scratch each time a screen is revisited, because Riverpod
/// disposes the provider the instant nothing is watching it. That is what
/// was making the whole app feel slow: every navigation showed a fresh
/// loading spinner even for data fetched moments earlier.
///
/// Usage inside a provider body:
/// ```dart
/// final ordersProvider = FutureProvider.autoDispose<List<Order>>((ref) async {
///   cacheFor(ref, const Duration(minutes: 5));
///   final service = ref.watch(restaurantServiceProvider);
///   return service.getOrders();
/// });
/// ```
///
/// The provider still disposes eventually (so data doesn't go stale
/// forever or leak memory), and pull-to-refresh / `ref.invalidate(...)`
/// continue to force an immediate refetch exactly as before.
void cacheFor(Ref ref, Duration duration) {
  final link = ref.keepAlive();
  Timer? timer;

  // Whenever the provider gains a listener again (e.g. the user navigates
  // back to the screen within the cache window), cancel any pending
  // disposal so the cached value keeps being served.
  ref.onCancel(() {
    timer = Timer(duration, link.close);
  });
  ref.onResume(() {
    timer?.cancel();
  });
  ref.onDispose(() {
    timer?.cancel();
  });
}
