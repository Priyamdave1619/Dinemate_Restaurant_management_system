/// Shared form validators used across login, menu, tables, staff, etc.
/// Frontend validation is a first line of defense only — the backend must
/// still reject invalid payloads.
class Validators {
  Validators._();

  static String? required(String? value, {String field = 'This field'}) {
    if (value == null || value.trim().isEmpty) {
      return '$field is required';
    }
    return null;
  }

  static String? username(String? value) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) return 'Please enter your username or Restaurant ID';
    // Staff usernames can be short (e.g. w1); Restaurant IDs are longer.
    if (v.length < 2) return 'Must be at least 2 characters';
    if (v.length > 64) return 'Must be at most 64 characters';
    return null;
  }

  static String? password(String? value, {bool requireStrength = false}) {
    if (value == null || value.isEmpty) return 'Please enter your password';
    if (value.length > 128) return 'Password is too long';
    if (requireStrength) {
      // Align with portal policy (Next.js passwordSchema): length + complexity
      if (value.length < 12) return 'Use at least 12 characters';
      if (!RegExp(r'[a-z]').hasMatch(value)) return 'Include a lowercase letter';
      if (!RegExp(r'[A-Z]').hasMatch(value)) return 'Include an uppercase letter';
      if (!RegExp(r'[0-9]').hasMatch(value)) return 'Include a number';
      if (!RegExp(r'[^A-Za-z0-9]').hasMatch(value)) {
        return 'Include a special character';
      }
    } else if (value.length < 4) {
      return 'Password is too short';
    }
    return null;
  }

  static String? name(String? value, {String field = 'Name'}) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) return '$field is required';
    if (v.length < 2) return '$field must be at least 2 characters';
    if (v.length > 120) return '$field is too long (max 120)';
    return null;
  }

  static String? positiveNumber(String? value, {String field = 'Value', bool required = true}) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) {
      return required ? '$field is required' : null;
    }
    final n = double.tryParse(v);
    if (n == null) return 'Enter a valid number';
    if (n < 0) return '$field cannot be negative';
    if (n > 9999999) return '$field is too large';
    return null;
  }

  static String? positiveInt(String? value, {String field = 'Value', bool required = true, int? min, int? max}) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) {
      return required ? '$field is required' : null;
    }
    final n = int.tryParse(v);
    if (n == null) return 'Enter a whole number';
    if (n < 0) return '$field cannot be negative';
    if (min != null && n < min) return '$field must be at least $min';
    if (max != null && n > max) return '$field must be at most $max';
    return null;
  }

  static String? email(String? value, {bool required = false}) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) return required ? 'Email is required' : null;
    final ok = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v);
    if (!ok) return 'Enter a valid email address';
    return null;
  }

  static String? phone(String? value, {bool required = false}) {
    final v = value?.trim() ?? '';
    if (v.isEmpty) return required ? 'Phone is required' : null;
    final digits = v.replaceAll(RegExp(r'\D'), '');
    if (digits.length < 8 || digits.length > 15) {
      return 'Enter a valid phone number';
    }
    return null;
  }

  static String? maxLength(String? value, int max, {String field = 'Text'}) {
    if (value != null && value.length > max) {
      return '$field must be at most $max characters';
    }
    return null;
  }

  /// Sanitize exception text before showing it to the user.
  static String friendlyError(Object error) {
    final raw = error.toString().replaceFirst(RegExp(r'^Exception:\s*'), '');
    if (raw.contains('SocketException') ||
        raw.contains('connection error') ||
        raw.contains('Failed host lookup')) {
      return 'Could not reach the server. Check your connection.';
    }
    if (raw.contains('TimeoutException') || raw.toLowerCase().contains('timeout')) {
      return 'The server is taking too long. Please try again.';
    }
    if (raw.contains('FormatException') || raw.contains('type \'')) {
      return 'Unexpected response from server. Please try again.';
    }
    // Cap length so stack-ish strings never flood the UI
    if (raw.length > 180) return '${raw.substring(0, 177)}…';
    return raw.isEmpty ? 'Something went wrong. Please try again.' : raw;
  }
}
