import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/models/menu_item.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/screens/menu/menu_form_sheet.dart';
import 'package:dinemate_restaurant/screens/menu/menu_bulk_import_screen.dart';
import 'package:dinemate_restaurant/core/utils/debounce.dart';


Future<void> _showCategoryForm(BuildContext context, WidgetRef ref) async {
  final nameCtrl = TextEditingController();
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
    ),
    builder: (ctx) {
      return Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Add Category', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 16),
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(labelText: 'Category name *'),
              textCapitalization: TextCapitalization.words,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () async {
                final name = nameCtrl.text.trim();
                if (name.length < 2) {
                  ScaffoldMessenger.of(ctx).showSnackBar(
                    const SnackBar(content: Text('Enter a category name')),
                  );
                  return;
                }
                try {
                  await ref.read(restaurantServiceProvider).createCategory(name: name);
                  ref.invalidate(categoriesProvider);
                  ref.invalidate(menuItemsProvider);
                  if (ctx.mounted) Navigator.pop(ctx);
                } catch (e) {
                  if (ctx.mounted) {
                    ScaffoldMessenger.of(ctx).showSnackBar(
                      SnackBar(content: Text('$e'), backgroundColor: AppColors.error),
                    );
                  }
                }
              },
              child: const Text('Create Category'),
            ),
          ],
        ),
      );
    },
  );
  nameCtrl.dispose();
}

class MenuScreen extends ConsumerStatefulWidget {
  const MenuScreen({super.key});

  @override
  ConsumerState<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends ConsumerState<MenuScreen> {
  String _search = '';
  String? _selectedCategoryId;
  final _searchDebounce = Debouncer(delay: const Duration(milliseconds: 300));
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchDebounce.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final menuAsync = ref.watch(menuItemsProvider);
    final categoriesAsync = ref.watch(categoriesProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Menu'),
        actions: [
          IconButton(
            tooltip: 'AI Menu Import',
            icon: const Icon(Icons.auto_awesome_rounded),
            color: AppColors.primary,
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const MenuBulkImportScreen()),
              ).then((_) {
                ref.invalidate(menuItemsProvider);
                ref.invalidate(categoriesProvider);
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.category_outlined),
            tooltip: 'Add category',
            onPressed: () => _showCategoryForm(context, ref),
          ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () {
              ref.invalidate(menuItemsProvider);
              ref.invalidate(categoriesProvider);
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Search
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search menu items…',
                prefixIcon: const Icon(Icons.search, size: 20),
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              controller: _searchCtrl,
              onChanged: (v) {
                _searchDebounce.run(() {
                  if (mounted) setState(() => _search = v.toLowerCase());
                });
              },
            ),
          ),

          // Category chips
          categoriesAsync.when(
            data: (cats) {
              if (cats.isEmpty) return const SizedBox.shrink();
              return SizedBox(
                height: 48,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: FilterChip(
                        label: const Text('All'),
                        selected: _selectedCategoryId == null,
                        onSelected: (_) => setState(() => _selectedCategoryId = null),
                      ),
                    ),
                    ...cats.map(
                      (c) => Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: FilterChip(
                          label: Text(c.name),
                          selected: _selectedCategoryId == c.id,
                          onSelected: (_) => setState(() => _selectedCategoryId = c.id),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
            loading: () => const SizedBox.shrink(),
            error: (_, __) => const SizedBox.shrink(),
          ),

          // Items
          Expanded(
            child: menuAsync.when(
              data: (items) {
                var filtered = items;
                if (_selectedCategoryId != null) {
                  filtered = filtered.where((i) => i.categoryId == _selectedCategoryId).toList();
                }
                if (_search.isNotEmpty) {
                  filtered = filtered
                      .where((i) => i.name.toLowerCase().contains(_search))
                      .toList();
                }

                if (filtered.isEmpty) {
                  return const Center(
                    child: Text('No menu items found', style: TextStyle(color: AppColors.textSecondary)),
                  );
                }

                return RefreshIndicator(
                  onRefresh: () async => ref.invalidate(menuItemsProvider),
                  child: ListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: filtered.length,
                    itemBuilder: (context, index) {
                      final item = filtered[index];
                      return _MenuItemTile(item: item);
                    },
                  ),
                );
              },
              loading: () => const LoadingView(message: 'Loading…'),
              error: (e, _) => Center(child: Text('Error: $e')),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showMenuItemForm(context, ref),
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }
}

class _MenuItemTile extends ConsumerWidget {
  final MenuItem item;
  const _MenuItemTile({required this.item});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: ListTile(
        onTap: () => showMenuItemForm(context, ref, existing: item),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: item.isVeg
                ? AppColors.success.withValues(alpha: 0.12)
                : AppColors.error.withValues(alpha: 0.12),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            item.isVeg ? Icons.eco_rounded : Icons.set_meal_rounded,
            color: item.isVeg ? AppColors.success : AppColors.error,
            size: 22,
          ),
        ),
        title: Text(
          item.name,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 14,
            decoration: item.available ? null : TextDecoration.lineThrough,
            color: item.available ? null : AppColors.textSecondary,
          ),
        ),
        subtitle: Text(
          item.categoryName ?? '',
          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '₹${item.price.toStringAsFixed(0)}',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
            const SizedBox(width: 8),
            Switch.adaptive(
              value: item.available,
              activeTrackColor: AppColors.primary.withValues(alpha: 0.45),
              activeThumbColor: AppColors.primary,
              onChanged: (val) async {
                try {
                  await ref.read(restaurantServiceProvider).toggleMenuItemAvailability(item.id, val);
                  ref.invalidate(menuItemsProvider);
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed: $e'), backgroundColor: AppColors.error),
                    );
                  }
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
