import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';
import 'package:dinemate_restaurant/models/menu_import.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/widgets/dinemate/dinemate_button.dart';

/// AI-powered menu import — upload photo/PDF/CSV → extract items → review → commit to DB.
class MenuBulkImportScreen extends ConsumerStatefulWidget {
  const MenuBulkImportScreen({super.key});

  @override
  ConsumerState<MenuBulkImportScreen> createState() => _MenuBulkImportScreenState();
}

enum _Step { upload, processing, review, result }

class _MenuBulkImportScreenState extends ConsumerState<MenuBulkImportScreen> {
  _Step _step = _Step.upload;
  final List<File> _files = [];
  MenuImportSession? _session;
  bool _busy = false;
  String? _error;
  String _filter = 'all';
  Map<String, dynamic>? _commitResult;
  Map<String, dynamic>? _aiStatus;

  final _currency = NumberFormat.currency(symbol: '₹', decimalDigits: 0);

  @override
  void initState() {
    super.initState();
    _loadAiStatus();
  }

  Future<void> _loadAiStatus() async {
    try {
      final s = await ref.read(restaurantServiceProvider).getAiExtractionStatus();
      if (mounted) setState(() => _aiStatus = s);
    } catch (_) {}
  }

  Future<void> _pickImages() async {
    final picker = ImagePicker();
    final images = await picker.pickMultiImage(imageQuality: 85);
    if (images.isEmpty) return;
    setState(() {
      _files.addAll(images.map((x) => File(x.path)));
      _error = null;
    });
  }

  Future<void> _pickCamera() async {
    final picker = ImagePicker();
    final shot = await picker.pickImage(source: ImageSource.camera, imageQuality: 85);
    if (shot == null) return;
    setState(() {
      _files.add(File(shot.path));
      _error = null;
    });
  }

  Future<void> _pickFiles() async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['jpg', 'jpeg', 'png', 'webp', 'pdf', 'csv', 'json', 'xlsx'],
    );
    if (result == null) return;
    setState(() {
      for (final f in result.files) {
        if (f.path != null) _files.add(File(f.path!));
      }
      _error = null;
    });
  }

  Future<void> _startImport() async {
    if (_files.isEmpty || _busy) return;
    setState(() {
      _busy = true;
      _error = null;
      _step = _Step.processing;
    });
    try {
      final service = ref.read(restaurantServiceProvider);
      var session = await service.uploadMenuImport(_files);
      setState(() => _session = session);
      session = await service.processMenuImport(session.id);
      // Poll until ready if still processing
      var attempts = 0;
      while (session.isProcessing && attempts < 30) {
        await Future.delayed(const Duration(seconds: 2));
        session = await service.getMenuImport(session.id);
        attempts++;
        if (mounted) setState(() => _session = session);
      }
      // Prefer preview endpoint for full items
      try {
        session = await service.getMenuImportPreview(session.id);
      } catch (_) {}
      if (mounted) {
        setState(() {
          _session = session;
          _step = _Step.review;
          _busy = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = e.toString().replaceFirst('Exception: ', '');
          _step = _Step.upload;
          _busy = false;
        });
      }
    }
  }

  Future<void> _commit() async {
    final session = _session;
    if (session == null || _busy) return;
    setState(() => _busy = true);
    try {
      final result = await ref.read(restaurantServiceProvider).commitMenuImport(session.id);
      ref.invalidate(menuItemsProvider);
      ref.invalidate(categoriesProvider);
      if (mounted) {
        setState(() {
          _commitResult = result;
          _step = _Step.result;
          _busy = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _error = e.toString().replaceFirst('Exception: ', '');
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_error ?? 'Commit failed'),
            backgroundColor: AppColors.error,
          ),
        );
      }
    }
  }

  Future<void> _deleteItem(ExtractedMenuItem item) async {
    final session = _session;
    if (session == null) return;
    try {
      await ref.read(restaurantServiceProvider).deleteMenuImportItem(session.id, item.id);
      final updated = await ref.read(restaurantServiceProvider).getMenuImportPreview(session.id);
      if (mounted) setState(() => _session = updated);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  List<ExtractedMenuItem> get _filteredItems {
    final items = _session?.items ?? [];
    if (_filter == 'all') return items;
    return items.where((i) => i.status.toLowerCase().contains(_filter)).toList();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.background,
      appBar: AppBar(
        title: const Text('AI Menu Import'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: switch (_step) {
        _Step.upload => _buildUpload(isDark),
        _Step.processing => _buildProcessing(isDark),
        _Step.review => _buildReview(isDark),
        _Step.result => _buildResult(isDark),
      },
    );
  }

  Widget _buildUpload(bool isDark) {
    final aiAvailable = _aiStatus?['aiExtractionAvailable'] == true;
    final provider = _aiStatus?['provider']?.toString();

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                AppColors.primary,
                AppColors.premiumNavy,
              ],
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Icon(Icons.auto_awesome, color: Colors.white, size: 32),
              const SizedBox(height: 12),
              const Text(
                'Upload menu photos',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'AI extracts item names, prices & categories and inserts them into your menu.',
                style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.85),
                  fontSize: 14,
                  height: 1.4,
                ),
              ),
              if (provider != null) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    aiAvailable ? 'AI ready · $provider' : 'AI offline',
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 24),
        Text(
          'Select files',
          style: DinemateTypography.sectionTitle(context).copyWith(
            color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _PickCard(
                icon: Icons.photo_library_outlined,
                label: 'Gallery',
                onTap: _pickImages,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _PickCard(
                icon: Icons.photo_camera_outlined,
                label: 'Camera',
                onTap: _pickCamera,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _PickCard(
                icon: Icons.folder_outlined,
                label: 'Files',
                onTap: _pickFiles,
              ),
            ),
          ],
        ),
        if (_files.isNotEmpty) ...[
          const SizedBox(height: 20),
          Text(
            '${_files.length} file(s) selected',
            style: DinemateTypography.caption(context).copyWith(
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 8),
          ..._files.asMap().entries.map((e) {
            final name = e.value.path.split(Platform.pathSeparator).last;
            return ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.insert_drive_file_outlined, color: AppColors.primary),
              title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
              trailing: IconButton(
                icon: const Icon(Icons.close, size: 18),
                onPressed: () => setState(() => _files.removeAt(e.key)),
              ),
            );
          }),
        ],
        if (_error != null) ...[
          const SizedBox(height: 12),
          Text(_error!, style: const TextStyle(color: AppColors.error, fontSize: 13)),
        ],
        const SizedBox(height: 24),
        DinemateButton(
          label: 'Extract with AI',
          icon: Icons.auto_awesome,
          loading: _busy,
          onPressed: _files.isEmpty ? null : _startImport,
        ),
        const SizedBox(height: 12),
        Text(
          'Supports JPG, PNG, WebP, PDF, CSV, XLSX',
          textAlign: TextAlign.center,
          style: DinemateTypography.caption(context).copyWith(
            color: AppColors.textMuted,
          ),
        ),
      ],
    );
  }

  Widget _buildProcessing(bool isDark) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              width: 48,
              height: 48,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                color: AppColors.primary,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'Extracting menu items…',
              style: DinemateTypography.sectionTitle(context).copyWith(
                color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'AI is reading your menu. This may take a moment.',
              textAlign: TextAlign.center,
              style: DinemateTypography.body(context).copyWith(
                color: AppColors.textSecondary,
              ),
            ),
            if (_session != null) ...[
              const SizedBox(height: 16),
              Text(
                'Status: ${_session!.status}',
                style: DinemateTypography.caption(context).copyWith(
                  color: AppColors.primary,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildReview(bool isDark) {
    final session = _session;
    final items = _filteredItems;

    return Column(
      children: [
        // Summary bar
        Container(
          width: double.infinity,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          color: isDark ? AppColors.darkSurface : AppColors.navyTint,
          child: Row(
            children: [
              Expanded(
                child: Text(
                  '${session?.totalItems ?? items.length} items extracted',
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: AppColors.primary,
                  ),
                ),
              ),
              if ((session?.categoriesDetected.length ?? 0) > 0)
                Text(
                  '${session!.categoriesDetected.length} categories',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                ),
            ],
          ),
        ),
        // Filter chips
        SizedBox(
          height: 48,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            children: [
              for (final f in ['all', 'ready', 'needs_review', 'duplicate', 'failed'])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: FilterChip(
                    label: Text(f == 'all' ? 'All' : f.replaceAll('_', ' ')),
                    selected: _filter == f,
                    onSelected: (_) => setState(() => _filter = f),
                    selectedColor: AppColors.navyTint,
                    labelStyle: TextStyle(
                      color: _filter == f ? AppColors.primary : AppColors.textSecondary,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: items.isEmpty
              ? Center(
                  child: Text(
                    'No items to review',
                    style: TextStyle(color: AppColors.textSecondary),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 100),
                  itemCount: items.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final item = items[i];
                    return Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: isDark ? AppColors.darkCard : AppColors.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: isDark ? AppColors.darkBorder : AppColors.border,
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item.name,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 15,
                                    color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                                  ),
                                ),
                                if (item.categoryName != null) ...[
                                  const SizedBox(height: 4),
                                  Text(
                                    item.categoryName!,
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                ],
                                if (item.description != null &&
                                    item.description!.isNotEmpty) ...[
                                  const SizedBox(height: 4),
                                  Text(
                                    item.description!,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppColors.textMuted,
                                    ),
                                  ),
                                ],
                                const SizedBox(height: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: AppColors.navyTint,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    item.status.replaceAll('_', ' '),
                                    style: const TextStyle(
                                      fontSize: 11,
                                      color: AppColors.primary,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                _currency.format(item.price),
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15,
                                  color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline, size: 20),
                                color: AppColors.error,
                                onPressed: () => _deleteItem(item),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
        ),
        // Commit bar
        Container(
          padding: EdgeInsets.fromLTRB(
            16,
            12,
            16,
            12 + MediaQuery.paddingOf(context).bottom,
          ),
          decoration: BoxDecoration(
            color: isDark ? AppColors.darkSurface : AppColors.surface,
            boxShadow: DinemateShadows.nav,
          ),
          child: DinemateButton(
            label: 'Insert ${items.length} items into menu',
            icon: Icons.check_rounded,
            loading: _busy,
            onPressed: items.isEmpty ? null : _commit,
          ),
        ),
      ],
    );
  }

  Widget _buildResult(bool isDark) {
    final inserted = _commitResult?['inserted'] ??
        _commitResult?['successfulItems'] ??
        _session?.successfulItems ??
        _session?.totalItems ??
        0;

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: AppColors.successSoft,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.check_rounded, color: AppColors.success, size: 36),
            ),
            const SizedBox(height: 20),
            Text(
              'Menu updated',
              style: DinemateTypography.pageTitle(context).copyWith(
                color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '$inserted items inserted into your database',
              textAlign: TextAlign.center,
              style: DinemateTypography.body(context).copyWith(
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 28),
            DinemateButton(
              label: 'Back to Menu',
              onPressed: () {
                ref.invalidate(menuItemsProvider);
                Navigator.pop(context);
              },
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: () {
                setState(() {
                  _step = _Step.upload;
                  _files.clear();
                  _session = null;
                  _commitResult = null;
                  _error = null;
                });
              },
              child: const Text('Import more'),
            ),
          ],
        ),
      ),
    );
  }
}

class _PickCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _PickCard({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Material(
      color: isDark ? AppColors.darkCard : AppColors.surface,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isDark ? AppColors.darkBorder : AppColors.border,
            ),
          ),
          child: Column(
            children: [
              Icon(icon, color: AppColors.primary, size: 28),
              const SizedBox(height: 8),
              Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
