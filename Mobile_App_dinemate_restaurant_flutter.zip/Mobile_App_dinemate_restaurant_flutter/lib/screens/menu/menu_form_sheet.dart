import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';
import 'package:dinemate_restaurant/core/utils/validators.dart';
import 'package:dinemate_restaurant/models/menu_item.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/widgets/dinemate/dinemate_button.dart';

Future<void> showMenuItemForm(
  BuildContext context,
  WidgetRef ref, {
  MenuItem? existing,
}) async {
  final categories =
      await ref.read(categoriesProvider.future).catchError((_) => <MenuCategory>[]);

  if (!context.mounted) return;

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (ctx) {
      return _MenuItemFormBody(
        existing: existing,
        categories: categories,
        parentRef: ref,
      );
    },
  );
}

class _MenuItemFormBody extends StatefulWidget {
  final MenuItem? existing;
  final List<MenuCategory> categories;
  final WidgetRef parentRef;

  const _MenuItemFormBody({
    required this.existing,
    required this.categories,
    required this.parentRef,
  });

  @override
  State<_MenuItemFormBody> createState() => _MenuItemFormBodyState();
}

class _MenuItemFormBodyState extends State<_MenuItemFormBody> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameCtrl;
  late final TextEditingController _priceCtrl;
  late final TextEditingController _descCtrl;
  late final TextEditingController _costCtrl;
  late String _foodType;
  String? _categoryId;
  late bool _available;
  bool _submitting = false;
  bool _deleting = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _nameCtrl = TextEditingController(text: e?.name ?? '');
    _priceCtrl = TextEditingController(
      text: e != null ? e.price.toStringAsFixed(e.price.truncateToDouble() == e.price ? 0 : 2) : '',
    );
    _descCtrl = TextEditingController(text: e?.description ?? '');
    _costCtrl = TextEditingController(
      text: e?.costPrice != null
          ? e!.costPrice!.toStringAsFixed(
              e.costPrice!.truncateToDouble() == e.costPrice ? 0 : 2,
            )
          : '',
    );
    _foodType = e?.foodType ?? (e?.isVeg == false ? 'non-veg' : 'veg');
    _categoryId = e?.categoryId;
    _available = e?.available ?? true;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _priceCtrl.dispose();
    _descCtrl.dispose();
    _costCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_submitting) return;

    setState(() => _submitting = true);
    try {
      final body = <String, dynamic>{
        'name': _nameCtrl.text.trim(),
        'price': double.parse(_priceCtrl.text.trim()),
        'description': _descCtrl.text.trim(),
        'foodType': _foodType,
        'isVeg': _foodType == 'veg',
        'available': _available,
        if (_categoryId != null) 'categoryId': _categoryId,
        if (_costCtrl.text.trim().isNotEmpty)
          'costPrice': double.tryParse(_costCtrl.text.trim()),
      };
      final service = widget.parentRef.read(restaurantServiceProvider);
      if (widget.existing == null) {
        await service.createMenuItem(body);
      } else {
        await service.updateMenuItem(widget.existing!.id, body);
      }
      widget.parentRef.invalidate(menuItemsProvider);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(Validators.friendlyError(e)),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Future<void> _delete() async {
    final existing = widget.existing;
    if (existing == null || _deleting) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete Item'),
        content: Text('Delete "${existing.name}"? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(c, true),
            style: TextButton.styleFrom(foregroundColor: AppColors.error),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    setState(() => _deleting = true);
    try {
      await widget.parentRef.read(restaurantServiceProvider).deleteMenuItem(existing.id);
      widget.parentRef.invalidate(menuItemsProvider);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(Validators.friendlyError(e)),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _deleting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final existing = widget.existing;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 12,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: AppColors.borderStrong,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              Text(
                existing == null ? 'Add Menu Item' : 'Edit Menu Item',
                style: DinemateTypography.sectionTitle(context),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _nameCtrl,
                textInputAction: TextInputAction.next,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(labelText: 'Name *'),
                validator: (v) => Validators.name(v, field: 'Name'),
                enabled: !_submitting,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _priceCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Price (₹) *',
                  prefixText: '₹ ',
                ),
                validator: (v) => Validators.positiveNumber(v, field: 'Price'),
                enabled: !_submitting,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _costCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'Cost Price (₹)',
                  prefixText: '₹ ',
                ),
                validator: (v) =>
                    Validators.positiveNumber(v, field: 'Cost price', required: false),
                enabled: !_submitting,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _descCtrl,
                decoration: const InputDecoration(labelText: 'Description'),
                maxLines: 2,
                maxLength: 500,
                validator: (v) => Validators.maxLength(v, 500, field: 'Description'),
                enabled: !_submitting,
              ),
              const SizedBox(height: 4),
              if (widget.categories.isNotEmpty) ...[
                DropdownButtonFormField<String>(
                  key: ValueKey('cat_$_categoryId'),
                  initialValue: _categoryId,
                  decoration: const InputDecoration(labelText: 'Category'),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('None')),
                    ...widget.categories.map(
                      (c) => DropdownMenuItem(value: c.id, child: Text(c.name)),
                    ),
                  ],
                  onChanged: _submitting
                      ? null
                      : (v) => setState(() => _categoryId = v),
                ),
                const SizedBox(height: 12),
              ],
              DropdownButtonFormField<String>(
                key: ValueKey('food_$_foodType'),
                initialValue: _foodType,
                decoration: const InputDecoration(labelText: 'Food Type'),
                items: const [
                  DropdownMenuItem(value: 'veg', child: Text('Veg')),
                  DropdownMenuItem(value: 'non-veg', child: Text('Non-Veg')),
                  DropdownMenuItem(value: 'egg', child: Text('Egg')),
                ],
                onChanged: _submitting
                    ? null
                    : (v) => setState(() => _foodType = v ?? 'veg'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Available'),
                value: _available,
                onChanged: _submitting
                    ? null
                    : (v) => setState(() => _available = v),
              ),
              const SizedBox(height: 8),
              DinemateButton(
                label: existing == null ? 'Add Item' : 'Save Changes',
                loading: _submitting,
                onPressed: _submitting || _deleting ? null : _submit,
              ),
              if (existing != null) ...[
                const SizedBox(height: 8),
                DinemateButton(
                  label: 'Delete Item',
                  variant: DinemateButtonVariant.destructive,
                  loading: _deleting,
                  onPressed: _submitting || _deleting ? null : _delete,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
