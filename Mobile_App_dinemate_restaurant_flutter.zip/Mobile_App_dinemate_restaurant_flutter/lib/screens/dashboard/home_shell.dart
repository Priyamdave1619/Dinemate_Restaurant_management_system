import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/widgets/dinemate/adaptive_scaffold.dart';
import 'package:dinemate_restaurant/screens/dashboard/dashboard_screen.dart';
import 'package:dinemate_restaurant/screens/orders/orders_screen.dart';
import 'package:dinemate_restaurant/screens/menu/menu_screen.dart';
import 'package:dinemate_restaurant/screens/tables/tables_screen.dart';
import 'package:dinemate_restaurant/screens/profile/more_screen.dart';

class HomeShell extends ConsumerStatefulWidget {
  const HomeShell({super.key});

  @override
  ConsumerState<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends ConsumerState<HomeShell> {
  int _index = 0;

  static const _destinations = [
    AdaptiveNavItem(
      icon: Icons.grid_view_outlined,
      selectedIcon: Icons.grid_view_rounded,
      label: 'Home',
    ),
    AdaptiveNavItem(
      icon: Icons.receipt_long_outlined,
      selectedIcon: Icons.receipt_long_rounded,
      label: 'Orders',
    ),
    AdaptiveNavItem(
      icon: Icons.restaurant_menu_outlined,
      selectedIcon: Icons.restaurant_menu_rounded,
      label: 'Menu',
    ),
    AdaptiveNavItem(
      icon: Icons.table_restaurant_outlined,
      selectedIcon: Icons.table_restaurant_rounded,
      label: 'Tables',
    ),
    AdaptiveNavItem(
      icon: Icons.more_horiz_rounded,
      selectedIcon: Icons.more_horiz_rounded,
      label: 'More',
    ),
  ];

  final _pages = const [
    DashboardScreen(),
    OrdersScreen(),
    MenuScreen(),
    TablesScreen(),
    MoreScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return DinemateAdaptiveScaffold(
      selectedIndex: _index,
      onDestinationSelected: (i) => setState(() => _index = i),
      destinations: _destinations,
      pages: _pages,
    );
  }
}
