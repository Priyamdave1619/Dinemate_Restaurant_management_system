import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';
import 'package:dinemate_restaurant/models/order.dart';
import 'package:dinemate_restaurant/providers/auth_provider.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/providers/theme_provider.dart';
import 'package:dinemate_restaurant/widgets/common/status_chip.dart';
import 'package:dinemate_restaurant/widgets/common/brand_logo.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:dinemate_restaurant/widgets/dinemate/dinemate_card.dart';
import 'package:dinemate_restaurant/core/responsive/dinemate_breakpoints.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider).valueOrNull;
    final statsAsync = ref.watch(dashboardStatsProvider);
    final ordersAsync = ref.watch(activeOrdersProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final name = user?.name ?? user?.username ?? 'there';

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.background,
      body: SafeArea(
        child: RefreshIndicator(
          color: AppColors.primary,
          onRefresh: () async {
            ref.invalidate(dashboardStatsProvider);
            ref.invalidate(activeOrdersProvider);
            ref.invalidate(tablesProvider);
          },
          child: CustomScrollView(
            physics: const AlwaysScrollableScrollPhysics(
              parent: BouncingScrollPhysics(),
            ),
            slivers: [
              // Header
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 12, 8),
                  child: Row(
                    children: [
                      const BrandLogo.icon(),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              user?.restaurantName ?? 'Dinemate',
                              style: DinemateTypography.sectionTitle(context).copyWith(
                                color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              '${_greeting()}, $name',
                              style: DinemateTypography.caption(context).copyWith(
                                color: AppColors.textSecondary,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: isDark ? 'Light mode' : 'Dark mode',
                        onPressed: () => ref.read(themeModeProvider.notifier).toggle(),
                        icon: Icon(
                          isDark ? Icons.light_mode_rounded : Icons.dark_mode_outlined,
                          color: AppColors.textSecondary,
                          size: 22,
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          ref.invalidate(dashboardStatsProvider);
                          ref.invalidate(activeOrdersProvider);
                          ref.invalidate(tablesProvider);
                        },
                        icon: const Icon(Icons.refresh_rounded, size: 22),
                        color: AppColors.primary,
                      ),
                    ],
                  ),
                ),
              ),

              // Metrics
              SliverToBoxAdapter(
                child: statsAsync.when(
                  data: (stats) => _MetricsGrid(stats: stats),
                  loading: () => const Padding(
                    padding: EdgeInsets.all(20),
                    child: SkeletonList(count: 2, itemHeight: 110),
                  ),
                  error: (_, __) => _MetricsGrid(stats: const {}),
                ),
              ),

              // Section header
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
                  child: Row(
                    children: [
                      Text(
                        'Active Orders',
                        style: DinemateTypography.sectionTitle(context).copyWith(
                          color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.navyTint,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: ordersAsync.when(
                          data: (orders) {
                            final n = orders
                                .where((o) =>
                                    o.status != OrderStatus.completed &&
                                    o.status != OrderStatus.cancelled)
                                .length;
                            return Text(
                              '$n live',
                              style: DinemateTypography.caption(context).copyWith(
                                color: AppColors.primary,
                                fontWeight: FontWeight.w600,
                              ),
                            );
                          },
                          loading: () => Text(
                            '…',
                            style: DinemateTypography.caption(context)
                                .copyWith(color: AppColors.primary),
                          ),
                          error: (_, __) => const SizedBox.shrink(),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Orders list
              ordersAsync.when(
                data: (orders) {
                  final active = orders
                      .where((o) =>
                          o.status != OrderStatus.completed &&
                          o.status != OrderStatus.cancelled)
                      .toList();
                  if (active.isEmpty) {
                    return SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 32),
                        child: Column(
                          children: [
                            Container(
                              width: 64,
                              height: 64,
                              decoration: BoxDecoration(
                                color: AppColors.navyTint,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.receipt_long_outlined,
                                color: AppColors.primary,
                                size: 28,
                              ),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'No active orders',
                              style: DinemateTypography.sectionTitle(context),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'New orders will appear here in real time',
                              style: DinemateTypography.body(context).copyWith(
                                color: AppColors.textSecondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }
                  return SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, i) => _OrderTile(order: active[i]),
                      childCount: active.length,
                    ),
                  );
                },
                loading: () => const SliverToBoxAdapter(
                  child: SkeletonList(count: 4, itemHeight: 88),
                ),
                error: (e, _) => SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Text(
                      'Couldn’t load orders. Pull to refresh.',
                      style: TextStyle(color: AppColors.error),
                    ),
                  ),
                ),
              ),

              const SliverToBoxAdapter(child: SizedBox(height: 32)),
            ],
          ),
        ),
      ),
    );
  }
}

class _MetricsGrid extends StatelessWidget {
  final Map<String, dynamic> stats;
  const _MetricsGrid({required this.stats});

  @override
  Widget build(BuildContext context) {
    final currency = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    final todaySales = (stats['todaySales'] as num?)?.toDouble() ?? 0;
    final activeOrders = (stats['activeOrders'] as num?)?.toInt() ??
        (stats['ordersToday'] as num?)?.toInt() ??
        0;
    final tablesOccupied = (stats['tablesOccupied'] as num?)?.toInt() ??
        (stats['occupiedTables'] as num?)?.toInt() ??
        0;
    final totalTables = (stats['totalTables'] as num?)?.toInt() ?? 0;

    final cards = [
      DinemateMetricCard(
        label: "Today's Sales",
        value: currency.format(todaySales),
        icon: Icons.payments_outlined,
        accent: AppColors.primary,
      ),
      DinemateMetricCard(
        label: 'Active Orders',
        value: '$activeOrders',
        icon: Icons.receipt_long_outlined,
        accent: AppColors.info,
      ),
      DinemateMetricCard(
        label: 'Tables Occupied',
        value: totalTables > 0 ? '$tablesOccupied / $totalTables' : '$tablesOccupied',
        icon: Icons.table_restaurant_outlined,
        accent: AppColors.success,
      ),
      DinemateMetricCard(
        label: 'Status',
        value: 'Live',
        icon: Icons.sensors_rounded,
        accent: AppColors.warning,
        subtitle: 'Real-time',
      ),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final cols = DinemateBreakpoints.metricColumns(constraints.maxWidth);
        final gap = 12.0;
        final itemWidth = (constraints.maxWidth - 32 - gap * (cols - 1)) / cols;
        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
          child: Wrap(
            spacing: gap,
            runSpacing: gap,
            children: [
              for (final c in cards)
                SizedBox(width: itemWidth.clamp(140, 600), child: c),
            ],
          ),
        );
      },
    );
  }
}

class _OrderTile extends StatelessWidget {
  final Order order;
  const _OrderTile({required this.order});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final currency = NumberFormat.currency(symbol: '₹', decimalDigits: 0);
    final time = DateFormat('hh:mm a').format(order.placedAt);

    return DinemateCard(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.navyTint,
              borderRadius: BorderRadius.circular(12),
            ),
            alignment: Alignment.center,
            child: Text(
              'T${order.tableNumber}',
              style: const TextStyle(
                fontWeight: FontWeight.w700,
                color: AppColors.primary,
                fontSize: 13,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  order.id,
                  style: DinemateTypography.cardTitle(context).copyWith(
                    color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 3),
                Text(
                  [
                    if (time.isNotEmpty) time,
                    '${order.itemCount} items',
                  ].join(' · '),
                  style: DinemateTypography.caption(context).copyWith(
                    color: AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                currency.format(order.total),
                style: DinemateTypography.cardTitle(context).copyWith(
                  color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                ),
              ),
              const SizedBox(height: 4),
              StatusChip(status: order.status),
            ],
          ),
        ],
      ),
    );
  }
}
