import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/models/offer.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';

class OffersScreen extends ConsumerWidget {
  const OffersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(offersProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Offers'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: () => ref.invalidate(offersProvider)),
        ],
      ),
      body: async.when(
        data: (offers) {
          if (offers.isEmpty) {
            return const Center(child: Text('No offers', style: TextStyle(color: AppColors.textSecondary)));
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(offersProvider),
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: offers.length,
              itemBuilder: (_, i) => _OfferTile(offer: offers[i]),
            ),
          );
        },
        loading: () => const LoadingView(message: 'Loading…'),
        error: (e, _) => Center(child: Text('$e')),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () => _showOfferForm(context, ref),
      ),
    );
  }

  void _showOfferForm(BuildContext context, WidgetRef ref) {
    final nameCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final valueCtrl = TextEditingController();
    String type = 'percent';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModal) {
            return Padding(
              padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Create Offer', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 16),
                  TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Offer Name')),
                  const SizedBox(height: 12),
                  TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Description')),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    key: ValueKey('offer_type_$type'),
                    initialValue: type,
                    decoration: const InputDecoration(labelText: 'Type'),
                    items: const [
                      DropdownMenuItem(value: 'percent', child: Text('Percentage')),
                      DropdownMenuItem(value: 'flat', child: Text('Flat Amount')),
                      DropdownMenuItem(value: 'bogo', child: Text('Buy X Get Y')),
                      DropdownMenuItem(value: 'coupon', child: Text('Coupon')),
                    ],
                    onChanged: (v) => setModal(() => type = v ?? 'percent'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: valueCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                      labelText: type == 'percent' ? 'Discount %' : 'Discount Amount (₹)',
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () async {
                      final val = double.tryParse(valueCtrl.text);
                      if (nameCtrl.text.trim().isEmpty) return;
                      try {
                        final body = <String, dynamic>{
                          'name': nameCtrl.text.trim(),
                          'description': descCtrl.text.trim(),
                          'type': type,
                          'active': true,
                        };
                        if (type == 'percent') {
                          body['discountPercent'] = val ?? 0;
                        } else {
                          body['discountAmount'] = val ?? 0;
                        }
                        await ref.read(restaurantServiceProvider).createOffer(body);
                        ref.invalidate(offersProvider);
                        if (ctx.mounted) Navigator.pop(ctx);
                      } catch (e) {
                        if (ctx.mounted) {
                          ScaffoldMessenger.of(ctx).showSnackBar(
                            SnackBar(content: Text('$e'), backgroundColor: AppColors.error),
                          );
                        }
                      }
                    },
                    child: const Text('Create Offer'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _OfferTile extends ConsumerWidget {
  final Offer offer;
  const _OfferTile({required this.offer});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: offer.active
              ? AppColors.warning.withValues(alpha: 0.15)
              : AppColors.surfaceMuted,
          child: Icon(Icons.local_offer_rounded,
              color: offer.active ? AppColors.warning : AppColors.textMuted),
        ),
        title: Text(offer.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('${offer.discountLabel} · ${offer.type}'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Switch.adaptive(
              value: offer.active,
              activeTrackColor: AppColors.primary.withValues(alpha: 0.45),
              activeThumbColor: AppColors.primary,
              onChanged: (v) async {
                await ref.read(restaurantServiceProvider).updateOffer(offer.id, {'active': v});
                ref.invalidate(offersProvider);
              },
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline, color: AppColors.error, size: 20),
              onPressed: () async {
                await ref.read(restaurantServiceProvider).deleteOffer(offer.id);
                ref.invalidate(offersProvider);
              },
            ),
          ],
        ),
      ),
    );
  }
}
