import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/models/settings.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';

class ActivityScreen extends ConsumerWidget {
  const ActivityScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(activityLogsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Activity Log'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: () => ref.invalidate(activityLogsProvider)),
        ],
      ),
      body: async.when(
        data: (logs) {
          if (logs.isEmpty) {
            return const Center(child: Text('No activity yet', style: TextStyle(color: AppColors.textSecondary)));
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(activityLogsProvider),
            child: ListView.builder(
              itemCount: logs.length,
              itemBuilder: (_, i) => _LogTile(log: logs[i]),
            ),
          );
        },
        loading: () => const LoadingView(message: 'Loading…'),
        error: (e, _) => Center(child: Text('$e')),
      ),
    );
  }
}

class _LogTile extends StatelessWidget {
  final ActivityLog log;
  const _LogTile({required this.log});

  @override
  Widget build(BuildContext context) {
    DateTime? dt;
    try { dt = DateTime.parse(log.createdAt); } catch (_) {}
    final time = dt != null ? DateFormat('dd MMM · hh:mm a').format(dt) : log.createdAt;

    return ListTile(
      leading: const CircleAvatar(
        backgroundColor: Color(0xFFE2E8F0),
        child: Icon(Icons.history_rounded, size: 20, color: AppColors.textSecondary),
      ),
      title: Text(log.action, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14)),
      subtitle: Text(
        [
          if (log.actorName != null) log.actorName!,
          if (log.actorRole != null) log.actorRole!,
          if (log.entityType != null) log.entityType!,
          time,
        ].join(' · '),
        style: const TextStyle(fontSize: 12),
      ),
    );
  }
}
