import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/models/order.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/widgets/common/status_chip.dart';

class OrdersScreen extends ConsumerStatefulWidget {
  const OrdersScreen({super.key});

  @override
  ConsumerState<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends ConsumerState<OrdersScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _searchCtrl = TextEditingController();
  String _query = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Orders'),
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          indicatorColor: AppColors.primary,
          tabs: const [
            Tab(text: 'Active'),
            Tab(text: 'History'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () {
              ref.invalidate(activeOrdersProvider);
              ref.invalidate(orderHistoryProvider);
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search orders, table, bill…',
                prefixIcon: const Icon(Icons.search_rounded),
                suffixIcon: _query.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.clear_rounded),
                        onPressed: () {
                          _searchCtrl.clear();
                          setState(() => _query = '');
                        },
                      ),
                isDense: true,
              ),
              onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _OrdersList(
                  provider: activeOrdersProvider,
                  isActive: true,
                  query: _query,
                ),
                _OrdersList(
                  provider: orderHistoryProvider,
                  isActive: false,
                  query: _query,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _OrdersList extends ConsumerWidget {
  final AutoDisposeFutureProvider<List<Order>> provider;
  final bool isActive;
  final String query;

  const _OrdersList({
    required this.provider,
    required this.isActive,
    this.query = '',
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(provider);

    return async.when(
      data: (orders) {
        var filtered = isActive
            ? orders
                .where((o) =>
                    o.status != OrderStatus.completed &&
                    o.status != OrderStatus.cancelled)
                .toList()
            : orders;
        if (query.isNotEmpty) {
          filtered = filtered.where((o) {
            final hay = [
              o.tableNumber.toString(),
              o.status.name,
              o.id,
              o.customerName ?? '',
              o.waiterName ?? '',
              ...o.items.map((i) => i.name),
            ].join(' ').toLowerCase();
            return hay.contains(query);
          }).toList();
        }

        if (filtered.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.receipt_long_outlined,
                  size: 56,
                  color: AppColors.textSecondary.withValues(alpha: 0.5),
                ),
                const SizedBox(height: 12),
                Text(
                  isActive ? 'No active orders' : 'No order history',
                  style: const TextStyle(color: AppColors.textSecondary),
                ),
              ],
            ),
          );
        }

        return RefreshIndicator(
          onRefresh: () async => ref.invalidate(provider),
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 8),
            itemCount: filtered.length,
            itemBuilder: (context, index) {
              final order = filtered[index];
              return _OrderListTile(order: order);
            },
          ),
        );
      },
      loading: () => const LoadingView(message: 'Loading…'),
      error: (e, _) => Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, color: AppColors.error, size: 40),
              const SizedBox(height: 12),
              Text('$e', textAlign: TextAlign.center),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () => ref.invalidate(provider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _OrderListTile extends ConsumerWidget {
  final Order order;
  const _OrderListTile({required this.order});

  Future<void> _updateStatus(BuildContext context, WidgetRef ref, OrderStatus next) async {
    try {
      final service = ref.read(restaurantServiceProvider);
      await service.updateOrderStatus(order.id, next.name);
      ref.invalidate(activeOrdersProvider);
      ref.invalidate(orderHistoryProvider);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Order updated to ${next.displayName}')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed: $e'), backgroundColor: AppColors.error),
        );
      }
    }
  }

  void _showActions(BuildContext context, WidgetRef ref) {
    final nextStatuses = <OrderStatus>[];
    switch (order.status) {
      case OrderStatus.pending:
        nextStatuses.addAll([OrderStatus.confirmed, OrderStatus.cancelled]);
        break;
      case OrderStatus.confirmed:
        nextStatuses.addAll([OrderStatus.preparing, OrderStatus.cancelled]);
        break;
      case OrderStatus.preparing:
        nextStatuses.addAll([OrderStatus.ready, OrderStatus.cancelled]);
        break;
      case OrderStatus.ready:
        nextStatuses.addAll([OrderStatus.served]);
        break;
      case OrderStatus.served:
        nextStatuses.addAll([OrderStatus.completed]);
        break;
      default:
        break;
    }

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 8),
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'Table ${order.tableNumber} · ₹${order.total.toStringAsFixed(0)}',
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                ),
              ),
              ...order.items.map(
                (item) => ListTile(
                  dense: true,
                  title: Text('${item.quantity}× ${item.name}'),
                  trailing: Text('₹${item.lineTotal.toStringAsFixed(0)}'),
                ),
              ),
              const Divider(),
              ...nextStatuses.map(
                (s) => ListTile(
                  leading: const Icon(Icons.arrow_forward_rounded),
                  title: Text('Mark as ${s.displayName}'),
                  onTap: () {
                    Navigator.pop(ctx);
                    _updateStatus(context, ref, s);
                  },
                ),
              ),
              if (order.status == OrderStatus.served || order.status == OrderStatus.ready)
                ListTile(
                  leading: const Icon(Icons.receipt_rounded),
                  title: const Text('Generate / View Bill'),
                  onTap: () async {
                    Navigator.pop(ctx);
                    try {
                      final bill = await ref
                          .read(restaurantServiceProvider)
                          .getOrderBill(order.id);
                      if (!context.mounted) return;
                      final settings = bill['settings'] is Map
                          ? bill['settings'] as Map
                          : {};
                      final ord = bill['order'] is Map ? bill['order'] as Map : {};
                      final name = settings['restaurantName'] ?? 'Restaurant';
                      final billNo = ord['billNumber'] ?? '—';
                      final total = ord['total'] ?? order.total;
                      showDialog(
                        context: context,
                        builder: (dCtx) => AlertDialog(
                          title: Text('$name'),
                          content: Text('Bill #$billNo\nTotal: ₹$total'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(dCtx),
                              child: const Text('Close'),
                            ),
                          ],
                        ),
                      );
                    } catch (e) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Failed: $e'),
                            backgroundColor: AppColors.error,
                          ),
                        );
                      }
                    }
                  },
                ),
              if (order.status != OrderStatus.cancelled &&
                  order.status != OrderStatus.completed)
                ListTile(
                  leading: const Icon(Icons.print_outlined),
                  title: const Text('Print KOT'),
                  onTap: () async {
                    Navigator.pop(ctx);
                    try {
                      await ref
                          .read(restaurantServiceProvider)
                          .markKotPrinted(order.id);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('KOT marked as printed')),
                        );
                      }
                    } catch (e) {
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('KOT failed: $e'),
                            backgroundColor: AppColors.error,
                          ),
                        );
                      }
                    }
                  },
                ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final time = DateFormat('dd MMM · hh:mm a').format(order.placedAt);
    return Card(
      child: InkWell(
        onTap: () => _showActions(context, ref),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              CircleAvatar(
                radius: 22,
                backgroundColor: AppColors.primary.withValues(alpha: 0.1),
                child: Text(
                  'T${order.tableNumber}',
                  style: const TextStyle(
                    color: AppColors.primary,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${order.itemCount} items · $time',
                      style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
                    ),
                    const SizedBox(height: 4),
                    StatusChip(status: order.status),
                  ],
                ),
              ),
              Text(
                '₹${order.total.toStringAsFixed(0)}',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
              ),
              const SizedBox(width: 4),
              const Icon(Icons.chevron_right, color: AppColors.textSecondary),
            ],
          ),
        ),
      ),
    );
  }
}
