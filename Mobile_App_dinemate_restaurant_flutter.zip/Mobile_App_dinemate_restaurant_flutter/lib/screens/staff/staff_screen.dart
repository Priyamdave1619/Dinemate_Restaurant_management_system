import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/models/staff_user.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';

class StaffScreen extends ConsumerWidget {
  const StaffScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final staffAsync = ref.watch(staffProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Staff'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => ref.invalidate(staffProvider),
          ),
        ],
      ),
      body: staffAsync.when(
        data: (staff) {
          if (staff.isEmpty) {
            return const Center(child: Text('No staff members', style: TextStyle(color: AppColors.textSecondary)));
          }
          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(staffProvider),
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: staff.length,
              itemBuilder: (context, i) => _StaffTile(user: staff[i]),
            ),
          );
        },
        loading: () => const LoadingView(message: 'Loading…'),
        error: (e, _) => Center(child: Text('Error: $e')),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.person_add_rounded, color: Colors.white),
        onPressed: () => _showStaffForm(context, ref),
      ),
    );
  }

  void _showStaffForm(BuildContext context, WidgetRef ref, {StaffUser? existing}) {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final userCtrl = TextEditingController(text: existing?.username ?? '');
    final passCtrl = TextEditingController();
    String role = existing?.role ?? 'waiter';
    bool active = existing?.active ?? true;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20, right: 20, top: 20,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(existing == null ? 'Add Staff' : 'Edit Staff',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 16),
                  TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Full Name')),
                  const SizedBox(height: 12),
                  if (existing == null)
                    TextField(controller: userCtrl, decoration: const InputDecoration(labelText: 'Username')),
                  if (existing == null) const SizedBox(height: 12),
                  TextField(
                    controller: passCtrl,
                    obscureText: true,
                    decoration: InputDecoration(
                      labelText: existing == null ? 'Password' : 'New Password (optional)',
                    ),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    key: ValueKey('role_$role'),
                    initialValue: role,
                    decoration: const InputDecoration(labelText: 'Role'),
                    items: const [
                      DropdownMenuItem(value: 'manager', child: Text('Manager')),
                      DropdownMenuItem(value: 'waiter', child: Text('Waiter')),
                    ],
                    onChanged: (v) => setModalState(() => role = v ?? 'waiter'),
                  ),
                  if (existing != null)
                    SwitchListTile(
                      title: const Text('Active'),
                      value: active,
                      onChanged: (v) => setModalState(() => active = v),
                    ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      final nameErr = nameCtrl.text.trim().isEmpty
                          ? 'Full name is required'
                          : (nameCtrl.text.trim().length < 2
                              ? 'Name is too short'
                              : null);
                      final userErr = existing == null &&
                              (userCtrl.text.trim().isEmpty ||
                                  userCtrl.text.trim().length < 3)
                          ? 'Username must be at least 3 characters'
                          : null;
                      final passErr = existing == null && passCtrl.text.length < 4
                          ? 'Password must be at least 4 characters'
                          : null;
                      final msg = nameErr ?? userErr ?? passErr;
                      if (msg != null) {
                        ScaffoldMessenger.of(ctx).showSnackBar(
                          SnackBar(content: Text(msg), backgroundColor: AppColors.error),
                        );
                        return;
                      }
                      try {
                        final service = ref.read(restaurantServiceProvider);
                        if (existing == null) {
                          await service.createStaff({
                            'name': nameCtrl.text.trim(),
                            'username': userCtrl.text.trim(),
                            'password': passCtrl.text,
                            'role': role,
                          });
                        } else {
                          final body = <String, dynamic>{
                            'name': nameCtrl.text.trim(),
                            'role': role,
                            'active': active,
                          };
                          if (passCtrl.text.isNotEmpty) body['password'] = passCtrl.text;
                          await service.updateStaff(existing.id, body);
                        }
                        ref.invalidate(staffProvider);
                        if (ctx.mounted) Navigator.pop(ctx);
                      } catch (e) {
                        if (ctx.mounted) {
                          final text = e
                              .toString()
                              .replaceFirst(RegExp(r'^Exception:\s*'), '');
                          ScaffoldMessenger.of(ctx).showSnackBar(
                            SnackBar(
                              content: Text(
                                text.length > 180
                                    ? '${text.substring(0, 177)}…'
                                    : text,
                              ),
                              backgroundColor: AppColors.error,
                            ),
                          );
                        }
                      }
                    },
                    child: Text(existing == null ? 'Create' : 'Save'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _StaffTile extends ConsumerWidget {
  final StaffUser user;
  const _StaffTile({required this.user});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: user.active
              ? AppColors.primary.withValues(alpha: 0.15)
              : AppColors.surfaceMuted,
          child: Text(
            user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
            style: TextStyle(
              color: user.active ? AppColors.primary : Colors.grey,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        title: Text(user.name, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('${user.username} · ${user.role}'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: (user.active ? AppColors.success : AppColors.textSecondary).withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                user.active ? 'Active' : 'Inactive',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: user.active ? AppColors.success : AppColors.textSecondary,
                ),
              ),
            ),
            PopupMenuButton<String>(
              onSelected: (v) async {
                if (v == 'edit') {
                  // reopen form — simplified: toggle active / delete
                } else if (v == 'toggle') {
                  await ref.read(restaurantServiceProvider).updateStaff(user.id, {'active': !user.active});
                  ref.invalidate(staffProvider);
                } else if (v == 'delete') {
                  final ok = await showDialog<bool>(
                    context: context,
                    builder: (c) => AlertDialog(
                      title: const Text('Delete Staff'),
                      content: Text('Delete ${user.name}?'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
                        TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
                      ],
                    ),
                  );
                  if (ok == true) {
                    await ref.read(restaurantServiceProvider).deleteStaff(user.id);
                    ref.invalidate(staffProvider);
                  }
                }
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'toggle', child: Text('Activate / Deactivate')),
                const PopupMenuItem(value: 'delete', child: Text('Delete')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
