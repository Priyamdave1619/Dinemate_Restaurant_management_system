import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';
import 'package:dinemate_restaurant/providers/notification_preferences_provider.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';

class NotificationSettingsScreen extends ConsumerWidget {
  const NotificationSettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(notificationPreferencesProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.background,
      appBar: AppBar(title: const Text('Notification Settings')),
      body: async.when(
        loading: () => const LoadingView(message: 'Loading preferences…'),
        error: (e, _) => Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('$e', style: const TextStyle(color: AppColors.error)),
              TextButton(
                onPressed: () =>
                    ref.invalidate(notificationPreferencesProvider),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
        data: (prefs) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
          children: [
            // Master toggle card
            _Card(
              isDark: isDark,
              child: _PrefTile(
                icon: Icons.notifications_active_rounded,
                title: 'Notifications',
                subtitle: 'Receive updates from Dinemate',
                value: prefs.enabled,
                onChanged: (v) async {
                  HapticFeedback.selectionClick();
                  await ref
                      .read(notificationPreferencesProvider.notifier)
                      .setEnabled(v);
                },
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'CATEGORIES',
              style: DinemateTypography.caption(context).copyWith(
                fontWeight: FontWeight.w700,
                letterSpacing: 0.8,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 8),
            _Card(
              isDark: isDark,
              child: Column(
                children: [
                  _PrefTile(
                    icon: Icons.receipt_long_rounded,
                    title: 'Order Updates',
                    subtitle: 'New, preparing, ready, cancelled',
                    value: prefs.orderUpdates,
                    enabled: prefs.enabled,
                    onChanged: (v) async {
                      HapticFeedback.selectionClick();
                      await ref
                          .read(notificationPreferencesProvider.notifier)
                          .setOrderUpdates(v);
                    },
                  ),
                  const Divider(height: 1),
                  _PrefTile(
                    icon: Icons.storefront_outlined,
                    title: 'Restaurant Updates',
                    subtitle: 'Menu, tables, staff changes',
                    value: prefs.restaurantUpdates,
                    enabled: prefs.enabled,
                    onChanged: (v) async {
                      HapticFeedback.selectionClick();
                      await ref
                          .read(notificationPreferencesProvider.notifier)
                          .setRestaurantUpdates(v);
                    },
                  ),
                  const Divider(height: 1),
                  _PrefTile(
                    icon: Icons.local_offer_outlined,
                    title: 'Promotions',
                    subtitle: 'Offers and campaigns',
                    value: prefs.promotions,
                    enabled: prefs.enabled,
                    onChanged: (v) async {
                      HapticFeedback.selectionClick();
                      await ref
                          .read(notificationPreferencesProvider.notifier)
                          .setPromotions(v);
                    },
                  ),
                  const Divider(height: 1),
                  _PrefTile(
                    icon: Icons.shield_outlined,
                    title: 'System Alerts',
                    subtitle: 'Important account & security notices',
                    value: prefs.systemAlerts,
                    enabled: prefs.enabled,
                    onChanged: (v) async {
                      HapticFeedback.selectionClick();
                      await ref
                          .read(notificationPreferencesProvider.notifier)
                          .setSystemAlerts(v);
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (!prefs.enabled)
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.warningSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info_outline, color: AppColors.warning, size: 20),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Optional notifications are paused. Existing history stays available.',
                        style: TextStyle(fontSize: 13, color: AppColors.textPrimary),
                      ),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 24),
            Text(
              'SYSTEM PERMISSION',
              style: DinemateTypography.caption(context).copyWith(
                fontWeight: FontWeight.w700,
                letterSpacing: 0.8,
                color: AppColors.textSecondary,
              ),
            ),
            const SizedBox(height: 8),
            _Card(
              isDark: isDark,
              child: ListTile(
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                leading: const Icon(Icons.settings_outlined, color: AppColors.primary),
                title: const Text('Device notification access'),
                subtitle: const Text(
                  'If alerts don’t appear, enable them in system settings',
                ),
                trailing: const Icon(Icons.open_in_new, size: 18),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Open your phone Settings → Apps → Dinemate → Notifications',
                      ),
                      behavior: SnackBarBehavior.floating,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final Widget child;
  final bool isDark;
  const _Card({required this.child, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkCard : AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isDark ? AppColors.darkBorder : AppColors.border,
        ),
        boxShadow: DinemateShadows.soft,
      ),
      child: child,
    );
  }
}

class _PrefTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final bool enabled;
  final ValueChanged<bool> onChanged;

  const _PrefTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.onChanged,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: enabled ? 1 : 0.45,
      child: SwitchListTile.adaptive(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        secondary: Icon(icon, color: AppColors.primary),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
        ),
        value: value && enabled,
        activeColor: AppColors.primary,
        onChanged: enabled ? onChanged : null,
      ),
    );
  }
}
