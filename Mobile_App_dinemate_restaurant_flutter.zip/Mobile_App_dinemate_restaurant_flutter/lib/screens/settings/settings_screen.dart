import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  final _nameCtrl = TextEditingController();
  final _taxCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _gstinCtrl = TextEditingController();
  final _billPrefixCtrl = TextEditingController();
  final _openCtrl = TextEditingController();
  final _closeCtrl = TextEditingController();
  final _currencyCtrl = TextEditingController();
  final _foodLicenceCtrl = TextEditingController();
  final _baseUrlCtrl = TextEditingController();
  bool _loaded = false;
  bool _saving = false;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _taxCtrl.dispose();
    _phoneCtrl.dispose();
    _addressCtrl.dispose();
    _gstinCtrl.dispose();
    _billPrefixCtrl.dispose();
    _openCtrl.dispose();
    _closeCtrl.dispose();
    _currencyCtrl.dispose();
    _foodLicenceCtrl.dispose();
    _baseUrlCtrl.dispose();
    super.dispose();
  }

  void _fill(Map<String, dynamic> s) {
    if (_loaded) return;
    _nameCtrl.text = s['restaurantName']?.toString() ?? '';
    _taxCtrl.text = (s['taxRatePercent'] as num?)?.toString() ?? '0';
    _phoneCtrl.text = s['phone']?.toString() ?? '';
    _addressCtrl.text = s['address']?.toString() ?? '';
    _gstinCtrl.text = s['gstin']?.toString() ?? '';
    _billPrefixCtrl.text = s['billPrefix']?.toString() ?? '';
    _openCtrl.text = s['openingTime']?.toString() ?? '';
    _closeCtrl.text = s['closingTime']?.toString() ?? '';
    _currencyCtrl.text = s['currency']?.toString() ?? 'INR';
    _foodLicenceCtrl.text = s['foodLicence']?.toString() ?? '';
    _baseUrlCtrl.text = s['baseUrl']?.toString() ?? '';
    _loaded = true;
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    try {
      await ref.read(restaurantServiceProvider).updateSettings({
        'restaurantName': _nameCtrl.text.trim(),
        'taxRatePercent': double.tryParse(_taxCtrl.text) ?? 0,
        'phone': _phoneCtrl.text.trim(),
        'address': _addressCtrl.text.trim(),
        'gstin': _gstinCtrl.text.trim(),
        'billPrefix': _billPrefixCtrl.text.trim(),
        'openingTime': _openCtrl.text.trim(),
        'closingTime': _closeCtrl.text.trim(),
        'currency': _currencyCtrl.text.trim().isEmpty ? 'INR' : _currencyCtrl.text.trim(),
        'foodLicence': _foodLicenceCtrl.text.trim(),
        'baseUrl': _baseUrlCtrl.text.trim(),
      });
      ref.invalidate(settingsProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'), backgroundColor: AppColors.error),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(settingsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: async.when(
        data: (settings) {
          _fill(settings.toJson());
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Restaurant Name')),
              const SizedBox(height: 12),
              TextField(
                controller: _taxCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Tax Rate (%)', suffixText: '%'),
              ),
              const SizedBox(height: 12),
              TextField(controller: _phoneCtrl, decoration: const InputDecoration(labelText: 'Phone'), keyboardType: TextInputType.phone),
              const SizedBox(height: 12),
              TextField(controller: _addressCtrl, decoration: const InputDecoration(labelText: 'Address'), maxLines: 2),
              const SizedBox(height: 12),
              TextField(controller: _gstinCtrl, decoration: const InputDecoration(labelText: 'GSTIN')),
              const SizedBox(height: 12),
              TextField(controller: _billPrefixCtrl, decoration: const InputDecoration(labelText: 'Bill Prefix')),
              const SizedBox(height: 12),
              TextField(controller: _currencyCtrl, decoration: const InputDecoration(labelText: 'Currency', hintText: 'INR')),
              const SizedBox(height: 12),
              TextField(controller: _foodLicenceCtrl, decoration: const InputDecoration(labelText: 'Food licence number')),
              const SizedBox(height: 12),
              TextField(controller: _baseUrlCtrl, decoration: const InputDecoration(labelText: 'Public base URL (QR / menu)', hintText: 'https://…')),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: TextField(controller: _openCtrl, decoration: const InputDecoration(labelText: 'Opening Time', hintText: '09:00'))),
                  const SizedBox(width: 12),
                  Expanded(child: TextField(controller: _closeCtrl, decoration: const InputDecoration(labelText: 'Closing Time', hintText: '23:00'))),
                ],
              ),
              const SizedBox(height: 24),
              SizedBox(
                height: 48,
                child: ElevatedButton(
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Save Settings'),
                ),
              ),
            ],
          );
        },
        loading: () => const LoadingView(message: 'Loading…'),
        error: (e, _) => Center(child: Text('$e')),
      ),
    );
  }
}
