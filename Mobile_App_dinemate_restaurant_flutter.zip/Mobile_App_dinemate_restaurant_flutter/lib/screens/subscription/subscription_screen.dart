import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/utils/validators.dart';
import 'package:dinemate_restaurant/models/settings.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';

class SubscriptionScreen extends ConsumerWidget {
  const SubscriptionScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(plansProvider);
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);

    return Scaffold(
      appBar: AppBar(title: const Text('Subscription')),
      body: async.when(
        data: (plans) {
          if (plans.isEmpty) {
            return const Center(child: Text('No plans available', style: TextStyle(color: AppColors.textSecondary)));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: plans.length,
            itemBuilder: (_, i) => _PlanCard(plan: plans[i], fmt: fmt),
          );
        },
        loading: () => const LoadingView(message: 'Loading…'),
        error: (e, _) => Center(child: Text('$e')),
      ),
    );
  }
}

class _PlanCard extends ConsumerWidget {
  final Plan plan;
  final NumberFormat fmt;
  const _PlanCard({required this.plan, required this.fmt});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(plan.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text(fmt.format(plan.price), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.primary)),
              ],
            ),
            const SizedBox(height: 4),
            Text('${plan.durationDays} days', style: const TextStyle(color: AppColors.textSecondary)),
            const SizedBox(height: 12),
            _limit('Products', plan.productLimit),
            _limit('Orders', plan.orderLimit),
            _limit('Users', plan.userLimit),
            _limit('Storage', '${plan.storageLimitMb} MB'),
            if (plan.features.isNotEmpty) ...[
              const SizedBox(height: 8),
              ...plan.features.map((f) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(
                      children: [
                        const Icon(Icons.check_circle, size: 16, color: AppColors.success),
                        const SizedBox(width: 6),
                        Expanded(child: Text(f, style: const TextStyle(fontSize: 13))),
                      ],
                    ),
                  )),
            ],
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  try {
                    final checkout = await ref
                        .read(restaurantServiceProvider)
                        .createCheckout(plan.id);
                    final url = (checkout['url'] ??
                            checkout['checkoutUrl'] ??
                            checkout['paymentUrl'] ??
                            checkout['short_url'])
                        ?.toString();
                    if (url != null && url.isNotEmpty) {
                      final uri = Uri.parse(url);
                      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
                      if (!ok && context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Could not open payment page')),
                        );
                      }
                    } else if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Checkout created. Complete payment in the browser when the link is available.',
                          ),
                        ),
                      );
                    }
                  } catch (e) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(Validators.friendlyError(e)),
                          backgroundColor: AppColors.error,
                        ),
                      );
                    }
                  }
                },
                child: const Text('Choose Plan'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _limit(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.textSecondary, fontSize: 13)),
          Text('$value', style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
        ],
      ),
    );
  }
}
