import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';
import 'package:dinemate_restaurant/models/settings.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/widgets/common/empty_state.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:dinemate_restaurant/services/local_notification_service.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(notificationsProvider);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.background,
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          TextButton(
            onPressed: () async {
              await ref.read(restaurantServiceProvider).markAllNotificationsRead();
              ref.invalidate(notificationsProvider);
              ref.invalidate(unreadNotificationsCountProvider);
            },
            child: const Text('Mark all read'),
          ),
        ],
      ),
      body: async.when(
        data: (list) {
          if (list.isEmpty) {
            return const EmptyState(
              icon: Icons.notifications_none_rounded,
              title: 'No notifications',
              subtitle: 'Order and system alerts will appear here',
            );
          }

          final grouped = _groupByDay(list);
          return RefreshIndicator(
            color: AppColors.primary,
            onRefresh: () async {
              ref.invalidate(notificationsProvider);
              ref.invalidate(unreadNotificationsCountProvider);
            },
            child: ListView.builder(
              padding: const EdgeInsets.only(bottom: 24),
              itemCount: grouped.length,
              itemBuilder: (context, sectionIndex) {
                final section = grouped[sectionIndex];
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                      child: Text(
                        section.label,
                        style: DinemateTypography.caption(context).copyWith(
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.4,
                        ),
                      ),
                    ),
                    ...section.items.map(
                      (n) => _NotifTile(
                        n: n,
                        onTap: () async {
                          if (!n.read) {
                            try {
                              await ref
                                  .read(restaurantServiceProvider)
                                  .markNotificationRead(n.id);
                            } catch (_) {}
                            ref.invalidate(notificationsProvider);
                            ref.invalidate(unreadNotificationsCountProvider);
                          }
                          if (!context.mounted) return;
                          // Deep-link hooks by type
                          _handleTap(context, n);
                        },
                      ),
                    ),
                  ],
                );
              },
            ),
          );
        },
        loading: () => const LoadingView(message: 'Loading alerts…'),
        error: (e, _) => Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, color: AppColors.error, size: 40),
                const SizedBox(height: 12),
                Text('Couldn’t load notifications', style: TextStyle(color: AppColors.textPrimary)),
                TextButton(
                  onPressed: () => ref.invalidate(notificationsProvider),
                  child: const Text('Retry'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _handleTap(BuildContext context, AppNotification n) {
    final type = n.type.toLowerCase();
    String msg = n.message;
    if (type.contains('order')) {
      msg = 'Open Orders tab to manage this order.';
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(
          label: 'OK',
          textColor: Colors.white,
          onPressed: () {},
        ),
      ),
    );
  }

  List<_NotifSection> _groupByDay(List<AppNotification> list) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final map = <String, List<AppNotification>>{};

    for (final n in list) {
      DateTime? dt;
      try {
        dt = DateTime.parse(n.createdAt).toLocal();
      } catch (_) {}
      final key = dt == null
          ? 'Earlier'
          : (DateTime(dt.year, dt.month, dt.day) == today
              ? 'Today'
              : DateTime(dt.year, dt.month, dt.day) == yesterday
                  ? 'Yesterday'
                  : DateFormat('dd MMM yyyy').format(dt));
      map.putIfAbsent(key, () => []).add(n);
    }

    // Preserve order: Today, Yesterday, then rest as encountered
    final order = <String>[];
    for (final k in ['Today', 'Yesterday']) {
      if (map.containsKey(k)) order.add(k);
    }
    for (final k in map.keys) {
      if (!order.contains(k)) order.add(k);
    }
    return order.map((k) => _NotifSection(label: k, items: map[k]!)).toList();
  }
}

class _NotifSection {
  final String label;
  final List<AppNotification> items;
  _NotifSection({required this.label, required this.items});
}

class _NotifTile extends StatelessWidget {
  final AppNotification n;
  final VoidCallback onTap;

  const _NotifTile({required this.n, required this.onTap});

  IconData get _icon {
    final t = n.type.toLowerCase();
    if (t.contains('order')) return Icons.receipt_long_rounded;
    if (t.contains('offer') || t.contains('promo')) return Icons.local_offer_outlined;
    if (t.contains('staff') || t.contains('user')) return Icons.person_outline;
    if (t.contains('table')) return Icons.table_restaurant_outlined;
    if (t.contains('menu')) return Icons.restaurant_menu_outlined;
    return Icons.notifications_rounded;
  }

  Color get _accent {
    final t = n.type.toLowerCase();
    if (t.contains('order')) return AppColors.info;
    if (t.contains('offer')) return AppColors.warning;
    if (t.contains('error') || t.contains('cancel')) return AppColors.error;
    return AppColors.primary;
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    DateTime? dt;
    try {
      dt = DateTime.parse(n.createdAt).toLocal();
    } catch (_) {}
    final time = dt != null ? DateFormat('hh:mm a').format(dt) : '';

    return Material(
      color: n.read
          ? Colors.transparent
          : (isDark
              ? AppColors.primary.withValues(alpha: 0.08)
              : AppColors.navyTint.withValues(alpha: 0.45)),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: _accent.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(_icon, color: _accent, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        if (!n.read)
                          Container(
                            width: 8,
                            height: 8,
                            margin: const EdgeInsets.only(right: 6),
                            decoration: const BoxDecoration(
                              color: AppColors.primary,
                              shape: BoxShape.circle,
                            ),
                          ),
                        Expanded(
                          child: Text(
                            n.title,
                            style: TextStyle(
                              fontWeight: n.read ? FontWeight.w500 : FontWeight.w700,
                              fontSize: 14,
                              color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                            ),
                          ),
                        ),
                        if (time.isNotEmpty)
                          Text(
                            time,
                            style: TextStyle(
                              fontSize: 11,
                              color: AppColors.textMuted,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      n.message,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 13,
                        color: AppColors.textSecondary,
                        height: 1.35,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Call once after login to surface a sample system banner if needed.
Future<void> showLocalAlert({
  required String title,
  required String body,
  String? payload,
}) {
  return LocalNotificationService.instance.show(
    id: DateTime.now().millisecondsSinceEpoch % 100000,
    title: title,
    body: body,
    payload: payload,
  );
}
