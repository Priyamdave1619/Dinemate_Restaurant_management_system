import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';
import 'package:dinemate_restaurant/core/utils/validators.dart';
import 'package:dinemate_restaurant/providers/auth_provider.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/services/auth_service.dart';
import 'package:dinemate_restaurant/widgets/dinemate/dinemate_button.dart';

/// Profile aligned with Next.js portal: account, change password, owner restaurant + logo.
class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  final _pwdFormKey = GlobalKey<FormState>();
  final _restaurantFormKey = GlobalKey<FormState>();

  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _currentPwdCtrl = TextEditingController();
  final _newPwdCtrl = TextEditingController();
  final _confirmPwdCtrl = TextEditingController();
  final _restNameCtrl = TextEditingController();
  final _ownerNameCtrl = TextEditingController();
  final _emailCtrl = TextEditingController();
  final _mobileCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _gstCtrl = TextEditingController();

  bool _loadedUser = false;
  bool _loadedRestaurant = false;
  bool _savingPwd = false;
  bool _savingRestaurant = false;
  bool _uploadingLogo = false;
  bool _obscureCurrent = true;
  bool _obscureNew = true;
  String? _logoUrl;

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _currentPwdCtrl.dispose();
    _newPwdCtrl.dispose();
    _confirmPwdCtrl.dispose();
    _restNameCtrl.dispose();
    _ownerNameCtrl.dispose();
    _emailCtrl.dispose();
    _mobileCtrl.dispose();
    _addressCtrl.dispose();
    _gstCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadRestaurant() async {
    try {
      final data = await ref.read(restaurantServiceProvider).getRestaurantMe();
      if (!mounted) return;
      setState(() {
        _restNameCtrl.text = data['name']?.toString() ?? '';
        _ownerNameCtrl.text = data['ownerName']?.toString() ?? '';
        _emailCtrl.text = data['email']?.toString() ?? '';
        _mobileCtrl.text =
            data['mobile']?.toString() ?? data['phone']?.toString() ?? '';
        _addressCtrl.text = data['address']?.toString() ?? '';
        _gstCtrl.text =
            data['gstNumber']?.toString() ?? data['gstin']?.toString() ?? '';
        _logoUrl = data['logoUrl']?.toString() ?? data['logo']?.toString();
        _loadedRestaurant = true;
      });
    } catch (_) {
      if (mounted) setState(() => _loadedRestaurant = true);
    }
  }

  Future<void> _changePassword() async {
    if (!_pwdFormKey.currentState!.validate()) return;
    setState(() => _savingPwd = true);
    try {
      await AuthService().changePassword(
        currentPassword: _currentPwdCtrl.text,
        newPassword: _newPwdCtrl.text,
      );
      _currentPwdCtrl.clear();
      _newPwdCtrl.clear();
      _confirmPwdCtrl.clear();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Password updated successfully')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(Validators.friendlyError(e)),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _savingPwd = false);
    }
  }

  Future<void> _saveRestaurant() async {
    if (!_restaurantFormKey.currentState!.validate()) return;
    setState(() => _savingRestaurant = true);
    try {
      await ref.read(restaurantServiceProvider).updateRestaurantMe({
        'name': _restNameCtrl.text.trim(),
        'ownerName': _ownerNameCtrl.text.trim(),
        'email': _emailCtrl.text.trim(),
        'mobile': _mobileCtrl.text.trim(),
        'address': _addressCtrl.text.trim(),
        'gstNumber': _gstCtrl.text.trim(),
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Restaurant profile updated')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(Validators.friendlyError(e)),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _savingRestaurant = false);
    }
  }

  Future<void> _pickLogo() async {
    final picker = ImagePicker();
    final x = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 85,
    );
    if (x == null) return;
    setState(() => _uploadingLogo = true);
    try {
      final url =
          await ref.read(restaurantServiceProvider).uploadLogo(File(x.path));
      if (mounted) {
        setState(() => _logoUrl = url ?? _logoUrl);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Logo uploaded')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(Validators.friendlyError(e)),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _uploadingLogo = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(authProvider).valueOrNull;
    final isOwner = user?.isOwner == true;

    if (!_loadedUser && user != null) {
      _nameCtrl.text = user.name ?? '';
      _phoneCtrl.text = user.phone ?? '';
      _loadedUser = true;
      if (isOwner && !_loadedRestaurant) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _loadRestaurant());
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: CircleAvatar(
              radius: 40,
              backgroundColor: AppColors.primary,
              backgroundImage:
                  (_logoUrl != null && _logoUrl!.isNotEmpty) ? NetworkImage(_logoUrl!) : null,
              child: (_logoUrl == null || _logoUrl!.isEmpty)
                  ? Text(
                      (user?.name ?? user?.username ?? 'U').substring(0, 1).toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  : null,
            ),
          ),
          const SizedBox(height: 8),
          Center(
            child: Text(user?.username ?? '',
                style: const TextStyle(color: AppColors.textSecondary)),
          ),
          Center(
            child: Text(
              '${user?.role ?? ''} · ${user?.restaurantName ?? ''}',
              style: const TextStyle(color: AppColors.textSecondary, fontSize: 13),
            ),
          ),
          const SizedBox(height: 24),
          Text('Change password', style: DinemateTypography.sectionTitle(context)),
          const SizedBox(height: 12),
          Form(
            key: _pwdFormKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _currentPwdCtrl,
                  obscureText: _obscureCurrent,
                  decoration: InputDecoration(
                    labelText: 'Current password',
                    suffixIcon: IconButton(
                      icon: Icon(_obscureCurrent
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined),
                      onPressed: () =>
                          setState(() => _obscureCurrent = !_obscureCurrent),
                    ),
                  ),
                  validator: Validators.password,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _newPwdCtrl,
                  obscureText: _obscureNew,
                  decoration: InputDecoration(
                    labelText: 'New password',
                    suffixIcon: IconButton(
                      icon: Icon(_obscureNew
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined),
                      onPressed: () => setState(() => _obscureNew = !_obscureNew),
                    ),
                  ),
                  validator: (v) => Validators.password(v, requireStrength: true),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _confirmPwdCtrl,
                  obscureText: true,
                  decoration:
                      const InputDecoration(labelText: 'Confirm new password'),
                  validator: (v) {
                    if (v != _newPwdCtrl.text) return 'Passwords do not match';
                    return Validators.password(v, requireStrength: true);
                  },
                ),
                const SizedBox(height: 16),
                DinemateButton(
                  label: 'Update Password',
                  loading: _savingPwd,
                  onPressed: _savingPwd ? null : _changePassword,
                ),
              ],
            ),
          ),
          if (isOwner) ...[
            const SizedBox(height: 28),
            Text('Restaurant profile',
                style: DinemateTypography.sectionTitle(context)),
            const SizedBox(height: 8),
            Text(
              'Visible on bills and customer-facing QR pages',
              style: DinemateTypography.caption(context)
                  .copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerLeft,
              child: OutlinedButton.icon(
                onPressed: _uploadingLogo ? null : _pickLogo,
                icon: _uploadingLogo
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.upload_rounded, size: 18),
                label: Text(_uploadingLogo ? 'Uploading…' : 'Upload logo'),
              ),
            ),
            const SizedBox(height: 12),
            Form(
              key: _restaurantFormKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _restNameCtrl,
                    decoration:
                        const InputDecoration(labelText: 'Restaurant name *'),
                    validator: (v) =>
                        Validators.name(v, field: 'Restaurant name'),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _ownerNameCtrl,
                    decoration: const InputDecoration(labelText: 'Owner name'),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _emailCtrl,
                    decoration: const InputDecoration(labelText: 'Email'),
                    keyboardType: TextInputType.emailAddress,
                    validator: (v) => Validators.email(v),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _mobileCtrl,
                    decoration: const InputDecoration(labelText: 'Mobile'),
                    keyboardType: TextInputType.phone,
                    validator: (v) => Validators.phone(v),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _addressCtrl,
                    decoration: const InputDecoration(labelText: 'Address'),
                    maxLines: 2,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _gstCtrl,
                    decoration: const InputDecoration(labelText: 'GST number'),
                  ),
                  const SizedBox(height: 16),
                  DinemateButton(
                    label: 'Save Restaurant Profile',
                    loading: _savingRestaurant,
                    onPressed: _savingRestaurant ? null : _saveRestaurant,
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 32),
        ],
      ),
    );
  }
}
