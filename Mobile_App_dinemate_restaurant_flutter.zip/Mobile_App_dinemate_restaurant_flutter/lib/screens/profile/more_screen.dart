import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/providers/auth_provider.dart';
import 'package:dinemate_restaurant/screens/staff/staff_screen.dart';
import 'package:dinemate_restaurant/screens/finance/finance_screen.dart';
import 'package:dinemate_restaurant/screens/offers/offers_screen.dart';
import 'package:dinemate_restaurant/screens/reports/reports_screen.dart';
import 'package:dinemate_restaurant/screens/subscription/subscription_screen.dart';
import 'package:dinemate_restaurant/screens/notifications/notifications_screen.dart';
import 'package:dinemate_restaurant/screens/activity/activity_screen.dart';
import 'package:dinemate_restaurant/screens/settings/settings_screen.dart';
import 'package:dinemate_restaurant/screens/profile/profile_screen.dart';
import 'package:dinemate_restaurant/screens/settings/notification_settings_screen.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';

class MoreScreen extends ConsumerWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider).valueOrNull;

    return Scaffold(
      appBar: AppBar(title: const Text('More')),
      body: ListView(
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: AppColors.primary,
                  child: Text(
                    (user?.name ?? user?.username ?? 'U').substring(0, 1).toUpperCase(),
                    style: const TextStyle(color: AppColors.darkTextOnPrimary, fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(user?.name ?? user?.username ?? 'User',
                          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
                      const SizedBox(height: 2),
                      Text('${user?.role ?? ''} · ${user?.restaurantName ?? ''}',
                          style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const _SectionTitle('Management'),
          if (user?.canManageStaff == true)
            _MenuTile(icon: Icons.people_outline_rounded, title: 'Staff',
                onTap: () => _push(context, const StaffScreen())),
          if (user?.canManageFinance == true)
            _MenuTile(icon: Icons.account_balance_wallet_outlined, title: 'Finance',
                onTap: () => _push(context, const FinanceScreen())),
          if (user?.canManageOffers == true)
            _MenuTile(icon: Icons.local_offer_outlined, title: 'Offers',
                onTap: () => _push(context, const OffersScreen())),
          if (user?.canViewReports == true)
            _MenuTile(icon: Icons.bar_chart_rounded, title: 'Reports',
                onTap: () => _push(context, const ReportsScreen())),
          if (user?.canManageSubscription == true)
            _MenuTile(icon: Icons.credit_card_outlined, title: 'Subscription',
                onTap: () => _push(context, const SubscriptionScreen())),

          const _SectionTitle('General'),
          _MenuTile(
            icon: Icons.notifications_outlined,
            title: 'Notifications',
            badge: ref.watch(unreadNotificationsCountProvider).valueOrNull,
            onTap: () => _push(context, const NotificationsScreen()),
          ),
          _MenuTile(
            icon: Icons.tune_rounded,
            title: 'Notification Settings',
            onTap: () => _push(context, const NotificationSettingsScreen()),
          ),
          if (user?.canManageStaff == true)
            _MenuTile(icon: Icons.history_rounded, title: 'Activity Log',
                onTap: () => _push(context, const ActivityScreen())),
          _MenuTile(icon: Icons.settings_outlined, title: 'Settings',
              onTap: () => _push(context, const SettingsScreen())),
          _MenuTile(icon: Icons.person_outline_rounded, title: 'Profile',
              onTap: () => _push(context, const ProfileScreen())),

          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: OutlinedButton.icon(
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Sign Out'),
                    content: const Text('Are you sure you want to sign out?'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                      TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sign Out')),
                    ],
                  ),
                );
                if (confirm == true) {
                  // Global session listener in main.dart handles the
                  // redirect to the login screen once auth state clears —
                  // no manual navigation needed here.
                  await ref.read(authProvider.notifier).logout();
                }
              },
              icon: const Icon(Icons.logout_rounded, color: AppColors.error),
              label: const Text('Sign Out', style: TextStyle(color: AppColors.error)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppColors.error),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 32),
          const Center(child: Text('DineMate v1.0.0', style: TextStyle(fontSize: 12, color: AppColors.textSecondary))),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  void _push(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      child: Text(title.toUpperCase(),
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.textSecondary, letterSpacing: 0.8)),
    );
  }
}

class _MenuTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  final int? badge;
  const _MenuTile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.badge,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary),
      title: Text(title),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (badge != null && badge! > 0)
            Container(
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                badge! > 99 ? '99+' : '$badge',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          const Icon(Icons.chevron_right, color: AppColors.textSecondary),
        ],
      ),
      onTap: onTap,
    );
  }
}
