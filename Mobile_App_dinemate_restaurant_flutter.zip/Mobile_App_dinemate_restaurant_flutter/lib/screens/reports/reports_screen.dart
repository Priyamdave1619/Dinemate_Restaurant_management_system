import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';

/// Reports parity with Next.js: daily, weekly, monthly, yearly snapshots.
class ReportsScreen extends ConsumerWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dailyAsync = ref.watch(dailyReportProvider);
    final weeklyAsync = ref.watch(weeklyReportProvider);
    final monthlyAsync = ref.watch(monthlyReportProvider);
    final yearlyAsync = ref.watch(yearlyReportProvider);
    final itemsAsync = ref.watch(itemsReportProvider);
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);

    void refreshAll() {
      ref.invalidate(dailyReportProvider);
      ref.invalidate(weeklyReportProvider);
      ref.invalidate(monthlyReportProvider);
      ref.invalidate(yearlyReportProvider);
      ref.invalidate(itemsReportProvider);
    }

    Widget section(String title, AsyncValue<Map<String, dynamic>> async, String keyName) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 8),
          async.when(
            data: (data) {
              final stats = data[keyName] as Map<String, dynamic>? ?? data;
              return _ReportCard(stats: stats, fmt: fmt);
            },
            loading: () => const LoadingView(message: 'Loading report…'),
            error: (e, _) => Text('$e', style: const TextStyle(color: AppColors.error)),
          ),
          const SizedBox(height: 24),
        ],
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Reports'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: refreshAll,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async => refreshAll(),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            section('Today', dailyAsync, 'day'),
            section('This Week', weeklyAsync, 'week'),
            section('This Month', monthlyAsync, 'month'),
            section('This Year', yearlyAsync, 'year'),
            Text(
              'Best sellers',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 8),
            itemsAsync.when(
              data: (data) {
                final best = (data['bestSelling'] as List?) ?? (data['items'] as List?) ?? [];
                if (best.isEmpty) {
                  return const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Text('No item sales data yet',
                          style: TextStyle(color: AppColors.textSecondary)),
                    ),
                  );
                }
                return Card(
                  child: Column(
                    children: [
                      for (var i = 0; i < best.length && i < 10; i++)
                        ListTile(
                          dense: true,
                          leading: CircleAvatar(
                            radius: 14,
                            backgroundColor: AppColors.primary.withValues(alpha: 0.12),
                            child: Text(
                              '${i + 1}',
                              style: const TextStyle(
                                fontSize: 12,
                                color: AppColors.primary,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          title: Text(
                            (best[i] is Map
                                    ? (best[i]['name'] ?? best[i]['itemName'] ?? 'Item')
                                    : best[i])
                                .toString(),
                          ),
                          trailing: Text(
                            best[i] is Map
                                ? '${best[i]['quantity'] ?? best[i]['qty'] ?? best[i]['count'] ?? ''}'
                                : '',
                            style: const TextStyle(fontWeight: FontWeight.w600),
                          ),
                        ),
                    ],
                  ),
                );
              },
              loading: () => const LoadingView(message: 'Loading items…'),
              error: (e, _) => Text('$e', style: const TextStyle(color: AppColors.error)),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _ReportCard extends StatelessWidget {
  final Map<String, dynamic> stats;
  final NumberFormat fmt;
  const _ReportCard({required this.stats, required this.fmt});

  @override
  Widget build(BuildContext context) {
    final items = [
      ('Gross Sales', stats['grossSales'], AppColors.primary),
      ('Net Sales', stats['netSales'], AppColors.info),
      ('Orders', stats['orderCount'], AppColors.warning),
      ('Items Sold', stats['itemsSold'], AppColors.preparing),
      ('Tax', stats['taxTotal'], AppColors.textSecondary),
      ('Gross Profit', stats['grossProfit'], AppColors.success),
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: items.map((i) {
            final val = i.$2;
            if (val == null) return const SizedBox.shrink();
            final isCount = i.$1 == 'Orders' || i.$1 == 'Items Sold';
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(color: i.$3, shape: BoxShape.circle),
                      ),
                      const SizedBox(width: 10),
                      Text(i.$1),
                    ],
                  ),
                  Text(
                    isCount
                        ? '${(val as num).toInt()}'
                        : fmt.format((val as num).toDouble()),
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
