import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';
import 'package:dinemate_restaurant/models/qr_style.dart';
import 'package:dinemate_restaurant/models/restaurant_table.dart';
import 'package:dinemate_restaurant/providers/auth_provider.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/services/qr_style_service.dart';

Color _hex(String hex) {
  var h = hex.replaceAll('#', '');
  if (h.length == 6) h = 'FF$h';
  return Color(int.parse(h, radix: 16));
}

PdfColor _pdfHex(String hex) {
  var h = hex.replaceAll('#', '');
  if (h.length == 6) h = 'FF$h';
  return PdfColor.fromInt(int.parse(h, radix: 16));
}

String _qrDataFor(RestaurantTable table, Map<String, dynamic>? apiQr) {
  final fromApi = apiQr?['targetUrl'] ??
      apiQr?['encryptedUrl'] ??
      apiQr?['plainUrl'] ??
      apiQr?['qrPath'];
  if (fromApi != null && fromApi.toString().trim().isNotEmpty) {
    return fromApi.toString().trim();
  }
  if (table.qrUrl != null && table.qrUrl!.trim().isNotEmpty) return table.qrUrl!.trim();
  if (table.qrPath != null && table.qrPath!.trim().isNotEmpty) return table.qrPath!.trim();
  return 'dinemate://table/${table.number}';
}

/// Full QR design studio — customize colors/layout + download PDF/PNG.
class QrStudioScreen extends ConsumerStatefulWidget {
  final RestaurantTable table;

  const QrStudioScreen({super.key, required this.table});

  @override
  ConsumerState<QrStudioScreen> createState() => _QrStudioScreenState();
}

class _QrStudioScreenState extends ConsumerState<QrStudioScreen> {
  final _styleService = QrStyleService();
  final _previewKey = GlobalKey();
  final _welcomeCtrl = TextEditingController();

  QrStyleConfig _style = QrStyleConfig.defaults;
  Map<String, dynamic>? _apiQr;
  bool _loading = true;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final style = await _styleService.load();
    _welcomeCtrl.text = style.welcomeMessage;
    Map<String, dynamic>? api;
    try {
      api = await ref.read(restaurantServiceProvider).getTableQr(widget.table.id);
    } catch (_) {}
    if (mounted) {
      setState(() {
        _style = style;
        _apiQr = api;
        _loading = false;
      });
    }
  }

  @override
  void dispose() {
    _welcomeCtrl.dispose();
    super.dispose();
  }

  Future<void> _saveStyle() async {
    final s = _style.copyWith(welcomeMessage: _welcomeCtrl.text.trim());
    await _styleService.save(s);
    setState(() => _style = s);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('QR style saved'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  Future<void> _regenerate() async {
    setState(() => _busy = true);
    try {
      final data = await ref
          .read(restaurantServiceProvider)
          .getTableQr(widget.table.id, regenerate: true);
      // try post regenerate if get with flag doesn't work
      try {
        final alt = await ref.read(restaurantServiceProvider).regenerateTableQr(widget.table.id);
        if (alt.isNotEmpty) {
          setState(() => _apiQr = alt);
        } else {
          setState(() => _apiQr = data);
        }
      } catch (_) {
        setState(() => _apiQr = data);
      }
    } catch (e) {
      setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<ui.Image?> _capturePreview() async {
    final boundary =
        _previewKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if (boundary == null) return null;
    return boundary.toImage(pixelRatio: 3);
  }

  Future<void> _downloadPng() async {
    setState(() => _busy = true);
    try {
      final image = await _capturePreview();
      if (image == null) throw Exception('Could not capture QR card');
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) throw Exception('PNG encode failed');
      final bytes = byteData.buffer.asUint8List();
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/dinemate_table_${widget.table.number}.png');
      await file.writeAsBytes(bytes);
      await Share.shareXFiles(
        [XFile(file.path)],
        text: 'Dinemate Table ${widget.table.number} QR',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'), backgroundColor: AppColors.error),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _downloadPdf() async {
    setState(() => _busy = true);
    try {
      final user = ref.read(authProvider).valueOrNull;
      final restaurantName = user?.restaurantName ?? 'Dinemate';
      final data = _qrDataFor(widget.table, _apiQr);
      final style = _style.copyWith(welcomeMessage: _welcomeCtrl.text.trim());

      final doc = pw.Document();
      final fg = _pdfHex(style.fgColor);
      final bg = _pdfHex(style.bgColor);
      final accent = _pdfHex(style.accentColor);
      final cardBg = _pdfHex(style.cardBg);
      final text = _pdfHex(style.textColor);

      // Build QR image for PDF via qr_flutter painter → bytes is heavy;
      // use barcode QR from printing package instead.
      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(40),
          build: (ctx) {
            return pw.Center(
              child: pw.Container(
                width: 360,
                padding: const pw.EdgeInsets.symmetric(horizontal: 28, vertical: 32),
                decoration: pw.BoxDecoration(
                  color: cardBg,
                  borderRadius: pw.BorderRadius.circular(style.borderRadius),
                  border: style.frameStyle == 'none'
                      ? null
                      : pw.Border.all(color: PdfColors.grey300, width: 1),
                ),
                child: pw.Column(
                  mainAxisSize: pw.MainAxisSize.min,
                  children: [
                    if (style.showLogo)
                      pw.Container(
                        width: 48,
                        height: 48,
                        decoration: pw.BoxDecoration(
                          color: accent,
                          borderRadius: pw.BorderRadius.circular(12),
                        ),
                        alignment: pw.Alignment.center,
                        child: pw.Text(
                          'D',
                          style: pw.TextStyle(
                            color: PdfColors.white,
                            fontSize: 22,
                            fontWeight: pw.FontWeight.bold,
                          ),
                        ),
                      ),
                    if (style.showLogo) pw.SizedBox(height: 12),
                    if (style.showRestaurantName)
                      pw.Text(
                        restaurantName,
                        textAlign: pw.TextAlign.center,
                        style: pw.TextStyle(
                          color: text,
                          fontSize: 14,
                          fontWeight: pw.FontWeight.bold,
                        ),
                      ),
                    if (style.showRestaurantName) pw.SizedBox(height: 6),
                    if (style.showTableLabel)
                      pw.Text(
                        'Table ${widget.table.number}',
                        style: pw.TextStyle(
                          color: accent,
                          fontSize: 26,
                          fontWeight: pw.FontWeight.bold,
                        ),
                      ),
                    pw.SizedBox(height: 16),
                    pw.Container(
                      padding: const pw.EdgeInsets.all(12),
                      decoration: pw.BoxDecoration(
                        color: bg,
                        borderRadius: pw.BorderRadius.circular(12),
                        border: style.frameStyle == 'double'
                            ? pw.Border.all(color: accent, width: 2)
                            : style.frameStyle == 'dashed'
                                ? pw.Border.all(color: accent, width: 1)
                                : pw.Border.all(color: PdfColors.grey300),
                      ),
                      child: pw.BarcodeWidget(
                        barcode: pw.Barcode.qrCode(
                          errorCorrectLevel: switch (style.errorCorrection) {
                            'L' => pw.BarcodeQRCorrectionLevel.low,
                            'Q' => pw.BarcodeQRCorrectionLevel.quartile,
                            'H' => pw.BarcodeQRCorrectionLevel.high,
                            _ => pw.BarcodeQRCorrectionLevel.medium,
                          },
                        ),
                        data: data,
                        width: style.qrSize.toDouble(),
                        height: style.qrSize.toDouble(),
                        color: fg,
                        backgroundColor: bg,
                      ),
                    ),
                    if (style.showWelcome) ...[
                      pw.SizedBox(height: 16),
                      pw.Text(
                        style.welcomeMessage,
                        style: pw.TextStyle(color: text, fontSize: 12),
                      ),
                    ],
                    pw.SizedBox(height: 8),
                    pw.Text(
                      '${widget.table.capacity} seats',
                      style: pw.TextStyle(color: PdfColors.grey600, fontSize: 10),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      );

      final bytes = await doc.save();
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/dinemate_table_${widget.table.number}.pdf');
      await file.writeAsBytes(bytes);

      // Share + also offer print dialog
      if (mounted) {
        await Share.shareXFiles(
          [XFile(file.path)],
          text: 'Dinemate Table ${widget.table.number} QR PDF',
        );
        // Optional system print/share sheet for PDF
        await Printing.layoutPdf(
          onLayout: (_) async => bytes,
          name: 'Dinemate_Table_${widget.table.number}',
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'), backgroundColor: AppColors.error),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final user = ref.watch(authProvider).valueOrNull;
    final restaurantName = user?.restaurantName ?? 'Dinemate';
    final data = _qrDataFor(widget.table, _apiQr);

    return Scaffold(
      backgroundColor: isDark ? AppColors.darkBackground : AppColors.background,
      appBar: AppBar(
        title: Text('QR · Table ${widget.table.number}'),
        actions: [
          IconButton(
            tooltip: 'Regenerate QR link',
            onPressed: _busy ? null : _regenerate,
            icon: const Icon(Icons.refresh_rounded),
          ),
          IconButton(
            tooltip: 'Save style',
            onPressed: _saveStyle,
            icon: const Icon(Icons.save_outlined),
          ),
        ],
      ),
      body: _loading
          ? const LoadingView(message: 'Preparing QR…')
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 120),
              children: [
                // Live preview
                Center(
                  child: RepaintBoundary(
                    key: _previewKey,
                    child: _QrCardPreview(
                      style: _style.copyWith(
                        welcomeMessage: _welcomeCtrl.text.trim().isEmpty
                            ? _style.welcomeMessage
                            : _welcomeCtrl.text.trim(),
                      ),
                      tableNumber: widget.table.number,
                      capacity: widget.table.capacity,
                      restaurantName: restaurantName,
                      qrData: data,
                    ),
                  ),
                ),
                if (_error != null) ...[
                  const SizedBox(height: 8),
                  Text(_error!, style: const TextStyle(color: AppColors.error, fontSize: 12)),
                ],
                const SizedBox(height: 24),
                Text(
                  'Customize',
                  style: DinemateTypography.sectionTitle(context).copyWith(
                    color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 12),

                // Color presets
                Text('Colors', style: DinemateTypography.caption(context)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 10,
                  runSpacing: 10,
                  children: [
                    _ColorPreset(
                      label: 'Navy',
                      color: const Color(0xFF0B2A4A),
                      selected: _style.accentColor.toUpperCase() == '#0B2A4A',
                      onTap: () => setState(() {
                        _style = _style.copyWith(
                          fgColor: '#0B2A4A',
                          accentColor: '#0B2A4A',
                          textColor: '#0B1726',
                          cardBg: '#FFFFFF',
                          bgColor: '#FFFFFF',
                        );
                      }),
                    ),
                    _ColorPreset(
                      label: 'Black',
                      color: const Color(0xFF111111),
                      selected: _style.fgColor.toUpperCase() == '#111111',
                      onTap: () => setState(() {
                        _style = _style.copyWith(
                          fgColor: '#111111',
                          accentColor: '#111111',
                          textColor: '#111111',
                        );
                      }),
                    ),
                    _ColorPreset(
                      label: 'Teal',
                      color: const Color(0xFF0D9488),
                      selected: _style.accentColor.toUpperCase() == '#0D9488',
                      onTap: () => setState(() {
                        _style = _style.copyWith(
                          fgColor: '#0D9488',
                          accentColor: '#0D9488',
                        );
                      }),
                    ),
                    _ColorPreset(
                      label: 'Orange',
                      color: const Color(0xFFF97316),
                      selected: _style.accentColor.toUpperCase() == '#F97316',
                      onTap: () => setState(() {
                        _style = _style.copyWith(accentColor: '#F97316');
                      }),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Frame
                Text('Frame', style: DinemateTypography.caption(context)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    for (final f in ['none', 'simple', 'double', 'dashed'])
                      ChoiceChip(
                        label: Text(f),
                        selected: _style.frameStyle == f,
                        onSelected: (_) =>
                            setState(() => _style = _style.copyWith(frameStyle: f)),
                        selectedColor: AppColors.navyTint,
                        labelStyle: TextStyle(
                          color: _style.frameStyle == f
                              ? AppColors.primary
                              : AppColors.textSecondary,
                          fontSize: 12,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 16),

                // Toggles
                _Toggle(
                  label: 'Show restaurant name',
                  value: _style.showRestaurantName,
                  onChanged: (v) =>
                      setState(() => _style = _style.copyWith(showRestaurantName: v)),
                ),
                _Toggle(
                  label: 'Show table label',
                  value: _style.showTableLabel,
                  onChanged: (v) =>
                      setState(() => _style = _style.copyWith(showTableLabel: v)),
                ),
                _Toggle(
                  label: 'Show logo mark',
                  value: _style.showLogo,
                  onChanged: (v) =>
                      setState(() => _style = _style.copyWith(showLogo: v)),
                ),
                _Toggle(
                  label: 'Show welcome message',
                  value: _style.showWelcome,
                  onChanged: (v) =>
                      setState(() => _style = _style.copyWith(showWelcome: v)),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _welcomeCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Welcome message',
                    hintText: 'Scan to order',
                  ),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 16),
                Text('QR size', style: DinemateTypography.caption(context)),
                Slider(
                  value: _style.qrSize.toDouble(),
                  min: 160,
                  max: 280,
                  divisions: 6,
                  activeColor: AppColors.primary,
                  label: '${_style.qrSize}',
                  onChanged: (v) =>
                      setState(() => _style = _style.copyWith(qrSize: v.round())),
                ),
                Text('Corner radius', style: DinemateTypography.caption(context)),
                Slider(
                  value: _style.borderRadius,
                  min: 8,
                  max: 32,
                  divisions: 12,
                  activeColor: AppColors.primary,
                  label: _style.borderRadius.toStringAsFixed(0),
                  onChanged: (v) =>
                      setState(() => _style = _style.copyWith(borderRadius: v)),
                ),
              ],
            ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _busy ? null : _downloadPng,
                  icon: const Icon(Icons.image_outlined, size: 18),
                  label: const Text('PNG'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primary,
                    side: const BorderSide(color: AppColors.primary),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: FilledButton.icon(
                  onPressed: _busy ? null : _downloadPdf,
                  icon: _busy
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.picture_as_pdf_outlined, size: 18),
                  label: const Text('Download PDF'),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QrCardPreview extends StatelessWidget {
  final QrStyleConfig style;
  final int tableNumber;
  final int capacity;
  final String restaurantName;
  final String qrData;

  const _QrCardPreview({
    required this.style,
    required this.tableNumber,
    required this.capacity,
    required this.restaurantName,
    required this.qrData,
  });

  @override
  Widget build(BuildContext context) {
    final accent = _hex(style.accentColor);
    final cardBg = _hex(style.cardBg);
    final text = _hex(style.textColor);
    final fg = _hex(style.fgColor);
    final bg = _hex(style.bgColor);

    Border? frameBorder;
    switch (style.frameStyle) {
      case 'double':
        frameBorder = Border.all(color: accent, width: 2.5);
        break;
      case 'dashed':
        frameBorder = Border.all(color: accent, width: 1.5);
        break;
      case 'simple':
        frameBorder = Border.all(color: AppColors.border);
        break;
      default:
        frameBorder = null;
    }

    return Container(
      width: 320,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(style.borderRadius),
        boxShadow: DinemateShadows.medium,
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (style.showLogo)
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: accent,
                borderRadius: BorderRadius.circular(12),
              ),
              alignment: Alignment.center,
              child: const Text(
                'D',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 22,
                ),
              ),
            ),
          if (style.showLogo) const SizedBox(height: 12),
          if (style.showRestaurantName)
            Text(
              restaurantName,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: text,
                fontWeight: FontWeight.w700,
                fontSize: 15,
              ),
            ),
          if (style.showRestaurantName) const SizedBox(height: 6),
          if (style.showTableLabel)
            Text(
              'Table $tableNumber',
              style: TextStyle(
                color: accent,
                fontWeight: FontWeight.w800,
                fontSize: 26,
              ),
            ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(12),
              border: frameBorder,
            ),
            child: QrImageView(
              data: qrData,
              version: QrVersions.auto,
              size: style.qrSize.toDouble().clamp(160, 280),
              backgroundColor: bg,
              eyeStyle: QrEyeStyle(eyeShape: QrEyeShape.square, color: fg),
              dataModuleStyle: QrDataModuleStyle(
                dataModuleShape: QrDataModuleShape.square,
                color: fg,
              ),
              errorStateBuilder: (_, __) => SizedBox(
                width: style.qrSize.toDouble(),
                height: style.qrSize.toDouble(),
                child: const Center(child: Text('Invalid QR data')),
              ),
            ),
          ),
          if (style.showWelcome) ...[
            const SizedBox(height: 16),
            Text(
              style.welcomeMessage,
              style: TextStyle(color: text, fontSize: 13),
            ),
          ],
          const SizedBox(height: 6),
          Text(
            '$capacity seats',
            style: TextStyle(color: AppColors.textMuted, fontSize: 11),
          ),
        ],
      ),
    );
  }
}

class _ColorPreset extends StatelessWidget {
  final String label;
  final Color color;
  final bool selected;
  final VoidCallback onTap;

  const _ColorPreset({
    required this.label,
    required this.color,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: selected ? AppColors.primary : AppColors.border,
            width: selected ? 2 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 18,
              height: 18,
              decoration: BoxDecoration(
                color: color,
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
          ],
        ),
      ),
    );
  }
}

class _Toggle extends StatelessWidget {
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _Toggle({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return SwitchListTile.adaptive(
      contentPadding: EdgeInsets.zero,
      title: Text(label, style: const TextStyle(fontSize: 14)),
      value: value,
      activeColor: AppColors.primary,
      onChanged: onChanged,
    );
  }
}
