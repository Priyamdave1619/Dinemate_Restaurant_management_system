import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';
import 'package:dinemate_restaurant/core/utils/validators.dart';
import 'package:dinemate_restaurant/models/restaurant_table.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/widgets/dinemate/dinemate_button.dart';

Future<void> showTableForm(
  BuildContext context,
  WidgetRef ref, {
  RestaurantTable? existing,
}) async {
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (ctx) {
      return _TableFormBody(existing: existing, parentRef: ref);
    },
  );
}

class _TableFormBody extends StatefulWidget {
  final RestaurantTable? existing;
  final WidgetRef parentRef;

  const _TableFormBody({required this.existing, required this.parentRef});

  @override
  State<_TableFormBody> createState() => _TableFormBodyState();
}

class _TableFormBodyState extends State<_TableFormBody> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _numberCtrl;
  late final TextEditingController _capacityCtrl;
  late String _status;
  bool _submitting = false;
  bool _deleting = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _numberCtrl = TextEditingController(text: e?.number.toString() ?? '');
    _capacityCtrl = TextEditingController(text: e?.capacity.toString() ?? '4');
    _status = e?.status.name ?? 'available';
  }

  @override
  void dispose() {
    _numberCtrl.dispose();
    _capacityCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_submitting) return;

    setState(() => _submitting = true);
    try {
      final number = int.parse(_numberCtrl.text.trim());
      final capacity = int.parse(_capacityCtrl.text.trim());
      final service = widget.parentRef.read(restaurantServiceProvider);
      if (widget.existing == null) {
        await service.createTable(number: number, capacity: capacity);
      } else {
        await service.updateTable(widget.existing!.id, {
          'capacity': capacity,
          'status': _status,
        });
      }
      widget.parentRef.invalidate(tablesProvider);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(Validators.friendlyError(e)),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  Future<void> _delete() async {
    final existing = widget.existing;
    if (existing == null || _deleting) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete Table'),
        content: Text('Delete Table ${existing.number}? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(c, true),
            style: TextButton.styleFrom(foregroundColor: AppColors.error),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;

    setState(() => _deleting = true);
    try {
      await widget.parentRef.read(restaurantServiceProvider).deleteTable(existing.id);
      widget.parentRef.invalidate(tablesProvider);
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(Validators.friendlyError(e)),
            backgroundColor: AppColors.error,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _deleting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final existing = widget.existing;
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 12,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  color: AppColors.borderStrong,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Text(
              existing == null ? 'Add Table' : 'Edit Table',
              style: DinemateTypography.sectionTitle(context),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _numberCtrl,
              keyboardType: TextInputType.number,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(labelText: 'Table Number *'),
              enabled: existing == null && !_submitting,
              validator: (v) => Validators.positiveInt(
                v,
                field: 'Table number',
                min: 1,
                max: 9999,
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _capacityCtrl,
              keyboardType: TextInputType.number,
              textInputAction: TextInputAction.done,
              decoration: const InputDecoration(labelText: 'Capacity (seats) *'),
              enabled: !_submitting,
              validator: (v) => Validators.positiveInt(
                v,
                field: 'Capacity',
                min: 1,
                max: 100,
              ),
            ),
            if (existing != null) ...[
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                key: ValueKey('status_$_status'),
                initialValue: _status,
                decoration: const InputDecoration(labelText: 'Status'),
                items: TableStatus.values
                    .map(
                      (s) => DropdownMenuItem(
                        value: s.name,
                        child: Text(s.displayName),
                      ),
                    )
                    .toList(),
                onChanged: _submitting
                    ? null
                    : (v) => setState(() => _status = v ?? 'available'),
              ),
            ],
            const SizedBox(height: 16),
            DinemateButton(
              label: existing == null ? 'Add Table' : 'Save',
              loading: _submitting,
              onPressed: _submitting || _deleting ? null : _submit,
            ),
            if (existing != null) ...[
              const SizedBox(height: 8),
              DinemateButton(
                label: 'Delete Table',
                variant: DinemateButtonVariant.destructive,
                loading: _deleting,
                onPressed: _submitting || _deleting ? null : _delete,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
