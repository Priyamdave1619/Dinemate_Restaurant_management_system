import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';
import 'package:dinemate_restaurant/models/restaurant_table.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/screens/tables/table_form_sheet.dart';
import 'package:dinemate_restaurant/screens/tables/qr_studio_screen.dart';
import 'package:dinemate_restaurant/widgets/common/status_chip.dart';
import 'package:dinemate_restaurant/widgets/common/empty_state.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:dinemate_restaurant/core/responsive/dinemate_breakpoints.dart';

class TablesScreen extends ConsumerWidget {
  const TablesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tablesAsync = ref.watch(tablesProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tables & QR'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => ref.invalidate(tablesProvider),
          ),
        ],
      ),
      body: tablesAsync.when(
        data: (tables) {
          if (tables.isEmpty) {
            return EmptyState(
              icon: Icons.table_restaurant_outlined,
              title: 'No tables yet',
              subtitle: 'Add your first table to get started',
              actionLabel: 'Add Table',
              onAction: () => showTableForm(context, ref),
            );
          }

          return LayoutBuilder(
            builder: (context, constraints) {
              final cols = DinemateBreakpoints.gridColumns(
                constraints.maxWidth,
                min: 2,
                max: 5,
              );
              return RefreshIndicator(
                color: AppColors.primary,
                onRefresh: () async => ref.invalidate(tablesProvider),
                child: GridView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 88),
                  physics: const AlwaysScrollableScrollPhysics(
                    parent: BouncingScrollPhysics(),
                  ),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: cols,
                    childAspectRatio: cols >= 4 ? 1.25 : 1.1,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  itemCount: tables.length,
                  itemBuilder: (context, index) {
                    final table = tables[index];
                    return _TableCard(
                      table: table,
                      onTap: () => _openTableSheet(context, ref, table),
                    );
                  },
                ),
              );
            },
          );
        },
        loading: () => const LoadingView(message: 'Loading tables…'),
        error: (e, _) => Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, color: AppColors.error, size: 40),
                const SizedBox(height: 12),
                Text('Couldn’t load tables', style: TextStyle(color: AppColors.textPrimary)),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () => ref.invalidate(tablesProvider),
                  child: const Text('Retry'),
                ),
              ],
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showTableForm(context, ref),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Add Table'),
      ),
    );
  }

  void _openTableSheet(BuildContext context, WidgetRef ref, RestaurantTable table) {
    HapticFeedback.selectionClick();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useRootNavigator: true,
      backgroundColor: Colors.transparent,
      constraints: BoxConstraints(
        maxWidth: MediaQuery.sizeOf(context).width >= 768 ? 480 : double.infinity,
      ),
      builder: (ctx) => _TableActionSheet(
        table: table,
        parentRef: ref,
        rootContext: context,
      ),
    );
  }
}

class _TableCard extends StatelessWidget {
  final RestaurantTable table;
  final VoidCallback onTap;

  const _TableCard({required this.table, required this.onTap});

  Color get _accent {
    switch (table.status) {
      case TableStatus.available:
        return AppColors.success;
      case TableStatus.occupied:
        return AppColors.error;
      case TableStatus.reserved:
        return AppColors.warning;
      case TableStatus.cleaning:
        return AppColors.info;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Material(
      color: isDark ? AppColors.darkCard : AppColors.surface,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _accent.withValues(alpha: 0.55), width: 1.5),
            boxShadow: DinemateShadows.soft,
          ),
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Table ${table.number}',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                        color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                      ),
                    ),
                  ),
                  Icon(Icons.qr_code_2_rounded, size: 20, color: AppColors.textSecondary),
                ],
              ),
              const Spacer(),
              Text(
                '${table.capacity} seats',
                style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
              ),
              const SizedBox(height: 8),
              TableStatusChip(status: table.status),
            ],
          ),
        ),
      ),
    );
  }
}

/// Bottom sheet with QR + actions (edit, status, delete)
class _TableActionSheet extends ConsumerStatefulWidget {
  final RestaurantTable table;
  final WidgetRef parentRef;
  final BuildContext rootContext;

  const _TableActionSheet({
    required this.table,
    required this.parentRef,
    required this.rootContext,
  });

  @override
  ConsumerState<_TableActionSheet> createState() => _TableActionSheetState();
}

class _TableActionSheetState extends ConsumerState<_TableActionSheet> {
  late TableStatus _status;
  bool _updating = false;

  @override
  void initState() {
    super.initState();
    _status = widget.table.status;
  }

  String get _qrData {
    final t = widget.table;
    if (t.qrUrl != null && t.qrUrl!.trim().isNotEmpty) return t.qrUrl!.trim();
    if (t.qrPath != null && t.qrPath!.trim().isNotEmpty) return t.qrPath!.trim();
    return 'dinemate://table/${t.number}';
  }

  Future<void> _updateStatus(TableStatus status) async {
    if (_updating) return;
    setState(() {
      _updating = true;
      _status = status;
    });
    try {
      await widget.parentRef.read(restaurantServiceProvider).updateTable(
        widget.table.id,
        {'status': status.name},
      );
      widget.parentRef.invalidate(tablesProvider);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Table ${widget.table.number} → ${status.displayName}'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _status = widget.table.status);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Couldn’t update status'),
            backgroundColor: AppColors.error,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _updating = false);
    }
  }

  void _showQrFullscreen() {
    showDialog(
      context: context,
      builder: (ctx) {
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Table ${widget.table.number}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Text(
                  'Scan to order',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: QrImageView(
                    data: _qrData,
                    version: QrVersions.auto,
                    size: 220,
                    backgroundColor: Colors.white,
                    errorStateBuilder: (c, err) => SizedBox(
                      width: 220,
                      height: 220,
                      child: Center(
                        child: Text(
                          'QR unavailable',
                          style: TextStyle(color: AppColors.error),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Capacity: ${widget.table.capacity} seats',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () => Navigator.pop(ctx),
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('Close'),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final table = widget.table;

    return Container(
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkCard : AppColors.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: EdgeInsets.fromLTRB(
        20,
        12,
        20,
        20 + MediaQuery.paddingOf(context).bottom,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Handle
          Center(
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.borderStrong,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Header
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppColors.navyTint,
                  borderRadius: BorderRadius.circular(14),
                ),
                alignment: Alignment.center,
                child: Text(
                  'T${table.number}',
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    color: AppColors.primary,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Table ${table.number}',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${table.capacity} seats',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 13),
                    ),
                  ],
                ),
              ),
              TableStatusChip(status: _status),
            ],
          ),
          const SizedBox(height: 20),

          // QR preview (tappable → fullscreen enlarge)
          GestureDetector(
            onTap: _showQrFullscreen,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: isDark ? AppColors.darkSurface : AppColors.surfaceMuted,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isDark ? AppColors.darkBorder : AppColors.border,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: QrImageView(
                      data: _qrData,
                      version: QrVersions.auto,
                      size: 72,
                      backgroundColor: Colors.white,
                      errorStateBuilder: (c, err) => const SizedBox(
                        width: 72,
                        height: 72,
                        child: Icon(Icons.qr_code_2, color: Colors.grey),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Table QR Code',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Tap to enlarge',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.fullscreen_rounded, color: AppColors.primary),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),

          // Status section
          Text(
            'Change status',
            style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 13,
              color: AppColors.textSecondary,
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: TableStatus.values.map((s) {
              final selected = _status == s;
              return ChoiceChip(
                label: Text(s.displayName),
                selected: selected,
                onSelected: _updating
                    ? null
                    : (_) => _updateStatus(s),
                selectedColor: AppColors.navyTint,
                labelStyle: TextStyle(
                  color: selected ? AppColors.primary : AppColors.textSecondary,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.w500,
                  fontSize: 13,
                ),
                side: BorderSide(
                  color: selected ? AppColors.primary : AppColors.border,
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 24),

          // Actions
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    Navigator.pop(context);
                    final root = widget.rootContext;
                    final tableRef = table;
                    final ref = widget.parentRef;
                    Future.delayed(const Duration(milliseconds: 200), () {
                      if (root.mounted) {
                        showTableForm(root, ref, existing: tableRef);
                      }
                    });
                  },
                  icon: const Icon(Icons.edit_outlined, size: 18),
                  label: const Text('Edit'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primary,
                    side: const BorderSide(color: AppColors.primary),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  onPressed: () {
                    final root = widget.rootContext;
                    final table = widget.table;
                    Navigator.pop(context);
                    Future.delayed(const Duration(milliseconds: 200), () {
                      if (root.mounted) {
                        Navigator.of(root).push(
                          MaterialPageRoute(
                            builder: (_) => QrStudioScreen(table: table),
                          ),
                        );
                      }
                    });
                  },
                  icon: const Icon(Icons.qr_code_2_rounded, size: 18),
                  label: const Text('Design QR'),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
