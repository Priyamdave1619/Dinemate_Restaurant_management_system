import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/providers/auth_provider.dart';
import 'package:dinemate_restaurant/models/user.dart';
import 'package:dinemate_restaurant/services/permission_service.dart';
import 'package:dinemate_restaurant/screens/auth/login_screen.dart';
import 'package:dinemate_restaurant/widgets/common/brand_logo.dart';
import 'package:dinemate_restaurant/screens/dashboard/home_shell.dart';

/// Cinematic Dinemate splash — deep navy gradient + refined motion.
class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final Animation<double> _fadeBg;
  late final Animation<double> _fadeLogo;
  late final Animation<double> _scaleLogo;
  late final Animation<double> _fadeName;
  late final Animation<Offset> _slideName;
  late final Animation<double> _fadeTag;
  late final Animation<double> _fadeLoader;

  @override
  void initState() {
    super.initState();
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(0xFF071A2F),
    ));

    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    );

    _fadeBg = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _c, curve: const Interval(0.0, 0.25, curve: Curves.easeOut)),
    );
    _fadeLogo = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _c, curve: const Interval(0.15, 0.5, curve: Curves.easeOut)),
    );
    _scaleLogo = Tween(begin: 0.78, end: 1.0).animate(
      CurvedAnimation(parent: _c, curve: const Interval(0.15, 0.55, curve: Curves.easeOutCubic)),
    );
    _fadeName = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _c, curve: const Interval(0.4, 0.7, curve: Curves.easeOut)),
    );
    _slideName = Tween(begin: const Offset(0, 0.3), end: Offset.zero).animate(
      CurvedAnimation(parent: _c, curve: const Interval(0.4, 0.7, curve: Curves.easeOutCubic)),
    );
    _fadeTag = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _c, curve: const Interval(0.55, 0.85, curve: Curves.easeOut)),
    );
    _fadeLoader = Tween(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _c, curve: const Interval(0.7, 1.0, curve: Curves.easeOut)),
    );

    _c.forward();
    _goNext();
  }

  Future<void> _goNext() async {
    await Future.delayed(const Duration(milliseconds: 900));
    if (!mounted) return;

    // System permission dialogs (notification, camera, photos, files)
    try {
      await PermissionService.instance.requestAllOnStartup();
    } catch (_) {}
    if (!mounted) return;

    // Restore session from durable storage. Prefer waiting for the provider
    // to leave AsyncLoading; never treat a timeout as "logged out" when a
    // token may still be present in storage.
    User? user;
    try {
      user = await ref.read(authProvider.future).timeout(
            const Duration(seconds: 12),
          );
    } catch (_) {
      final snap = ref.read(authProvider);
      user = snap.valueOrNull;
      // If still loading, give storage one more chance via rehydrate
      if (user == null && snap.isLoading) {
        try {
          await ref.read(authProvider.notifier).rehydrate().timeout(
                const Duration(seconds: 4),
              );
          user = ref.read(authProvider).valueOrNull;
        } catch (_) {}
      }
    }

    if (!mounted) return;
    final next = user != null ? const HomeShell() : const LoginScreen();
    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => next,
        transitionsBuilder: (_, a, __, child) =>
            FadeTransition(opacity: a, child: child),
        transitionDuration: const Duration(milliseconds: 450),
      ),
    );
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnimatedBuilder(
        animation: _c,
        builder: (_, __) {
          return Opacity(
            opacity: _fadeBg.value,
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppColors.deepNavy,
                    AppColors.primary,
                    AppColors.premiumNavy,
                  ],
                  stops: [0.0, 0.55, 1.0],
                ),
              ),
              child: SafeArea(
                child: Column(
                  children: [
                    const Spacer(flex: 3),
                    // Logo mark
                    Opacity(
                      opacity: _fadeLogo.value,
                      child: Transform.scale(
                        scale: _scaleLogo.value,
                        child: Container(
                          width: 108,
                          height: 108,
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.18),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.3),
                                blurRadius: 40,
                                offset: const Offset(0, 16),
                              ),
                            ],
                          ),
                          padding: const EdgeInsets.all(20),
                          child: Image.asset(
                            'assets/logos/logo-blue.png',
                            fit: BoxFit.contain,
                            errorBuilder: (_, __, ___) => const Icon(
                              Icons.restaurant_menu_rounded,
                              size: 48,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 28),
                    // Name
                    Opacity(
                      opacity: _fadeName.value,
                      child: SlideTransition(
                        position: _slideName,
                        child: const Text(
                          'Dinemate',
                          style: TextStyle(
                            fontSize: 36,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.6,
                            color: Colors.white,
                            height: 1.05,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    // Tagline
                    Opacity(
                      opacity: _fadeTag.value,
                      child: Text(
                        'Elevate Your Dining Experience',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          letterSpacing: 1.4,
                          color: Colors.white.withValues(alpha: 0.72),
                        ),
                      ),
                    ),
                    const Spacer(flex: 4),
                    // Loader
                    Opacity(
                      opacity: _fadeLoader.value,
                      child: Column(
                        children: [
                          SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(
                                Colors.white.withValues(alpha: 0.85),
                              ),
                            ),
                          ),
                          const SizedBox(height: 18),
                          Text(
                            'RESTAURANT PORTAL',
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 2.2,
                              color: Colors.white.withValues(alpha: 0.4),
                            ),
                          ),
                          const SizedBox(height: 36),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
