import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/widgets/common/loading_view.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/models/expense.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';

class FinanceScreen extends ConsumerStatefulWidget {
  const FinanceScreen({super.key});

  @override
  ConsumerState<FinanceScreen> createState() => _FinanceScreenState();
}

class _FinanceScreenState extends ConsumerState<FinanceScreen> with SingleTickerProviderStateMixin {
  late TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Finance'),
        bottom: TabBar(
          controller: _tabs,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textSecondary,
          indicatorColor: AppColors.primary,
          tabs: const [Tab(text: 'Expenses'), Tab(text: 'P&L')],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: const [_ExpensesTab(), _PnlTab()],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () => _showExpenseForm(context, ref),
      ),
    );
  }

  void _showExpenseForm(BuildContext context, WidgetRef ref) {
    final amountCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    String category = 'Supplies';
    DateTime date = DateTime.now();
    final categories = ['Supplies', 'Utilities', 'Rent', 'Salary', 'Maintenance', 'Marketing', 'Other'];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModal) {
            return Padding(
              padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Add Expense', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 16),
                  TextField(
                    controller: amountCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(labelText: 'Amount (₹)', prefixText: '₹ '),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    key: ValueKey('exp_cat_$category'),
                    initialValue: category,
                    decoration: const InputDecoration(labelText: 'Category'),
                    items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                    onChanged: (v) => setModal(() => category = v ?? 'Other'),
                  ),
                  const SizedBox(height: 12),
                  TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Description')),
                  const SizedBox(height: 12),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text('Date: ${DateFormat('dd MMM yyyy').format(date)}'),
                    trailing: const Icon(Icons.calendar_today),
                    onTap: () async {
                      final picked = await showDatePicker(
                        context: ctx,
                        initialDate: date,
                        firstDate: DateTime(2020),
                        lastDate: DateTime.now(),
                      );
                      if (picked != null) setModal(() => date = picked);
                    },
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () async {
                      final amount = double.tryParse(amountCtrl.text);
                      if (amount == null || amount <= 0) return;
                      try {
                        await ref.read(restaurantServiceProvider).createExpense({
                          'amount': amount,
                          'category': category,
                          'description': descCtrl.text.trim(),
                          'date': DateFormat('yyyy-MM-dd').format(date),
                        });
                        ref.invalidate(expensesProvider);
                        ref.invalidate(pnlProvider);
                        if (ctx.mounted) Navigator.pop(ctx);
                      } catch (e) {
                        if (ctx.mounted) {
                          ScaffoldMessenger.of(ctx).showSnackBar(
                            SnackBar(content: Text('$e'), backgroundColor: AppColors.error),
                          );
                        }
                      }
                    },
                    child: const Text('Save Expense'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _ExpensesTab extends ConsumerWidget {
  const _ExpensesTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(expensesProvider);
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);

    return async.when(
      data: (expenses) {
        if (expenses.isEmpty) {
          return const Center(child: Text('No expenses yet', style: TextStyle(color: AppColors.textSecondary)));
        }
        final total = expenses.fold<double>(0, (s, e) => s + e.amount);
        return RefreshIndicator(
          onRefresh: () async => ref.invalidate(expensesProvider),
          child: ListView(
            padding: const EdgeInsets.only(bottom: 80),
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text('Total: ${fmt.format(total)}',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              ...expenses.map((e) => _ExpenseTile(expense: e)),
            ],
          ),
        );
      },
      loading: () => const LoadingView(message: 'Loading…'),
      error: (e, _) => Center(child: Text('$e')),
    );
  }
}

class _ExpenseTile extends ConsumerWidget {
  final Expense expense;
  const _ExpenseTile({required this.expense});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: ListTile(
        title: Text(expense.category, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text('${expense.description}\n${expense.date}'),
        isThreeLine: true,
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('₹${expense.amount.toStringAsFixed(0)}',
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            IconButton(
              icon: const Icon(Icons.delete_outline, color: AppColors.error, size: 20),
              onPressed: () async {
                await ref.read(restaurantServiceProvider).deleteExpense(expense.id);
                ref.invalidate(expensesProvider);
                ref.invalidate(pnlProvider);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class _PnlTab extends ConsumerWidget {
  const _PnlTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(pnlProvider);
    final fmt = NumberFormat.currency(symbol: '₹', decimalDigits: 0);

    return async.when(
      data: (data) {
        final pnl = data['pnl'] as Map<String, dynamic>? ?? data;
        final rows = [
          ('Gross Sales', pnl['grossSales']),
          ('Discounts', pnl['discountTotal']),
          ('Net Sales', pnl['netSales']),
          ('Tax', pnl['taxTotal']),
          ('COGS', pnl['cogsTotal']),
          ('Gross Profit', pnl['grossProfit']),
          ('Expenses', pnl['expenses'] ?? pnl['expenseTotal']),
          ('Net Profit', pnl['netProfit']),
        ];
        return RefreshIndicator(
          onRefresh: () async => ref.invalidate(pnlProvider),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('Period: ${data['period'] ?? 'This month'}',
                  style: const TextStyle(color: AppColors.textSecondary)),
              const SizedBox(height: 12),
              ...rows.map((r) {
                final val = (r.$2 as num?)?.toDouble();
                if (val == null) return const SizedBox.shrink();
                return Card(
                  child: ListTile(
                    title: Text(r.$1),
                    trailing: Text(fmt.format(val),
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: r.$1.contains('Profit')
                              ? (val >= 0 ? AppColors.success : AppColors.error)
                              : null,
                        )),
                  ),
                );
              }),
            ],
          ),
        );
      },
      loading: () => const LoadingView(message: 'Loading…'),
      error: (e, _) => Center(child: Text('$e')),
    );
  }
}
