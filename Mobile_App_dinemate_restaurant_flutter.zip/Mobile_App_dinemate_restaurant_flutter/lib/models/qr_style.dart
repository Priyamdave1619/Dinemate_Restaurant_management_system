import 'dart:convert';

class QrStyleConfig {
  final String fgColor;
  final String bgColor;
  final String accentColor;
  final String cardBg;
  final String textColor;
  final double borderRadius;
  final int qrSize;
  final bool showLogo;
  final bool showRestaurantName;
  final bool showTableLabel;
  final bool showWelcome;
  final String welcomeMessage;
  final String frameStyle; // none | simple | double | dashed
  final String errorCorrection; // L M Q H

  const QrStyleConfig({
    this.fgColor = '#0B2A4A',
    this.bgColor = '#FFFFFF',
    this.accentColor = '#0B2A4A',
    this.cardBg = '#FFFFFF',
    this.textColor = '#0B1726',
    this.borderRadius = 20,
    this.qrSize = 220,
    this.showLogo = true,
    this.showRestaurantName = true,
    this.showTableLabel = true,
    this.showWelcome = true,
    this.welcomeMessage = 'Scan to order',
    this.frameStyle = 'simple',
    this.errorCorrection = 'M',
  });

  static const defaults = QrStyleConfig();

  QrStyleConfig copyWith({
    String? fgColor,
    String? bgColor,
    String? accentColor,
    String? cardBg,
    String? textColor,
    double? borderRadius,
    int? qrSize,
    bool? showLogo,
    bool? showRestaurantName,
    bool? showTableLabel,
    bool? showWelcome,
    String? welcomeMessage,
    String? frameStyle,
    String? errorCorrection,
  }) {
    return QrStyleConfig(
      fgColor: fgColor ?? this.fgColor,
      bgColor: bgColor ?? this.bgColor,
      accentColor: accentColor ?? this.accentColor,
      cardBg: cardBg ?? this.cardBg,
      textColor: textColor ?? this.textColor,
      borderRadius: borderRadius ?? this.borderRadius,
      qrSize: qrSize ?? this.qrSize,
      showLogo: showLogo ?? this.showLogo,
      showRestaurantName: showRestaurantName ?? this.showRestaurantName,
      showTableLabel: showTableLabel ?? this.showTableLabel,
      showWelcome: showWelcome ?? this.showWelcome,
      welcomeMessage: welcomeMessage ?? this.welcomeMessage,
      frameStyle: frameStyle ?? this.frameStyle,
      errorCorrection: errorCorrection ?? this.errorCorrection,
    );
  }

  Map<String, dynamic> toJson() => {
        'fgColor': fgColor,
        'bgColor': bgColor,
        'accentColor': accentColor,
        'cardBg': cardBg,
        'textColor': textColor,
        'borderRadius': borderRadius,
        'qrSize': qrSize,
        'showLogo': showLogo,
        'showRestaurantName': showRestaurantName,
        'showTableLabel': showTableLabel,
        'showWelcome': showWelcome,
        'welcomeMessage': welcomeMessage,
        'frameStyle': frameStyle,
        'errorCorrection': errorCorrection,
      };

  factory QrStyleConfig.fromJson(Map<String, dynamic> json) {
    return QrStyleConfig(
      fgColor: json['fgColor']?.toString() ?? defaults.fgColor,
      bgColor: json['bgColor']?.toString() ?? defaults.bgColor,
      accentColor: json['accentColor']?.toString() ?? defaults.accentColor,
      cardBg: json['cardBg']?.toString() ?? defaults.cardBg,
      textColor: json['textColor']?.toString() ?? defaults.textColor,
      borderRadius: (json['borderRadius'] as num?)?.toDouble() ?? defaults.borderRadius,
      qrSize: (json['qrSize'] as num?)?.toInt() ?? defaults.qrSize,
      showLogo: json['showLogo'] as bool? ?? defaults.showLogo,
      showRestaurantName: json['showRestaurantName'] as bool? ?? defaults.showRestaurantName,
      showTableLabel: json['showTableLabel'] as bool? ?? defaults.showTableLabel,
      showWelcome: json['showWelcome'] as bool? ?? defaults.showWelcome,
      welcomeMessage: json['welcomeMessage']?.toString() ?? defaults.welcomeMessage,
      frameStyle: json['frameStyle']?.toString() ?? defaults.frameStyle,
      errorCorrection: json['errorCorrection']?.toString() ?? defaults.errorCorrection,
    );
  }

  String encode() => jsonEncode(toJson());
  static QrStyleConfig decode(String raw) {
    try {
      return QrStyleConfig.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return defaults;
    }
  }
}
