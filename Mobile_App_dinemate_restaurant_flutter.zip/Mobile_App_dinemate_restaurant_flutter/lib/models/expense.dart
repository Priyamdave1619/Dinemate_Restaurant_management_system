import 'package:equatable/equatable.dart';

class Expense extends Equatable {
  final String id;
  final String restaurantId;
  final String date;
  final String category;
  final String description;
  final double amount;
  final String? monthKey;
  final String? yearKey;
  final String? createdAt;

  const Expense({
    required this.id,
    required this.restaurantId,
    required this.date,
    required this.category,
    this.description = '',
    required this.amount,
    this.monthKey,
    this.yearKey,
    this.createdAt,
  });

  factory Expense.fromJson(Map<String, dynamic> json) {
    return Expense(
      id: json['id']?.toString() ?? '',
      restaurantId: json['restaurantId']?.toString() ?? '',
      date: json['date']?.toString() ?? '',
      category: json['category']?.toString() ?? '',
      description: json['description']?.toString() ?? '',
      amount: (json['amount'] as num?)?.toDouble() ?? 0,
      monthKey: json['monthKey']?.toString(),
      yearKey: json['yearKey']?.toString(),
      createdAt: json['createdAt']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'restaurantId': restaurantId,
        'date': date,
        'category': category,
        'description': description,
        'amount': amount,
        'monthKey': monthKey,
        'yearKey': yearKey,
        'createdAt': createdAt,
      };

  @override
  List<Object?> get props => [id, date, category, amount];
}
