import 'dart:convert';

class NotificationPreferences {
  final bool enabled;
  final bool orderUpdates;
  final bool restaurantUpdates;
  final bool promotions;
  final bool systemAlerts;

  const NotificationPreferences({
    this.enabled = true,
    this.orderUpdates = true,
    this.restaurantUpdates = true,
    this.promotions = true,
    this.systemAlerts = true,
  });

  static const defaults = NotificationPreferences();

  bool allowsType(String type) {
    if (!enabled) {
      // Critical system may still show in-app history, but no new optional delivery
      final t = type.toLowerCase();
      if (t.contains('security') || t.contains('critical')) return systemAlerts;
      return false;
    }
    final t = type.toLowerCase();
    if (t.contains('order')) return orderUpdates;
    if (t.contains('offer') || t.contains('promo')) return promotions;
    if (t.contains('system') || t.contains('security')) return systemAlerts;
    return restaurantUpdates;
  }

  NotificationPreferences copyWith({
    bool? enabled,
    bool? orderUpdates,
    bool? restaurantUpdates,
    bool? promotions,
    bool? systemAlerts,
  }) {
    return NotificationPreferences(
      enabled: enabled ?? this.enabled,
      orderUpdates: orderUpdates ?? this.orderUpdates,
      restaurantUpdates: restaurantUpdates ?? this.restaurantUpdates,
      promotions: promotions ?? this.promotions,
      systemAlerts: systemAlerts ?? this.systemAlerts,
    );
  }

  Map<String, dynamic> toJson() => {
        'notificationsEnabled': enabled,
        'orderUpdates': orderUpdates,
        'restaurantUpdates': restaurantUpdates,
        'promotions': promotions,
        'systemAlerts': systemAlerts,
      };

  factory NotificationPreferences.fromJson(Map<String, dynamic> json) {
    return NotificationPreferences(
      enabled: json['notificationsEnabled'] as bool? ??
          json['enabled'] as bool? ??
          true,
      orderUpdates: json['orderUpdates'] as bool? ?? true,
      restaurantUpdates: json['restaurantUpdates'] as bool? ?? true,
      promotions: json['promotions'] as bool? ?? true,
      systemAlerts: json['systemAlerts'] as bool? ?? true,
    );
  }

  String encode() => jsonEncode(toJson());
  static NotificationPreferences decode(String raw) {
    try {
      return NotificationPreferences.fromJson(
        jsonDecode(raw) as Map<String, dynamic>,
      );
    } catch (_) {
      return defaults;
    }
  }
}
