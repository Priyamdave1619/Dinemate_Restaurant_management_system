import 'package:equatable/equatable.dart';

class StaffUser extends Equatable {
  final String id;
  final String username;
  final String name;
  final String role;
  final bool active;
  final String? createdAt;
  final List<String> permissions;
  final String? lastLoginAt;

  const StaffUser({
    required this.id,
    required this.username,
    required this.name,
    required this.role,
    this.active = true,
    this.createdAt,
    this.permissions = const [],
    this.lastLoginAt,
  });

  factory StaffUser.fromJson(Map<String, dynamic> json) {
    return StaffUser(
      id: json['id']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      role: json['role']?.toString() ?? 'waiter',
      active: json['active'] as bool? ?? true,
      createdAt: json['createdAt']?.toString(),
      permissions: (json['permissions'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          [],
      lastLoginAt: json['lastLoginAt']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'name': name,
        'role': role,
        'active': active,
        'createdAt': createdAt,
        'permissions': permissions,
        'lastLoginAt': lastLoginAt,
      };

  @override
  List<Object?> get props => [id, username, role, active];
}
