import 'package:equatable/equatable.dart';

enum TableStatus {
  available,
  occupied,
  reserved,
  cleaning;

  static TableStatus fromString(String value) {
    return TableStatus.values.firstWhere(
      (e) => e.name == value.toLowerCase(),
      orElse: () => TableStatus.available,
    );
  }

  String get displayName {
    switch (this) {
      case TableStatus.available:
        return 'Available';
      case TableStatus.occupied:
        return 'Occupied';
      case TableStatus.reserved:
        return 'Reserved';
      case TableStatus.cleaning:
        return 'Cleaning';
    }
  }
}

class RestaurantTable extends Equatable {
  final String id;
  final String restaurantId;
  final int number;
  final int capacity;
  final TableStatus status;
  final String? currentOrderId;
  final String? waiterName;
  final String? qrPath;
  final String? qrUrl;

  const RestaurantTable({
    required this.id,
    required this.restaurantId,
    required this.number,
    required this.capacity,
    required this.status,
    this.currentOrderId,
    this.waiterName,
    this.qrPath,
    this.qrUrl,
  });

  factory RestaurantTable.fromJson(Map<String, dynamic> json) {
    return RestaurantTable(
      id: json['id']?.toString() ?? '',
      restaurantId: json['restaurantId']?.toString() ?? '',
      number: (json['number'] as num?)?.toInt() ?? 0,
      capacity: (json['capacity'] as num?)?.toInt() ?? 4,
      status: TableStatus.fromString(json['status']?.toString() ?? 'available'),
      currentOrderId: json['currentOrderId']?.toString(),
      waiterName: json['waiterName']?.toString(),
      qrPath: json['qrPath']?.toString(),
      qrUrl: json['qrUrl']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'restaurantId': restaurantId,
        'number': number,
        'capacity': capacity,
        'status': status.name,
        'currentOrderId': currentOrderId,
        'waiterName': waiterName,
        'qrPath': qrPath,
        'qrUrl': qrUrl,
      };

  RestaurantTable copyWith({TableStatus? status, String? currentOrderId}) {
    return RestaurantTable(
      id: id,
      restaurantId: restaurantId,
      number: number,
      capacity: capacity,
      status: status ?? this.status,
      currentOrderId: currentOrderId ?? this.currentOrderId,
      waiterName: waiterName,
      qrPath: qrPath,
      qrUrl: qrUrl,
    );
  }

  @override
  List<Object?> get props => [id, number, status];
}
