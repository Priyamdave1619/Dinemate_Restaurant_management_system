import 'package:equatable/equatable.dart';

enum OrderStatus {
  pending,
  confirmed,
  preparing,
  ready,
  served,
  completed,
  cancelled;

  static OrderStatus fromString(String value) {
    return OrderStatus.values.firstWhere(
      (e) => e.name == value.toLowerCase(),
      orElse: () => OrderStatus.pending,
    );
  }

  String get displayName {
    switch (this) {
      case OrderStatus.pending:
        return 'Pending';
      case OrderStatus.confirmed:
        return 'Confirmed';
      case OrderStatus.preparing:
        return 'Preparing';
      case OrderStatus.ready:
        return 'Ready';
      case OrderStatus.served:
        return 'Served';
      case OrderStatus.completed:
        return 'Completed';
      case OrderStatus.cancelled:
        return 'Cancelled';
    }
  }
}

class OrderItem extends Equatable {
  final String id;
  final String itemId;
  final String name;
  final int quantity;
  final double price;
  final String? note;
  final String? variant;
  final bool kotPrinted;
  final String? foodType;
  final String? categoryId;
  final double? costPrice;
  final String? addedBy;

  const OrderItem({
    required this.id,
    required this.itemId,
    required this.name,
    required this.quantity,
    required this.price,
    this.note,
    this.variant,
    this.kotPrinted = false,
    this.foodType,
    this.categoryId,
    this.costPrice,
    this.addedBy,
  });

  double get lineTotal => price * quantity;

  factory OrderItem.fromJson(Map<String, dynamic> json) {
    return OrderItem(
      id: json['id']?.toString() ?? '',
      itemId: json['itemId']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      quantity: (json['quantity'] as num?)?.toInt() ?? 1,
      price: (json['price'] as num?)?.toDouble() ?? 0,
      note: json['note']?.toString(),
      variant: json['variant']?.toString(),
      kotPrinted: json['kotPrinted'] as bool? ?? false,
      foodType: json['foodType']?.toString(),
      categoryId: json['categoryId']?.toString(),
      costPrice: (json['costPrice'] as num?)?.toDouble(),
      addedBy: json['addedBy']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'itemId': itemId,
        'name': name,
        'quantity': quantity,
        'price': price,
        'note': note,
        'variant': variant,
        'kotPrinted': kotPrinted,
        'foodType': foodType,
        'categoryId': categoryId,
        'costPrice': costPrice,
        'addedBy': addedBy,
      };

  @override
  List<Object?> get props => [id, itemId, quantity, price];
}

class Order extends Equatable {
  final String id;
  final String restaurantId;
  final int tableNumber;
  final List<OrderItem> items;
  final OrderStatus status;
  final DateTime placedAt;
  final DateTime updatedAt;
  final double total;
  final double subtotal;
  final double? tax;
  final double? discount;
  final String? note;
  final String? waiterName;
  final String? customerName;
  final bool? billed;

  const Order({
    required this.id,
    required this.restaurantId,
    required this.tableNumber,
    required this.items,
    required this.status,
    required this.placedAt,
    required this.updatedAt,
    required this.total,
    required this.subtotal,
    this.tax,
    this.discount,
    this.note,
    this.waiterName,
    this.customerName,
    this.billed,
  });

  int get itemCount => items.fold(0, (sum, i) => sum + i.quantity);

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id']?.toString() ?? '',
      restaurantId: json['restaurantId']?.toString() ?? '',
      tableNumber: (json['tableNumber'] as num?)?.toInt() ?? 0,
      items: (json['items'] as List<dynamic>?)
              ?.map((e) => OrderItem.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
      status: OrderStatus.fromString(json['status']?.toString() ?? 'pending'),
      placedAt: DateTime.tryParse(json['placedAt']?.toString() ?? '') ?? DateTime.now(),
      updatedAt: DateTime.tryParse(json['updatedAt']?.toString() ?? '') ?? DateTime.now(),
      total: (json['total'] as num?)?.toDouble() ?? 0,
      subtotal: (json['subtotal'] as num?)?.toDouble() ?? 0,
      tax: (json['tax'] as num?)?.toDouble(),
      discount: (json['discount'] as num?)?.toDouble(),
      note: json['note']?.toString(),
      waiterName: json['waiterName']?.toString(),
      customerName: json['customerName']?.toString(),
      billed: json['billed'] as bool?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'restaurantId': restaurantId,
        'tableNumber': tableNumber,
        'items': items.map((e) => e.toJson()).toList(),
        'status': status.name,
        'placedAt': placedAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'total': total,
        'subtotal': subtotal,
        'tax': tax,
        'discount': discount,
        'note': note,
        'waiterName': waiterName,
        'customerName': customerName,
        'billed': billed,
      };

  Order copyWith({
    OrderStatus? status,
    List<OrderItem>? items,
    double? total,
    double? subtotal,
  }) {
    return Order(
      id: id,
      restaurantId: restaurantId,
      tableNumber: tableNumber,
      items: items ?? this.items,
      status: status ?? this.status,
      placedAt: placedAt,
      updatedAt: DateTime.now(),
      total: total ?? this.total,
      subtotal: subtotal ?? this.subtotal,
      tax: tax,
      discount: discount,
      note: note,
      waiterName: waiterName,
      customerName: customerName,
      billed: billed,
    );
  }

  @override
  List<Object?> get props => [id, status, tableNumber, total];
}
