import 'package:equatable/equatable.dart';

class ExtractedMenuItem extends Equatable {
  final String id;
  final String name;
  final String? description;
  final double price;
  final String? categoryName;
  final String? categoryId;
  final String? foodType;
  final String status;
  final String? errorMessage;
  final String? sourceFile;
  final double? confidenceOverall;

  const ExtractedMenuItem({
    required this.id,
    required this.name,
    this.description,
    required this.price,
    this.categoryName,
    this.categoryId,
    this.foodType,
    this.status = 'ready',
    this.errorMessage,
    this.sourceFile,
    this.confidenceOverall,
  });

  factory ExtractedMenuItem.fromJson(Map<String, dynamic> json) {
    final conf = json['confidence'];
    double? overall;
    if (conf is Map) {
      overall = (conf['overall'] as num?)?.toDouble();
    }
    return ExtractedMenuItem(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      description: json['description']?.toString(),
      price: (json['price'] as num?)?.toDouble() ?? 0,
      categoryName: json['categoryName']?.toString(),
      categoryId: json['categoryId']?.toString(),
      foodType: json['foodType']?.toString(),
      status: json['status']?.toString() ?? 'ready',
      errorMessage: json['errorMessage']?.toString(),
      sourceFile: json['sourceFile']?.toString(),
      confidenceOverall: overall,
    );
  }

  Map<String, dynamic> toPatch() => {
        'name': name,
        'description': description,
        'price': price,
        'categoryName': categoryName,
        'foodType': foodType,
      };

  ExtractedMenuItem copyWith({
    String? name,
    String? description,
    double? price,
    String? categoryName,
    String? foodType,
    String? status,
  }) {
    return ExtractedMenuItem(
      id: id,
      name: name ?? this.name,
      description: description ?? this.description,
      price: price ?? this.price,
      categoryName: categoryName ?? this.categoryName,
      categoryId: categoryId,
      foodType: foodType ?? this.foodType,
      status: status ?? this.status,
      errorMessage: errorMessage,
      sourceFile: sourceFile,
      confidenceOverall: confidenceOverall,
    );
  }

  @override
  List<Object?> get props => [id, name, price, status];
}

class MenuImportSession extends Equatable {
  final String id;
  final String restaurantId;
  final String status;
  final int totalFiles;
  final int totalItems;
  final int processedItems;
  final int successfulItems;
  final int failedItems;
  final int duplicateItems;
  final int needsReviewItems;
  final List<ExtractedMenuItem> items;
  final List<String> categoriesDetected;

  const MenuImportSession({
    required this.id,
    required this.restaurantId,
    required this.status,
    this.totalFiles = 0,
    this.totalItems = 0,
    this.processedItems = 0,
    this.successfulItems = 0,
    this.failedItems = 0,
    this.duplicateItems = 0,
    this.needsReviewItems = 0,
    this.items = const [],
    this.categoriesDetected = const [],
  });

  bool get isProcessing =>
      status == 'processing' || status == 'uploaded' || status == 'pending';

  bool get isReadyForReview =>
      status == 'ready' ||
      status == 'processed' ||
      status == 'needs_review' ||
      items.isNotEmpty;

  factory MenuImportSession.fromJson(Map<String, dynamic> json) {
    final itemsRaw = json['items'];
    final items = itemsRaw is List
        ? itemsRaw
            .map((e) => ExtractedMenuItem.fromJson(e as Map<String, dynamic>))
            .toList()
        : <ExtractedMenuItem>[];
    final cats = json['categoriesDetected'];
    return MenuImportSession(
      id: json['id']?.toString() ?? '',
      restaurantId: json['restaurantId']?.toString() ?? '',
      status: json['status']?.toString() ?? 'pending',
      totalFiles: (json['totalFiles'] as num?)?.toInt() ?? 0,
      totalItems: (json['totalItems'] as num?)?.toInt() ?? items.length,
      processedItems: (json['processedItems'] as num?)?.toInt() ?? 0,
      successfulItems: (json['successfulItems'] as num?)?.toInt() ?? 0,
      failedItems: (json['failedItems'] as num?)?.toInt() ?? 0,
      duplicateItems: (json['duplicateItems'] as num?)?.toInt() ?? 0,
      needsReviewItems: (json['needsReviewItems'] as num?)?.toInt() ?? 0,
      items: items,
      categoriesDetected: cats is List
          ? cats.map((e) => e.toString()).toList()
          : const [],
    );
  }

  @override
  List<Object?> get props => [id, status, totalItems];
}
