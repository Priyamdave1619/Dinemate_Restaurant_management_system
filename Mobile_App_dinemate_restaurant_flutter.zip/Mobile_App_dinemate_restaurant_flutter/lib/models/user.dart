import 'package:equatable/equatable.dart';

class User extends Equatable {
  final String id;
  final String username;
  final String? name;
  /// Normalized: owner | manager | waiter | super_admin
  final String role;
  final String? restaurantId;
  final String? restaurantName;
  final bool active;
  final String? email;
  final String? phone;

  const User({
    required this.id,
    required this.username,
    this.name,
    required this.role,
    this.restaurantId,
    this.restaurantName,
    this.active = true,
    this.email,
    this.phone,
  });

  bool get isOwner => role == 'owner';
  bool get isManager => role == 'manager';
  bool get isWaiter => role == 'waiter' || role == 'staff';
  bool get canManageStaff => isOwner || isManager;
  bool get canManageFinance => isOwner || isManager;
  bool get canManageOffers => isOwner || isManager;
  bool get canViewReports => isOwner || isManager;
  bool get canManageSubscription => isOwner;

  /// Roles allowed to sign in to this management app (owners & managers only).
  /// Waiters / floor staff are blocked — use the waiter app if provided.
  static bool isRestaurantPortalRole(String role) {
    const allowed = {'owner', 'manager'};
    return allowed.contains(role.toLowerCase());
  }

  /// Floor roles that must not access this portal.
  static bool isWaiterRole(String role) {
    const blocked = {'waiter', 'staff', 'employee', 'server'};
    return blocked.contains(role.toLowerCase());
  }

  factory User.fromJson(Map<String, dynamic> json) {
    var role = json['role']?.toString().trim().toLowerCase() ?? 'waiter';
    // Backend aliases
    if (role == 'staff' || role == 'employee' || role == 'server') {
      role = 'waiter';
    }

    // restaurantId may arrive as restaurant_id
    final restaurantId = json['restaurantId']?.toString() ??
        json['restaurant_id']?.toString() ??
        (json['restaurant'] is Map
            ? (json['restaurant'] as Map)['id']?.toString()
            : null);

    final restaurantName = json['restaurantName']?.toString() ??
        json['restaurant_name']?.toString() ??
        (json['restaurant'] is Map
            ? (json['restaurant'] as Map)['name']?.toString()
            : null);

    return User(
      id: json['id']?.toString() ?? json['_id']?.toString() ?? '',
      username: json['username']?.toString() ?? '',
      name: json['name']?.toString(),
      role: role.isEmpty ? 'waiter' : role,
      restaurantId: restaurantId,
      restaurantName: restaurantName,
      active: _parseBool(json['active']) ?? true,
      email: json['email']?.toString(),
      phone: json['phone']?.toString() ?? json['mobile']?.toString(),
    );
  }

  static bool? _parseBool(dynamic value) {
    if (value == null) return null;
    if (value is bool) return value;
    if (value is num) return value != 0;
    if (value is String) {
      final v = value.toLowerCase();
      return v == 'true' || v == '1' || v == 'yes' || v == 'active';
    }
    return null;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'name': name,
        'role': role,
        'restaurantId': restaurantId,
        'restaurantName': restaurantName,
        'active': active,
        'email': email,
        'phone': phone,
      };

  User copyWith({
    String? id,
    String? username,
    String? name,
    String? role,
    String? restaurantId,
    String? restaurantName,
    bool? active,
    String? email,
    String? phone,
  }) {
    return User(
      id: id ?? this.id,
      username: username ?? this.username,
      name: name ?? this.name,
      role: role ?? this.role,
      restaurantId: restaurantId ?? this.restaurantId,
      restaurantName: restaurantName ?? this.restaurantName,
      active: active ?? this.active,
      email: email ?? this.email,
      phone: phone ?? this.phone,
    );
  }

  @override
  List<Object?> get props => [id, username, role, restaurantId];
}
