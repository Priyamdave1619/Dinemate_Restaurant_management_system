import 'package:equatable/equatable.dart';

class Offer extends Equatable {
  final String id;
  final String restaurantId;
  final String name;
  final String? description;
  final String type; // percent | flat | bogo | coupon | ...
  final bool active;
  final double? discountPercent;
  final double? discountAmount;
  final double? maxDiscountAmount;
  final double? minOrderAmount;
  final String? startsAt;
  final String? endsAt;
  final String? couponCode;
  final int? usageLimit;
  final int? usageCount;
  final String? status;

  const Offer({
    required this.id,
    required this.restaurantId,
    required this.name,
    this.description,
    required this.type,
    this.active = true,
    this.discountPercent,
    this.discountAmount,
    this.maxDiscountAmount,
    this.minOrderAmount,
    this.startsAt,
    this.endsAt,
    this.couponCode,
    this.usageLimit,
    this.usageCount,
    this.status,
  });

  factory Offer.fromJson(Map<String, dynamic> json) {
    return Offer(
      id: json['id']?.toString() ?? '',
      restaurantId: json['restaurantId']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      description: json['description']?.toString(),
      type: json['type']?.toString() ?? 'percent',
      active: json['active'] as bool? ?? true,
      discountPercent: (json['discountPercent'] as num?)?.toDouble(),
      discountAmount: (json['discountAmount'] as num?)?.toDouble(),
      maxDiscountAmount: (json['maxDiscountAmount'] as num?)?.toDouble(),
      minOrderAmount: (json['minOrderAmount'] as num?)?.toDouble(),
      startsAt: json['startsAt']?.toString(),
      endsAt: json['endsAt']?.toString(),
      couponCode: json['couponCode']?.toString(),
      usageLimit: (json['usageLimit'] as num?)?.toInt(),
      usageCount: (json['usageCount'] as num?)?.toInt(),
      status: json['status']?.toString(),
    );
  }

  String get discountLabel {
    if (discountPercent != null) return '${discountPercent!.toStringAsFixed(0)}% off';
    if (discountAmount != null) return '₹${discountAmount!.toStringAsFixed(0)} off';
    return type;
  }

  @override
  List<Object?> get props => [id, name, active];
}
