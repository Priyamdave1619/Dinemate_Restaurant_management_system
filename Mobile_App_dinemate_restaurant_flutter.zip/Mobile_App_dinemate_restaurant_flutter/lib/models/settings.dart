import 'package:equatable/equatable.dart';

class RestaurantSettings extends Equatable {
  final String restaurantId;
  final double taxRatePercent;
  final String restaurantName;
  final String? currency;
  final String? baseUrl;
  final String? openingTime;
  final String? closingTime;
  final String? address;
  final String? phone;
  final String? foodLicence;
  final String? gstin;
  final String? billPrefix;

  const RestaurantSettings({
    required this.restaurantId,
    this.taxRatePercent = 0,
    required this.restaurantName,
    this.currency = 'INR',
    this.baseUrl,
    this.openingTime,
    this.closingTime,
    this.address,
    this.phone,
    this.foodLicence,
    this.gstin,
    this.billPrefix,
  });

  factory RestaurantSettings.fromJson(Map<String, dynamic> json) {
    return RestaurantSettings(
      restaurantId: json['restaurantId']?.toString() ?? '',
      taxRatePercent: (json['taxRatePercent'] as num?)?.toDouble() ?? 0,
      restaurantName: json['restaurantName']?.toString() ?? '',
      currency: json['currency']?.toString() ?? 'INR',
      baseUrl: json['baseUrl']?.toString(),
      openingTime: json['openingTime']?.toString(),
      closingTime: json['closingTime']?.toString(),
      address: json['address']?.toString(),
      phone: json['phone']?.toString(),
      foodLicence: json['foodLicence']?.toString(),
      gstin: json['gstin']?.toString(),
      billPrefix: json['billPrefix']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
        'restaurantId': restaurantId,
        'taxRatePercent': taxRatePercent,
        'restaurantName': restaurantName,
        'currency': currency,
        'baseUrl': baseUrl,
        'openingTime': openingTime,
        'closingTime': closingTime,
        'address': address,
        'phone': phone,
        'foodLicence': foodLicence,
        'gstin': gstin,
        'billPrefix': billPrefix,
      };

  @override
  List<Object?> get props => [restaurantId, restaurantName, taxRatePercent];
}

class AppNotification extends Equatable {
  final String id;
  final String type;
  final String title;
  final String message;
  final bool read;
  final String createdAt;
  final String? targetRole;
  final String? imageUrl;
  final String? action;
  final String? entityId;
  final Map<String, dynamic>? data;

  const AppNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.message,
    this.read = false,
    required this.createdAt,
    this.targetRole,
    this.imageUrl,
    this.action,
    this.entityId,
    this.data,
  });

  factory AppNotification.fromJson(Map<String, dynamic> json) {
    final data = json['data'];
    return AppNotification(
      id: json['id']?.toString() ?? '',
      type: json['type']?.toString() ?? json['category']?.toString() ?? 'system',
      title: json['title']?.toString() ?? '',
      message: json['message']?.toString() ?? json['body']?.toString() ?? '',
      read: json['read'] as bool? ?? json['isRead'] as bool? ?? false,
      createdAt: json['createdAt']?.toString() ?? json['created_at']?.toString() ?? '',
      targetRole: json['targetRole']?.toString(),
      imageUrl: json['imageUrl']?.toString() ?? json['image']?.toString(),
      action: json['action']?.toString() ?? json['deepLink']?.toString(),
      entityId: json['entityId']?.toString() ?? json['orderId']?.toString(),
      data: data is Map ? Map<String, dynamic>.from(data) : null,
    );
  }

  AppNotification copyWith({bool? read}) => AppNotification(
        id: id,
        type: type,
        title: title,
        message: message,
        read: read ?? this.read,
        createdAt: createdAt,
        targetRole: targetRole,
        imageUrl: imageUrl,
        action: action,
        entityId: entityId,
        data: data,
      );

  @override
  List<Object?> get props => [id, read, title];
}

class ActivityLog extends Equatable {
  final String id;
  final String? restaurantId;
  final String? actorUserId;
  final String? actorName;
  final String? actorRole;
  final String action;
  final String? entityType;
  final String? entityId;
  final String createdAt;

  const ActivityLog({
    required this.id,
    this.restaurantId,
    this.actorUserId,
    this.actorName,
    this.actorRole,
    required this.action,
    this.entityType,
    this.entityId,
    required this.createdAt,
  });

  factory ActivityLog.fromJson(Map<String, dynamic> json) {
    return ActivityLog(
      id: json['id']?.toString() ?? '',
      restaurantId: json['restaurantId']?.toString(),
      actorUserId: json['actorUserId']?.toString(),
      actorName: json['actorName']?.toString(),
      actorRole: json['actorRole']?.toString(),
      action: json['action']?.toString() ?? '',
      entityType: json['entityType']?.toString(),
      entityId: json['entityId']?.toString(),
      createdAt: json['createdAt']?.toString() ?? '',
    );
  }

  @override
  List<Object?> get props => [id, action, createdAt];
}

class Plan extends Equatable {
  final String id;
  final String name;
  final int durationDays;
  final double price;
  final int productLimit;
  final int orderLimit;
  final int userLimit;
  final int storageLimitMb;
  final List<String> features;
  final bool active;

  const Plan({
    required this.id,
    required this.name,
    required this.durationDays,
    required this.price,
    this.productLimit = 0,
    this.orderLimit = 0,
    this.userLimit = 0,
    this.storageLimitMb = 0,
    this.features = const [],
    this.active = true,
  });

  factory Plan.fromJson(Map<String, dynamic> json) {
    return Plan(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      durationDays: (json['durationDays'] as num?)?.toInt() ?? 30,
      price: (json['price'] as num?)?.toDouble() ?? 0,
      productLimit: (json['productLimit'] as num?)?.toInt() ?? 0,
      orderLimit: (json['orderLimit'] as num?)?.toInt() ?? 0,
      userLimit: (json['userLimit'] as num?)?.toInt() ?? 0,
      storageLimitMb: (json['storageLimitMb'] as num?)?.toInt() ?? 0,
      features: (json['features'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
      active: json['active'] as bool? ?? true,
    );
  }

  @override
  List<Object?> get props => [id, name, price];
}
