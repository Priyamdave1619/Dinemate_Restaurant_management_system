import 'package:equatable/equatable.dart';

class MenuCategory extends Equatable {
  final String id;
  final String name;
  final int sortOrder;
  final bool active;

  const MenuCategory({
    required this.id,
    required this.name,
    this.sortOrder = 0,
    this.active = true,
  });

  factory MenuCategory.fromJson(Map<String, dynamic> json) {
    return MenuCategory(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      sortOrder: (json['sortOrder'] as num?)?.toInt() ?? 0,
      active: json['active'] as bool? ?? true,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'sortOrder': sortOrder,
        'active': active,
      };

  @override
  List<Object?> get props => [id, name];
}

class MenuItem extends Equatable {
  final String id;
  final String restaurantId;
  final String name;
  final String? description;
  final double price;
  final double? costPrice;
  final String? categoryId;
  final String? categoryName;
  final String? imageUrl;
  final bool available;
  final bool isVeg;
  final String? foodType; // veg | non-veg | egg
  final List<String> tags;
  final List<String> allergens;
  final int? preparationTimeMinutes;
  final bool allowCookingRequest;
  final int sortOrder;

  const MenuItem({
    required this.id,
    required this.restaurantId,
    required this.name,
    this.description,
    required this.price,
    this.costPrice,
    this.categoryId,
    this.categoryName,
    this.imageUrl,
    this.available = true,
    this.isVeg = true,
    this.foodType,
    this.tags = const [],
    this.allergens = const [],
    this.preparationTimeMinutes,
    this.allowCookingRequest = false,
    this.sortOrder = 0,
  });

  factory MenuItem.fromJson(Map<String, dynamic> json) {
    return MenuItem(
      id: json['id']?.toString() ?? '',
      restaurantId: json['restaurantId']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      description: json['description']?.toString(),
      price: (json['price'] as num?)?.toDouble() ?? 0,
      costPrice: (json['costPrice'] as num?)?.toDouble(),
      categoryId: json['categoryId']?.toString(),
      categoryName: json['categoryName']?.toString(),
      imageUrl: json['imageUrl']?.toString(),
      available: json['available'] as bool? ?? true,
      isVeg: json['isVeg'] as bool? ?? (json['foodType']?.toString() == 'veg'),
      foodType: json['foodType']?.toString(),
      tags: (json['tags'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
      allergens: (json['allergens'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
      preparationTimeMinutes: (json['preparationTimeMinutes'] as num?)?.toInt(),
      allowCookingRequest: json['allowCookingRequest'] as bool? ?? false,
      sortOrder: (json['sortOrder'] as num?)?.toInt() ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'restaurantId': restaurantId,
        'name': name,
        'description': description,
        'price': price,
        'costPrice': costPrice,
        'categoryId': categoryId,
        'categoryName': categoryName,
        'imageUrl': imageUrl,
        'available': available,
        'isVeg': isVeg,
        'foodType': foodType,
        'tags': tags,
        'allergens': allergens,
        'preparationTimeMinutes': preparationTimeMinutes,
        'allowCookingRequest': allowCookingRequest,
        'sortOrder': sortOrder,
      };

  MenuItem copyWith({bool? available, String? name, double? price}) {
    return MenuItem(
      id: id,
      restaurantId: restaurantId,
      name: name ?? this.name,
      description: description,
      price: price ?? this.price,
      costPrice: costPrice,
      categoryId: categoryId,
      categoryName: categoryName,
      imageUrl: imageUrl,
      available: available ?? this.available,
      isVeg: isVeg,
      foodType: foodType,
      tags: tags,
      allergens: allergens,
      preparationTimeMinutes: preparationTimeMinutes,
      allowCookingRequest: allowCookingRequest,
      sortOrder: sortOrder,
    );
  }

  @override
  List<Object?> get props => [id, name, price, available];
}
