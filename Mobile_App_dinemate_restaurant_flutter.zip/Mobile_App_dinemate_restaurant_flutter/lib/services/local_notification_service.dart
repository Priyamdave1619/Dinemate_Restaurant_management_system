import 'package:flutter/foundation.dart';
import 'package:dinemate_restaurant/models/notification_preferences.dart';

/// Lightweight notification presenter for Dinemate.
/// Respects [NotificationPreferences] when provided.
class LocalNotificationService {
  LocalNotificationService._();
  static final instance = LocalNotificationService._();

  bool _ready = false;
  void Function(String? payload)? onTap;

  /// Last known prefs — updated by UI / provider.
  NotificationPreferences preferences = NotificationPreferences.defaults;

  Future<void> init({void Function(String? payload)? onNotificationTap}) async {
    onTap = onNotificationTap;
    _ready = true;
    debugPrint('LocalNotificationService ready (in-app mode)');
  }

  void updatePreferences(NotificationPreferences prefs) {
    preferences = prefs;
  }

  Future<void> show({
    required int id,
    required String title,
    required String body,
    String? payload,
    String type = 'system',
  }) async {
    if (!_ready) await init();
    if (!preferences.allowsType(type)) {
      debugPrint('Notify suppressed by prefs [$type]: $title');
      return;
    }
    debugPrint('Notify [$id] $title — $body payload=$payload');
  }

  Future<void> cancelAll() async {}
}
