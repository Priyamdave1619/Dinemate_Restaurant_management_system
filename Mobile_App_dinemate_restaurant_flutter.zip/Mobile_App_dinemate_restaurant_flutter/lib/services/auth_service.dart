import 'package:dio/dio.dart';
import 'package:dinemate_restaurant/core/api/api_client.dart';
import 'package:dinemate_restaurant/models/user.dart';

class AuthService {
  final ApiClient _client = apiClient;

  /// Restaurant portal login — owner (Restaurant ID) or manager only. Waiters are rejected.
  Future<({User user, String accessToken, String refreshToken})> login({
    required String username,
    required String password,
  }) async {
    try {
      final response = await _client.dio.post(
        '/api/auth/login',
        data: {
          'username': username.trim(),
          'password': password,
        },
      );

      final rawData = response.data;
      if (rawData is! Map) {
        throw Exception('Unexpected response from server. Please try again.');
      }

      final data = (rawData['data'] is Map ? rawData['data'] : rawData) as Map;

      final accessToken = data['accessToken']?.toString();
      final refreshToken = data['refreshToken']?.toString();
      if (accessToken == null ||
          accessToken.isEmpty ||
          refreshToken == null ||
          refreshToken.isEmpty) {
        throw Exception(
          'Login response was missing session data. Please try again.',
        );
      }

      // Build user JSON from nested `user` or flat `data`
      final Map<String, dynamic> userJson;
      if (data['user'] is Map) {
        userJson = Map<String, dynamic>.from(data['user'] as Map);
      } else {
        userJson = Map<String, dynamic>.from(data);
        // Strip token fields so they are not mistaken for profile fields
        userJson.remove('accessToken');
        userJson.remove('refreshToken');
        userJson.remove('token');
      }

      // Restaurant may be nested: { restaurant: { id, name } }
      final restaurant = data['restaurant'];
      if (restaurant is Map) {
        if ((userJson['restaurantId'] == null ||
                userJson['restaurantId'].toString().isEmpty) &&
            restaurant['id'] != null) {
          userJson['restaurantId'] = restaurant['id'].toString();
        }
        if ((userJson['restaurantName'] == null ||
                userJson['restaurantName'].toString().isEmpty) &&
            restaurant['name'] != null) {
          userJson['restaurantName'] = restaurant['name'].toString();
        }
      }

      // Some backends put restaurantId only on the root payload
      if ((userJson['restaurantId'] == null ||
              userJson['restaurantId'].toString().isEmpty) &&
          data['restaurantId'] != null) {
        userJson['restaurantId'] = data['restaurantId'].toString();
      }

      // Normalize role aliases used by older backends
      final rawRole = (userJson['role'] ?? data['role'] ?? '').toString().trim().toLowerCase();
      userJson['role'] = _normalizeRole(rawRole);

      final user = User.fromJson(userJson);

      // Portal is for restaurant management only — not platform super admin
      if (user.role == 'super_admin') {
        throw Exception(
          'Use the Platform Admin panel for super admin accounts.',
        );
      }

      // Waiters / floor staff cannot sign in to this management app
      if (user.isWaiter || User.isWaiterRole(user.role)) {
        throw Exception(
          'Waiter accounts cannot sign in here. This app is for restaurant owners and managers only.',
        );
      }

      // Owner / manager must belong to a restaurant
      if (user.restaurantId == null || user.restaurantId!.isEmpty) {
        throw Exception(
          'This account is not linked to a restaurant. Ask your owner to re-invite you.',
        );
      }

      if (!user.active) {
        throw Exception(
          'This staff account is deactivated. Contact your restaurant owner.',
        );
      }

      // Allowed management roles only
      if (!User.isRestaurantPortalRole(user.role)) {
        throw Exception(
          'This account type cannot sign in to the restaurant app. Owners and managers only.',
        );
      }

      await _client.saveTokens(accessToken, refreshToken);

      return (user: user, accessToken: accessToken, refreshToken: refreshToken);
    } on DioException catch (e) {
      final responseData = e.response?.data;
      final message =
          (responseData is Map ? responseData['message']?.toString() : null) ??
              _friendlyMessageFor(e);
      throw Exception(message);
    } on Exception {
      rethrow;
    } catch (_) {
      throw Exception('Something went wrong signing in. Please try again.');
    }
  }

  /// Maps backend role strings onto portal roles.
  static String _normalizeRole(String role) {
    switch (role) {
      case 'staff':
      case 'employee':
      case 'server':
        return 'waiter';
      case 'admin':
      case 'restaurant_owner':
        return 'owner';
      case 'restaurant_manager':
        return 'manager';
      default:
        return role.isEmpty ? 'waiter' : role;
    }
  }

  String _friendlyMessageFor(DioException e) {
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return 'The server is taking too long to respond. Please try again.';
      case DioExceptionType.connectionError:
        return 'Could not reach the server. Check your internet connection.';
      default:
        final status = e.response?.statusCode;
        if (status == 401 || status == 403) {
          return 'Incorrect username or password, or this account cannot sign in.';
        }
        if (status != null && status >= 500) {
          return 'Server error. Please try again in a moment.';
        }
        return e.message ?? 'Login failed';
    }
  }

  Future<void> logout() async {
    try {
      await _client.dio.post('/api/auth/logout');
    } catch (_) {
      // ignore network errors on logout
    } finally {
      await _client.clearTokens();
    }
  }

  Future<User?> getCurrentUser() async {
    try {
      final response = await _client.dio.get('/api/auth/me');
      final data = response.data['data'] ?? response.data;
      if (data is! Map) return null;
      final map = Map<String, dynamic>.from(data as Map);
      if (map['restaurant'] is Map) {
        final r = map['restaurant'] as Map;
        map['restaurantId'] ??= r['id']?.toString();
        map['restaurantName'] ??= r['name']?.toString();
      }
      final role = (map['role'] ?? '').toString().trim().toLowerCase();
      map['role'] = _normalizeRole(role);
      return User.fromJson(map);
    } catch (_) {
      return null;
    }
  }

  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      await _client.dio.post(
        '/api/auth/change-password',
        data: {
          'currentPassword': currentPassword,
          'newPassword': newPassword,
        },
      );
    } on DioException catch (e) {
      final responseData = e.response?.data;
      final message =
          (responseData is Map ? responseData['message']?.toString() : null) ??
              _friendlyMessageFor(e);
      throw Exception(message);
    }
  }
}
