import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';

/// Requests app-related permissions on every launch, for as long as any
/// of them are still not granted. Once the user grants a permission it's
/// never asked again (checking `.status` short-circuits it below); if
/// they deny it, the OS dialog reappears next launch instead of the app
/// silently giving up after a single denial.
///
/// If a permission has been *permanently* denied, the OS itself won't
/// show its dialog again — `permission_handler` returns that status
/// immediately without a popup, so calling this repeatedly is harmless.
/// The caller can check for `isPermanentlyDenied` and point the user to
/// `openSystemSettings()` instead.
class PermissionService {
  PermissionService._();
  static final instance = PermissionService._();

  /// Call when UI is visible (after short splash) so OS dialogs can appear.
  Future<Map<Permission, PermissionStatus>> requestAllOnStartup({
    bool force = false,
  }) async {
    final empty = <Permission, PermissionStatus>{};
    if (kIsWeb) return empty;

    final results = <Permission, PermissionStatus>{};

    // Request one-by-one so each system dialog is visible
    final list = <Permission>[
      Permission.notification,
      Permission.camera,
      Permission.photos,
      Permission.videos,
      Permission.storage, // ignored / auto-granted on modern Android
    ];

    for (final permission in list) {
      try {
        final status = await permission.status;
        if (status.isGranted || status.isLimited || status.isRestricted) {
          results[permission] = status;
          continue;
        }
        // Permanently denied → OS won't show a dialog anyway; skip asking
        // and let the caller direct the user to Settings instead.
        if (status.isPermanentlyDenied) {
          results[permission] = status;
          continue;
        }
        // Not yet granted (first ask, or a previous "Deny") → (re)prompt.
        final next = await permission.request();
        results[permission] = next;
        // Brief gap so dialogs don't stack poorly on some OEMs
        await Future.delayed(const Duration(milliseconds: 250));
      } catch (e) {
        debugPrint('Permission $permission error: $e');
      }
    }

    debugPrint('Permissions done: $results');
    return results;
  }

  Future<bool> ensureCamera() async {
    final s = await Permission.camera.request();
    return s.isGranted || s.isLimited;
  }

  Future<bool> ensurePhotos() async {
    var s = await Permission.photos.request();
    if (s.isGranted || s.isLimited) return true;
    s = await Permission.storage.request();
    return s.isGranted;
  }

  Future<bool> ensureNotifications() async {
    final s = await Permission.notification.request();
    return s.isGranted;
  }

  Future<void> openSystemSettings() => openAppSettings();
}
