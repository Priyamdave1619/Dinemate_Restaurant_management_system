import 'package:dinemate_restaurant/core/api/api_client.dart';
import 'package:dinemate_restaurant/models/expense.dart';
import 'package:dinemate_restaurant/models/menu_item.dart';
import 'package:dinemate_restaurant/models/offer.dart';
import 'package:dinemate_restaurant/models/order.dart';
import 'package:dinemate_restaurant/models/restaurant_table.dart';
import 'package:dinemate_restaurant/models/settings.dart';
import 'package:dinemate_restaurant/models/staff_user.dart';
import 'package:dinemate_restaurant/models/menu_import.dart';
import 'package:dinemate_restaurant/models/notification_preferences.dart';
import 'package:dio/dio.dart';
import 'dart:io';

class RestaurantService {
  final ApiClient _client = apiClient;

  // ─── Orders ───────────────────────────────────────────────

  Future<List<Order>> getOrders({String? status, int page = 1, int pageSize = 50}) async {
    final response = await _client.dio.get(
      '/api/orders',
      queryParameters: {
        if (status != null) 'status': status,
        'page': page,
        'pageSize': pageSize,
      },
    );
    final data = response.data['data'];
    final list = (data is Map ? (data['orders'] ?? data['items']) : data) as List<dynamic>? ?? [];
    return list.map((e) => Order.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<Order> getOrder(String orderId) async {
    final response = await _client.dio.get('/api/orders/$orderId');
    final data = response.data['data'] ?? response.data;
    final order = data is Map && data['order'] != null ? data['order'] : data;
    return Order.fromJson(order as Map<String, dynamic>);
  }

  Future<Order> updateOrderStatus(String orderId, String status) async {
    final response = await _client.dio.patch(
      '/api/orders/$orderId',
      data: {'status': status},
    );
    final data = response.data['data'] ?? response.data;
    final order = data is Map && data['order'] != null ? data['order'] : data;
    return Order.fromJson(order as Map<String, dynamic>);
  }

    Future<void> generateBill(String orderId) async {
    await _client.dio.get('/api/orders/$orderId/bill');
  }

  Future<Map<String, dynamic>> getOrderBill(String orderId) async {
    final response = await _client.dio.get('/api/orders/$orderId/bill');
    final data = response.data['data'] ?? response.data;
    return data is Map<String, dynamic> ? data : {};
  }

  Future<Map<String, dynamic>> getOrderKot(String orderId) async {
    final response = await _client.dio.get('/api/orders/$orderId/kot');
    final data = response.data['data'] ?? response.data;
    return data is Map<String, dynamic> ? data : {};
  }

  Future<void> markKotPrinted(String orderId) async {
    await _client.dio.post('/api/orders/$orderId/kot');
  }


  // ─── Menu ─────────────────────────────────────────────────

  Future<List<MenuItem>> getMenuItems() async {
    final response = await _client.dio.get('/api/menu');
    final data = response.data['data'];
    final list = (data is Map ? (data['items'] ?? data['menu']) : data) as List<dynamic>? ?? [];
    return list.map((e) => MenuItem.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<List<MenuCategory>> getCategories() async {
    final response = await _client.dio.get('/api/categories');
    final data = response.data['data'];
    final list = (data is Map ? data['categories'] : data) as List<dynamic>? ?? [];
    return list.map((e) => MenuCategory.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<MenuCategory> createCategory({required String name, String? icon}) async {
    final response = await _client.dio.post('/api/categories', data: {
      'name': name,
      if (icon != null) 'icon': icon,
    });
    final data = response.data['data'];
    final cat = data is Map && data['category'] != null ? data['category'] : data;
    return MenuCategory.fromJson(cat as Map<String, dynamic>);
  }

  Future<void> updateCategory(String id, Map<String, dynamic> payload) async {
    await _client.dio.patch('/api/categories/$id', data: payload);
  }

  Future<void> deleteCategory(String id) async {
    await _client.dio.delete('/api/categories/$id');
  }

  Future<MenuItem> createMenuItem(Map<String, dynamic> payload) async {
    final response = await _client.dio.post('/api/menu', data: payload);
    final data = response.data['data'];
    final item = data is Map && data['item'] != null ? data['item'] : data;
    return MenuItem.fromJson(item as Map<String, dynamic>);
  }

  Future<void> updateMenuItem(String id, Map<String, dynamic> payload) async {
    await _client.dio.patch('/api/menu/$id', data: payload);
  }

  Future<void> toggleMenuItemAvailability(String id, bool available) async {
    await _client.dio.patch('/api/menu/$id', data: {'available': available});
  }

  Future<void> deleteMenuItem(String id) async {
    await _client.dio.delete('/api/menu/$id');
  }

  // ─── Tables ───────────────────────────────────────────────

  Future<List<RestaurantTable>> getTables() async {
    final response = await _client.dio.get('/api/tables');
    final data = response.data['data'];
    final list = (data is Map ? data['tables'] : data) as List<dynamic>? ?? [];
    return list.map((e) => RestaurantTable.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<RestaurantTable> createTable({required int number, required int capacity}) async {
    final response = await _client.dio.post(
      '/api/tables',
      data: {'number': number, 'capacity': capacity},
    );
    final data = response.data['data'];
    final table = data is Map && data['table'] != null ? data['table'] : data;
    return RestaurantTable.fromJson(table as Map<String, dynamic>);
  }

  Future<void> updateTable(String id, Map<String, dynamic> payload) async {
    await _client.dio.patch('/api/tables/$id', data: payload);
  }

  Future<void> deleteTable(String id) async {
    await _client.dio.delete('/api/tables/$id');
  }

  Future<Map<String, dynamic>> getTableQr(String id, {bool regenerate = false}) async {
    final response = await _client.dio.get(
      '/api/tables/$id/qr',
      queryParameters: {
        'format': 'json',
        if (regenerate) 'regenerate': '1',
      },
    );
    return response.data['data'] as Map<String, dynamic>? ?? {};
  }

  Future<Map<String, dynamic>> regenerateTableQr(String id) async {
    final response = await _client.dio.post('/api/tables/$id/qr');
    return response.data['data'] as Map<String, dynamic>? ?? {};
  }

  // ─── Dashboard ────────────────────────────────────────────

  Future<Map<String, dynamic>> getDashboardStats() async {
    try {
      final response = await _client.dio.get('/api/analytics');
      return response.data['data'] as Map<String, dynamic>? ?? {};
    } catch (_) {
      return {};
    }
  }

  // ─── Staff ────────────────────────────────────────────────

  Future<List<StaffUser>> getStaff() async {
    final response = await _client.dio.get('/api/users');
    final data = response.data['data'];
    final list = (data is Map ? data['users'] : data) as List<dynamic>? ?? [];
    return list.map((e) => StaffUser.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<StaffUser> createStaff(Map<String, dynamic> payload) async {
    final response = await _client.dio.post('/api/users', data: payload);
    final data = response.data['data'];
    final user = data is Map && data['user'] != null ? data['user'] : data;
    return StaffUser.fromJson(user as Map<String, dynamic>);
  }

  Future<void> updateStaff(String id, Map<String, dynamic> payload) async {
    await _client.dio.patch('/api/users/$id', data: payload);
  }

  Future<void> deleteStaff(String id) async {
    await _client.dio.delete('/api/users/$id');
  }

  // ─── Finance ──────────────────────────────────────────────

  Future<List<Expense>> getExpenses({String? month, String? year}) async {
    final response = await _client.dio.get(
      '/api/finance/expenses',
      queryParameters: {
        if (month != null) 'month': month,
        if (year != null) 'year': year,
      },
    );
    final data = response.data['data'];
    final list = (data is Map ? data['expenses'] : data) as List<dynamic>? ?? [];
    return list.map((e) => Expense.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<Expense> createExpense(Map<String, dynamic> payload) async {
    final response = await _client.dio.post('/api/finance/expenses', data: payload);
    final data = response.data['data'];
    final expense = data is Map && data['expense'] != null ? data['expense'] : data;
    return Expense.fromJson(expense as Map<String, dynamic>);
  }

  Future<void> updateExpense(String id, Map<String, dynamic> payload) async {
    await _client.dio.patch('/api/finance/expenses/$id', data: payload);
  }

  Future<void> deleteExpense(String id) async {
    await _client.dio.delete('/api/finance/expenses/$id');
  }

  Future<Map<String, dynamic>> getPnl({String? period, String? key}) async {
    final response = await _client.dio.get(
      '/api/finance/pnl',
      queryParameters: {
        if (period != null) 'period': period,
        if (key != null) 'key': key,
      },
    );
    return response.data['data'] as Map<String, dynamic>? ?? {};
  }

  // ─── Offers ───────────────────────────────────────────────

  Future<List<Offer>> getOffers() async {
    final response = await _client.dio.get('/api/offers');
    final data = response.data['data'];
    final list = (data is Map ? data['offers'] : data) as List<dynamic>? ?? [];
    return list.map((e) => Offer.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<Offer> createOffer(Map<String, dynamic> payload) async {
    final response = await _client.dio.post('/api/offers', data: payload);
    final data = response.data['data'];
    final offer = data is Map && data['offer'] != null ? data['offer'] : data;
    return Offer.fromJson(offer as Map<String, dynamic>);
  }

  Future<void> updateOffer(String id, Map<String, dynamic> payload) async {
    await _client.dio.patch('/api/offers/$id', data: payload);
  }

  Future<void> deleteOffer(String id) async {
    await _client.dio.delete('/api/offers/$id');
  }

  // ─── Reports ──────────────────────────────────────────────

  Future<Map<String, dynamic>> getDailyReport({String? date, String? from, String? to}) async {
    final response = await _client.dio.get(
      '/api/reports/daily',
      queryParameters: {
        if (date != null) 'date': date,
        if (from != null) 'from': from,
        if (to != null) 'to': to,
      },
    );
    return response.data['data'] as Map<String, dynamic>? ?? {};
  }

  Future<Map<String, dynamic>> getMonthlyReport({String? month, String? year}) async {
    final response = await _client.dio.get(
      '/api/reports/monthly',
      queryParameters: {
        if (month != null) 'month': month,
        if (year != null) 'year': year,
      },
    );
    return response.data['data'] as Map<String, dynamic>? ?? {};
  }

  Future<Map<String, dynamic>> getWeeklyReport({String? week}) async {
    final response = await _client.dio.get(
      '/api/reports/weekly',
      queryParameters: {if (week != null) 'week': week},
    );
    return response.data['data'] as Map<String, dynamic>? ?? {};
  }

  Future<Map<String, dynamic>> getYearlyReport({String? year}) async {
    final response = await _client.dio.get(
      '/api/reports/yearly',
      queryParameters: {if (year != null) 'year': year},
    );
    return response.data['data'] as Map<String, dynamic>? ?? {};
  }

  Future<Map<String, dynamic>> getItemsReport({String? from, String? to}) async {
    final response = await _client.dio.get(
      '/api/reports/items',
      queryParameters: {
        if (from != null) 'from': from,
        if (to != null) 'to': to,
      },
    );
    return response.data['data'] as Map<String, dynamic>? ?? {};
  }

  // ─── Notifications ────────────────────────────────────────

  Future<List<AppNotification>> getNotifications({bool? unread}) async {
    final response = await _client.dio.get(
      '/api/notifications',
      queryParameters: {
        if (unread == true) 'unread': '1',
      },
    );
    final data = response.data['data'];
    final list = (data is Map ? data['notifications'] : data) as List<dynamic>? ?? [];
    return list.map((e) => AppNotification.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> markAllNotificationsRead() async {
    await _client.dio.patch('/api/notifications', data: {'markAllRead': true});
  }

  Future<void> markNotificationRead(String id) async {
    await _client.dio.patch('/api/notifications/$id', data: {'read': true});
  }

  // ─── Activity ─────────────────────────────────────────────

  Future<List<ActivityLog>> getActivityLogs({int page = 1, int pageSize = 50}) async {
    final response = await _client.dio.get(
      '/api/activity-logs',
      queryParameters: {'page': page, 'pageSize': pageSize},
    );
    final data = response.data['data'];
    final list = (data is Map
            ? (data['logs'] ?? data['activityLogs'])
            : data) as List<dynamic>? ??
        [];
    return list.map((e) => ActivityLog.fromJson(e as Map<String, dynamic>)).toList();
  }

  // ─── Settings ─────────────────────────────────────────────

  Future<RestaurantSettings> getSettings() async {
    final response = await _client.dio.get('/api/settings');
    final data = response.data['data'];
    final settings = data is Map && data['settings'] != null ? data['settings'] : data;
    return RestaurantSettings.fromJson(settings as Map<String, dynamic>);
  }

  Future<void> updateSettings(Map<String, dynamic> payload) async {
    await _client.dio.patch('/api/settings', data: payload);
  }

  Future<Map<String, dynamic>> getRestaurantMe() async {
    final response = await _client.dio.get('/api/restaurants/me');
    final data = response.data['data'];
    return (data is Map && data['restaurant'] != null ? data['restaurant'] : data)
        as Map<String, dynamic>? ??
        {};
  }

  Future<void> updateRestaurantMe(Map<String, dynamic> payload) async {
    await _client.dio.patch('/api/restaurants/me', data: payload);
  }

  Future<String?> uploadLogo(File file) async {
    final name = file.path.split(Platform.pathSeparator).last;
    final form = FormData.fromMap({
      'file': await MultipartFile.fromFile(file.path, filename: name),
    });
    final response = await _client.dio.post(
      '/api/restaurants/upload-logo',
      data: form,
    );
    final data = response.data['data'] ?? response.data;
    if (data is Map) return data['logoUrl']?.toString();
    return null;
  }

  
  Future<Map<String, dynamic>> createCheckout(String planId) async {
    final response = await _client.dio.post('/api/billing/checkout', data: {'planId': planId});
    final data = response.data['data'] ?? response.data;
    if (data is Map && data['checkout'] is Map) {
      return Map<String, dynamic>.from(data['checkout'] as Map);
    }
    return data is Map<String, dynamic> ? data : {};
  }

  Future<Map<String, dynamic>> verifyPayment(Map<String, dynamic> body) async {
    final response = await _client.dio.post('/api/billing/verify', data: body);
    final data = response.data['data'] ?? response.data;
    return data is Map<String, dynamic> ? data : {};
  }

  Future<Order> addOrderItems(
    String orderId,
    List<Map<String, dynamic>> items,
  ) async {
    final response = await _client.dio.post(
      '/api/orders/$orderId/items',
      data: {'items': items},
    );
    final data = response.data['data'] ?? response.data;
    final order = data is Map && data['order'] != null ? data['order'] : data;
    return Order.fromJson(order as Map<String, dynamic>);
  }

  // ─── Subscription ─────────────────────────────────────────

  Future<List<Plan>> getPlans() async {
    final response = await _client.dio.get('/api/admin/plans');
    final data = response.data['data'];
    final list = (data is Map ? data['plans'] : data) as List<dynamic>? ?? [];
    return list.map((e) => Plan.fromJson(e as Map<String, dynamic>)).toList();
  }


  // ─── AI / Bulk Menu Import ─────────────────────────────────

  Future<MenuImportSession> uploadMenuImport(List<File> files) async {
    final form = FormData();
    for (final f in files) {
      final name = f.path.split(Platform.pathSeparator).last;
      form.files.add(MapEntry(
        'files',
        await MultipartFile.fromFile(f.path, filename: name),
      ));
    }
    final response = await _client.dio.post(
      '/api/menu-import/upload',
      data: form,
      options: Options(
        sendTimeout: const Duration(seconds: 120),
        receiveTimeout: const Duration(seconds: 120),
      ),
    );
    final data = response.data['data'];
    final session = data is Map && data['session'] != null ? data['session'] : data;
    return MenuImportSession.fromJson(session as Map<String, dynamic>);
  }

  Future<MenuImportSession> processMenuImport(String id) async {
    final response = await _client.dio.post(
      '/api/menu-import/$id/process',
      options: Options(receiveTimeout: const Duration(seconds: 180)),
    );
    final data = response.data['data'];
    final session = data is Map && data['session'] != null ? data['session'] : data;
    return MenuImportSession.fromJson(session as Map<String, dynamic>);
  }

  Future<MenuImportSession> getMenuImport(String id) async {
    final response = await _client.dio.get('/api/menu-import/$id');
    final data = response.data['data'];
    final session = data is Map && data['session'] != null ? data['session'] : data;
    return MenuImportSession.fromJson(session as Map<String, dynamic>);
  }

  Future<MenuImportSession> getMenuImportPreview(String id, {String? filter}) async {
    final response = await _client.dio.get(
      '/api/menu-import/$id/preview',
      queryParameters: filter != null ? {'filter': filter} : null,
    );
    final data = response.data['data'];
    final session = data is Map && data['session'] != null ? data['session'] : data;
    return MenuImportSession.fromJson(session as Map<String, dynamic>);
  }

  Future<MenuImportSession> updateMenuImportItem(
    String sessionId,
    String itemId,
    Map<String, dynamic> patch,
  ) async {
    final response = await _client.dio.patch(
      '/api/menu-import/$sessionId/items/$itemId',
      data: patch,
    );
    final data = response.data['data'];
    final session = data is Map && data['session'] != null ? data['session'] : data;
    return MenuImportSession.fromJson(session as Map<String, dynamic>);
  }

  Future<Map<String, dynamic>> commitMenuImport(String id) async {
    final response = await _client.dio.post('/api/menu-import/$id/commit');
    final data = response.data['data'];
    return data is Map<String, dynamic> ? data : {'session': data};
  }

  Future<List<MenuImportSession>> listMenuImportHistory() async {
    final response = await _client.dio.get('/api/menu-import/history');
    final data = response.data['data'];
    final list = (data is Map ? data['history'] : data) as List<dynamic>? ?? [];
    return list
        .map((e) => MenuImportSession.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<Map<String, dynamic>> getAiExtractionStatus({bool probe = true}) async {
    final response = await _client.dio.get(
      '/api/settings/ai-status',
      queryParameters: probe ? {'probe': '1'} : null,
    );
    final data = response.data['data'];
    return data is Map<String, dynamic> ? data : {};
  }


  Future<MenuImportSession> bulkUpdateMenuImport(
    String sessionId,
    List<String> itemIds,
    Map<String, dynamic> patch,
  ) async {
    final response = await _client.dio.post(
      '/api/menu-import/$sessionId/bulk',
      data: {'itemIds': itemIds, 'patch': patch},
    );
    final data = response.data['data'];
    final session = data is Map && data['session'] != null ? data['session'] : data;
    return MenuImportSession.fromJson(session as Map<String, dynamic>);
  }

  Future<MenuImportSession> deleteMenuImportItems(
    String sessionId,
    List<String> itemIds,
  ) async {
    final response = await _client.dio.post(
      '/api/menu-import/$sessionId/bulk',
      data: {'itemIds': itemIds, 'action': 'delete'},
    );
    final data = response.data['data'];
    final session = data is Map && data['session'] != null ? data['session'] : data;
    return MenuImportSession.fromJson(session as Map<String, dynamic>);
  }

  Future<Map<String, dynamic>> deleteMenuImport(
    String id, {
    bool deleteItems = true,
  }) async {
    final response = await _client.dio.delete(
      '/api/menu-import/$id',
      queryParameters: {'deleteItems': deleteItems ? '1' : '0'},
    );
    final data = response.data['data'] ?? response.data;
    return data is Map<String, dynamic> ? data : {};
  }

  Future<Order> updateOrder(String orderId, Map<String, dynamic> body) async {
    final response = await _client.dio.patch('/api/orders/$orderId', data: body);
    final data = response.data['data'] ?? response.data;
    final order = data is Map && data['order'] != null ? data['order'] : data;
    return Order.fromJson(order as Map<String, dynamic>);
  }

  Future<void> deleteMenuImportItem(String sessionId, String itemId) async {
    await _client.dio.delete('/api/menu-import/$sessionId/items/$itemId');
  }


  // ─── Notification Preferences ──────────────────────────────

  Future<NotificationPreferences?> getNotificationPreferences() async {
    try {
      final response = await _client.dio.get('/api/settings/notification-preferences');
      final data = response.data['data'] ?? response.data;
      if (data is Map<String, dynamic>) {
        return NotificationPreferences.fromJson(data);
      }
      return null;
    } catch (_) {
      // Fallback endpoint
      try {
        final response = await _client.dio.get('/api/users/me/notification-preferences');
        final data = response.data['data'] ?? response.data;
        if (data is Map<String, dynamic>) {
          return NotificationPreferences.fromJson(data);
        }
      } catch (_) {}
      return null;
    }
  }

  Future<void> updateNotificationPreferences(NotificationPreferences prefs) async {
    try {
      await _client.dio.put(
        '/api/settings/notification-preferences',
        data: prefs.toJson(),
      );
    } catch (_) {
      try {
        await _client.dio.patch(
          '/api/users/me/notification-preferences',
          data: prefs.toJson(),
        );
      } catch (_) {
        // Local-only when backend has no preference endpoint
      }
    }
  }

}
