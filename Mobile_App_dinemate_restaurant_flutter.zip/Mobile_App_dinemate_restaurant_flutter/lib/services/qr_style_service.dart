import 'package:shared_preferences/shared_preferences.dart';
import 'package:dinemate_restaurant/models/qr_style.dart';

class QrStyleService {
  static const _key = 'dinemate_qr_style';

  Future<QrStyleConfig> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return QrStyleConfig.defaults;
    return QrStyleConfig.decode(raw);
  }

  Future<void> save(QrStyleConfig style) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, style.encode());
  }
}
