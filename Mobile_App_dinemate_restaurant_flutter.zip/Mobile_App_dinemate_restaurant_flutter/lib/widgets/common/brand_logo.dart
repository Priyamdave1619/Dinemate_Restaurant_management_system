import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';

/// Official DineMate brand assets
/// Light mode → gold mark
/// Dark mode  → navy/blue mark
class BrandLogo extends StatelessWidget {
  final BrandLogoSize size;
  final bool showName;
  final bool showTagline;
  final String? companyName;
  final String? tagline;
  final bool iconOnly;

  const BrandLogo({
    super.key,
    this.size = BrandLogoSize.md,
    this.showName = false,
    this.showTagline = false,
    this.companyName,
    this.tagline,
    this.iconOnly = false,
  });

  /// Login / splash large logo (image only)
  const BrandLogo.login({super.key})
      : size = BrandLogoSize.xl,
        showName = false,
        showTagline = false,
        companyName = null,
        tagline = null,
        iconOnly = true;

  /// App bar / compact
  const BrandLogo.header({super.key})
      : size = BrandLogoSize.sm,
        showName = true,
        showTagline = false,
        companyName = 'Dinemate',
        tagline = null,
        iconOnly = false;

  /// Icon only (sidebar collapsed style)
  const BrandLogo.icon({super.key})
      : size = BrandLogoSize.md,
        showName = false,
        showTagline = false,
        companyName = null,
        tagline = null,
        iconOnly = true;

  double get _imgSize {
    switch (size) {
      case BrandLogoSize.xs:
        return 28;
      case BrandLogoSize.sm:
        return 36;
      case BrandLogoSize.md:
        return 48;
      case BrandLogoSize.lg:
        return 72;
      case BrandLogoSize.xl:
        return 100;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    // Light → gold, Dark → blue (matches original web branding)
    final asset = isDark
        ? 'assets/logos/logo-blue.png'
        : 'assets/logos/logo-gold.png';

    final image = Image.asset(
      asset,
      width: _imgSize,
      height: _imgSize,
      fit: BoxFit.contain,
      errorBuilder: (_, __, ___) => Icon(
        Icons.restaurant_menu_rounded,
        size: _imgSize * 0.7,
        color: isDark ? AppColors.primaryLight : AppColors.primary,
      ),
    );

    if (iconOnly || (!showName && !showTagline)) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: image,
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: image,
        ),
        if (showName) ...[
          const SizedBox(height: 12),
          Text(
            companyName ?? 'Dinemate',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
              color: isDark ? AppColors.primaryLight : AppColors.primary,
            ),
          ),
        ],
        if (showTagline && tagline != null) ...[
          const SizedBox(height: 4),
          Text(
            tagline!,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.6),
            ),
          ),
        ],
      ],
    );
  }
}

enum BrandLogoSize { xs, sm, md, lg, xl }