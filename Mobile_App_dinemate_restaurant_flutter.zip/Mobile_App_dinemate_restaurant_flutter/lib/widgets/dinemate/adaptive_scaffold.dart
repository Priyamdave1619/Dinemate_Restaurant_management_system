import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';
import 'package:dinemate_restaurant/core/responsive/dinemate_breakpoints.dart';
import 'package:dinemate_restaurant/core/responsive/dinemate_responsive.dart';
import 'package:dinemate_restaurant/widgets/common/brand_logo.dart';

class AdaptiveNavItem {
  final IconData icon;
  final IconData selectedIcon;
  final String label;

  const AdaptiveNavItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
  });
}

/// Adaptive shell:
/// - compact  → modern floating bottom navigation
/// - medium   → navigation rail
/// - expanded → persistent sidebar
class DinemateAdaptiveScaffold extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;
  final List<AdaptiveNavItem> destinations;
  final List<Widget> pages;
  final String? title;
  final Widget? trailing;

  const DinemateAdaptiveScaffold({
    super.key,
    required this.selectedIndex,
    required this.onDestinationSelected,
    required this.destinations,
    required this.pages,
    this.title,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return DinemateResponsiveBuilder(
      builder: (context, layout, constraints) {
        final isDark = Theme.of(context).brightness == Brightness.dark;

        switch (layout) {
          case DinemateLayout.compact:
            return _CompactShell(
              selectedIndex: selectedIndex,
              onDestinationSelected: onDestinationSelected,
              destinations: destinations,
              pages: pages,
              isDark: isDark,
            );
          case DinemateLayout.medium:
            return _RailShell(
              selectedIndex: selectedIndex,
              onDestinationSelected: onDestinationSelected,
              destinations: destinations,
              pages: pages,
              isDark: isDark,
              extended: false,
            );
          case DinemateLayout.expanded:
          case DinemateLayout.large:
            return _RailShell(
              selectedIndex: selectedIndex,
              onDestinationSelected: onDestinationSelected,
              destinations: destinations,
              pages: pages,
              isDark: isDark,
              extended: true,
              maxContent: layout == DinemateLayout.large,
            );
        }
      },
    );
  }
}

// ─── Mobile: modern bottom nav ───────────────────────────────────────────────

class _CompactShell extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;
  final List<AdaptiveNavItem> destinations;
  final List<Widget> pages;
  final bool isDark;

  const _CompactShell({
    required this.selectedIndex,
    required this.onDestinationSelected,
    required this.destinations,
    required this.pages,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.paddingOf(context).bottom;

    return Scaffold(
      // Let body extend under nav; pages pad themselves via FAB margin
      extendBody: false, // keep body above bar so FABs stay visible
      body: IndexedStack(index: selectedIndex, children: pages),
      bottomNavigationBar: _ModernBottomBar(
        selectedIndex: selectedIndex,
        destinations: destinations,
        isDark: isDark,
        bottomInset: bottomInset,
        onSelect: (i) {
          if (i != selectedIndex) {
            HapticFeedback.selectionClick();
            onDestinationSelected(i);
          }
        },
      ),
    );
  }
}

class _ModernBottomBar extends StatelessWidget {
  final int selectedIndex;
  final List<AdaptiveNavItem> destinations;
  final bool isDark;
  final double bottomInset;
  final ValueChanged<int> onSelect;

  const _ModernBottomBar({
    required this.selectedIndex,
    required this.destinations,
    required this.isDark,
    required this.bottomInset,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final barColor = isDark ? AppColors.darkSurface : AppColors.surface;
    final borderColor =
        isDark ? AppColors.darkBorder : AppColors.border.withValues(alpha: 0.7);

    return Container(
      decoration: BoxDecoration(
        color: barColor,
        border: Border(top: BorderSide(color: borderColor, width: 0.8)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withValues(alpha: isDark ? 0.12 : 0.06),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        minimum: EdgeInsets.only(bottom: bottomInset > 0 ? 0 : 6),
        child: SizedBox(
          height: 64,
          child: Row(
            children: [
              for (var i = 0; i < destinations.length; i++)
                Expanded(
                  child: _NavTab(
                    item: destinations[i],
                    selected: selectedIndex == i,
                    isDark: isDark,
                    onTap: () => onSelect(i),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavTab extends StatelessWidget {
  final AdaptiveNavItem item;
  final bool selected;
  final bool isDark;
  final VoidCallback onTap;

  const _NavTab({
    required this.item,
    required this.selected,
    required this.isDark,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final active = isDark ? AppColors.primaryLight : AppColors.primary;
    final inactive = isDark ? AppColors.darkTextMuted : AppColors.textMuted;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        splashColor: active.withValues(alpha: 0.08),
        highlightColor: active.withValues(alpha: 0.04),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Indicator pill behind icon
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutCubic,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              decoration: BoxDecoration(
                color: selected
                    ? active.withValues(alpha: isDark ? 0.22 : 0.12)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(
                selected ? item.selectedIcon : item.icon,
                size: 22,
                color: selected ? active : inactive,
              ),
            ),
            const SizedBox(height: 3),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 200),
              style: TextStyle(
                fontSize: 11,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                color: selected ? active : inactive,
                height: 1.1,
              ),
              child: Text(
                item.label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Tablet / Desktop rail ───────────────────────────────────────────────────

class _RailShell extends StatelessWidget {
  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;
  final List<AdaptiveNavItem> destinations;
  final List<Widget> pages;
  final bool isDark;
  final bool extended;
  final bool maxContent;

  const _RailShell({
    required this.selectedIndex,
    required this.onDestinationSelected,
    required this.destinations,
    required this.pages,
    required this.isDark,
    required this.extended,
    this.maxContent = false,
  });

  @override
  Widget build(BuildContext context) {
    final body = IndexedStack(index: selectedIndex, children: pages);
    final railBg = isDark ? const Color(0xFF0F1C2E) : Colors.white;
    final borderColor = isDark ? AppColors.darkBorder : AppColors.border;

    return Scaffold(
      body: Row(
        children: [
          AnimatedContainer(
            duration: DinemateAnimations.normal,
            width: extended ? 228 : 84,
            decoration: BoxDecoration(
              color: railBg,
              border: Border(right: BorderSide(color: borderColor)),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primary.withValues(alpha: 0.04),
                  blurRadius: 12,
                  offset: const Offset(2, 0),
                ),
              ],
            ),
            child: SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: EdgeInsets.fromLTRB(
                      extended ? 18 : 14,
                      20,
                      extended ? 18 : 14,
                      16,
                    ),
                    child: extended
                        ? Row(
                            children: [
                              _BrandMark(),
                              const SizedBox(width: 12),
                              const Expanded(
                                child: Text(
                                  'Dinemate',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 18,
                                    color: AppColors.primary,
                                    letterSpacing: -0.3,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          )
                        : const Center(child: _BrandMark()),
                  ),
                  Expanded(
                    child: NavigationRail(
              leading: const Padding(
                padding: EdgeInsets.only(top: 12, bottom: 8),
                child: BrandLogo.icon(),
              ),
                      extended: extended,
                      backgroundColor: Colors.transparent,
                      selectedIndex: selectedIndex,
                      onDestinationSelected: (i) {
                        HapticFeedback.selectionClick();
                        onDestinationSelected(i);
                      },
                      minWidth: 72,
                      minExtendedWidth: 220,
                      groupAlignment: -0.85,
                      labelType: extended
                          ? NavigationRailLabelType.none
                          : NavigationRailLabelType.all,
                      indicatorColor: AppColors.navyTint,
                      selectedIconTheme: const IconThemeData(
                        color: AppColors.primary,
                        size: 22,
                      ),
                      unselectedIconTheme: IconThemeData(
                        color: isDark
                            ? const Color(0xFF8B9BB4)
                            : AppColors.textMuted,
                        size: 22,
                      ),
                      selectedLabelTextStyle: const TextStyle(
                        color: AppColors.primary,
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                      ),
                      unselectedLabelTextStyle: TextStyle(
                        color: isDark
                            ? const Color(0xFF8B9BB4)
                            : AppColors.textMuted,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                      destinations: [
                        for (final d in destinations)
                          NavigationRailDestination(
                            icon: Icon(d.icon),
                            selectedIcon: Icon(d.selectedIcon),
                            label: Text(d.label),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: maxContent
                ? DinemateConstrainedContent(child: body)
                : body,
          ),
        ],
      ),
    );
  }
}

class _BrandMark extends StatelessWidget {
  const _BrandMark();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primary, AppColors.premiumNavy],
        ),
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.withValues(alpha: 0.25),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: const Icon(
        Icons.restaurant_menu_rounded,
        color: Colors.white,
        size: 20,
      ),
    );
  }
}
