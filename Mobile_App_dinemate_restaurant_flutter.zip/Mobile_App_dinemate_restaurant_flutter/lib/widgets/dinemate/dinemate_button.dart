import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';

enum DinemateButtonVariant { primary, secondary, tertiary, destructive, soft }

class DinemateButton extends StatefulWidget {
  final String label;
  final VoidCallback? onPressed;
  final DinemateButtonVariant variant;
  final bool loading;
  final bool expanded;
  final IconData? icon;
  final double? height;

  const DinemateButton({
    super.key,
    required this.label,
    this.onPressed,
    this.variant = DinemateButtonVariant.primary,
    this.loading = false,
    this.expanded = true,
    this.icon,
    this.height,
  });

  @override
  State<DinemateButton> createState() => _DinemateButtonState();
}

class _DinemateButtonState extends State<DinemateButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onPressed != null && !widget.loading;
    final h = widget.height ?? 52.0;

    Color bg;
    Color fg;
    BorderSide? border;

    switch (widget.variant) {
      case DinemateButtonVariant.primary:
        bg = AppColors.primary;
        fg = Colors.white;
        break;
      case DinemateButtonVariant.secondary:
        bg = Colors.transparent;
        fg = AppColors.primary;
        border = const BorderSide(color: AppColors.primary, width: 1.5);
        break;
      case DinemateButtonVariant.tertiary:
        bg = Colors.transparent;
        fg = AppColors.primary;
        break;
      case DinemateButtonVariant.destructive:
        bg = AppColors.error;
        fg = Colors.white;
        break;
      case DinemateButtonVariant.soft:
        bg = AppColors.navyTint;
        fg = AppColors.primary;
        break;
    }

    if (!enabled) {
      bg = bg.withValues(alpha: 0.45);
      fg = fg.withValues(alpha: 0.7);
    }

    final child = widget.loading
        ? SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(
              strokeWidth: 2.4,
              valueColor: AlwaysStoppedAnimation(fg),
            ),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (widget.icon != null) ...[
                Icon(widget.icon, size: 20, color: fg),
                const SizedBox(width: 8),
              ],
              Text(
                widget.label,
                style: DinemateTypography.button(context).copyWith(color: fg),
              ),
            ],
          );

    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onTapUp: enabled
          ? (_) {
              setState(() => _pressed = false);
              widget.onPressed?.call();
            }
          : null,
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.97 : 1.0,
        duration: DinemateAnimations.fast,
        curve: Curves.easeOut,
        child: AnimatedContainer(
          duration: DinemateAnimations.fast,
          height: h,
          width: widget.expanded ? double.infinity : null,
          padding: EdgeInsets.symmetric(
            horizontal: widget.expanded ? 24 : 20,
          ),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: DinemateRadius.button,
            border: border != null ? Border.fromBorderSide(border) : null,
            boxShadow: widget.variant == DinemateButtonVariant.primary && enabled
                ? [
                    BoxShadow(
                      color: AppColors.primary.withValues(alpha: 0.25),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ]
                : null,
          ),
          alignment: Alignment.center,
          child: child,
        ),
      ),
    );
  }
}
