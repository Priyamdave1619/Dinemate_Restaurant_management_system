import 'package:flutter/material.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/core/theme/dinemate_tokens.dart';

class DinemateCard extends StatefulWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final VoidCallback? onTap;
  final Color? color;
  final bool elevated;

  const DinemateCard({
    super.key,
    required this.child,
    this.padding,
    this.margin,
    this.onTap,
    this.color,
    this.elevated = false,
  });

  @override
  State<DinemateCard> createState() => _DinemateCardState();
}

class _DinemateCardState extends State<DinemateCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bg = widget.color ?? (isDark ? AppColors.darkCard : AppColors.surface);
    final borderColor = isDark ? AppColors.darkBorder : AppColors.border;

    return GestureDetector(
      onTapDown: widget.onTap != null ? (_) => setState(() => _pressed = true) : null,
      onTapUp: widget.onTap != null
          ? (_) {
              setState(() => _pressed = false);
              widget.onTap?.call();
            }
          : null,
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.985 : 1.0,
        duration: DinemateAnimations.fast,
        curve: Curves.easeOut,
        child: AnimatedContainer(
          duration: DinemateAnimations.fast,
          margin: widget.margin ??
              const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          padding: widget.padding ?? const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: DinemateRadius.card,
            border: Border.all(color: borderColor, width: 1),
            boxShadow: widget.elevated ? DinemateShadows.medium : DinemateShadows.soft,
          ),
          child: widget.child,
        ),
      ),
    );
  }
}

/// Metric / KPI card used on dashboard
class DinemateMetricCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color? accent;
  final String? subtitle;

  const DinemateMetricCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    this.accent,
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final color = accent ?? AppColors.primary;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return DinemateCard(
      elevated: true,
      padding: const EdgeInsets.all(16),
      margin: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: isDark ? 0.2 : 0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, size: 18, color: color),
              ),
              const Spacer(),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            value,
            style: DinemateTypography.pageTitle(context).copyWith(
              color: isDark ? AppColors.darkTextPrimary : AppColors.textPrimary,
              fontSize: 22,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: DinemateTypography.caption(context).copyWith(
              color: AppColors.textSecondary,
            ),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 2),
            Text(
              subtitle!,
              style: DinemateTypography.overline(context).copyWith(
                color: color,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
