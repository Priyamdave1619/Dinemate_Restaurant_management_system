import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

final themeModeProvider = StateNotifierProvider<ThemeModeNotifier, ThemeMode>((ref) {
  return ThemeModeNotifier();
});

class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  static const _key = 'dinemate_theme_mode';

  /// In-memory cache so subsequent reads (and hot restarts within the same
  /// process) do not flash the wrong theme while SharedPreferences loads.
  static ThemeMode? _cached;

  ThemeModeNotifier() : super(_cached ?? _systemMode()) {
    if (_cached == null) {
      _load();
    }
  }

  static ThemeMode _systemMode() {
    final brightness =
        SchedulerBinding.instance.platformDispatcher.platformBrightness;
    return brightness == Brightness.dark ? ThemeMode.dark : ThemeMode.light;
  }

  Future<void> _load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final value = prefs.getString(_key);
      ThemeMode mode;
      if (value == 'light') {
        mode = ThemeMode.light;
      } else if (value == 'dark') {
        mode = ThemeMode.dark;
      } else {
        mode = ThemeMode.system;
      }
      _cached = mode;
      if (state != mode) {
        state = mode;
      }
    } catch (_) {
      // Keep current state on storage failure
    }
  }

  Future<void> setMode(ThemeMode mode) async {
    // Apply immediately — UI must not wait on disk I/O for the visual change.
    state = mode;
    _cached = mode;
    try {
      final prefs = await SharedPreferences.getInstance();
      final value = mode == ThemeMode.light
          ? 'light'
          : mode == ThemeMode.dark
              ? 'dark'
              : 'system';
      await prefs.setString(_key, value);
    } catch (_) {
      // Preference persistence failure must not undo the in-session choice
    }
  }

  Future<void> toggle() async {
    // Resolve "system" to the concrete brightness so toggle always flips.
    final effective = state == ThemeMode.system
        ? _systemMode()
        : state;
    if (effective == ThemeMode.dark) {
      await setMode(ThemeMode.light);
    } else {
      await setMode(ThemeMode.dark);
    }
  }
}
