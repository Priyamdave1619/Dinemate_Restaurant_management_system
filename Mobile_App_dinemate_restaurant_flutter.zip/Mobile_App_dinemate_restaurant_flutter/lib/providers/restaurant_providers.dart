import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/utils/provider_cache.dart';
import 'package:dinemate_restaurant/models/expense.dart';
import 'package:dinemate_restaurant/models/menu_item.dart';
import 'package:dinemate_restaurant/models/offer.dart';
import 'package:dinemate_restaurant/models/order.dart';
import 'package:dinemate_restaurant/models/restaurant_table.dart';
import 'package:dinemate_restaurant/models/settings.dart';
import 'package:dinemate_restaurant/models/staff_user.dart';
import 'package:dinemate_restaurant/services/restaurant_service.dart';

final restaurantServiceProvider = Provider((ref) => RestaurantService());

// Data that changes often (orders, tables, dashboard stats) is cached
// briefly so quick navigation feels instant but the screen still catches
// up soon after. Data that rarely changes (menu, categories, staff,
// settings) is cached longer. Pull-to-refresh / ref.invalidate(...) still
// force an immediate refetch everywhere, exactly as before.
const _shortCache = Duration(minutes: 2);
const _longCache = Duration(minutes: 10);

// ─── Orders ─────────────────────────────────────────────────

final activeOrdersProvider = FutureProvider.autoDispose<List<Order>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getOrders(status: 'active');
});

final orderHistoryProvider = FutureProvider.autoDispose<List<Order>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getOrders();
});

// ─── Menu ───────────────────────────────────────────────────

final menuItemsProvider = FutureProvider.autoDispose<List<MenuItem>>((ref) async {
  cacheFor(ref, _longCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getMenuItems();
});

final categoriesProvider = FutureProvider.autoDispose<List<MenuCategory>>((ref) async {
  cacheFor(ref, _longCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getCategories();
});

// ─── Tables ─────────────────────────────────────────────────

final tablesProvider = FutureProvider.autoDispose<List<RestaurantTable>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getTables();
});

// ─── Dashboard ──────────────────────────────────────────────

final dashboardStatsProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getDashboardStats();
});

// ─── Staff ──────────────────────────────────────────────────

final staffProvider = FutureProvider.autoDispose<List<StaffUser>>((ref) async {
  cacheFor(ref, _longCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getStaff();
});

// ─── Finance ────────────────────────────────────────────────

final expensesProvider = FutureProvider.autoDispose<List<Expense>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getExpenses();
});

final pnlProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getPnl(period: 'month');
});

// ─── Offers ─────────────────────────────────────────────────

final offersProvider = FutureProvider.autoDispose<List<Offer>>((ref) async {
  cacheFor(ref, _longCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getOffers();
});

// ─── Notifications ──────────────────────────────────────────

final notificationsProvider = FutureProvider.autoDispose<List<AppNotification>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getNotifications();
});

final unreadNotificationsCountProvider = FutureProvider.autoDispose<int>((ref) async {
  cacheFor(ref, _shortCache);
  final list = await ref.watch(notificationsProvider.future);
  return list.where((n) => !n.read).length;
});

// ─── Activity ───────────────────────────────────────────────

final activityLogsProvider = FutureProvider.autoDispose<List<ActivityLog>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getActivityLogs();
});

// ─── Settings ───────────────────────────────────────────────

final settingsProvider = FutureProvider.autoDispose<RestaurantSettings>((ref) async {
  cacheFor(ref, _longCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getSettings();
});

// ─── Reports ────────────────────────────────────────────────


final weeklyReportProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getWeeklyReport();
});

final yearlyReportProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getYearlyReport();
});

final itemsReportProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getItemsReport();
});

final dailyReportProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getDailyReport();
});

final monthlyReportProvider = FutureProvider.autoDispose<Map<String, dynamic>>((ref) async {
  cacheFor(ref, _shortCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getMonthlyReport();
});

// ─── Subscription ───────────────────────────────────────────

final plansProvider = FutureProvider.autoDispose<List<Plan>>((ref) async {
  cacheFor(ref, _longCache);
  final service = ref.watch(restaurantServiceProvider);
  return service.getPlans();
});
