import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dinemate_restaurant/models/notification_preferences.dart';
import 'package:dinemate_restaurant/providers/auth_provider.dart';
import 'package:dinemate_restaurant/providers/restaurant_providers.dart';
import 'package:dinemate_restaurant/services/local_notification_service.dart';

const _prefsKeyPrefix = 'dinemate_notif_prefs_';

/// Central notification preference state (per user).
final notificationPreferencesProvider =
    AsyncNotifierProvider<NotificationPreferencesNotifier, NotificationPreferences>(
  NotificationPreferencesNotifier.new,
);

class NotificationPreferencesNotifier
    extends AsyncNotifier<NotificationPreferences> {
  String? _userKey;

  @override
  Future<NotificationPreferences> build() async {
    final user = ref.watch(authProvider).valueOrNull;
    final uid = user?.id ?? 'guest';
    _userKey = '$_prefsKeyPrefix$uid';

    // Local first
    final local = await _loadLocal(_userKey!);

    // Try backend sync (non-blocking failure)
    try {
      final remote = await ref
          .read(restaurantServiceProvider)
          .getNotificationPreferences();
      if (remote != null) {
        await _saveLocal(_userKey!, remote);
        LocalNotificationService.instance.updatePreferences(remote);
        return remote;
      }
    } catch (e) {
      debugPrint('Notif prefs: backend load skipped: $e');
    }

    LocalNotificationService.instance.updatePreferences(local);
    return local;
  }

  Future<NotificationPreferences> _loadLocal(String key) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null || raw.isEmpty) return NotificationPreferences.defaults;
    return NotificationPreferences.decode(raw);
  }

  Future<void> _saveLocal(String key, NotificationPreferences value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, value.encode());
  }

  Future<void> setEnabled(bool enabled) =>
      _update(state.valueOrNull?.copyWith(enabled: enabled) ??
          NotificationPreferences(enabled: enabled));

  Future<void> setOrderUpdates(bool v) =>
      _update((state.valueOrNull ?? NotificationPreferences.defaults)
          .copyWith(orderUpdates: v));

  Future<void> setRestaurantUpdates(bool v) =>
      _update((state.valueOrNull ?? NotificationPreferences.defaults)
          .copyWith(restaurantUpdates: v));

  Future<void> setPromotions(bool v) =>
      _update((state.valueOrNull ?? NotificationPreferences.defaults)
          .copyWith(promotions: v));

  Future<void> setSystemAlerts(bool v) =>
      _update((state.valueOrNull ?? NotificationPreferences.defaults)
          .copyWith(systemAlerts: v));

  Future<void> _update(NotificationPreferences next) async {
    // Optimistic UI (previous kept only if we choose to rollback on API failure)
    state = AsyncData(next);
    LocalNotificationService.instance.updatePreferences(next);

    final key = _userKey ?? '$_prefsKeyPrefix${ref.read(authProvider).valueOrNull?.id ?? 'guest'}';
    await _saveLocal(key, next);

    try {
      await ref
          .read(restaurantServiceProvider)
          .updateNotificationPreferences(next);
    } catch (e) {
      debugPrint('Notif prefs: backend save failed: $e');
      // Keep local preference — offline-friendly. Don't rollback unless desired.
      // Optional: rollback on hard API failure:
      // state = AsyncData(previous);
      // await _saveLocal(key, previous);
      // rethrow;
    }
  }

  /// Clear user-specific prefs from memory on logout (storage kept for next login).
  void clearMemory() {
    state = const AsyncData(NotificationPreferences.defaults);
  }
}
