import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/api/api_client.dart';
import 'package:dinemate_restaurant/core/constants/app_constants.dart';
import 'package:dinemate_restaurant/models/user.dart';
import 'package:dinemate_restaurant/services/auth_service.dart';
import 'package:dinemate_restaurant/providers/notification_preferences_provider.dart';

final authServiceProvider = Provider((ref) => AuthService());

/// Single source of truth for session. Restores from durable storage on start
/// so force-killing the app does not drop a valid login.
final authProvider = AsyncNotifierProvider<AuthNotifier, User?>(() {
  return AuthNotifier();
});

class AuthNotifier extends AsyncNotifier<User?> {
  final _authService = AuthService();
  final _client = apiClient;

  @override
  Future<User?> build() async {
    _client.onSessionInvalid ??= () {
      state = const AsyncData(null);
    };
    return _restoreSession();
  }

  Future<User?> _restoreSession() async {
    try {
      final token = await _client.getAccessToken();
      if (token == null || token.isEmpty) {
        debugPrint('Auth: no stored token');
        return null;
      }

      debugPrint('Auth: token found — restoring session');

      final userJson = await _client.readKey(AppConstants.keyUser);
      User? cached;
      if (userJson != null && userJson.isNotEmpty) {
        try {
          cached = User.fromJson(jsonDecode(userJson) as Map<String, dynamic>);
        } catch (e) {
          debugPrint('Auth: cached user parse failed: $e');
        }
      }

      if (cached != null) {
        // Only eject when we are certain the role is a blocked waiter.
        // Unknown/empty roles with a valid token are kept so a bad parse
        // never silently logs an owner out after app kill.
        if (cached.isWaiter || User.isWaiterRole(cached.role)) {
          debugPrint('Auth: blocked waiter session (role=${cached.role})');
          await _client.clearTokens();
          return null;
        }
        unawaited(_refreshProfileInBackground());
        return cached;
      }

      // Token exists but no profile cache — try /me once.
      try {
        final fresh = await _authService.getCurrentUser();
        if (fresh != null) {
          if (fresh.isWaiter || User.isWaiterRole(fresh.role)) {
            debugPrint('Auth: blocked waiter /me (role=${fresh.role})');
            await _client.clearTokens();
            return null;
          }
          if (!User.isRestaurantPortalRole(fresh.role) &&
              fresh.role != 'super_admin') {
            // Keep session if role is owner/manager; otherwise only drop
            // clearly disallowed roles after we know them.
            if (fresh.role.isNotEmpty &&
                !User.isRestaurantPortalRole(fresh.role)) {
              await _client.clearTokens();
              return null;
            }
          }
          await _persistUser(fresh);
          return fresh;
        }
      } catch (e) {
        debugPrint('Auth: /me failed with token present: $e');
      }

      // CRITICAL: token is still valid storage-wise. Do NOT clear it when
      // offline. Return a minimal placeholder so splash keeps the user in.
      // Background refresh will repair the profile when network returns.
      debugPrint('Auth: keeping token-only session (offline / no profile yet)');
      return const User(
        id: 'session',
        username: 'session',
        role: 'owner',
        active: true,
      );
    } catch (e) {
      debugPrint('Auth: restore error (keeping attempt): $e');
      // Last resort: if a token still exists, do not force login screen.
      try {
        if (await _client.hasStoredSession()) {
          return const User(
            id: 'session',
            username: 'session',
            role: 'owner',
            active: true,
          );
        }
      } catch (_) {}
      return null;
    }
  }

  Future<void> _refreshProfileInBackground() async {
    try {
      final fresh = await _authService.getCurrentUser();
      if (fresh != null) {
        if (fresh.isWaiter || User.isWaiterRole(fresh.role)) {
          await _client.clearTokens();
          state = const AsyncData(null);
          return;
        }
        await _persistUser(fresh);
        if (state.valueOrNull != null) {
          state = AsyncData(fresh);
        }
      }
    } catch (e) {
      debugPrint('Auth: background profile refresh failed (keeping cache): $e');
    }
  }

  Future<void> _persistUser(User user) async {
    await _client.writeKey(
      AppConstants.keyUser,
      jsonEncode(user.toJson()),
    );
    if (user.restaurantId != null && user.restaurantId!.isNotEmpty) {
      await _client.writeKey(
        AppConstants.keyRestaurantId,
        user.restaurantId!,
      );
    }
  }

  Future<void> login(String username, String password) async {
    state = const AsyncLoading();
    try {
      final result = await _authService.login(
        username: username,
        password: password,
      );
      await _persistUser(result.user);
      // Ensure tokens are flushed (AuthService already saves them)
      state = AsyncData(result.user);
      debugPrint('Auth: login success role=${result.user.role}');
    } catch (e, st) {
      state = AsyncError(e, st);
      rethrow;
    }
  }

  Future<void> logout() async {
    debugPrint('Auth: explicit logout');
    try {
      await _authService.logout();
    } catch (_) {}
    await _client.clearTokens();
    try {
      ref.read(notificationPreferencesProvider.notifier).clearMemory();
    } catch (_) {}
    state = const AsyncData(null);
  }

  User? get currentUser => state.valueOrNull;

  bool get isAuthenticated => currentUser != null;

  Future<void> rehydrate() async {
    final user = await _restoreSession();
    state = AsyncData(user);
  }
}
