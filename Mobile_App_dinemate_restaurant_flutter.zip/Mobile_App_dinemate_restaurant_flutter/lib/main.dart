import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dinemate_restaurant/core/theme/app_theme.dart';
import 'package:dinemate_restaurant/models/user.dart';
import 'package:dinemate_restaurant/providers/auth_provider.dart';
import 'package:dinemate_restaurant/providers/theme_provider.dart';
import 'package:dinemate_restaurant/screens/auth/login_screen.dart';
import 'package:dinemate_restaurant/screens/splash/splash_screen.dart';
import 'package:dinemate_restaurant/services/local_notification_service.dart';

/// App-wide navigator so session-expiry can redirect without a BuildContext.
final navigatorKey = GlobalKey<NavigatorState>();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations(DeviceOrientation.values);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
  ));
  try {
    // ignore: unawaited_futures
    LocalNotificationService.instance.init();
  } catch (_) {}
  runApp(const ProviderScope(child: DinemateApp()));
}

class DinemateApp extends ConsumerStatefulWidget {
  const DinemateApp({super.key});

  @override
  ConsumerState<DinemateApp> createState() => _DinemateAppState();
}

class _DinemateAppState extends ConsumerState<DinemateApp> {
  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(themeModeProvider);

    // Schedule navigation AFTER the current frame so we never dispose
    // InheritedWidgets (Theme / Provider) while dependents still attach.
    // That was the root of: Failed assertion: '_dependents.isEmpty'.
    ref.listen<AsyncValue<User?>>(authProvider, (previous, next) {
      final wasSignedIn = previous?.valueOrNull != null;
      final isSignedOutNow = next is! AsyncLoading && next.valueOrNull == null;
      if (!wasSignedIn || !isSignedOutNow) return;

      WidgetsBinding.instance.addPostFrameCallback((_) {
        final nav = navigatorKey.currentState;
        if (nav == null || !nav.mounted) return;
        nav.pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginScreen()),
          (_) => false,
        );
      });
    });

    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'Dinemate',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: themeMode,
      // Do NOT wrap with AnimatedTheme(Theme.of(context)) here — that
      // creates a Theme dependency cycle during mode switches and can
      // trigger the _dependents.isEmpty crash on dispose.
      home: const SplashScreen(),
    );
  }
}
