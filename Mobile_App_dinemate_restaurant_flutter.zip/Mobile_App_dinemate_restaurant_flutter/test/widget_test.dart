// Basic Flutter widget smoke test for Dinemate.

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:dinemate_restaurant/main.dart';

void main() {
  testWidgets('App builds smoke test', (WidgetTester tester) async {
    // ProviderScope is required because the app uses Riverpod
    await tester.pumpWidget(
      const ProviderScope(
        child: DinemateApp(),
      ),
    );

    // Pump a few frames — avoid pumpAndSettle (splash has ongoing animations/timers)
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 100));

    // App should build a MaterialApp (starts on SplashScreen)
    expect(find.byType(MaterialApp), findsOneWidget);
    expect(find.text('Dinemate'), findsWidgets);
  });
}
